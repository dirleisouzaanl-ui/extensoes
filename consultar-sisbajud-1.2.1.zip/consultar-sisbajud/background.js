// Coordena as guias: lista de ordens (origem) → guia nova da ordem (destino) → volta à lista.
const KEY = 'sb_fila';
const get = () => chrome.storage.local.get(KEY).then((o) => o[KEY] || null);
const set = (v) => chrome.storage.local.set({ [KEY]: v });

// Guia aberta por "Abrir em nova guia": vira a guia de trabalho e recebe o foco
chrome.tabs.onCreated.addListener(async (tab) => {
  const f = await get();
  if (!f || !f.ativo || f.etapa !== 'abrindo') return;
  const recente = Date.now() - (f.abrindoEm || 0) < 20000;
  if (tab.openerTabId === f.listaTabId || recente) {
    f.etapa = 'detalhe';
    f.detalheTabId = tab.id;
    f.serieClicada = false;
    f.exportado = false;
    f.impresso = false;
    await set(f);
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId) chrome.windows.update(tab.windowId, { focused: true });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, resp) => {
  (async () => {
    if (msg.tipo === 'meu-id') return resp({ tabId: sender.tab ? sender.tab.id : null });
    if (msg.tipo === 'voltar-lista') {
      const f = await get();
      if (f && f.listaTabId) {
        try { await chrome.tabs.update(f.listaTabId, { active: true }); } catch (e) {}
      }
      return resp({ ok: true });
    }
    resp({ ok: false });
  })();
  return true;
});
