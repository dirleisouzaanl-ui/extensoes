// CONSULTAR SISBAJUD — consulta do mês e exportação das ordens, uma a uma.
// Seletores por TEXTO VISÍVEL (Angular Material): os rótulos da tela são estáveis, os ids não.
(function () {
  if (window.top !== window || window.__sbConsultar) return;
  window.__sbConsultar = true;

  // ---------------- utilidades ----------------
  const KEY = 'sb_fila';
  const VARA = '8867';
  const ASSESSOR = 'DIRLEI DE SOUZA';
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  const visivel = (el) => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  const waitFor = async (fn, timeout = 10000, step = 250) => {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) { try { const v = fn(); if (v) return v; } catch (e) {} await sleep(step); }
    return null;
  };
  const getFila = () => new Promise((r) => chrome.storage.local.get(KEY, (o) => r(o[KEY] || null)));
  const setFila = (v) => new Promise((r) => chrome.storage.local.set({ [KEY]: v }, r));
  const meuId = () => new Promise((r) => chrome.runtime.sendMessage({ tipo: 'meu-id' }, (x) => r(x && x.tabId)));

  function toast(msg, tipo = 'ok', ms = 7000) {
    const d = document.createElement('div');
    d.className = 'sb-toast sb-' + tipo;
    d.textContent = msg;
    document.body.appendChild(d);
    setTimeout(() => d.remove(), ms);
  }

  // elemento clicável cujo texto visível (sem ícones) casa com a expressão
  function textoSemIcone(el) {
    const c = el.cloneNode(true);
    c.querySelectorAll('mat-icon, .material-icons, i, svg').forEach((x) => x.remove());
    return norm(c.textContent);
  }
  function botao(re, raiz = document) {
    return [...raiz.querySelectorAll('button, a, [role="button"], [role="menuitem"], .mat-menu-item, .mat-mdc-menu-item')]
      .filter((b) => visivel(b) && !b.closest('#sb-painel') && !b.disabled)
      .find((b) => re.test(textoSemIcone(b))) || null;
  }
  // rótulo de texto (o elemento mais interno que contém o texto)
  function rotulo(re) {
    const cand = [...document.querySelectorAll('body *')]
      .filter((e) => !e.closest('#sb-painel') && visivel(e) && e.textContent.length < 80 && re.test(norm(e.textContent)));
    return cand.find((e) => !cand.some((o) => o !== e && e.contains(o))) || null;
  }
  const depois = (ref, sel) => ref ? [...document.querySelectorAll(sel)].filter((e) => visivel(e) && (ref.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) : [];

  // digita num input do Angular (dispara os eventos que o formulário escuta)
  function digitar(el, valor) {
    el.focus();
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(el, valor);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter' }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  const dd = (n) => String(n).padStart(2, '0');
  function periodoDoMes(aaaamm) {
    const [a, m] = aaaamm.split('-').map(Number);
    let ultimo = new Date(a, m, 0).getDate();
    const hoje = new Date();
    if (a === hoje.getFullYear() && m === hoje.getMonth() + 1) ultimo = Math.min(ultimo, hoje.getDate()); // calendário não aceita datas futuras
    return { a, m, diaIni: 1, diaFim: ultimo, ini: `01/${dd(m)}/${a}`, fim: `${dd(ultimo)}/${dd(m)}/${a}` };
  }


  // ---------------- tela: Ordens Judiciais ----------------
  const ehListaOrdens = () => /ordens judiciais/.test(norm((document.body.textContent || "").slice(0, 5000))) && !!botao(/^consultar$/);

  // escolhe a data PELO CALENDÁRIO (o campo interpreta texto digitado como mês/dia)
  const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  const calendario = () => [...document.querySelectorAll('mat-calendar, .mat-calendar')].find(visivel) || null;
  function mesDoCabecalho(cal) {
    const t = norm((cal.querySelector('.mat-calendar-period-button, [aria-label*="ano"], button') || {}).textContent);
    const ano = Number((t.match(/\d{4}/) || [])[0]);
    const mes = MESES.findIndex((x) => t.startsWith(x)) + 1;
    return ano && mes ? ano * 12 + (mes - 1) : null;
  }
  async function preencherData(inp, dia, mes, ano, valor) {
    const ff = inp.closest('mat-form-field, .mat-form-field, .mat-mdc-form-field') || inp.parentElement;
    const toggle = ff.querySelector('mat-datepicker-toggle button, .mat-datepicker-toggle button, button[aria-label*="calend" i]');
    (toggle || inp).click();
    let cal = await waitFor(calendario, 4000);
    if (!cal) return false;
    // se abriu em visão de ano/multiano, volta para a visão de mês clicando no mês atual exibido
    const alvo = ano * 12 + (mes - 1);
    for (let i = 0; i < 400; i++) {
      cal = calendario();
      const atual = mesDoCabecalho(cal);
      if (atual === null) return false;
      if (atual === alvo) break;
      const btn = cal.querySelector(atual > alvo ? '.mat-calendar-previous-button' : '.mat-calendar-next-button');
      if (!btn || btn.disabled) return false;
      btn.click();
      await sleep(120);
    }
    await sleep(250);
    cal = calendario();
    const cel = [...cal.querySelectorAll('.mat-calendar-body-cell')]
      .filter((c) => !c.classList.contains('mat-calendar-body-disabled') && c.getAttribute('aria-disabled') !== 'true')
      .find((c) => norm((c.querySelector('.mat-calendar-body-cell-content') || c).textContent) === String(dia));
    if (!cel) { document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); return false; }
    cel.click();
    await waitFor(() => !calendario(), 3000);
    await sleep(300);
    return inp.value === valor;
  }

  // campo do Período do protocolamento inicial: o 1º "Data inicial" / "Data final" depois do rótulo
  function campoData(rot, re) {
    const ins = depois(rot, 'input').filter((i) => i.type !== 'checkbox' && i.type !== 'radio');
    const porNome = ins.find((i) => {
      const ff = i.closest('mat-form-field, .mat-form-field, .mat-mdc-form-field');
      return re.test(norm(i.placeholder)) || re.test(norm(i.getAttribute('aria-label'))) || (ff && re.test(norm(ff.textContent)));
    });
    return porNome || null;
  }

  async function consultarMes(aaaamm) {
    // aba "Busca por filtros de pesquisa"
    const aba = [...document.querySelectorAll('[role="tab"], .mat-tab-label, .mdc-tab, a, div')]
      .find((e) => visivel(e) && norm(e.textContent) === 'busca por filtros de pesquisa');
    if (aba) { aba.click(); await sleep(800); }

    const p = periodoDoMes(aaaamm);
    let rot = await waitFor(() => rotulo(/^periodo do protocolamento inicial$/), 4000);
    if (!rot) { await expandirFiltros(); rot = await waitFor(() => rotulo(/^periodo do protocolamento inicial$/), 4000); }
    if (!rot) return toast('Não localizei "Período do protocolamento inicial".', 'erro');
    const dIni = campoData(rot, /data inicial/);
    const dFim = campoData(rot, /data final/);
    if (!dIni || !dFim) return toast('Campos "Data inicial"/"Data final" não localizados.', 'erro');
    const okIni = await preencherData(dIni, p.diaIni, p.m, p.a, p.ini); await sleep(500);
    const okFim = await preencherData(dFim, p.diaFim, p.m, p.a, p.fim); await sleep(500);

    const okVara = await selecionar(/^vara\s*\/\s*juizo:?$/, VARA, VARA);
    await expandirFiltros(); // "Exibir mais filtros" antes do Assessor
    const okAss = await selecionar(/^assessor:?$/, ASSESSOR, 'DIRLEI');

    const pend = [];
    if (!okIni) pend.push('Data inicial');
    if (!okFim) pend.push('Data final');
    if (!okVara) pend.push('Vara/Juízo');
    if (!okAss) pend.push('Assessor');
    if (pend.length) return toast(`Período ${p.ini} a ${p.fim}. Não consegui preencher: ${pend.join(', ')}. Ajuste e clique em Consultar.`, 'erro', 15000);

    await sleep(500);
    const b = botao(/^consultar$/);
    if (!b) return toast('Botão Consultar não localizado.', 'erro');
    b.click();
    toast(`Consulta: ${p.ini} a ${p.fim} | Vara/Juízo 8867 | Assessor ${ASSESSOR}.`);
  }

  // botão "Exibir mais filtros" (se já estiver "Exibir menos filtros", nada a fazer)
  async function expandirFiltros() {
    const mais = botao(/exibir mais filtros/);
    if (!mais) return !!botao(/exibir menos filtros/);
    mais.click();
    const ok = await waitFor(() => botao(/exibir menos filtros/) || rotulo(/^assessor:?$/), 5000);
    await sleep(600);
    return !!ok;
  }

  // campo de seleção (mat-select ou autocomplete) identificado pelo rótulo
  async function selecionar(reRotulo, textoFinal, busca) {
    const rot = rotulo(reRotulo);
    const campo = rot && (rot.closest('mat-form-field, .mat-form-field, .mat-mdc-form-field') || rot.parentElement);
    if (!campo) return false;
    const temValor = () => norm(campo.textContent).includes(norm(textoFinal)) ||
      [...campo.querySelectorAll('input')].some((i) => norm(i.value).includes(norm(textoFinal)));
    if (temValor()) return true; // já preenchido
    const sel = campo.querySelector('mat-select, .mat-select-trigger, .mat-mdc-select-trigger, [role="combobox"]:not(input)');
    const inp = campo.querySelector('input');
    if (inp && !sel) digitar(inp, busca);
    else if (sel) sel.click();
    else return false;
    const op = await waitFor(() => [...document.querySelectorAll('mat-option, .mat-option, .mat-mdc-option, [role="option"]')]
      .find((o) => visivel(o) && norm(o.textContent).includes(norm(textoFinal))), 8000);
    if (!op) return false;
    op.click();
    await sleep(700);
    return temValor();
  }

  const PROC = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;
  const linhas = () => [...document.querySelectorAll('tr, mat-row, .mat-row, .mat-mdc-row')]
    .filter((r) => visivel(r) && PROC.test(r.textContent) && r.querySelector('button, a'))
    .filter((r, i, arr) => !arr.some((o) => o !== r && o.contains(r))); // sem duplicar linhas aninhadas

  async function abrirOrdem(f) {
    const ls = linhas();
    const r = ls[f.indice];
    if (!r) { toast('Linha ' + (f.indice + 1) + ' não encontrada na página.', 'erro'); return; }
    r.scrollIntoView({ block: 'center' });
    r.classList.add('sb-linha-atual');
    // coluna Ações: último botão da linha ("...")
    const bts = [...r.querySelectorAll('button, a, [role="button"]')].filter(visivel);
    const acoes = bts[bts.length - 1];
    acoes.click();
    const item = await waitFor(() => botao(/abrir em nova guia/), 5000);
    if (!item) { toast('Opção "Abrir em nova guia" não apareceu.', 'erro'); return; }
    f.etapa = 'abrindo';
    f.abrindoEm = Date.now();
    await setFila(f);
    const href = item.getAttribute('href') || (item.closest('a') && item.closest('a').getAttribute('href'));
    if (href && href !== '#') {
      document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      window.open(new URL(href, location.href).href, '_blank');
    } else item.click();
    toast(`Ordem ${f.indice + 1} de ${f.total}: ${(r.textContent.match(PROC) || [''])[0]}`);
    // se a guia não abrir (bloqueio de pop-up), pede o clique da usuária
    setTimeout(async () => {
      const g = await getFila();
      if (g && g.ativo && g.etapa === 'abrindo' && g.indice === f.indice) {
        toast('A nova guia não abriu (pop-up bloqueado?). Clique em "Próxima ordem".', 'aviso', 12000);
        g.etapa = 'aguardando'; await setFila(g); atualizarPainel();
      }
    }, 7000);
  }

  async function iniciarFila() {
    const ls = linhas();
    if (!ls.length) return toast('Nenhuma ordem na tabela. Faça a consulta antes.', 'erro');
    const inicio = Math.max(1, Number(document.getElementById('sb-inicio').value) || 1) - 1;
    const f = { ativo: true, listaTabId: await meuId(), indice: inicio, total: ls.length, etapa: 'lista' };
    await setFila(f);
    atualizarPainel();
    abrirOrdem(f);
  }

  async function continuarFila() {
    const f = await getFila();
    if (!f || !f.ativo) return;
    if (f.indice >= f.total) {
      f.ativo = false; f.etapa = 'fim'; await setFila(f);
      atualizarPainel();
      return toast(`Concluído: ${f.total} ordem(ns) processada(s) nesta página.`, 'ok', 15000);
    }
    atualizarPainel();
    abrirOrdem(f);
  }

  // ---------------- guia da ordem: Visualizar série → Exportar PDF → imprimir ----------------
  let ocupado = false;
  async function passoDetalhe() {
    if (ocupado) return;
    const f = await getFila();
    if (!f || !f.ativo || f.etapa !== 'detalhe') return;
    if (f.detalheTabId !== (await meuId())) return;
    ocupado = true;
    try {
      if (!f.serieClicada) {
        const vs = botao(/visualizar serie/);
        if (vs) {
          await sleep(1000);
          vs.click();
          f.serieClicada = true; await setFila(f);
          toast('Visualizar série acionado. Aguardando a próxima tela...');
        }
      } else if (!f.exportado) {
        const exp = botao(/exportar pdf/);
        if (exp) {
          await sleep(1500); // tela da série estabilizada
          exp.click();
          f.exportado = true; await setFila(f);
          toast('Exportar PDF acionado. Abrindo a impressão...');
          await sleep(3500);
          imprimir(f);
        }
      }
    } finally {
      ocupado = false;
    }
  }

  function imprimir(f) {
    const depoisImprimir = async () => {
      window.removeEventListener('afterprint', depoisImprimir);
      const g = await getFila();
      if (!g || !g.ativo) return;
      g.impresso = true; g.indice = f.indice + 1; g.etapa = 'proxima';
      await setFila(g);
      chrome.runtime.sendMessage({ tipo: 'voltar-lista' });
    };
    window.addEventListener('afterprint', depoisImprimir);
    window.print(); // a usuária escolhe "Salvar como PDF" e o nome do arquivo
  }

  // ---------------- painel (tela Ordens Judiciais) ----------------
  function mesPadrao() { const d = new Date(); return `${d.getFullYear()}-${dd(d.getMonth() + 1)}`; }
  async function atualizarPainel() {
    const s = document.getElementById('sb-status');
    if (!s) return;
    const f = await getFila();
    s.textContent = !f ? 'Pronto.' :
      f.ativo ? `Ordem ${Math.min(f.indice + 1, f.total)} de ${f.total} (${f.etapa})` :
      f.etapa === 'fim' ? `Concluído: ${f.total} ordem(ns).` : 'Parado.';
    const prox = document.getElementById('sb-prox');
    if (prox) prox.classList.toggle('sb-destaque', !!(f && f.ativo && f.etapa === 'aguardando'));
  }
  function montarPainel() {
    if (document.getElementById('sb-painel') || !ehListaOrdens()) return;
    const p = document.createElement('div');
    p.id = 'sb-painel';
    p.innerHTML = `
      <div class="sb-tit">CONSULTAR SISBAJUD <span class="sb-x" title="Minimizar">–</span></div>
      <div class="sb-corpo">
        <label>Mês do protocolamento inicial</label>
        <input type="month" id="sb-mes" value="${mesPadrao()}">
        <button type="button" id="sb-consultar">1. Consultar mês</button>
        <label>Começar na linha</label>
        <input type="number" id="sb-inicio" min="1" value="1">
        <button type="button" id="sb-processar">2. Exportar ordens (uma a uma)</button>
        <button type="button" id="sb-prox" class="sb-sec">Próxima ordem</button>
        <button type="button" id="sb-parar" class="sb-sec">Parar</button>
        <div id="sb-status" class="sb-status">Pronto.</div>
      </div>`;
    document.body.appendChild(p);
    p.querySelector('.sb-x').onclick = () => p.classList.toggle('sb-min');
    document.getElementById('sb-consultar').onclick = () => {
      const v = document.getElementById('sb-mes').value;
      if (!/^\d{4}-\d{2}$/.test(v)) return toast('Informe o mês.', 'erro');
      consultarMes(v);
    };
    document.getElementById('sb-processar').onclick = iniciarFila;
    document.getElementById('sb-prox').onclick = async () => {
      const f = await getFila();
      if (!f || !f.ativo) return toast('Nenhuma fila em andamento. Use "2. Exportar ordens".', 'aviso');
      abrirOrdem(f);
    };
    document.getElementById('sb-parar').onclick = async () => {
      const f = await getFila();
      if (f) { f.ativo = false; f.etapa = 'parado'; await setFila(f); }
      atualizarPainel();
      toast('Fila interrompida.', 'aviso');
    };
    atualizarPainel();
  }

  // ---------------- laço principal ----------------
  let agendado = false;
  const tick = () => {
    if (agendado) return;
    agendado = true;
    setTimeout(() => { agendado = false; montarPainel(); passoDetalhe(); }, 500);
  };
  new MutationObserver(tick).observe(document.documentElement, { childList: true, subtree: true });
  tick();

  chrome.storage.onChanged.addListener(async (ch) => {
    if (!ch[KEY]) return;
    atualizarPainel();
    const f = ch[KEY].newValue;
    if (f && f.ativo && f.etapa === 'proxima' && f.listaTabId === (await meuId())) {
      f.etapa = 'lista'; await setFila(f);
      await sleep(1200);
      continuarFila();
    }
    if (f && f.ativo && f.etapa === 'detalhe') passoDetalhe();
  });
})();
