/*
 * content-sisbajud.js — roda DENTRO da página do SISBAJUD (depois do config.js).
 *
 * Mostra um painel flutuante (canto inferior direito) com o processo trazido
 * do PROJUDI e os botões da minuta de bloqueio:
 *
 *   Preencher minuta  → juiz, vara, tipo de ação, nº do processo, autor,
 *                       TODOS os executados com CPF/CNPJ e a "teimosinha";
 *                       e o Valor (= Valor da Causa copiado do PROJUDI; sem ele, cursor no campo).
 *   Salvar minuta     → clica em "Salvar"
 *   Protocolar        → clica em "Protocolar" (com confirmação, se ativada)
 *   Copiar nº         → copia o nº CNJ da página para a área de transferência
 *   Gerar recibo      → clica em "Gerar Recibo"
 *
 * Os dados vêm de chrome.storage.local, que o content script PODE ler
 * diretamente; o painel se atualiza sozinho quando você copia outro processo
 * no PROJUDI (chrome.storage.onChanged), sem F5.
 */

(async () => {
  'use strict';

  const S = self.SISBAJUD; // definido em config.js
  if (!S || !S.ehUrlSisbajud(location.href)) return;
  if (window.top !== window) return; // painel só no quadro principal

  let opcoes = await S.lerOpcoes();
  let dados = (await chrome.storage.local.get(S.CHAVE_DADOS))[S.CHAVE_DADOS] || null;

  const esperar = (ms) => new Promise((r) => setTimeout(r, ms));
  const pausa = (fator = 1) => esperar(Math.round(opcoes.pausaMs * fator));

  // -------------------------------------------------------------------------
  // 1) Utilitários de preenchimento (Angular Material).
  // -------------------------------------------------------------------------
  const campo = (placeholder) => document.querySelector(`input[placeholder="${placeholder}"]`);

  // Campo de texto simples (nº do processo, nome).
  function digitar(el, valor) {
    el.focus();
    el.click();
    el.select();
    document.execCommand('insertText', false, valor);
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  // Campo com máscara (CPF/CNPJ): um caractere por vez.
  async function digitarComMascara(el, valor) {
    el.focus();
    el.click();
    el.select();
    document.execCommand('delete');
    el.dispatchEvent(new Event('input', { bubbles: true }));
    for (const ch of valor) {
      document.execCommand('insertText', false, ch);
      await esperar(50);
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  // Autocomplete (Juiz): grava o valor pelo setter nativo e avisa o Angular.
  function gravarAutocomplete(el, valor) {
    el.focus();
    el.click();
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(el, valor);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  const opcoesAbertas = () => [...document.querySelectorAll('mat-option')];

  // mat-select pelo rótulo do mat-form-field (ou por texto próximo).
  function selectPeloRotulo(rotulo) {
    for (const ff of document.querySelectorAll('mat-form-field')) {
      const l = ff.querySelector('mat-label');
      if (l && l.textContent.includes(rotulo)) return ff.querySelector('mat-select');
    }
    for (const el of document.querySelectorAll('span,div,label')) {
      if (el.children.length < 3 && el.textContent.trim().includes(rotulo)) {
        let p = el.parentElement;
        for (let k = 0; k < 6 && p; k++, p = p.parentElement) {
          const s = p.querySelector('mat-select');
          if (s) return s;
        }
      }
    }
    return null;
  }

  // Botão "+" (adicionar réu) na mesma linha do campo CPF/CNPJ do réu.
  function botaoAdicionarReu(input) {
    const bloco = input.closest('mat-form-field') || input.closest('div');
    const vizinho = bloco && bloco.parentElement && bloco.parentElement.querySelector('button');
    if (vizinho) return vizinho;
    const r = input.getBoundingClientRect();
    return [...document.querySelectorAll('button')].find((b) => {
      const rb = b.getBoundingClientRect();
      return Math.abs(rb.top - r.top) < 30 && rb.left > r.right;
    }) || null;
  }

  const botaoPorTexto = (re) => [...document.querySelectorAll('button')]
    .find((b) => re.test(b.textContent.replace(/\s+/g, ' ').trim()));

  // -------------------------------------------------------------------------
  // 2) Teimosinha: "Repetir a ordem até a data:" + calendário.
  // -------------------------------------------------------------------------
  function radioRepetir() {
    for (const rb of document.querySelectorAll('mat-radio-button')) {
      if (/Repetir a ordem/i.test(rb.textContent)) return rb.querySelector('input[type="radio"]') || rb;
    }
    for (const input of document.querySelectorAll('input[type="radio"]')) {
      const rotulo = input.closest('label, div');
      if (rotulo && /Repetir a ordem/i.test(rotulo.textContent)) return input;
    }
    return null;
  }

  const MESES = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];

  async function marcarTeimosinha() {
    const radio = radioRepetir();
    if (!radio) return { ok: false, motivo: 'opção "Repetir a ordem" não encontrada' };
    radio.click();
    await pausa();

    const alvo = new Date();
    alvo.setDate(alvo.getDate() + opcoes.diasTeimosinha);
    const dataStr = alvo.toLocaleDateString('pt-BR');

    const input = campo('Data limite:') || document.querySelector('input[aria-haspopup="dialog"]');
    const ff = input && input.closest('mat-form-field');
    const botaoCal = ff && ff.querySelector('mat-datepicker-toggle button, button');
    if (!botaoCal) return { ok: false, motivo: 'calendário da data limite não encontrado', dataStr };
    botaoCal.click();
    await pausa();

    // Avança até o mês/ano do alvo (no máximo 3 voltas: 30 dias cabem em 2).
    for (let i = 0; i < 3; i++) {
      const cab = (document.querySelector('.mat-calendar-period-button') || {}).textContent || '';
      const texto = cab.toUpperCase();
      const mes = MESES.findIndex((m) => texto.includes(m));
      const ano = Number((texto.match(/\d{4}/) || [])[0]);
      if (mes === alvo.getMonth() && ano === alvo.getFullYear()) break;
      const prox = document.querySelector('.mat-calendar-next-button');
      if (!prox) break;
      prox.click();
      await pausa(0.5);
    }

    // Só células habilitadas do mês exibido.
    const dia = String(alvo.getDate());
    const celula = [...document.querySelectorAll('.mat-calendar-body-cell')]
      .find((c) => c.textContent.trim() === dia && c.getAttribute('aria-disabled') !== 'true');
    if (!celula) return { ok: false, motivo: `dia ${dataStr} indisponível no calendário`, dataStr };
    celula.click();
    await pausa(0.5);
    return { ok: true, dataStr };
  }

  // -------------------------------------------------------------------------
  // 3) Preencher a minuta.
  // -------------------------------------------------------------------------
  async function preencher() {
    const avisos = [];

    // Juiz
    const juiz = campo('Juiz Solicitante');
    if (!juiz) return '✗ Campo Juiz não encontrado — está na tela de cadastro da minuta?';
    gravarAutocomplete(juiz, opcoes.juiz);
    await pausa(2);
    const opJuiz = opcoesAbertas().find((o) => o.textContent.trim().toUpperCase() === opcoes.juiz.toUpperCase());
    if (!opJuiz) return `✗ Juiz "${opcoes.juiz}" não apareceu na lista`;
    opJuiz.click();
    await pausa();

    // Vara/Juízo
    const vara = selectPeloRotulo('Vara/Ju');
    if (!vara) return '✗ Campo Vara/Juízo não encontrado';
    vara.click();
    await pausa(1.5);
    const busca = document.querySelector('.mat-select-search-input, mat-select-panel input, input[placeholder*="Pesquisar"]');
    if (busca) {
      busca.focus();
      document.execCommand('insertText', false, opcoes.varaCodigo);
      await pausa(1.5);
    }
    const opVara = opcoesAbertas().find((o) => o.textContent.includes(opcoes.varaCodigo));
    if (!opVara) return `✗ Vara ${opcoes.varaCodigo} não apareceu na lista`;
    opVara.scrollIntoView({ block: 'center' });
    await esperar(300);
    opVara.click();
    await pausa();

    // Tipo/natureza da ação
    const tipo = selectPeloRotulo('Tipo/natureza');
    if (!tipo) return '✗ Campo Tipo/natureza não encontrado';
    tipo.click();
    await pausa();
    const opTipo = opcoesAbertas().find((o) => o.textContent.trim() === opcoes.tipoAcao);
    if (!opTipo) return `✗ Tipo "${opcoes.tipoAcao}" não apareceu na lista`;
    opTipo.click();
    await pausa(0.5);

    if (!dados) return '✓ Campos fixos preenchidos (sem dados do PROJUDI)';

    // Nº do processo
    const num = campo('Número do Processo');
    if (num && dados.numProcesso) { digitar(num, dados.numProcesso); await pausa(0.5); }
    else avisos.push('nº do processo');

    // Autor/exequente (o SISBAJUD aceita um: usa o 1º)
    const exq = (dados.exequentes || [])[0];
    if (exq) {
      const cpfA = campo('CPF/CNPJ do autor/exequente da ação');
      if (cpfA && exq.doc) { await digitarComMascara(cpfA, exq.doc.replace(/\D/g, '')); await pausa(0.5); }
      const nomeA = campo('Nome do autor/exequente da ação');
      if (nomeA) { digitar(nomeA, exq.nome); await pausa(0.5); }
    } else {
      avisos.push('exequente');
    }

    // Réus/executados: TODOS os que têm CPF/CNPJ, um por vez.
    let incluidos = 0;
    const semDoc = [];
    for (const exe of dados.executados || []) {
      if (!exe.doc) { semDoc.push(exe.nome); continue; }
      const cpfR = campo('CPF/CNPJ do réu/executado'); // relê: o Angular pode recriar o campo
      if (!cpfR) { avisos.push('campo CPF/CNPJ do réu'); break; }
      await digitarComMascara(cpfR, exe.doc.replace(/\D/g, ''));
      await pausa(0.5);
      const mais = botaoAdicionarReu(cpfR);
      if (!mais) { avisos.push('botão de adicionar réu'); break; }
      mais.click();
      incluidos++;
      await pausa();
    }
    if (semDoc.length) avisos.push(`${semDoc.length} executado(s) sem CPF/CNPJ: ${semDoc.join('; ')}`);

    // Teimosinha
    let teimosinha = '';
    if (opcoes.teimosinha) {
      const t = await marcarTeimosinha();
      teimosinha = t.ok ? ` | teimosinha até ${t.dataStr}` : '';
      if (!t.ok) avisos.push(t.motivo);
    }

    // Valor: o "Valor da Causa" copiado do PROJUDI (o campo tem máscara: digita só os dígitos).
    const valor = campo('Valor aplicado a todos os réus/executados');
    let valorTxt = ' — digite o VALOR';
    if (valor) {
      valor.scrollIntoView({ block: 'center' });
      if (dados.valorCausa) {
        await digitarComMascara(valor, dados.valorCausa.replace(/\D/g, ''));
        await pausa(0.5);
        valorTxt = ` — valor R$ ${dados.valorCausa} (valor da causa; confira)`;
      } else {
        valor.focus();
        valor.click();
        avisos.push('valor da causa não copiado: digite o valor');
      }
    } else avisos.push('campo Valor');

    const base = `✓ ${incluidos} réu(s) incluído(s)${teimosinha}${valorTxt}`;
    return avisos.length ? `${base}\n⚠ Verifique: ${avisos.join(' | ')}` : base;
  }

  // -------------------------------------------------------------------------
  // 4) Demais botões.
  // -------------------------------------------------------------------------
  function clicar(re, nome) {
    const b = botaoPorTexto(re);
    if (!b) return `✗ Botão "${nome}" não encontrado`;
    if (b.disabled) return `✗ Botão "${nome}" está desabilitado`;
    b.click();
    return `✓ "${nome}" clicado`;
  }

  function protocolar() {
    if (opcoes.confirmarProtocolo &&
        !window.confirm(`Protocolar a ordem${dados ? ' do processo ' + dados.numProcesso : ''}?`)) {
      return 'Protocolo cancelado';
    }
    return clicar(/^Protocolar$/i, 'Protocolar');
  }

  function copiarNumero() {
    const m = document.body.innerText.match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/);
    if (!m) return '✗ Nº do processo não encontrado na página';
    const ta = document.createElement('textarea');
    ta.value = m[0];
    ta.style.cssText = 'position:fixed;left:-9999px';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    return `✓ Nº copiado: ${m[0]}`;
  }

  // -------------------------------------------------------------------------
  // 5) Painel flutuante.
  // -------------------------------------------------------------------------
  let painel = null;
  let ocupado = false;

  function descreverDados() {
    if (!dados) return 'Nenhum processo copiado do PROJUDI.';
    const exe = dados.executados || [];
    const linhas = exe.map((p) => `• ${p.nome}${p.doc ? ' — ' + p.doc : ' — SEM CPF/CNPJ'}`);
    return `${dados.numProcesso}${dados.valorCausa ? ' — valor da causa R$ ' + dados.valorCausa : ''}\n${exe.length} executado(s):\n${linhas.join('\n')}`;
  }

  function montarPainel() {
    painel = document.createElement('div');
    painel.id = 'sisbajud-painel';
    painel.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;width:280px;' +
      'font:12px Verdana,sans-serif;color:#222;background:#fff;border:1px solid #1565c0;' +
      'border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,.35);padding:8px';

    const topo = document.createElement('div');
    topo.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:6px';
    const titulo = document.createElement('b');
    titulo.textContent = 'PROJUDI → SISBAJUD';
    titulo.style.color = '#1565c0';
    const recolher = document.createElement('button');
    recolher.type = 'button';
    recolher.textContent = '–';
    recolher.title = 'Recolher/expandir';
    recolher.style.cssText = 'border:0;background:none;cursor:pointer;font-size:14px';
    topo.append(titulo, recolher);

    const corpo = document.createElement('div');
    const info = document.createElement('pre');
    info.id = 'sisbajud-info';
    info.style.cssText = 'white-space:pre-wrap;margin:0 0 6px;font:11px Verdana,sans-serif;' +
      'max-height:120px;overflow:auto;background:#f4f7fb;padding:4px;border-radius:4px';

    const status = document.createElement('div');
    status.id = 'sisbajud-status';
    status.style.cssText = 'white-space:pre-wrap;font-size:11px;color:#555;min-height:14px;margin-top:4px';

    const acoes = [
      ['Preencher minuta', '#1565c0', preencher],
      ['Salvar minuta', '#e65100', () => clicar(/^Salvar$/i, 'Salvar')],
      ['Protocolar', '#2e7d32', protocolar],
      ['Copiar nº do processo', '#6a1b9a', copiarNumero],
      ['Gerar recibo', '#ad1457', () => clicar(/Gerar Recibo/i, 'Gerar Recibo')]
    ];
    corpo.appendChild(info);
    for (const [rotulo, cor, acao] of acoes) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = rotulo;
      b.style.cssText = `display:block;width:100%;margin:3px 0;padding:6px;border:0;border-radius:4px;` +
        `color:#fff;background:${cor};cursor:pointer;font:bold 12px Verdana,sans-serif`;
      b.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (ocupado) return;
        ocupado = true;
        status.textContent = `${rotulo}…`;
        try {
          status.textContent = await acao();
        } catch (erro) {
          console.error('[sisbajud]', erro);
          status.textContent = `✗ ${erro.message}`;
        } finally {
          ocupado = false;
        }
      });
      corpo.appendChild(b);
    }
    corpo.appendChild(status);

    recolher.addEventListener('click', () => {
      const oculto = corpo.style.display === 'none';
      corpo.style.display = oculto ? '' : 'none';
      recolher.textContent = oculto ? '–' : '+';
    });

    painel.append(topo, corpo);
    document.body.appendChild(painel);
  }

  // O painel só aparece onde é usado: cadastro da minuta (campo "Juiz Solicitante") ou
  // tela com os botões Protocolar / Gerar Recibo. Nas demais telas do SISBAJUD fica oculto.
  const telaDaMinuta = () => !!campo('Juiz Solicitante') ||
    [...document.querySelectorAll('button')].some((b) => !(painel && painel.contains(b)) && /^\s*(Protocolar|Gerar Recibo)\s*$/i.test(b.textContent || ''));

  function atualizarPainel() {
    if (!opcoes.mostrarPainel || (!ocupado && !telaDaMinuta())) {
      if (painel) { painel.remove(); painel = null; }
      return;
    }
    if (!painel || !document.body.contains(painel)) montarPainel();
    painel.querySelector('#sisbajud-info').textContent = descreverDados();
  }

  atualizarPainel();

  // O SISBAJUD é uma aplicação de página única: se o Angular remover o
  // painel ao trocar de tela, ele é recolocado.
  let agendado = false;
  new MutationObserver(() => {
    if (agendado) return;
    agendado = true;
    requestAnimationFrame(() => {
      agendado = false;
      atualizarPainel();
    });
  }).observe(document.body, { childList: true });
  // o SISBAJUD troca de tela sem recarregar: confere a cada segundo se o painel deve aparecer
  setInterval(atualizarPainel, 1000);

  // Novo processo copiado no PROJUDI ou opções alteradas → atualiza AO VIVO.
  chrome.storage.onChanged.addListener((mudancas, area) => {
    if (area === 'local' && mudancas[S.CHAVE_DADOS]) {
      dados = mudancas[S.CHAVE_DADOS].newValue || null;
      atualizarPainel();
    }
    if (area === 'sync') S.lerOpcoes().then((op) => { opcoes = op; atualizarPainel(); });
  });
})();
