/* calendario.js - contagem de prazos em dias úteis do Juizado Especial (TJPR), igual à skill
   prazo-juizado-tjpr (scripts/prazo.py). Calendário: Decreto Judiciário TJPR n.º 621/2025 (calendário 2026). Atualizar a cada novo decreto anual (publicado em nov/dez).
   Atualize CALENDARIO_TJPR a cada novo decreto anual (publicado em nov/dez). */
var CALENDARIO_TJPR = {
 "anos_oficiais": [
  2026
 ],
 "estaduais": {
  "2026-01-01": "Confraternização Universal",
  "2026-02-16": "Véspera de Carnaval (suspensão de expediente)",
  "2026-02-17": "Carnaval",
  "2026-04-02": "Quinta-feira Santa (suspensão de expediente)",
  "2026-04-03": "Paixão de Cristo",
  "2026-04-20": "Suspensão de expediente (ponte)",
  "2026-04-21": "Tiradentes",
  "2026-05-01": "Dia do Trabalho",
  "2026-06-04": "Corpus Christi",
  "2026-06-05": "Suspensão de expediente (ponte)",
  "2026-09-07": "Independência do Brasil",
  "2026-10-12": "Nossa Senhora Aparecida",
  "2026-10-30": "Dia do Funcionário Público (transferido de 28/10)",
  "2026-11-02": "Finados",
  "2026-11-15": "Proclamação da República",
  "2026-11-20": "Consciência Negra",
  "2026-12-18": "Dia da Justiça (transferido de 08/12)",
  "2026-12-24": "Véspera de Natal (suspensão de expediente)",
  "2026-12-25": "Natal",
  "2026-12-31": "Véspera de Ano Novo (suspensão de expediente)"
 },
 "municipais": {
  "assis chateaubriand": {
   "2026-07-16": "Padroeira do Município",
   "2026-08-20": "Aniversário do Município"
  },
  "curitiba": {
   "2026-09-08": "Padroeira de Curitiba"
  }
 }
};

var PrazoJE = (() => {
  const DIAS = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
  const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const br = d => String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear();
  const mais = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  const parse = s => { const m = /(\d{2})\/(\d{2})\/(\d{4})/.exec(s || ''); return m ? new Date(+m[3], +m[2] - 1, +m[1]) : null; };

  function pascoa(a) {
    const b = Math.floor(a / 100), c = a % 100;
    const d = ((19 * (a % 19) + b - Math.floor(b / 4) - Math.floor((b - Math.floor((b + 8) / 25) + 1) / 3) + 15) % 30 + 30) % 30;
    const e = ((32 + 2 * (b % 4) + 2 * Math.floor(c / 4) - d - c % 4) % 7 + 7) % 7;
    const f = d + e - 7 * Math.floor((a % 19 + 11 * d + 22 * e) / 451) + 114;
    return new Date(a, Math.floor(f / 31) - 1, f % 31 + 1);
  }
  const cacheProv = {};
  function provisorios(a) {
    if (cacheProv[a]) return cacheProv[a];
    const p = pascoa(a), r = {};
    const fixos = { '01-01': 'Confraternização Universal', '04-21': 'Tiradentes', '05-01': 'Dia do Trabalho', '09-07': 'Independência',
      '10-12': 'N. Sra. Aparecida', '10-28': 'Dia do Servidor Público', '11-02': 'Finados', '11-15': 'Proclamação da República',
      '11-20': 'Consciência Negra', '12-08': 'Dia da Justiça', '12-24': 'Véspera de Natal', '12-25': 'Natal', '12-31': 'Véspera de Ano Novo' };
    Object.entries(fixos).forEach(([k, v]) => { r[a + '-' + k] = v; });
    r[iso(mais(p, -48))] = 'Véspera de Carnaval'; r[iso(mais(p, -47))] = 'Carnaval';
    r[iso(mais(p, -3))] = 'Quinta-feira Santa'; r[iso(mais(p, -2))] = 'Paixão de Cristo'; r[iso(mais(p, 60))] = 'Corpus Christi';
    return (cacheProv[a] = r);
  }

  function motivoNaoUtil(d, comarca, avisos) {
    const dw = d.getDay();
    if (dw === 0 || dw === 6) return 'Final de semana';
    const m = d.getMonth() + 1, dia = d.getDate();
    if ((m === 12 && dia >= 20) || (m === 1 && dia <= 20)) return 'Recesso — prazos suspensos (art. 220 CPC)';
    if (CALENDARIO_TJPR.anos_oficiais.includes(d.getFullYear())) {
      const e = CALENDARIO_TJPR.estaduais[iso(d)];
      if (e) return e;
      const mu = comarca && (CALENDARIO_TJPR.municipais[comarca] || {})[iso(d)];
      if (mu) return 'Feriado municipal — ' + mu;
    } else {
      if (avisos) avisos.add(d.getFullYear());
      const p = provisorios(d.getFullYear())[iso(d)];
      if (p) return p + ' (PROVISÓRIO)';
    }
    return null;
  }
  const proxUtil = (d, comarca, av) => { let x = mais(d, 1); while (motivoNaoUtil(x, comarca, av)) x = mais(x, 1); return x; };

  // modo 'inicio': data = dia do começo (leitura), excluído. modo 'djen': data = disponibilização.
  function calcular(dias, modo, dataTxt, comarca) {
    comarca = comarca === undefined ? 'assis chateaubriand' : comarca;
    const avisos = new Set();
    const base = parse(dataTxt);
    if (!base) return null;
    let inicio = base, publicacao = null;
    if (modo === 'djen') { publicacao = proxUtil(base, comarca, avisos); inicio = publicacao; }
    let d = inicio, n = 0;
    const pulados = [], recesso = [];
    while (n < dias) {
      d = mais(d, 1);
      const m = motivoNaoUtil(d, comarca, avisos);
      if (m) { if (/^Recesso/.test(m)) recesso.push(d); else if (m !== 'Final de semana') pulados.push(br(d) + ' — ' + m); }
      else n++;
    }
    if (recesso.length) pulados.push(br(recesso[0]) + ' a ' + br(recesso[recesso.length - 1]) + ' — Recesso, prazos suspensos (art. 220 CPC)');
    return {
      modo, dias, disponibilizacao: modo === 'djen' ? br(base) : '', publicacao: publicacao ? br(publicacao) : '',
      inicio: br(inicio), vencimento: br(d), vencimentoData: d, diaSemana: DIAS[d.getDay()], pulados,
      avisos: [...avisos].sort().map(a => 'Calendário ' + a + ' não oficial: feriados estimados; conferir com o Decreto Judiciário do TJPR.'),
      link: 'https://claude.ai/artifact/C5dzv1anpXiBJSRzVwhgxC?dias=' + dias + '&modo=' + modo + '&data=' + dataTxt
    };
  }
  return { calcular, parse, br, proxUtil, motivoNaoUtil };
})();
