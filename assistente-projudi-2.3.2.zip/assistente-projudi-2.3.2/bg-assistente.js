/* Assistente PROJUDI - módulo Alvará: copia os dados da tela "Detalhes do Alvará Eletrônico"
   e preenche o formulário de novo alvará (alvaraEletronicoForm), exceto a conta judicial. */
const dormir = ms => new Promise(r => setTimeout(r, ms));
const ERRO_NAV = /destroyed|navigat|unload|was removed|no frame with id|frame with id|no tab with id|context invalidated/i;
let ativo = false, interromper = false, registro = [], abaEmUso = null;

function avisar(msg) {
  try { const r = chrome.runtime.sendMessage(msg); if (r && r.catch) r.catch(() => {}); } catch (e) {}
  if (abaEmUso != null) {
    try { const r = chrome.tabs.sendMessage(abaEmUso, msg, { frameId: 0 }); if (r && r.catch) r.catch(() => {}); } catch (e) {}
  }
}
function log(texto) { registro.push(texto); avisar({ tipo: 'log', texto }); }

/* ======================================================================
   Função injetada na página (em cada frame). Precisa ser autocontida.
   ====================================================================== */
function acaoNaPagina(acao, a) {
  const semAcento = s => String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const N = s => semAcento(s).toUpperCase().replace(/[^A-Z0-9]+/g, ' ').trim();
  const dig = s => String(s == null ? '' : s).replace(/\D/g, '');
  const porNome = n => document.querySelector('[name="' + n + '"]') || document.getElementById(n);
  const disparar = (el, ...evs) => evs.forEach(e => el.dispatchEvent(new Event(e, { bubbles: true })));
  const textoDe = el => (el.innerText != null ? el.innerText : el.textContent) || el.value || '';
  const ok = info => ({ status: 'ok', info: info || '' });
  const nao = () => ({ status: 'nao' });
  const erro = info => ({ status: 'erro', info });

  const escolherOpcao = (sel, alvos, reserva, codigo) => {
    const ops = Array.from(sel.options).filter(o => o.value !== '' && !/^SELECIONE/.test(N(o.text)));
    let melhor = null, nota = 0;
    for (const o of ops) {
      const t = N(o.text);
      let s = 0;
      if (codigo && new RegExp('(^| )0*' + codigo + '( |$)').test(t)) s = 95;
      for (const alvo of alvos || []) {
        const x = N(alvo);
        if (!x) continue;
        if (t === x) s = Math.max(s, 100);
        else if (t.length >= 3 && x.length >= 3 && (t.includes(x) || x.includes(t))) s = Math.max(s, 85);
        else {
          const pal = x.split(' ').filter(w => w.length > 2);
          if (pal.length) {
            const tp = t.split(' ');
            s = Math.max(s, Math.round(70 * pal.filter(w => tp.includes(w)).length / pal.length));
          }
        }
      }
      if (s > nota) { nota = s; melhor = o; }
    }
    if ((!melhor || nota < 55) && reserva) {
      const o = ops.find(op => reserva.includes(op.value));
      if (o) return o;
    }
    return melhor && nota >= 55 ? melhor : null;
  };

  const ler = () => {
    const txt = (document.body.innerText || document.body.textContent || '').replace(/\u00a0/g, ' ');
    if (!/Detalhes do Alvar/i.test(txt)) return nao();
    const campo = rot => {
      const m = new RegExp('(?:^|\\n)[ \\t]*' + rot + '[ \\t]*:[ \\t]*\\n?[ \\t]*([^\\n]*)', 'i').exec(txt);
      return m ? m[1].trim() : '';
    };
    const pessoa = s => {
      const m = /^\(([^)]+)\)\s*(.*?)\s*CPF\/CNPJ:\s*([\d.\/-]+)/i.exec(s);
      return m ? { tipo: m[1].trim(), nome: m[2].trim(), documento: m[3].trim() } : { tipo: '', nome: s, documento: '' };
    };
    const numDv = s => {
      const m = /^([^\s]+)\s*(?:DV:\s*([^\s]*))?/i.exec(s || '');
      return m ? { numero: m[1].replace(/DV:?$/i, ''), dv: (m[2] || '').trim() } : { numero: '', dv: '' };
    };
    const banco = campo('Banco \\(Cr[eé]dito\\)');
    const mb = /^(.*?)\(\s*(\d+)\s*\)/.exec(banco);
    const adv = campo('Advogado');
    const ma = /^(.*?)\s+OAB:\s*(\S+)\s+CPF:\s*([\d.\-]+)/i.exec(adv);
    const mod = /Detalhes do Alvar[aá] Eletr[oô]nico\s*-\s*([^\n]+)/i.exec(txt);
    const proc = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/.exec(campo('Processo'));
    const valor = /R\$\s*[\d.,]+/.exec(campo('Valor Total'));
    return ok({
      processo: proc ? proc[0] : '',
      numero: campo('N[uú]mero'),
      modalidade: mod ? mod[1].trim() : '',
      natureza: campo('Natureza do Alvar[aá]'),
      magistrado: campo('Magistrado'),
      urgente: /^sim/i.test(campo('Urgente')),
      beneficiario: pessoa(campo('Benefici[aá]rio')),
      representacao: campo('Representa[cç][aã]o Processual \\(Benefici[aá]rio\\)').replace(/\s*\(.*$/, '').trim(),
      advogado: ma ? { nome: ma[1].trim(), oab: ma[2].trim(), cpf: ma[3].trim() } : { nome: adv.replace(/\s*\(.*$/, '').trim(), oab: '', cpf: '' },
      sacador: pessoa(campo('Sacador principal')),
      finalidade: campo('Finalidade do Pagamento'),
      tipoCredito: campo('Tipo de Cr[eé]dito'),
      banco: mb ? { nome: mb[1].trim(), codigo: mb[2] } : { nome: banco, codigo: '' },
      agencia: numDv(campo('Ag[eê]ncia \\(Cr[eé]dito\\)')),
      conta: numDv(campo('Conta \\(Cr[eé]dito\\)')),
      operacao: campo('Opera[cç][aã]o \\(Cr[eé]dito\\)'),
      valorTotal: valor ? valor[0] : ''
    });
  };

  switch (acao) {
    case 'ler': return ler();

    case 'temForm': {
      const s = porNome('naturezaAlvara') || porNome('codModalidade');
      return s && s.tagName === 'SELECT' ? ok() : nao();
    }

    case 'select': {
      const el = a.nomes.map(porNome).find(e => e && e.tagName === 'SELECT');
      if (!el) return nao();
      const o = escolherOpcao(el, a.alvos, a.reserva, a.codigo);
      if (!o) return erro('nenhuma opção corresponde a "' + a.alvos.filter(Boolean).join(' / ') + '"');
      if (el.value !== o.value) { el.focus(); el.value = o.value; disparar(el, 'input', 'change'); }
      return ok(o.text.trim());
    }

    case 'texto': {
      const el = a.nomes.map(porNome).find(e => e && /^(INPUT|TEXTAREA)$/.test(e.tagName));
      if (!el) return nao();
      el.focus();
      el.value = a.valor;
      disparar(el, 'input', 'change');
      el.dispatchEvent(new Event('blur'));
      return ok(a.valor);
    }

    case 'radio': {
      const el = document.getElementById(a.id);
      if (!el) return nao();
      if (!el.checked) el.click();
      return ok();
    }

    case 'clicarId': {
      const el = document.getElementById(a.id) || porNome(a.id);
      if (!el) return nao();
      el.click();
      return ok();
    }

    case 'clicarTexto': {
      const alvo = N(a.texto);
      const lista = Array.from(document.querySelectorAll(a.seletor || 'a, span, input[type="button"], button'))
        .filter(e => { const t = N(textoDe(e)); return a.exato ? t === alvo : t.startsWith(alvo); });
      const el = lista[(a.pos || 1) - 1];
      if (!el) return nao();
      el.click();
      return ok();
    }

    case 'temJanelaSacador': {
      // A janela "Seleção de Beneficiário/Sacador" está carregada neste documento?
      const temTipo = !!porNome('codTipoSacadorFiltro') || Array.from(document.querySelectorAll('select')).some(s => {
        const t = Array.from(s.options).map(o => N(o.text));
        return t.some(x => /^PARTE\b/.test(x)) && t.some(x => /^ADVOGAD/.test(x));
      });
      const temLista = !!document.querySelector('input[name="idSacadorSelecao"]');
      const temTitulo = /SELECAO DE (BENEFICIARIO|SACADOR)/.test(N(textoDe(document.body || document.documentElement)));
      return (temTipo || temLista || temTitulo) ? ok(location.href.replace(/\?.*$/, '').split('/').pop()) : nao();
    }

    case 'modalFiltro': {
      // Campo "Tipo" da janela "Seleção de Beneficiário/Sacador...": pelo nome conhecido ou, se o
      // PROJUDI tiver mudado o nome, por ser a lista cujas opções incluem Parte e Advogado.
      let sel = porNome('codTipoSacadorFiltro');
      if (!sel || sel.tagName !== 'SELECT') {
        sel = Array.from(document.querySelectorAll('select')).find(s => {
          const t = Array.from(s.options).map(o => N(o.text));
          return t.some(x => /^PARTE\b/.test(x)) && t.some(x => /^ADVOGAD/.test(x));
        }) || null;
      }
      if (!sel) {
        const temJanela = /SELECAO DE (BENEFICIARIO|SACADOR)/.test(N(textoDe(document.body)));
        return { status: 'nao', info: temJanela ? 'janela aberta, mas sem o campo Tipo reconhecível' : '' };
      }
      const o = escolherOpcao(sel, a.alvos, a.reserva);
      if (!o) return erro('tipo "' + a.alvos.join(' / ') + '" não encontrado no filtro');
      if (sel.value !== o.value) { sel.value = o.value; disparar(sel, 'input', 'change'); }
      if (a.cnpjSociedade) {
        const c = porNome('cnpjSociedadeAdvogados');
        if (c) { c.value = dig(a.cnpjSociedade); disparar(c, 'input', 'change'); }
      }
      const raiz = sel.form || document;
      const botoes = Array.from(raiz.querySelectorAll('input[type="submit"], input[type="button"], button'));
      const b = botoes.find(x => N(x.value || x.textContent) === 'FILTRAR') || botoes.find(x => /submit/i.test(x.type));
      if (!b) return erro('botão Filtrar não encontrado');
      b.click();
      return ok(o.text.trim());
    }

    case 'modalEscolher': {
      let radios = Array.from(document.querySelectorAll('input[name="idSacadorSelecao"]'));
      // Nome do campo mudou? Usa os botões de rádio da lista da janela de seleção.
      if (!radios.length && /SELECAO DE (BENEFICIARIO|SACADOR)/.test(N(textoDe(document.body))))
        radios = Array.from(document.querySelectorAll('input[type="radio"]')).filter(r => /CPF|CNPJ|\d{11}/.test(N(textoDe(r.closest('tr') || r.parentElement))));
      if (!radios.length) return { status: 'nao', info: 'a lista de nomes não carregou (filtro sem resultado)' };
      const d = dig(a.documento), nm = N(a.nome);
      const linhaDe = r => r.closest('tr') || r.parentElement;
      let candidatos = radios;
      if (a.polo) {
        // Ex.: "FULANO DE TAL (Exequente) (CPF: ...)". Polo ativo: qualquer um dos termos informados.
        const termos = (Array.isArray(a.polo) ? a.polo : [a.polo]).map(N);
        const doPolo = r => { const t = ' ' + N(textoDe(linhaDe(r))) + ' '; return termos.some(P => t.includes(' ' + P + ' ')); };
        candidatos = radios.filter(doPolo);
        if (!candidatos.length) return { status: 'nao', info: 'a lista tem ' + radios.length + ' nome(s), nenhum do polo ativo (' + termos.join(', ').toLowerCase() + ')' };
      }
      let alvo = null;
      if (a.regraAdvogado) {
        // Sacador advogado: o único da lista; havendo vários, o primeiro ligado à parte beneficiária.
        const linhaTxt = r => N(textoDe(linhaDe(r)));
        const rel = N(a.relacionado);
        const palavras = rel.split(' ').filter(w => w.length > 2);
        // Sempre o advogado ligado ao beneficiário selecionado.
        if (rel) alvo = candidatos.find(r => linhaTxt(r).includes(rel));
        if (!alvo && palavras.length) alvo = candidatos.find(r => { const t = linhaTxt(r).split(' '); return palavras.every(w => t.includes(w)); });
        // Lista sem indicação de cliente e com um só advogado: é ele.
        if (!alvo && candidatos.length === 1) alvo = candidatos[0];
        if (!alvo) return erro('há ' + candidatos.length + ' advogados na lista e nenhum ligado a "' + a.relacionado + '"; selecione manualmente');
      }
      if (!alvo && candidatos.length === 1 && a.polo) alvo = candidatos[0];
      if (!alvo && d) alvo = candidatos.find(r => dig(textoDe(linhaDe(r))).includes(d));
      if (!alvo && nm) alvo = candidatos.find(r => N(textoDe(linhaDe(r))).includes(nm));
      if (!alvo && a.polo) alvo = candidatos[0];
      if (!alvo) return erro('"' + a.nome + '" não está na lista; selecione manualmente');
      const rotuloEscolhido = (textoDe(linhaDe(alvo)) || '').trim().replace(/\s+/g, ' ');
      alvo.click();
      if (!alvo.checked) { alvo.checked = true; }
      disparar(alvo, 'change');
      const b = porNome('btnSelecionar') || Array.from(document.querySelectorAll('input[type="button"], input[type="submit"], button')).find(x => N(x.value || x.textContent) === 'SELECIONAR');
      if (!b) return erro('botão Selecionar não encontrado; confirme manualmente');
      b.click();
      return ok(rotuloEscolhido || a.nome);
    }

    case 'dataHoje': {
      // Preenche "Data de Atualização (Saldo)" com a data de hoje, sem depender do calendário.
      const d = new Date();
      const hoje = String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear();
      const ehCampo = e => e && e.tagName === 'INPUT' && !/^(hidden|button|submit|radio|checkbox|image)$/i.test(e.type);
      let inp = null;
      const cal = document.getElementById('calDataAtualizacao');
      if (cal) {
        const cel = cal.closest('td') || cal.parentElement;
        inp = cel && Array.from(cel.querySelectorAll('input')).find(ehCampo);
        if (!inp) { const tr = cal.closest('tr'); inp = tr && Array.from(tr.querySelectorAll('input')).find(ehCampo); }
      }
      if (!inp) {
        const tr = Array.from(document.querySelectorAll('tr')).find(t => {
          const c = t.querySelector('td, th');
          return c && N(textoDe(c)).startsWith('DATA DE ATUALIZACAO');
        });
        inp = tr && Array.from(tr.querySelectorAll('input')).find(ehCampo);
      }
      if (!inp) return nao();
      inp.focus();
      inp.value = hoje;
      disparar(inp, 'input', 'change');
      inp.dispatchEvent(new Event('blur'));
      return ok(hoje);
    }

    case 'clicarLupa': {
      // Clica na lupa da linha cujo rótulo começa com a.rotulo (ex.: "Beneficiário", "Sacador principal").
      if (window !== window.top) return nao();
      // 1º: o link que chama openDialog na linha do campo oculto (idBeneficiario / idSacador).
      if (a.campo) {
        const campo = porNome(a.campo);
        const linha = campo && campo.closest('tr');
        const lnk = linha && Array.from(linha.querySelectorAll('a, input[type="button"], input[type="image"], button, img'))
          .find(e => /openDialog/i.test((e.getAttribute('href') || '') + ' ' + (e.getAttribute('onclick') || '')));
        if (lnk) { lnk.click(); return ok('openDialog'); }
      }
      const alvo = N(a.rotulo);
      const tr = Array.from(document.querySelectorAll('tr')).find(t => {
        const c = t.querySelector('td, th');
        return c && N(textoDe(c)).startsWith(alvo);
      });
      if (!tr) return nao();
      const rotuloCel = tr.querySelector('td, th');
      const desc = e => [e.getAttribute('src'), e.getAttribute('title'), e.getAttribute('alt'), e.getAttribute('onclick'),
        e.getAttribute('class'), e.getAttribute('id'), e.getAttribute('href')].join(' ') +
        Array.from(e.querySelectorAll('img')).map(i => ' ' + i.getAttribute('src') + ' ' + i.getAttribute('title') + ' ' + i.getAttribute('alt')).join('');
      const EH_LUPA = /lupa|search|pesquis|busca|buscar|sele[cç]|lookup|find|localiz|zoom/i;
      const NAO_LUPA = /borracha|eraser|limpa|clear|apaga|delete|remov|excluir|copiar/i;
      const clicaveis = Array.from(tr.querySelectorAll('a, input[type="image"], input[type="button"], button, img'))
        .filter(e => !rotuloCel.contains(e))
        .filter(e => !(e.tagName === 'IMG' && e.closest('a')))   // a imagem dentro de link: clica no link
        .filter(e => !NAO_LUPA.test(desc(e)));
      const el = clicaveis.find(e => /openDialog/i.test(desc(e))) || clicaveis.find(e => EH_LUPA.test(desc(e))) || clicaveis[0];
      if (!el) return nao();
      el.click();
      return ok();
    }

    case 'campoPorRotulo': {
      // Valor do campo da linha cujo rótulo começa com a.rotulo (ex.: "Conta Judicial", "Valor a pagar").
      if (window !== window.top) return nao();
      const alvo = N(a.rotulo);
      const tr = Array.from(document.querySelectorAll('tr')).find(t => {
        const c = t.querySelector('td, th');
        return c && N(textoDe(c)).startsWith(alvo);
      });
      const inp = tr && Array.from(tr.querySelectorAll('input, textarea')).find(e => !/^(hidden|button|submit|radio|checkbox|image)$/i.test(e.type || ''));
      if (!inp) return nao();
      const v = String(inp.value || '').trim();
      return a.exigirValor && !v ? nao() : ok(v);
    }

    case 'lerProcesso': {
      if (window !== window.top) return nao();
      const m = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/.exec(textoDe(document.body));
      return m ? ok(m[0]) : nao();
    }

    case 'destacar': {
      if (window !== window.top) return nao();
      const CORES = { amarelo: ['#e0a000', '#fff4c2'], azul: ['#1a73e8', '#e6f0ff'] };
      document.querySelectorAll('[data-copiar-alvara]').forEach(e => {
        e.style.outline = ''; e.style.outlineOffset = ''; e.style.backgroundColor = ''; e.removeAttribute('data-copiar-alvara');
      });
      const linhaPorRotulo = rot => Array.from(document.querySelectorAll('tr')).find(t => {
        const c = t.querySelector('td, th');
        return c && N(textoDe(c)).startsWith(N(rot));
      });
      let primeiro = null, total = 0;
      (a.itens || []).forEach(it => {
        const els = [];
        (it.nomes || []).forEach(n => { const e = porNome(n); if (e) els.push(e); });
        if (it.id) { const e = document.getElementById(it.id); if (e) els.push(e.closest('td') || e); }
        if (it.rotulo) {
          const tr = linhaPorRotulo(it.rotulo);
          if (tr) {
            const cel = tr.querySelector('td, th');
            const campo = Array.from(tr.querySelectorAll('input, select, textarea'))
              .find(e => !cel.contains(e) && !/^(hidden|button|submit|image)$/i.test(e.type || ''));
            els.push(campo || tr);
          }
        }
        els.forEach(e => {
          const [borda, fundo] = CORES[it.cor] || CORES.amarelo;
          e.style.outline = '3px solid ' + borda; e.style.outlineOffset = '1px'; e.style.backgroundColor = fundo;
          e.setAttribute('data-copiar-alvara', '1');
          if (it.dica) e.title = it.dica;
          const limpar = () => { e.style.outline = ''; e.style.backgroundColor = ''; e.removeAttribute('data-copiar-alvara'); };
          e.addEventListener('change', limpar, { once: true });
          total++; primeiro = primeiro || e;
        });
      });
      if (primeiro && a.rolar) primeiro.scrollIntoView({ block: 'center' });
      return ok(String(total));
    }

    case 'textoDaLinha': {
      // Texto da linha onde está o botão (para ler a resposta do "Verificar Conta").
      if (window !== window.top) return nao();
      const b = Array.from(document.querySelectorAll('input[type="button"], input[type="submit"], button'))
        .find(e => N(textoDe(e)) === N(a.botao));
      if (!b) return nao();
      const tr = b.closest('tr');
      const t = (tr ? textoDe(tr) : textoDe(b.parentElement)).replace(/\s+/g, ' ').trim();
      return ok(t.replace(textoDe(b).trim(), '').trim());
    }

    case 'escolherContaHistorico': {
      // Janela "Histórico de contas do Sacador" (abre em iframe): escolhe a primeira conta da lista.
      if (window === window.top) return nao();
      const radios = Array.from(document.querySelectorAll('input[type="radio"]')).filter(r => r.name !== 'idSacadorSelecao');
      if (radios.length) {
        const r = radios[0];
        r.click(); r.checked = true; disparar(r, 'change');
        const info = textoDe(r.closest('tr') || r.parentElement).replace(/\s+/g, ' ').trim();
        const b = Array.from(document.querySelectorAll('input[type="button"], input[type="submit"], button'))
          .find(e => /^(SELECIONAR|CONFIRMAR|OK|ESCOLHER|UTILIZAR|USAR)/.test(N(textoDe(e))));
        if (b) b.click();
        return ok(info);
      }
      if (document.querySelector('input[name="idSacadorSelecao"]')) return nao();
      const linhas = Array.from(document.querySelectorAll('tr')).filter(tr => tr.querySelector('a') && /\d{4,}/.test(textoDe(tr)));
      if (!linhas.length) return nao();
      const info = textoDe(linhas[0]).replace(/\s+/g, ' ').trim();
      linhas[0].querySelector('a').click();
      return ok(info);
    }

    case 'temTexto': {
      if (window !== window.top) return nao();
      return N(textoDe(document.body)).includes(N(a.texto)) ? ok() : nao();
    }

    case 'escolherAdvogado': {
      const cpf = dig(a.cpf), oab = dig(a.oab), nm = N(a.nome);
      const casa = t => (cpf && dig(t).includes(cpf)) || (oab && dig(t).includes(oab)) || (nm && N(t).includes(nm));
      for (const sel of document.querySelectorAll('select')) {
        const o = Array.from(sel.options).find(op => op.value !== '' && casa(op.text));
        if (o) { if (sel.value !== o.value) { sel.value = o.value; disparar(sel, 'change'); } return ok(o.text.trim()); }
      }
      for (const inp of document.querySelectorAll('input[type="radio"], input[type="checkbox"]')) {
        if (inp.name === 'idSacadorSelecao') continue;
        const linha = inp.closest('tr');
        if (linha && casa(textoDe(linha))) { if (!inp.checked) inp.click(); return ok(a.nome); }
      }
      return nao();
    }
  }
  return erro('ação desconhecida: ' + acao);
}

/* ======================================================================
   Orquestração (roda no fundo, passo a passo)
   ====================================================================== */
async function esperarAba(tabId, seg) {
  const fim = Date.now() + seg * 1000;
  await dormir(250);
  while (Date.now() < fim && !interromper) {
    try { const t = await chrome.tabs.get(tabId); if (t.status === 'complete') return; } catch (e) { return; }
    await dormir(200);
  }
}

// Executa a ação em todos os frames até um deles responder "ok" ou "erro".
// mundo 'MAIN': roda no contexto da própria página. Necessário para clicar em links
// "javascript:..." (ex.: a lupa, que chama openDialog): no contexto isolado da extensão
// o Chrome bloqueia esse tipo de link e a janela de seleção não abre.
async function rodar(tabId, acao, args, { segundos = 10, clique = false, mundo = 'ISOLATED' } = {}) {
  const fim = Date.now() + segundos * 1000;
  let ultimaInfo = '';
  while (!interromper) {
    try {
      const rs = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: acaoNaPagina, args: [acao, args || {}], world: mundo });
      const res = (rs || []).map(r => r && r.result).filter(Boolean);
      const info = res.find(r => r.status === 'nao' && r.info);
      if (info) ultimaInfo = info.info;
      const bom = res.find(r => r.status === 'ok');
      if (bom) { await dormir(500); await esperarAba(tabId, 30); return bom; }
      const ruim = res.find(r => r.status === 'erro');
      if (ruim) return ruim;
    } catch (e) {
      const msg = (e && e.message) || String(e);
      if (/permission|cannot access|missing host/i.test(msg)) return { status: 'erro', info: 'sem acesso ao site (conceda acesso no menu da extensão)', fatal: true };
      if (ERRO_NAV.test(msg)) { await esperarAba(tabId, 30); if (clique) return { status: 'ok' }; }
    }
    if (Date.now() > fim) return { status: 'nao', info: ultimaInfo };
    await dormir(400);
  }
  return { status: 'erro', info: 'interrompido', fatal: true };
}

async function noTopo(tabId, func, args, world) {
  const rs = await chrome.scripting.executeScript({ target: { tabId }, func, args: args || [], world: world || 'ISOLATED' });
  return rs && rs[0] ? rs[0].result : undefined;
}

async function confirmarNaPagina(tabId, texto) {
  try { return !!(await noTopo(tabId, t => window.confirm(t), [texto])); } catch (e) { return false; }
}

/* ---------- validade dos dados copiados: só valem no dia em que foram copiados ---------- */
async function dadosValidos() {
  const st = await chrome.storage.local.get(['alvaraCopiado', 'copiadoEm']);
  if (!st.alvaraCopiado) return { dados: null, expirou: false };
  const dia = st.copiadoEm ? new Date(st.copiadoEm).toDateString() : '';
  if (dia !== new Date().toDateString()) {
    await chrome.storage.local.remove(['alvaraCopiado', 'copiadoEm']);
    return { dados: null, expirou: true };
  }
  return { dados: st.alvaraCopiado, expirou: false, copiadoEm: st.copiadoEm };
}

function tipoFiltro(tipo) {
  const t = String(tipo || '').toUpperCase();
  if (t.includes('SOCIEDADE')) return { alvos: ['Sociedade de Advogados'], reserva: ['5'], sociedade: true };
  if (t.includes('ADVOGAD')) return { alvos: ['Advogado'], reserva: ['3'] };
  if (t.includes('PARTE')) return { alvos: ['Parte'], reserva: ['1'] };
  return { alvos: [tipo], reserva: null };
}

let pendencias = [];
function pendente(item) { pendencias.push(item); }

const POLO_ATIVO = ['Exequente', 'Autor', 'Autora', 'Ativo', 'Ativa', 'Polo Ativo'];

async function selecionarPessoa(tabId, pos, p, rotulo, regra) {
  const rotuloCampo = pos === 1 ? 'Beneficiário' : 'Sacador principal';
  const falhou = msg => { log('⚠ ' + rotulo + ': ' + msg); pendente({ rotulo: rotuloCampo, dica: msg }); return ''; };
  if (!p || !p.nome) return '';
  const f = regra && regra.tipo ? tipoFiltro(regra.tipo) : tipoFiltro(p.tipo);
  const campoOculto = pos === 1 ? 'idBeneficiario' : 'idSacador';
  // A lupa é um link "javascript:openDialog(...)": o clique tem de ser feito no contexto da página.
  let r = await rodar(tabId, 'clicarLupa', { rotulo: rotuloCampo, campo: campoOculto }, { clique: true, segundos: 8, mundo: 'MAIN' });
  if (r.status !== 'ok') r = await rodar(tabId, 'clicarTexto', { texto: 'Seleção de Beneficiário', pos, seletor: 'a' }, { clique: true, segundos: 3, mundo: 'MAIN' });
  if (r.status !== 'ok') return falhou('lupa do campo "' + rotuloCampo + '" não encontrada');
  log('   ' + rotulo + ': lupa acionada');
  r = await rodar(tabId, 'modalFiltro', { alvos: f.alvos, reserva: f.reserva, cnpjSociedade: f.sociedade ? p.documento : '' }, { clique: true, segundos: 20 });
  if (r.status !== 'ok') {
    // Diagnóstico para ajuste: quais frames existem e quais listas cada um tem.
    try {
      const rs = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: () => ({
        url: location.href.replace(/\?.*$/, ''), titulo: (document.title || '').slice(0, 40),
        listas: Array.from(document.querySelectorAll('select')).map(s => (s.name || s.id || '?') + '[' + Array.from(s.options).slice(0, 3).map(o => o.text.trim()).join('|') + ']').slice(0, 6)
      }) });
      log('   diagnóstico: ' + (rs || []).map(x => x.result && (x.result.url.split('/').pop() + ' ' + x.result.listas.join(', '))).filter(Boolean).join(' || '));
    } catch (e) { log('   diagnóstico indisponível: ' + ((e && e.message) || e)); }
  }
  if (r.status !== 'ok') return falhou(r.info || 'o campo Tipo da janela não apareceu');
  log('   ' + rotulo + ': filtro "' + (r.info || f.alvos[0]) + '" aplicado');
  await dormir(1500);
  r = await rodar(tabId, 'modalEscolher', {
    documento: p.documento, nome: p.nome, polo: regra && regra.polo,
    regraAdvogado: !!(regra && regra.regraAdvogado), relacionado: regra && regra.relacionado
  }, { clique: true, segundos: 20 });
  if (r.status !== 'ok') return falhou(r.info || 'pessoa não encontrada na lista; selecione manualmente');
  log('✔ ' + rotulo + ': ' + (r.info || p.nome));
  const escolhido = String(r.info || p.nome).replace(/\s*\(.*$/, '').trim();
  const conf = await rodar(tabId, 'temTexto', { texto: escolhido }, { segundos: 8 });
  if (conf.status !== 'ok') { log('⚠ ' + rotulo + ': "' + escolhido + '" foi marcado, mas não apareceu no formulário; confira'); pendente({ rotulo: rotuloCampo }); }
  return escolhido;
}

// Passo simples; se falhar, o campo é marcado em amarelo na tela.
async function passo(tabId, rotulo, acao, args, opc, destaque) {
  if (interromper) return { status: 'erro' };
  const r = await rodar(tabId, acao, args, opc);
  if (r.status === 'ok') log('✔ ' + rotulo + (r.info ? ': ' + r.info : ''));
  else {
    const msg = r.info || 'campo não encontrado';
    log('⚠ ' + rotulo + ': ' + msg);
    const alvo = destaque || (args && args.nomes ? { nomes: args.nomes } : args && args.id ? { id: args.id } : null);
    if (alvo) pendente(Object.assign({ dica: rotulo + ': ' + msg }, alvo));
  }
  return r;
}

async function verificarConta(tabId) {
  // Captura o alert() que a página costuma mostrar com o resultado, sem travar a execução.
  try {
    await noTopo(tabId, () => {
      window.__caMsgs = [];
      if (!window.__caAlertOriginal) window.__caAlertOriginal = window.alert;
      window.alert = m => { window.__caMsgs.push(String(m)); };
    }, [], 'MAIN');
  } catch (e) {}
  const b = await rodar(tabId, 'clicarTexto', { texto: 'Verificar Conta', exato: true, seletor: 'input[type="button"], input[type="submit"], button, a' }, { clique: true, segundos: 5 });
  if (b.status !== 'ok') { log('⚠ Verificar Conta: botão não encontrado'); return; }
  let msgs = [];
  const fim = Date.now() + 8000;
  while (Date.now() < fim && !interromper) {
    await dormir(700);
    try { msgs = (await noTopo(tabId, () => window.__caMsgs || [], [], 'MAIN')) || []; } catch (e) {}
    if (msgs.length) break;
  }
  try { await noTopo(tabId, () => { if (window.__caAlertOriginal) window.alert = window.__caAlertOriginal; }, [], 'MAIN'); } catch (e) {}
  let texto = msgs.join(' | ').replace(/\s+/g, ' ').trim();
  if (!texto) { const t = await rodar(tabId, 'textoDaLinha', { botao: 'Verificar Conta' }, { segundos: 2 }); texto = t.status === 'ok' ? t.info : ''; }
  if (!texto) { log('✔ Verificar Conta acionado; confira o resultado na tela.'); return; }
  const ruim = /inv[aá]lid|erro|n[aã]o (foi|confere|encontrad|existe)|incorret|diverg|inexist/i.test(texto);
  log((ruim ? '⚠ ' : '✔ ') + 'Verificar Conta: ' + texto);
  if (ruim) pendente({ nomes: ['codBancoCredito', 'numeroAgencia', 'dvAgencia', 'numeroConta', 'dvConta'], dica: texto });
}

async function contaPeloHistorico(tabId) {
  const falhou = msg => {
    log('⚠ Conta de crédito: ' + msg);
    pendente({ nomes: ['codBancoCredito', 'numeroAgencia', 'numeroConta', 'dvConta'], dica: 'Informe a conta de crédito' });
    return false;
  };
  const h = await rodar(tabId, 'clicarTexto', { texto: 'Histórico de contas do Sacador', exato: true, seletor: 'input[type="button"], button, a, span' }, { clique: true, segundos: 5, mundo: 'MAIN' });
  if (h.status !== 'ok') return falhou('botão "Histórico de contas do Sacador" não encontrado; informe banco, agência e conta');
  log('   Conta de crédito: histórico do sacador aberto');
  await dormir(1500);
  const c = await rodar(tabId, 'escolherContaHistorico', {}, { clique: true, segundos: 10 });
  if (c.status !== 'ok') return falhou('nenhuma conta no histórico do sacador; informe banco, agência e conta');
  const conf = await rodar(tabId, 'campoPorRotulo', { rotulo: 'Conta (Crédito)', exigirValor: true }, { segundos: 8 });
  if (conf.status !== 'ok') return falhou('a conta do histórico não chegou ao formulário; confira');
  log('✔ Conta de crédito (histórico do sacador): ' + c.info);
  return true;
}

async function destacarPendencias(tabId, comConta) {
  const itens = pendencias.slice();
  if (comConta) itens.push({ rotulo: 'Conta Judicial', cor: 'azul', dica: 'Selecione a conta judicial' });
  try { await rodar(tabId, 'destacar', { itens, rolar: pendencias.length > 0 }, { segundos: 2 }); } catch (e) {}
}

async function preencher(tabId, d) {
  const Z = !!d.doZero;   // sem alvará copiado: valores padrão das macros do iMacros
  const R = v => (Z ? v : null);
  pendencias = [];
  log(Z ? '▶ Preenchendo do zero com as regras padrão.'
        : '▶ Preenchendo com os dados do alvará ' + (d.numero || '') + (d.processo ? ' (proc. ' + d.processo + ')' : ''));
  const chk = await rodar(tabId, 'temForm', {}, { segundos: 4 });
  if (chk.status !== 'ok') { log('✖ Esta aba não está na tela de novo alvará eletrônico.'); return; }
  await rodar(tabId, 'destacar', { itens: [] }, { segundos: 2 });

  // Trava de processo: os dados copiados só entram nos mesmos autos, salvo confirmação.
  if (!Z && d.processo) {
    const t = await rodar(tabId, 'lerProcesso', {}, { segundos: 3 });
    const igual = t.status === 'ok' && t.info.replace(/\D/g, '') === d.processo.replace(/\D/g, '');
    if (!igual) {
      const pergunta = t.status === 'ok'
        ? 'ATENÇÃO: os dados copiados são do processo ' + d.processo + ', mas esta tela é do processo ' + t.info + '.\n\nPreencher mesmo assim?'
        : 'Não identifiquei o número do processo nesta tela.\nOs dados copiados são do processo ' + d.processo + '.\n\nPreencher mesmo assim?';
      if (!(await confirmarNaPagina(tabId, pergunta))) { log('■ Preenchimento cancelado: processo diferente do alvará copiado.'); return; }
      log('⚠ Processo: preenchimento confirmado por você' + (t.status === 'ok' ? ' (' + t.info + ')' : ''));
    } else log('✔ Processo conferido: ' + t.info);
  }

  if (d.modalidade || Z) {
    const m = await rodar(tabId, 'select', { nomes: ['codModalidade'], alvos: [d.modalidade || ''], reserva: R(['2']) }, { segundos: 3 });
    if (m.status === 'ok') log('✔ Modalidade: ' + m.info);   // nesta tela a modalidade pode já vir definida
  }
  if (d.magistrado || Z) await passo(tabId, 'Magistrado', 'select', { nomes: ['codMagistrado', 'loginMagistrado'], alvos: [d.magistrado || 'Arthur Araújo de Oliveira'], reserva: R(['aaro.juiz']) });
  await passo(tabId, 'Urgente', 'radio', { id: d.urgente ? 'urgenteTrue' : 'urgenteFalse' }, { segundos: 4 });
  if (d.natureza || Z) await passo(tabId, 'Natureza do alvará', 'select', { nomes: ['naturezaAlvara'], alvos: [d.natureza || 'Pagamento para Reclamante Autor'], reserva: R(['1']) });

  await passo(tabId, 'Data de atualização (saldo)', 'dataHoje', {}, { segundos: 5 }, { rotulo: 'Data de Atualização' });

  // Beneficiário: sempre Tipo "Parte" e a parte do polo ativo (autor/autora, ativo/ativa, exequente).
  const nomeBenef = await selecionarPessoa(tabId, 1, d.beneficiario || { nome: 'Exequente' }, 'Beneficiário', { tipo: 'Parte', polo: POLO_ATIVO });

  // Representação Processual (Beneficiário): sempre Advogado.
  const rep = await passo(tabId, 'Representação processual', 'select', { nomes: ['codRepresentacaoProcessual'], alvos: ['Advogado'], reserva: ['1'] });
  if (rep && rep.status === 'ok') await rodar(tabId, 'clicarId', { id: 'vincButton' }, { segundos: 3, clique: true });

  if (d.finalidade || Z) await passo(tabId, 'Finalidade do pagamento', 'select', { nomes: ['codFinalidadePagamento'], alvos: [d.finalidade || 'Levantamento de demais tipos de depósitos judiciais'], reserva: R(['3']) });
  if (d.tipoCredito || Z) await passo(tabId, 'Tipo de crédito', 'select', { nomes: ['tipoCredito'], alvos: [d.tipoCredito || 'Crédito em conta'], reserva: R(['2']) });

  // Sacador principal: sempre Tipo Advogado, o ligado à parte beneficiária selecionada.
  const benefRef = nomeBenef || (d.beneficiario && d.beneficiario.nome) || '';
  await selecionarPessoa(tabId, 2, { nome: (d.sacador && d.sacador.nome) || 'Advogado', documento: (d.sacador && d.sacador.documento) || '' },
    'Sacador', { tipo: 'Advogado', regraAdvogado: true, relacionado: benefRef });

  if (d.tipoCredito || Z) await rodar(tabId, 'select', { nomes: ['tipoCredito'], alvos: [d.tipoCredito || 'Crédito em conta'], reserva: R(['2']) }, { segundos: 3 });

  let temConta = false;
  if (Z) temConta = await contaPeloHistorico(tabId);
  else if (d.banco && (d.banco.nome || d.banco.codigo)) {
    await passo(tabId, 'Banco', 'select', { nomes: ['codBancoCredito'], alvos: [d.banco.nome], codigo: d.banco.codigo });
    if (d.agencia.numero) await passo(tabId, 'Agência', 'texto', { nomes: ['numeroAgencia'], valor: d.agencia.numero }, { segundos: 5 });
    if (d.agencia.dv) await passo(tabId, 'DV da agência', 'texto', { nomes: ['dvAgencia'], valor: d.agencia.dv }, { segundos: 4 });
    if (d.conta.numero) await passo(tabId, 'Conta', 'texto', { nomes: ['numeroConta'], valor: d.conta.numero }, { segundos: 5 });
    if (d.conta.dv) await passo(tabId, 'DV da conta', 'texto', { nomes: ['dvConta'], valor: d.conta.dv }, { segundos: 4 });
    if (d.operacao) await passo(tabId, 'Operação', 'select', { nomes: ['operacaoConta'], alvos: [d.operacao] }, { segundos: 4 });
    temConta = true;
  }
  if (temConta && !interromper) await verificarConta(tabId);

  if (interromper) { log('■ Interrompido.'); await destacarPendencias(tabId, false); return; }

  // Valor a pagar: não é copiado do alvará anterior. Depois que a conta judicial for selecionada
  // (manualmente), a extensão clica em "Copiar Saldo Total da Conta".
  let conta = await rodar(tabId, 'campoPorRotulo', { rotulo: 'Conta Judicial', exigirValor: true }, { segundos: 2 });
  await destacarPendencias(tabId, conta.status !== 'ok');
  if (pendencias.length) log('⚠ ' + pendencias.length + (pendencias.length === 1 ? ' campo ficou marcado' : ' campos ficaram marcados') + ' em amarelo na tela para conferência.');
  if (conta.status !== 'ok') {
    log('… Selecione agora a conta judicial (em azul na tela). Assim que ela aparecer, clico em "Copiar Saldo Total da Conta" (aguardo até 5 minutos; "Parar" cancela).');
    conta = await rodar(tabId, 'campoPorRotulo', { rotulo: 'Conta Judicial', exigirValor: true }, { segundos: 300 });
  }
  if (interromper) { log('■ Interrompido. O valor a pagar não foi preenchido.'); return; }
  if (conta.status !== 'ok') { log('⚠ A conta judicial não foi selecionada a tempo; clique em "Copiar Saldo Total da Conta" depois de escolhê-la.'); return; }
  log('✔ Conta judicial: ' + conta.info);
  const btn = await passo(tabId, 'Copiar Saldo Total da Conta', 'clicarTexto', { texto: 'Copiar Saldo Total da Conta', exato: true, seletor: 'input[type="button"], input[type="submit"], button' }, { segundos: 6, clique: true });
  if (btn && btn.status === 'ok') {
    const v = await rodar(tabId, 'campoPorRotulo', { rotulo: 'Valor a pagar', exigirValor: true }, { segundos: 8 });
    if (v.status === 'ok') log('✔ Valor a pagar: ' + v.info);
    else { log('⚠ O valor a pagar não apareceu; confira o campo.'); pendente({ rotulo: 'Valor a pagar' }); }
  }
  await destacarPendencias(tabId, false);
  log('✔ Concluído. Confira os campos marcados antes de enviar.');
}

/* ---------- texto para a área de transferência ---------- */
function textoCopia(d) {
  const pessoa = p => p && p.nome ? (p.tipo ? '(' + p.tipo + ') ' : '') + p.nome + (p.documento ? ', ' + p.documento : '') : '';
  const conta = d.banco && (d.banco.nome || d.banco.codigo)
    ? d.banco.nome + (d.banco.codigo ? ' (' + d.banco.codigo + ')' : '') + ', ag. ' + d.agencia.numero + (d.agencia.dv ? '-' + d.agencia.dv : '') +
      ', conta ' + d.conta.numero + (d.conta.dv ? '-' + d.conta.dv : '') + (d.operacao ? ', op. ' + d.operacao : '') : '';
  return 'ALVARÁ ELETRÔNICO - DADOS COPIADOS\n' + [
    ['Processo', d.processo], ['Alvará nº', d.numero], ['Modalidade', d.modalidade], ['Natureza', d.natureza],
    ['Magistrado', d.magistrado], ['Urgente', d.urgente ? 'Sim' : 'Não'], ['Beneficiário', pessoa(d.beneficiario)],
    ['Representação', d.representacao],
    ['Advogado', d.advogado && d.advogado.nome ? d.advogado.nome + (d.advogado.oab ? ', OAB ' + d.advogado.oab : '') : ''],
    ['Sacador', pessoa(d.sacador)], ['Finalidade', d.finalidade], ['Tipo de crédito', d.tipoCredito],
    ['Conta de crédito', conta], ['Valor total', d.valorTotal]
  ].filter(l => l[1]).map(l => l[0] + ': ' + l[1]).join('\n');
}

chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || !msg.cmd) return;
  const tabId = msg.tabId != null ? msg.tabId : (remetente.tab && remetente.tab.id);
  if (msg.cmd === 'copiar') {
    (async () => {
      try {
        const rs = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: acaoNaPagina, args: ['ler', {}] });
        const r = (rs || []).map(x => x && x.result).find(x => x && x.status === 'ok');
        if (!r) { responder({ ok: false, erro: 'Abra a tela "Detalhes do Alvará Eletrônico" antes de copiar.' }); return; }
        await chrome.storage.local.set({ alvaraCopiado: r.info, copiadoEm: Date.now() });
        responder({ ok: true, dados: r.info, texto: textoCopia(r.info) });
      } catch (e) {
        const m = (e && e.message) || String(e);
        responder({ ok: false, erro: /permission|cannot access|missing host/i.test(m) ? 'Sem acesso ao site: clique em "Conceder acesso".' : m });
      }
    })();
    return true;
  }
  if (msg.cmd === 'dados') { dadosValidos().then(responder); return true; }
  if (msg.cmd === 'limpar') { chrome.storage.local.remove(['alvaraCopiado', 'copiadoEm']).then(() => responder({ ok: true })); return true; }
  if (msg.cmd === 'preencher') {
    if (ativo) { responder({ ok: false, erro: 'O preenchimento já está em andamento.' }); return; }
    dadosValidos().then(v => {
      const zero = { doZero: true, urgente: false, banco: {}, agencia: {}, conta: {} };
      if (msg.modo !== 'zero' && !v.dados) {
        responder({ ok: false, erro: v.expirou ? 'Os dados copiados eram de outro dia e foram apagados. Copie o alvará novamente.' : 'Nenhum alvará copiado. Copie um alvará ou use "Preencher do zero".' });
        return;
      }
      const dados = msg.modo === 'zero' ? zero : v.dados;
      ativo = true; interromper = false; registro = []; abaEmUso = tabId;
      preencher(tabId, dados)
        .catch(e => log('✖ ' + ((e && e.message) || e)))
        .finally(() => { ativo = false; avisar({ tipo: 'fim' }); abaEmUso = null; });
      responder({ ok: true });
    });
    return true;
  }
  if (msg.cmd === 'parar') { interromper = true; responder({ ok: true }); return; }
  if (msg.cmd === 'estado') { responder({ ativo, registro }); return; }
});

/* ======================================================================
   Leitor de PDF (Triagem de Juntadas e Retorno de Conclusão):
   carrega o pdf.js na aba só quando uma petição ou decisão precisa ser lida.
   ====================================================================== */
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || msg.cmd !== 'carregarLeitorPdf' || !remetente.tab) return;
  chrome.scripting.executeScript({
    target: { tabId: remetente.tab.id, frameIds: [remetente.frameId || 0] },
    files: ['lib/pdf.worker.min.js', 'lib/pdf.min.js']
  }).then(() => responder({ ok: true }), e => responder({ ok: false, erro: (e && e.message) || String(e) }));
  return true;
});

/* ======================================================================
   Ofícios: PDFs abertos em outras abas e arquivos dos autos (aba do processo).
   ====================================================================== */
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg) return;
  if (msg.cmd === 'listarPdfs') {
    chrome.tabs.query({}).then(abas => {
      responder(abas.filter(t => /^https?:\/\/[^/]*tjpr\.jus\.br\//i.test(t.url || '') && (/\.pdf|arquivo|download/i.test(t.url) || /\.pdf$/i.test(t.title || '')))
        .map(t => ({ id: t.id, titulo: t.title || t.url, url: t.url })));
    }, () => responder([]));
    return true;
  }
  if (msg.cmd === 'arquivosDoProcesso') {
    chrome.tabs.query({}).then(async abas => {
      const candidatas = abas.filter(t => /tjpr\.jus\.br\/projudi/i.test(t.url || '') && (!remetente.tab || t.id !== remetente.tab.id));
      for (const t of candidatas) {
        try {
          const r = await chrome.tabs.sendMessage(t.id, { cmd: 'coletarArquivos', processo: msg.processo, limite: msg.limite }, { frameId: 0 });
          if (r && r.ok) { responder({ ok: true, lista: r.lista, aba: t.title }); return; }
        } catch (e) { /* aba sem o script ou sem resposta */ }
      }
      responder({ ok: false });
    });
    return true;
  }
});

/* ======================================================================
   Alvará (modulos/alvarapdf): clique no mundo da própria página.
   O content script marca o elemento com data-alvara-clique e pede o clique aqui,
   porque links "javascript:" não disparam quando clicados pelo script da extensão.
   ====================================================================== */
chrome.runtime.onMessage.addListener((msg, remetente, responder) => {
  if (!msg || msg.cmd !== 'alvaraClicarMain' || !remetente.tab) return;
  chrome.scripting.executeScript({
    target: { tabId: remetente.tab.id, frameIds: [remetente.frameId || 0] },
    world: 'MAIN',
    func: () => {
      const e = document.querySelector('[data-alvara-clique]');
      if (!e) return false;
      e.removeAttribute('data-alvara-clique');
      e.click();
      return true;
    }
  }).then(rs => responder({ ok: !!(rs && rs[0] && rs[0].result) }))
    .catch(e => responder({ ok: false, erro: (e && e.message) || String(e) }));
  return true;
});
