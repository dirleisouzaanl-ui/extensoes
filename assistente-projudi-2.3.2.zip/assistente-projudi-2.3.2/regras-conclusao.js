/* regras.js - o que procurar no texto da decisão e qual ação do PROJUDI corresponde.
   "acao" é o texto exato do link no quadro "Ações"/"Outras Ações" da tela Movimentar Processo.
   "ultimo: true" marca as ações com (*) no PROJUDI, que bloqueiam o processo e vão para o fim. */
var REGRAS_ATOS = [
  { id: 'alvara', acao: 'Alvará Eletrônico', rotulo: 'Expedir alvará eletrônico',
    se: /EXPE[CÇ]A-SE (O )?ALVARA|EXPEDICAO D[OE] ALVARA|DEFIRO O (PEDIDO DE )?LEVANTAMENTO|LEVANTAMENTO D[OA]S? (VALOR|QUANTIA|DEPOSITO|SALDO)|ALVARA/ },
  { id: 'sisbajud', acao: 'Ordenar Cumprimentos', rotulo: 'SISBAJUD', cumprimento: { tipos: ['SISBAJUD'], polo: 'reu' },
    se: /SISBAJUD|BACENJUD|PENHORA ON ?LINE|BLOQUEIO DE (VALORES|ATIVOS)|TEIMOSINHA/ },
  { id: 'renajud', acao: 'Ordenar Cumprimentos', rotulo: 'RENAJUD', cumprimento: { tipos: ['RENAJUD'], polo: 'reu' }, se: /RENAJUD/ },
  { id: 'infojud', acao: 'Ordenar Cumprimentos', rotulo: 'INFOJUD', cumprimento: { tipos: ['INFOJUD'], polo: 'reu' }, se: /INFOJUD/ },
  { id: 'cnib', acao: 'Ordenar Cumprimentos', rotulo: 'CNIB', cumprimento: { tipos: ['CNIB'], polo: 'reu' }, se: /CNIB|INDISPONIBILIDADE DE BENS/ },
  { id: 'serasajud', acao: 'Ordenar Cumprimentos', rotulo: 'SERASAJUD', cumprimento: { tipos: ['SERASAJUD'], polo: 'reu' }, se: /SERASAJUD|SERASA/ },
  { id: 'infoseg', acao: 'Ordenar Cumprimentos', rotulo: 'Busca INFOSEG', cumprimento: { tipos: ['INFOSEG'], polo: 'reu' }, se: /INFOSEG/ },
  { id: 'siel', acao: 'Ordenar Cumprimentos', rotulo: 'Busca SIEL', cumprimento: { tipos: ['SIEL'], polo: 'reu' }, se: /\bSIEL\b/ },
  { id: 'sniper', acao: 'Ordenar Cumprimentos', rotulo: 'Busca SNIPER', cumprimento: { tipos: ['SNIPER'], polo: 'reu' }, se: /SNIPER/ },
  { id: 'ccs', acao: 'Ordenar Cumprimentos', rotulo: 'Busca CCS', cumprimento: { tipos: ['CCS'], polo: 'reu' }, se: /\bCCS\b|CADASTRO DE CLIENTES DO SISTEMA FINANCEIRO/ },
  { id: 'serpjud', acao: 'Ordenar Cumprimentos', rotulo: 'Busca SERP-JUD', cumprimento: { tipos: ['SERP'], polo: 'reu' }, se: /SERP-?JUD|REGISTRO DE IMOVEIS|BENS IMOVEIS/ },
  { id: 'caged', acao: 'Ordenar Cumprimentos', rotulo: 'Busca CAGED', cumprimento: { tipos: ['CAGED'], polo: 'reu' }, se: /CAGED/ },
  { id: 'censec', acao: 'Ordenar Cumprimentos', rotulo: 'Busca CENSEC', cumprimento: { tipos: ['CENSEC'], polo: 'reu' }, se: /CENSEC/ },
  { id: 'endereco', acao: 'Ordenar Cumprimentos', rotulo: 'Busca de endereço', cumprimento: { tipos: ['ENDERECO'], polo: 'reu' },
    se: /BUSCA DE ENDERECO|PESQUISA DE ENDERECO|PESQUISA DO ENDERECO|LOCALIZACAO D[OA] (REU|REQUERID|EXECUTAD|DEVEDOR)/ },
  { id: 'calculo', acao: 'Ordenar Cumprimentos', rotulo: 'Remeter ao contador (cálculo)', cumprimento: { tipos: ['CALCULO'], polo: null },
    se: /CONTADOR|CONTADORIA|ELABORE-SE O CALCULO|ATUALIZE-SE O CALCULO/ },
  { id: 'protesto', acao: 'Ordenar Cumprimentos', rotulo: 'Protesto', cumprimento: { tipos: ['PROTESTO'], polo: 'reu' }, se: /PROTESTO/ },
  { id: 'certidaodivida', acao: 'Ordenar Cumprimentos', rotulo: 'Certidão de dívida/crédito', cumprimento: { tipos: ['CERTIDAO DE DIVIDA', 'CERTIDAO DE CREDITO'], polo: 'autor' },
    se: /CERTIDAO DE (DIVIDA|CREDITO)/ },
  { id: 'oficio', acao: 'Ordenar Cumprimentos', rotulo: 'Expedir ofício', cumprimento: { tipos: ['OFICIO'], polo: 'reu' },
    se: /OFICIE-SE|OFICIEM-SE|EXPE[CÇ]A-SE OFICIO|EXPEDICAO DE OFICIO|REITERE-SE O OFICIO|DESCONTO EM FOLHA|DESCONTO NO BENEFICIO|PENHORA NO ROSTO/ },
  { id: 'mandado', acao: 'Ordenar Cumprimentos', rotulo: 'Expedir mandado', cumprimento: { tipos: ['MANDADO'], polo: 'reu' },
    se: /EXPE[CÇ]A-SE (O )?MANDADO|EXPEDICAO DE MANDADO|POR MANDADO/ },
  { id: 'citacao', acao: 'Citar Partes', rotulo: 'Citar', se: /CITE-SE|CITEM-SE|PROCEDA-SE A CITACAO/ },
  { id: 'notificar', acao: 'Notificar Partes', rotulo: 'Notificar', se: /NOTIFIQUE-SE|NOTIFIQUEM-SE/ },
  { id: 'carta', acao: 'Carta Precatória Eletrônica', rotulo: 'Carta precatória', se: /CARTA PRECATORIA/ },
  { id: 'perito', acao: 'Intimar Peritos e Auxiliares da Justiça', rotulo: 'Intimar perito', se: /INTIME-SE O PERITO|NOMEIO (COMO )?PERITO|PERICIA/ },
  { id: 'audiencia', acao: 'Ordenar Cumprimentos', rotulo: 'Agendar audiência', cumprimento: { tipos: ['AGENDAR AUDIENCIA', 'AGENDAR CONCILIACAO'], polo: 'partes' }, se: /DESIGNO AUDIENCIA|DESIGNE-SE AUDIENCIA|DESIGNE-SE DATA|INCLUA-SE EM PAUTA|AUDIENCIA DE INSTRUCAO/ },
  { id: 'suspender', acao: 'Suspender ou Sobrestar Processo', rotulo: 'Suspender o processo', se: /SUSPENDO O|SUSPENDA-SE|SUSPENSAO D[OA] (PROCESSO|FEITO|EXECUCAO)|SOBRESTE/ },
  { id: 'transito', acao: 'Transitar em Julgado', rotulo: 'Certificar o trânsito em julgado', ultimo: true, se: /CERTIFIQUE-SE O TRANSITO|APOS O TRANSITO|TRANSITADA EM JULGADO/ },
  { id: 'remessa', acao: 'Realizar Remessa', rotulo: 'Remeter à Turma Recursal', ultimo: true, se: /TURMA RECURSAL|REMETAM-SE OS AUTOS/ },
  { id: 'concluso', acao: 'Enviar Concluso', rotulo: 'Fazer conclusos', ultimo: true, se: /VOLTEM CONCLUSOS|VOLTEM-ME CONCLUSOS|FACAM-SE CONCLUSOS|VENHAM CONCLUSOS|APOS,? CONCLUSOS/ },
  { id: 'arquivar', acao: 'Arquivar Processo', rotulo: 'Arquivar', ultimo: true, se: /ARQUIVE-SE|ARQUIVEM-SE|ARQUIVEM-SE OS AUTOS|AO ARQUIVO/ }
];

// Modo do cumprimento, na ordem de prioridade (o primeiro que casar no trecho da decisão).
var MODO_CUMPRIMENTO = [
  ['DESBLOQUEIO', /DESBLOQUEI|LIBERACAO D[OA]S? (BLOQUEIO|RESTRICAO|VALOR|VEICULO)|LEVANTAMENTO D[AO]S? (BLOQUEIO|RESTRICAO|INDISPONIBILIDADE)|BAIXA D[AO] (RESTRICAO|INDISPONIBILIDADE)/],
  ['TRANSFERENCIA', /TRANSFIRA|TRANSFERENCIA/],
  ['BUSCA AUTOMATIZADA', /TEIMOSINHA|AUTOMATIZADA|REITERACAO AUTOMATICA/],
  ['EXCLUSAO', /EXCLUSAO|EXCLUA-SE|RETIRADA D[OA] NOME/],
  ['INCLUSAO', /INCLUSAO|INCLUA-SE|NEGATIVACAO/],
  ['BLOQUEIO', /BLOQUEIO|BLOQUEIE|PENHORA|RESTRICAO|INDISPONIB|CONSTRI|ARRESTO/],
  ['CONSULTA', /CONSULTA/],
  ['BUSCA', /BUSCA|PESQUIS|LOCALIZ|ENDERECO|INFORMAC/]
];
// Opções preferidas pela vara quando há duas equivalentes (nome da opção sem acentos).
var PREFERIDAS_CUMPRIMENTO = ['TRANSFERENCIA SISBAJUD'];

// Palavras que, se aparecerem na decisão e na opção, aproximam a escolha.
var CONTEXTO_CUMPRIMENTO = ['ENDERECO', 'SALDO', 'CPF', 'SIGILO', 'INSS', 'CONCILIACAO', 'INSTRUCAO', 'CITACAO', 'INTIMACAO',
  'NOTIFICACAO', 'EDITAL', 'WHATSAPP', 'REITERACAO', 'MINISTERIO', 'CAIXA', 'CLARO', 'TIM', 'VIVO', 'OI', 'DEPRECANTE', 'DEPRECADO',
  'EMAIL', 'DETRAN', 'COPEL', 'SANEPAR', 'TRE', 'VIRTUAL', 'VIDEOCONFERENCIA', 'DIVIDA', 'CREDITO', 'IMOVEIS', 'AVERBACAO'];

// Quem intimar, conforme as palavras da frase.
var ALVOS_INTIMACAO = {
  partes: /\bPARTES\b|AMBAS AS PARTES/,
  autor: /AUTOR|AUTORA|RECLAMANTE|EXEQUENTE|CREDOR|REQUERENTE|PROMOVENTE/,
  reu: /REQUERID|RECLAMAD|EXECUTAD|\bREU\b|\bRE\b|DEVEDOR|PROMOVID/
};

// Para quê (primeira que casar).
var FINALIDADES = [
  [/CONTRARRAZ/, 'contrarrazões'], [/IMPUGN/, 'impugnação'], [/PAGAMENTO|PAGAR|QUITAR/, 'pagamento'],
  [/DADOS BANCARIOS|CONTA BANCARIA/, 'dados bancários'], [/MANIFEST/, 'manifestação'],
  [/COMPROV|JUNTAR|APRESENT/, 'juntar ou comprovar'], [/INDIC/, 'indicação'], [/CIENCIA/, 'ciência']
];
