/*
 * EXTENSAO -INTIMAÇOES — content.js (roda em todas as páginas/quadros do PROJUDI)
 *
 * Máquina de etapas guardada em chrome.storage.local (sobrevive às recargas de página):
 *   1  Finalizar Conclusão Pendente
 *   2  Reabrir os mesmos autos
 *   3  Aba Movimentações
 *   4  Clicar na movimentação da decisão/sentença (última do Magistrado com arquivo)
 *   5  Movimentar a Partir Desta Movimentação
 *   6  Menu Ações → Intimar Partes
 *   7  Marcar Advogado/Sociedade de Advogados
 *   8  Polo Ativo  → Prazo = 10
 *   9  Polo Passivo → Prazo = 10
 * Ao final PARA: a conferência e a confirmação da intimação ficam com o usuário.
 */
(() => {
  'use strict';

  // ---------------- CONFIGURAÇÃO ----------------
  const CFG = {
    prazo: '10',
    // Movimentações descartadas na escolha da decisão/sentença:
    ignorarEvento: /CONCLUS|REMESSA|JUNTADA|EXPEDI|CERTID|LEITURA|DECORRIDO|RECEBIDO/i,
    esperaMax: 20000,        // ms para cada elemento aparecer
    expiraFluxo: 180000      // ms sem avanço → fluxo encerrado
  };
  const CHAVE = 'intimacoes_estado';
  const TOPO = window.top === window;
  const RX = {
    finalizar: /finalizar\s+conclus[aã]o\s+pendente/i,
    abaMov: /^\s*movimenta[cç][oõ]es\s*$/i,
    movimentar: /movimentar\s+a\s+partir\s+desta\s+movimenta/i,
    intimar: /^\s*intimar\s+partes\s*$/i,
    advogado: /advogad/i,
    poloAtivo: /polo\s+ativo/i,
    poloPassivo: /polo\s+passivo/i
  };

  let meuTab = null;
  let ocupado = false;

  // ---------------- utilitários ----------------
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const txt = (el) => (el.innerText || el.value || el.title || el.alt || el.textContent || '')
    .replace(/\s+/g, ' ').trim();
  const visivel = (el) => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);

  // Extensão recarregada/atualizada: o script antigo que ficou na aba perde o contato
  // ("Extension context invalidated"). Detecta e encerra em silêncio.
  let timer = null;
  function vivo() {
    try { if (chrome.runtime?.id) return true; } catch { /* contexto invalidado */ }
    if (timer) { clearInterval(timer); timer = null; }
    return false;
  }
  async function lerEstado() {
    if (!vivo()) return null;
    try {
      const { [CHAVE]: e } = await chrome.storage.local.get(CHAVE);
      return e || null;
    } catch { vivo(); return null; }
  }
  async function gravar(patch, msg) {
    const e = (await lerEstado()) || {};
    const novo = { ...e, ...patch, desde: Date.now() };
    if (msg) novo.log = [...(e.log || []), new Date().toLocaleTimeString('pt-BR') + ' ' + msg];
    if (!vivo()) return novo;
    try { await chrome.storage.local.set({ [CHAVE]: novo }); } catch { vivo(); }
    return novo;
  }
  const log = (msg) => gravar({}, msg);
  async function falhar(msg) {
    await gravar({ ativo: false, etapa: 'erro' }, '✗ ' + msg);
    vivo() && chrome.runtime.sendMessage({ tipo: 'BADGE', texto: '!', cor: '#b00020', titulo: msg });
  }

  // Elemento clicável cujo próprio texto casa com a regex (prefere o mais interno/visível).
  // Rápido: 1º procura só em links/botões; se não achar, amplia. Pré-filtro por textContent
  // (barato) antes do innerText (que força layout).
  const SEL_CLICAVEIS = 'a, button, input[type=button], input[type=submit], input[type=image]';
  const SEL_AMPLO = 'span, li, td, div, img';
  function rapido(el) {
    return (el.textContent || el.value || el.title || el.alt || '').replace(/\s+/g, ' ').trim();
  }
  function acharClicavel(rx, raiz = document) {
    return acharEm(rx, raiz, SEL_CLICAVEIS) || acharEm(rx, raiz, SEL_AMPLO);
  }
  function acharEm(rx, raiz, sel) {
    const cands = [...raiz.querySelectorAll(sel)]
      .filter((el) => { const t = rapido(el); return t.length < 120 && rx.test(t); })
      .filter((el) => !el.closest('#ext-intimacoes-painel') && rx.test(txt(el)));
    if (!cands.length) return null;
    // remove os que contêm outro candidato (fica o mais interno)
    const internos = cands.filter((el) => !cands.some((o) => o !== el && el.contains(o)));
    internos.sort((a, b) => visivel(b) - visivel(a));
    const el = internos[0];
    return el.closest('a, button, input') || el;
  }

  async function esperar(fn, ms = CFG.esperaMax) {
    const fim = Date.now() + ms;
    while (Date.now() < fim) {
      const r = fn();
      if (r) return r;
      await sleep(120);
    }
    return null;
  }

  async function autoConfirm() {
    try { await chrome.runtime.sendMessage({ tipo: 'AUTO_CONFIRM' }); } catch { /* ignore */ }
  }

  function clicar(el) {
    el.scrollIntoView({ block: 'center' });
    ['mouseover', 'mousedown', 'mouseup'].forEach((t) =>
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
    el.click();
  }

  function numeroProcesso() {
    const m = (document.body?.innerText || '').match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/);
    return m ? m[0] : '';
  }

  // Linhas da tabela de movimentações (mesma estrutura da extensão Juntadas e Decisões).
  function linhasMov() {
    return [...document.querySelectorAll('tr')].filter((tr) =>
      tr.cells.length >= 5 && /^\d+$/.test(tr.cells[1].innerText.trim()) &&
      /^\d{2}\/\d{2}\/\d{4}/.test(tr.cells[2].innerText.trim()));
  }

  // Texto que identifica um checkbox/campo (label, célula, cabeçalho da coluna, irmãos).
  function rotulo(el) {
    const partes = [el.title, el.name, el.id];
    if (el.id) { const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`); if (l) partes.push(txt(l)); }
    const lp = el.closest('label'); if (lp) partes.push(txt(lp));
    if (el.nextSibling) partes.push((el.nextSibling.textContent || '').trim());
    if (el.nextElementSibling) partes.push(txt(el.nextElementSibling));
    const td = el.closest('td, th');
    if (td) {
      partes.push(txt(td));
      const cab = cabecalhoColuna(td); if (cab) partes.push(cab);
    }
    return partes.filter(Boolean).join(' | ');
  }

  // Texto da célula anterior na mesma linha (rótulo à esquerda do campo).
  function rotuloLinha(el) {
    const td = el.closest('td'); const ant = td && td.previousElementSibling;
    return ant ? txt(ant) : '';
  }

  // Link (http) que abre os autos do processo, se houver na tela da conclusão.
  function linkProcesso(num) {
    if (!num) return '';
    const a = [...document.querySelectorAll('a[href]')].find((x) => txt(x).includes(num) &&
      /^https?:/i.test(x.href) && !/conclusao/i.test(x.href));
    return a ? a.href : '';
  }

  function cabecalhoColuna(td) {
    const tabela = td.closest('table'); const tr = td.parentElement;
    if (!tabela || !tr) return '';
    let col = 0;
    for (const c of tr.cells) { if (c === td) break; col += c.colSpan || 1; }
    const linhas = [...tabela.rows];
    const linhaCab = linhas.find((r) => r !== tr && r.querySelector('th')) || linhas[0];
    if (!linhaCab || linhaCab === tr) return '';
    let i = 0;
    for (const c of linhaCab.cells) { if (col >= i && col < i + (c.colSpan || 1)) return txt(c); i += c.colSpan || 1; }
    return '';
  }

  // Polo do elemento: o último título "Polo Ativo"/"Polo Passivo" que aparece antes dele no documento.
  function poloDe(el) {
    const marcas = [...document.querySelectorAll('h1,h2,h3,h4,h5,legend,th,td,b,strong,span,div,label,caption')]
      .filter((m) => m.children.length <= 3 && txt(m).length < 60 &&
        (RX.poloAtivo.test(txt(m)) || RX.poloPassivo.test(txt(m))));
    let polo = '';
    for (const m of marcas) {
      if (m.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING || m.contains(el)) {
        polo = RX.poloAtivo.test(txt(m)) ? 'ativo' : 'passivo';
      }
    }
    return polo;
  }

  function preencher(input, valor) {
    input.focus();
    input.value = valor;
    ['input', 'keyup', 'change', 'blur'].forEach((t) =>
      input.dispatchEvent(new Event(t, { bubbles: true })));
  }

  // ---------------- ETAPAS ----------------
  const ETAPAS = {
    // 1) Finalizar Conclusão Pendente
    async 1() {
      const bt = acharClicavel(RX.finalizar);
      if (!bt) return false; // outro quadro
      await gravar({
        etapa: 2, clicadoEm: Date.now(),
        linkAutos: linkProcesso(numeroProcesso()), processo: numeroProcesso()
      }, `1) Finalizar Conclusão Pendente — autos ${numeroProcesso() || '(nº não lido)'}.`);
      await autoConfirm();
      clicar(bt);
      return true;
    },

    // 2) Reabrir os mesmos autos (só o quadro de topo navega)
    async 2(e) {
      if (!TOPO) return false;
      const paginaNova = performance.timeOrigin > e.clicadoEm;
      // sem recarga (finalização por AJAX): aguarda no máximo 2 s
      if (!paginaNova) await sleep(Math.max(0, e.clicadoEm + 1200 - Date.now()));
      const atual = await lerEstado();
      if (!atual?.ativo || atual.etapa !== 2) return true;

      // Se a página que voltou após finalizar já são os autos do mesmo processo,
      // não carrega de novo (evita a segunda carga, que é a parte lenta).
      if (paginaNova) {
        const docs = [document];
        for (let i = 0; i < window.frames.length; i++) {
          try { docs.push(window.frames[i].document); } catch { /* outro domínio */ }
        }
        const jaAberto = docs.some((d) => {
          const n = ((d.body?.innerText || '').match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0];
          const temAba = [...d.querySelectorAll('a, li, span, td')].some((el) => RX.abaMov.test(txt(el)));
          return n && n === e.processo && temAba;
        });
        if (jaAberto) {
          await gravar({ etapa: 3, navegouEm: 0 }, '2) Autos já reabertos após a finalização.');
          return true;
        }
      }
      if (!e.processo) { await falhar('2) Número do processo não lido na tela da conclusão.'); return true; }
      // NÃO reabrir pela URL da conclusão (conclusao.do): o PROJUDI responde "Conclusão já analisada".
      if (e.linkAutos) {
        await gravar({ etapa: 3, navegouEm: Date.now() }, '2) Reabrindo os mesmos autos (link do processo).');
        location.href = e.linkAutos;
        return true;
      }
      // Sem link direto: busca pelo menu "Processo" do cabeçalho.
      const menu = [...document.querySelectorAll('a')].find((a) => /^\s*processo\s*$/i.test(txt(a)));
      if (!menu) { await falhar('2) Link "Processo" do cabeçalho não encontrado para reabrir os autos.'); return true; }
      await gravar({ etapa: '2b', navegouEm: Date.now() }, `2) Reabrindo os autos pela busca de processo (${e.processo}).`);
      clicar(menu);
      return true;
    },

    // 2b) Tela de busca de processo: preenche o número e pesquisa
    async '2b'(e) {
      if (performance.timeOrigin < e.navegouEm) return false;
      const campo = await esperar(() => [...document.querySelectorAll('input:not([type]), input[type=text]')]
        .find((i) => visivel(i) && !i.disabled && /n[uú]mero/i.test(rotulo(i) + ' ' + rotuloLinha(i))), 8000);
      if (!campo) return false;
      preencher(campo, e.processo);
      const bt = [...document.querySelectorAll('input[type=submit], input[type=button], button')]
        .find((b) => visivel(b) && /^\s*(pesquisar|buscar|consultar|filtrar|ok)\s*$/i.test(txt(b)));
      await gravar({ etapa: '2c', navegouEm: Date.now() }, '2) Pesquisando o processo.');
      if (bt) clicar(bt); else (campo.form ? campo.form.submit() : null);
      return true;
    },

    // 2c) Resultado da busca: abre o processo
    async '2c'(e) {
      // resultado pode vir sem recarga (AJAX): após 5 s aceita a própria página
      if (performance.timeOrigin < e.navegouEm && Date.now() - e.navegouEm < 5000) return false;
      if ([...document.querySelectorAll('a, li, span, td')].some((el) => RX.abaMov.test(txt(el)))) {
        await gravar({ etapa: 3, navegouEm: 0 }, '2) Autos reabertos.');
        return true;
      }
      const ln = await esperar(() => [...document.querySelectorAll('a')]
        .find((a) => txt(a).includes(e.processo)), 8000);
      if (!ln) return false;
      await gravar({ etapa: 3, navegouEm: Date.now() }, '2) Autos reabertos pela busca.');
      clicar(ln);
      return true;
    },

    // 3) Aba Movimentações
    async 3(e) {
      if (performance.timeOrigin < e.navegouEm) return false; // página antiga, aguardando recarga
      if (linhasMov().length) { await gravar({ etapa: 4 }, '3) Aba Movimentações já aberta.'); return true; }
      const aba = await esperar(() => acharClicavel(RX.abaMov), 8000);
      if (!aba) return false;
      await gravar({ etapa: 4, clicadoEm: Date.now() }, '3) Aba Movimentações.');
      clicar(aba);
      return true;
    },

    // 4) Movimentação da decisão/sentença
    async 4() {
      const ok = await esperar(() => linhasMov().length, 8000);
      if (!ok) return false;
      const movs = linhasMov().map((tr) => ({
        tr, seq: +tr.cells[1].innerText.trim(), data: tr.cells[2].innerText.trim().slice(0, 10),
        evento: tr.cells[3].innerText.trim().split('\n')[0].trim(), por: tr.cells[4].innerText.trim()
      }));
      const dec = movs.filter((m) => /magistrad|juiz/i.test(m.por) && !CFG.ignorarEvento.test(m.evento))
        .sort((a, b) => b.seq - a.seq)[0];
      if (!dec) { await falhar('4) Nenhuma decisão/sentença de Magistrado encontrada nas movimentações.'); return true; }
      await gravar({ etapa: 5, clicadoEm: Date.now(), mov: `${dec.seq} — ${dec.evento} (${dec.data})` },
        `4) Movimentação ${dec.seq} — ${dec.evento} (${dec.data}).`);
      dec.tr.style.outline = '3px solid #1565c0';
      const alvo = dec.tr.cells[3].querySelector('a') || dec.tr.cells[3];
      // abre a movimentação na MESMA aba (evita nova aba que a extensão não acompanha)
      if (alvo.tagName === 'A') alvo.removeAttribute('target');
      if (alvo.tagName === 'A' && /^https?:/i.test(alvo.href)) location.href = alvo.href;
      else clicar(alvo);
      return true;
    },

    // 5) Movimentar a Partir Desta Movimentação
    async 5() {
      const bt = await esperar(() => acharClicavel(RX.movimentar), 10000);
      if (!bt) return false;
      await gravar({ etapa: 6, clicadoEm: Date.now() }, '5) Movimentar a Partir Desta Movimentação.');
      await autoConfirm();
      clicar(bt);
      return true;
    },

    // 6) Menu Ações → Intimar Partes
    async 6() {
      const ln = await esperar(() => acharClicavel(RX.intimar), 10000);
      if (!ln) return false;
      await gravar({ etapa: 7, clicadoEm: Date.now() }, '6) Ações → Intimar Partes.');
      await autoConfirm();
      clicar(ln);
      return true;
    },

    // 7, 8, 9) Tela Intimar Partes
    async 7(e) {
      const modo = e.modo || 'ambas'; // 'autora' | 're' | 'ambas'
      const quer = (polo) => modo === 'ambas' || (modo === 'autora' ? polo === 'ativo' : polo === 'passivo');
      const achou = await esperar(() =>
        [...document.querySelectorAll('input[type=checkbox]')].some((c) => RX.advogado.test(rotulo(c))) &&
        [...document.querySelectorAll('input')].some((i) => /prazo/i.test(i.name + ' ' + i.id + ' ' +
          (i.closest('td') ? cabecalhoColuna(i.closest('td')) : ''))), 10000);
      if (!achou) return false;

      // 7) Advogado/Sociedade de Advogados
      const caixas = [...document.querySelectorAll('input[type=checkbox]')]
        .filter((c) => RX.advogado.test(rotulo(c)) && !c.closest('thead') && quer(poloDe(c)));
      let marcadas = 0;
      for (const c of caixas) {
        if (!c.disabled && !c.checked) { clicar(c); marcadas++; }
      }
      await log(`7) Advogado/Sociedade de Advogados: ${caixas.length} caixa(s), ${marcadas} marcada(s) agora.`);
      // campos de prazo podem habilitar após a marcação: espera só o necessário (máx. 1,5 s)
      await esperar(() => ![...document.querySelectorAll('input')]
        .some((i) => /prazo/i.test(i.name + ' ' + i.id) && i.disabled), 1500);

      // 8 e 9) Prazo = 10 nos polos ativo e passivo
      const campos = [...document.querySelectorAll('input:not([type]), input[type=text], input[type=number]')]
        .filter((i) => /prazo/i.test(i.name + ' ' + i.id + ' ' + i.title) ||
          /prazo/i.test(i.closest('td') ? cabecalhoColuna(i.closest('td')) : ''));
      const cont = { ativo: 0, passivo: 0, semPolo: 0, bloqueado: 0 };
      for (const i of campos) {
        const p = poloDe(i);
        if (!quer(p)) continue;
        if (i.disabled || i.readOnly) { cont.bloqueado++; continue; }
        preencher(i, CFG.prazo);
        i.style.outline = '2px solid #2e7d32';
        cont[p || 'semPolo']++;
      }
      if (modo !== 're') await log(`8) Polo Ativo — Prazo ${CFG.prazo}: ${cont.ativo} campo(s).`);
      await log((modo !== 'autora' ? `9) Polo Passivo — Prazo ${CFG.prazo}: ${cont.passivo} campo(s).` : '') +
        (cont.semPolo ? ` Sem polo identificado: ${cont.semPolo}.` : '') +
        (cont.bloqueado ? ` Bloqueados (não preenchidos): ${cont.bloqueado}.` : ''));

      const aviso = !caixas.length || (modo !== 're' && !cont.ativo) || (modo !== 'autora' && !cont.passivo);
      await gravar({ ativo: false, etapa: 'concluido' },
        aviso ? '⚠ Concluído com pendências — confira a tela antes de confirmar.'
              : '✓ Concluído. Confira e confirme a intimação manualmente.');
      vivo() && chrome.runtime.sendMessage({ tipo: 'BADGE', texto: aviso ? '⚠' : '✓',
        cor: aviso ? '#e65100' : '#2e7d32', titulo: 'Intimar Partes preenchido — conferir e confirmar.' });
      return true;
    }
  };

  // ---------------- motor ----------------
  async function tick() {
    if (ocupado) return;
    const e = await lerEstado();
    if (!e || !e.ativo) return;
    if (Date.now() - e.desde > CFG.expiraFluxo) {
      if (TOPO) await falhar(`Etapa ${e.etapa} sem avanço — fluxo encerrado por tempo.`);
      return;
    }
    if (!meuTab) { try { meuTab = await chrome.runtime.sendMessage({ tipo: 'MEU_TAB' }); } catch { return; } }
    const mesmaAba = meuTab.tabId === e.tabId;
    // telas abertas em nova aba/janela: aceita a aba filha ou qualquer aba carregada depois do último clique
    const abaFilha = typeof e.etapa === 'number' && e.etapa >= 3 &&
      (meuTab.opener === e.tabId || (e.etapa >= 5 && e.clicadoEm && performance.timeOrigin > e.clicadoEm));
    if (!mesmaAba && !abaFilha) return;
    const fn = ETAPAS[e.etapa];
    if (!fn) return;
    ocupado = true;
    let feito = false;
    try {
      vivo() && chrome.runtime.sendMessage({ tipo: 'BADGE', texto: String(e.etapa), cor: '#1565c0' });
      feito = await fn(e);
      if (feito && abaFilha) await gravar({ tabId: meuTab.tabId });
    } catch (err) {
      await falhar(`Etapa ${e.etapa}: ${err.message || err}`);
    } finally {
      ocupado = false;
    }
    // etapa concluída sem troca de página: segue imediatamente para a próxima
    if (feito) setTimeout(tick, 50);
  }

  // ---------------- painel (só no topo) ----------------
  function painel(e) {
    if (!TOPO || !document.body) return;
    let p = document.getElementById('ext-intimacoes-painel');
    if (!e || !e.log || (!e.ativo && Date.now() - e.desde > 120000)) { p?.remove(); return; }
    if (!meuTab || (meuTab.tabId !== e.tabId)) { p?.remove(); return; }
    if (!p) {
      p = document.createElement('div');
      p.id = 'ext-intimacoes-painel';
      p.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:2147483647;width:380px;max-height:45vh;' +
        'overflow:auto;background:#fff;border:2px solid #1565c0;border-radius:6px;padding:8px 10px;' +
        'font:12px/1.45 Verdana,sans-serif;color:#222;box-shadow:0 3px 10px rgba(0,0,0,.35)';
      document.body.appendChild(p);
    }
    const cor = e.etapa === 'erro' ? '#b00020' : e.etapa === 'concluido' ? '#2e7d32' : '#1565c0';
    p.style.borderColor = cor;
    p.innerHTML = `<div style="font-weight:bold;color:${cor};margin-bottom:4px">EXTENSAO -INTIMAÇOES` +
      `${e.processo ? ' — ' + e.processo : ''}</div>` +
      e.log.map((l) => `<div>${l.replace(/</g, '&lt;')}</div>`).join('') +
      `<div style="margin-top:6px;text-align:right"><button type="button" id="ext-int-fechar">` +
      `${e.ativo ? 'Cancelar' : 'Fechar'}</button></div>`;
    p.querySelector('#ext-int-fechar').onclick = async () => {
      if (e.ativo) await gravar({ ativo: false, etapa: 'cancelado' }, 'Fluxo cancelado pelo usuário.');
      p.remove();
    };
  }

  chrome.storage.onChanged.addListener((mud, area) => {
    if (area !== 'local' || !mud[CHAVE]) return;
    painel(mud[CHAVE].newValue);
    menu();
    tick();
  });

  // ---------------- acionamento por número (1, 2, 3) ----------------
  const MODOS = { 1: ['autora', 'Intimação parte autora'], 2: ['re', 'Intimação parte ré'], 3: ['ambas', 'Intimação ambas as partes'] };
  const telaConclusao = () => !!acharEm(RX.finalizar, document, SEL_CLICAVEIS) || !!acharClicavel(RX.finalizar);

  async function iniciar(n) {
    const e = await lerEstado();
    if (e?.ativo) return;
    vivo() && chrome.runtime.sendMessage({ tipo: 'INICIAR', modo: MODOS[n][0], rotulo: MODOS[n][1] });
    document.getElementById('ext-intimacoes-menu')?.remove();
  }

  document.addEventListener('keydown', (ev) => {
    if (!MODOS[ev.key] || ev.ctrlKey || ev.altKey || ev.metaKey || ev.repeat) return;
    const t = ev.target;
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return; // digitando
    if (!telaConclusao()) return;
    ev.preventDefault();
    iniciar(ev.key);
  }, true);

  async function menu() {
    const existe = document.getElementById('ext-intimacoes-menu');
    const e = await lerEstado();
    if (e?.ativo || !telaConclusao()) { existe?.remove(); return; }
    if (existe || !document.body) return;
    const m = document.createElement('div');
    m.id = 'ext-intimacoes-menu';
    m.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:2147483647;background:#fff;' +
      'border:2px solid #1565c0;border-radius:6px;padding:8px 10px;font:12px/1.6 Verdana,sans-serif;' +
      'color:#222;box-shadow:0 3px 10px rgba(0,0,0,.35)';
    m.innerHTML = '<div style="font-weight:bold;color:#1565c0;margin-bottom:4px">EXTENSAO -INTIMAÇOES — tecle:</div>' +
      Object.entries(MODOS).map(([k, [, r]]) =>
        `<div><button type="button" data-n="${k}" style="min-width:26px;font-weight:bold;cursor:pointer">${k}</button> ${r}</div>`).join('');
    m.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => iniciar(b.dataset.n)));
    document.body.appendChild(m);
  }

  (async () => {
    try { meuTab = await chrome.runtime.sendMessage({ tipo: 'MEU_TAB' }); } catch { /* ignore */ }
    menu();
    painel(await lerEstado());
    tick();
    // reavalia periodicamente (telas que mudam por AJAX sem recarregar)
    timer = setInterval(async () => { const e = await lerEstado(); if (e?.ativo) tick(); }, 700);
  })();
})();
