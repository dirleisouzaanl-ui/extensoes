/* decurso.js - tela "Analisar Decurso de Prazo" (menu Intimações / Decurso de Prazo).
   Marca cada linha com o tipo de prazo e a sugestão de andamento, agrupa as intimações do
   mesmo ato e mostra um quadro com o total por categoria. Não analisa nada sozinho. */
(() => {
  const CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
  const CORES = {
    vermelho: ['#b42318', '#fde7e4'], roxo: ['#6b3fa0', '#efe7f8'], verde: ['#2c7a37', '#e3f3e5'],
    azul: ['#1a5fa8', '#e3eefb'], laranja: ['#a45a00', '#fdf0de'], cinza: ['#56626e', '#eef1f3']
  };
  let filtro = null, aviso = '', agendado = null;

  // Cabeçalho da tabela: localiza as colunas pelo nome.
  function tabela() {
    const cab = Array.from(document.querySelectorAll('tr')).find(tr => {
      const t = N(tr.innerText);
      return /DATA DECURSO/.test(t) && /MOVIMENTACAO/.test(t) && /PARTES/.test(t);
    });
    if (!cab) return null;
    const cels = Array.from(cab.querySelectorAll(':scope > th, :scope > td'));
    const idx = nome => cels.findIndex(c => N(c.innerText).includes(nome));
    const col = { proc: idx('PROCESSO'), dec: idx('DATA DECURSO'), mov: idx('MOVIMENTACAO'), partes: idx('PARTES'), sit: idx('SITUACAO'), urg: idx('URGENTE') };
    const corpo = cab.closest('table');
    const linhas = Array.from(corpo.querySelectorAll('tr')).filter(tr => {
      if (tr === cab || tr.closest('table') !== corpo) return false;
      const c = tr.querySelectorAll(':scope > td');
      return c.length >= cels.length - 1 && CNJ.test((c[col.proc] || c[0] || {}).innerText || '');
    });
    return { col, linhas };
  }

  const classificar = mov => REGRAS_DECURSO.find(r => r.se.test(N(mov))) ||
    { cat: 'Não classificada', cor: 'cinza', enc: 'Abrir o processo e verificar o andamento.' };

  function diasDesde(txt) {
    const m = /(\d{2})\/(\d{2})\/(\d{4})/.exec(txt || '');
    if (!m) return null;
    return Math.floor((new Date() - new Date(+m[3], +m[2] - 1, +m[1])) / 86400000);
  }

  function marcar() {
    if (!/Data\s*Decurso/i.test((document.body && document.body.innerText) || '')) return;
    const t = tabela();
    if (!t) return;
    const { col, linhas } = t;
    const contagem = {}, porAto = {};
    linhas.forEach(tr => {
      const c = tr.querySelectorAll(':scope > td');
      const ato = (CNJ.exec(c[col.proc].innerText) || [''])[0] + '|' + ((c[col.proc].innerText.match(/\b\d{2,6}\b\s*$/) || [''])[0].trim());
      porAto[ato] = (porAto[ato] || 0) + 1;
      tr.dataset.decursoAto = ato;
    });
    linhas.forEach(tr => {
      const c = tr.querySelectorAll(':scope > td');
      const celMov = c[col.mov];
      if (!celMov) return;
      const mov = (celMov.innerText || '').replace(/\n?Sugest[aã]o:[\s\S]*$/, '').split('\n')[0];
      const r = classificar(mov);
      const dias = diasDesde(c[col.dec] && c[col.dec].innerText);
      const urgente = c[col.urg] && /SIM/.test(N(c[col.urg].innerText));
      const mesmos = porAto[tr.dataset.decursoAto];
      const [borda, fundo] = CORES[r.cor] || CORES.cinza;
      let selo = celMov.querySelector('.decurso-selo');
      if (!selo) { selo = document.createElement('div'); selo.className = 'decurso-selo'; celMov.appendChild(selo); }
      selo.style.cssText = 'margin:6px 0 2px;padding:5px 8px;border-left:4px solid ' + borda + ';background:' + fundo +
        ';color:#1b2631;font:12px/1.35 "Segoe UI",system-ui,sans-serif;border-radius:3px;text-align:left';
      selo.textContent = '';
      const b = document.createElement('b'); b.style.color = borda;
      b.textContent = (urgente ? '⚑ ' : '') + r.cat;
      const e = document.createElement('div'); e.textContent = 'Sugestão: ' + r.enc;
      selo.append(b, e);
      const extra = [];
      if (dias !== null && dias >= 0) extra.push('decorrido há ' + dias + ' dia(s)');
      if (mesmos > 1) extra.push(mesmos + ' intimações do mesmo ato: analisar uma vez');
      if (extra.length) { const x = document.createElement('div'); x.style.color = '#56626e'; x.textContent = extra.join(' · '); selo.appendChild(x); }
      const det = tr.__detalhe;
      if (det && !det.erro) {
        const x = document.createElement('div');
        x.style.cssText = 'font-weight:600;color:' + (det.manifestou ? '#2c7a37' : '#a45a00');
        x.textContent = (det.intimado ? det.intimado + ': ' : '') + (det.manifestou ? 'cumprimento em ' + det.cumprimento : 'sem cumprimento registrado');
        selo.appendChild(x);
      }
      tr.dataset.decurso = r.cat;
      tr.style.display = filtro && filtro !== r.cat ? 'none' : '';
      contagem[r.cat] = contagem[r.cat] || { n: 0, cor: r.cor, urg: 0, antigos: 0 };
      contagem[r.cat].n++;
      if (urgente) contagem[r.cat].urg++;
      if (dias !== null && dias > 30) contagem[r.cat].antigos++;
    });
    painel(contagem, linhas.length, Object.values(porAto).filter(n => n > 1).length);
  }

  const detalhes = new Map();   // ato -> resultado de lerDetalheDecurso
  let verificando = false;
  async function verificar() {
    if (verificando) return;
    verificando = true;
    const t = tabela();
    try {
      const linhas = t.linhas.filter(tr => tr.style.display !== 'none');
      let i = 0, sem = 0;
      for (const tr of linhas) {
        i++; aviso = 'Conferindo ' + i + ' de ' + linhas.length + '...'; marcar();
        const chave = tr.dataset.decursoAto + '|' + i;
        const c = tr.querySelectorAll(':scope > td');
        const link = Array.from(tr.querySelectorAll('a')).find(a => /^https?:/.test(a.href) && !/javascript/i.test(a.getAttribute('href') || '') && c[t.col.dec] && c[t.col.dec].contains(a))
          || Array.from(tr.querySelectorAll('a')).find(a => /intima/i.test(a.getAttribute('href') || ''));
        if (!link) { sem++; continue; }
        try {
          const html = await (await fetch(link.href, { credentials: 'include' })).text();
          const doc = new DOMParser().parseFromString(html, 'text/html');
          tr.__detalhe = lerDetalheDecurso(doc);
        } catch (e) { tr.__detalhe = { erro: true }; }
      }
      const total = linhas.length - sem;
      aviso = sem === linhas.length ? 'Não consegui abrir os detalhes pela lista; use o lápis de cada linha.' :
        '✔ ' + total + ' prazo(s) conferido(s).' + (sem ? ' ' + sem + ' sem link acessível.' : '');
    } finally { verificando = false; marcar(); }
  }

  function marcarLote(cat) {
    const t = tabela(); if (!t) return;
    let n = 0, sem = 0;
    t.linhas.forEach(tr => {
      const cb = tr.querySelector('input[type="checkbox"]');
      if (!cb) { sem++; return; }
      const quer = tr.dataset.decurso === cat;
      if (cb.checked !== quer) cb.click();
      if (quer) n++;
    });
    aviso = sem && !n ? 'Esta lista não tem caixas de seleção; analise linha a linha.' : n + ' prazo(s) marcado(s). Confira antes de usar a ação do PROJUDI.';
    marcar();
  }

  function painel(contagem, total, repetidos) {
    let host = document.getElementById('decurso-prazo-painel');
    if (!total) { if (host) host.remove(); return; }
    if (!host) {
      host = document.createElement('div');
      host.id = 'decurso-prazo-painel';
      host.style.cssText = 'position:fixed;right:16px;top:16px;z-index:2147483647;';
      host.attachShadow({ mode: 'open' });
      document.body.appendChild(host);
    }
    const raiz = host.shadowRoot;
    const min = raiz.getElementById('p') && raiz.getElementById('p').classList.contains('min');
    raiz.innerHTML = `<style>
      .p{font:13px/1.35 "Segoe UI",system-ui,sans-serif;background:#fff;color:#1b2631;border:1px solid #c9d1d8;border-top:3px solid #0f5f73;
         border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.18);padding:10px;width:320px;max-height:75vh;overflow:auto}
      .t{display:flex;justify-content:space-between;align-items:center;font-weight:700;margin-bottom:6px}
      .x{border:0;background:none;font-size:16px;cursor:pointer;color:#56626e}
      button.c{display:flex;justify-content:space-between;width:100%;margin-top:4px;font:inherit;text-align:left;padding:5px 8px;
         border-radius:5px;border:1px solid #d3d9de;background:#fff;color:#1b2631;cursor:pointer}
      button.c.on{outline:2px solid #0f5f73}
      button.a{display:block;width:100%;margin-top:6px;font:inherit;font-weight:600;padding:6px 8px;border-radius:6px;
         border:1px solid #0f5f73;background:#fff;color:#0f5f73;cursor:pointer;text-align:left}
      .n{font-weight:700;margin-left:8px;white-space:nowrap} .s{color:#a45a00;font-weight:400}
      .r{margin-top:8px;font-size:12px;color:#56626e} .av{margin-top:8px;font-size:12px;font-weight:600;color:#0f5f73}
      .min .corpo{display:none} .min{width:auto}
    </style>
    <div class="p${min ? ' min' : ''}" id="p"><div class="t"><span>Decurso de prazo: ${total}</span><button class="x" id="min">${min ? '+' : '–'}</button></div>
    <div class="corpo" id="corpo"></div></div>`;
    const corpo = raiz.getElementById('corpo');
    Object.entries(contagem).sort((a, b) => b[1].urg - a[1].urg || b[1].n - a[1].n).forEach(([cat, c]) => {
      const b = document.createElement('button');
      b.className = 'c' + (filtro === cat ? ' on' : '');
      b.style.borderLeft = '4px solid ' + (CORES[c.cor] || CORES.cinza)[0];
      const s1 = document.createElement('span'); s1.textContent = (c.urg ? '⚑ ' : '') + cat;
      if (c.antigos) { const s = document.createElement('span'); s.className = 's'; s.textContent = ' · ' + c.antigos + ' há mais de 30 dias'; s1.appendChild(s); }
      const s2 = document.createElement('span'); s2.className = 'n'; s2.textContent = c.n;
      b.append(s1, s2);
      b.addEventListener('click', () => { filtro = filtro === cat ? null : cat; aviso = ''; marcar(); });
      corpo.appendChild(b);
    });
    const v = document.createElement('button'); v.className = 'a';
    v.textContent = verificando ? 'Conferindo...' : 'Verificar manifestações' + (filtro ? ' desta categoria' : '');
    v.disabled = verificando;
    v.addEventListener('click', verificar);
    corpo.appendChild(v);
    if (filtro) {
      const l = document.createElement('button'); l.className = 'a';
      l.textContent = 'Marcar as ' + (contagem[filtro] ? contagem[filtro].n : 0) + ' desta categoria';
      l.addEventListener('click', () => marcarLote(filtro));
      corpo.appendChild(l);
    }
    if (aviso) { const a = document.createElement('div'); a.className = 'av'; a.textContent = aviso; corpo.appendChild(a); }
    const r = document.createElement('div'); r.className = 'r';
    r.textContent = (repetidos ? repetidos + ' ato(s) com várias intimações na lista. ' : '') +
      (filtro ? 'Mostrando só: ' + filtro + ' (clique de novo para ver todas).' : 'Clique numa categoria para filtrar.');
    corpo.appendChild(r);
    raiz.getElementById('min').addEventListener('click', () => {
      const p = raiz.getElementById('p'); p.classList.toggle('min');
      raiz.getElementById('min').textContent = p.classList.contains('min') ? '+' : '–';
    });
  }

  marcar();
  new MutationObserver(m => {
    if (m.every(x => x.target.closest && (x.target.closest('.decurso-selo') || x.target.closest('#decurso-prazo-painel')))) return;
    clearTimeout(agendado); agendado = setTimeout(marcar, 400);
  }).observe(document.body, { childList: true, subtree: true });
})();
