/*
 * options.js — a página de opções.
 *
 *   1. chrome.storage.sync.get / set → lê e grava as OPÇÕES.
 *   2. chrome.storage.onChanged      → mostra ao vivo o processo copiado no
 *                                      PROJUDI (storage.local).
 *   3. chrome.runtime.sendMessage({tipo:'LIMPAR_DADOS'}) → só o service
 *      worker apaga os dados, para que haja um único ponto de gravação.
 */

const S = self.SISBAJUD;
const $ = (id) => document.getElementById(id);

$('diasTeimosinha').min = S.LIMITES.diasTeimosinha.min;
$('diasTeimosinha').max = S.LIMITES.diasTeimosinha.max;
$('pausaMs').min = S.LIMITES.pausaMs.min;
$('pausaMs').max = S.LIMITES.pausaMs.max;
$('faixaDias').textContent =
  `De ${S.LIMITES.diasTeimosinha.min} a ${S.LIMITES.diasTeimosinha.max} (padrão ${S.OPCOES_PADRAO.diasTeimosinha}).`;
$('faixaPausa').textContent =
  `De ${S.LIMITES.pausaMs.min} a ${S.LIMITES.pausaMs.max} ms (padrão ${S.OPCOES_PADRAO.pausaMs}). Aumente se o SISBAJUD estiver lento.`;

const CAMPOS_TEXTO = ['juiz', 'varaCodigo', 'tipoAcao', 'diasTeimosinha', 'pausaMs'];
const CAMPOS_MARCA = ['teimosinha', 'confirmarProtocolo', 'mostrarPainel'];

function preencher(op) {
  CAMPOS_TEXTO.forEach((c) => { $(c).value = op[c]; });
  CAMPOS_MARCA.forEach((c) => { $(c).checked = op[c]; });
}

function avisar(texto) {
  $('status').textContent = texto;
  setTimeout(() => { $('status').textContent = ''; }, 2500);
}

S.lerOpcoes().then(preencher);

$('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const bruto = {};
  CAMPOS_TEXTO.forEach((c) => { bruto[c] = $(c).value; });
  CAMPOS_MARCA.forEach((c) => { bruto[c] = $(c).checked; });
  const op = S.normalizar(bruto);
  await chrome.storage.sync.set(op);
  preencher(op);
  avisar('Salvo.');
});

$('restaurar').addEventListener('click', async () => {
  await chrome.storage.sync.set(S.OPCOES_PADRAO);
  preencher(S.OPCOES_PADRAO);
  avisar('Padrão restaurado.');
});

// --- Processo copiado --------------------------------------------------------
function mostrarDados(d) {
  if (!d) { $('dados').textContent = 'Nenhum processo copiado.'; return; }
  const partes = (rotulo, lista) => `${rotulo}:\n` + (lista || [])
    .map((p) => `  • ${p.nome}${p.doc ? ' — ' + p.doc : ' — SEM CPF/CNPJ'}`).join('\n');
  $('dados').textContent = [
    `Processo: ${d.numProcesso}`,
    `Copiado em: ${new Date(d.capturadoEm).toLocaleString('pt-BR')}`,
    partes('Exequente(s)', d.exequentes),
    partes('Executado(s)', d.executados)
  ].join('\n');
}

chrome.storage.local.get(S.CHAVE_DADOS).then((r) => mostrarDados(r[S.CHAVE_DADOS]));

chrome.storage.onChanged.addListener((mudancas, area) => {
  if (area === 'local' && mudancas[S.CHAVE_DADOS]) mostrarDados(mudancas[S.CHAVE_DADOS].newValue);
  if (area === 'sync') S.lerOpcoes().then(preencher);
});

$('limpar').addEventListener('click', async () => {
  const r = await chrome.runtime.sendMessage({ tipo: 'LIMPAR_DADOS' });
  avisar(r && r.ok ? 'Dados apagados.' : `Não foi possível: ${r && r.motivo}`);
});
