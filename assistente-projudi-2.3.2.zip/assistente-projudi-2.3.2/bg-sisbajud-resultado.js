// Assistente PROJUDI — SISBAJUD: resultado da ordem (tecla S do menu).
// Lê o nº dos autos na aba do PROJUDI, grava a tarefa e abre o SISBAJUD; o roteiro
// na página é feito por modulos/sisbajudresultado/content.js.
const RE_CNJ_LIVRE = /\b\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}\b/;

async function numeroDosAutos(tab) {
  const t = (tab.title || '').match(RE_CNJ_LIVRE);
  if (t) return t[0];
  try {
    const rs = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: () => {
        const re = /\b\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}\b/;
        const h = document.querySelector('h1, h2, h3, .titulo, #titulo');
        const m = (h && h.innerText.match(re)) || (document.title || '').match(re) || (document.body ? document.body.innerText.match(re) : null);
        return m ? m[0] : '';
      }
    });
    const achado = (rs || []).map((r) => r && r.result).find(Boolean);
    if (achado) return achado;
  } catch (e) { /* página sem acesso */ }
  return '';
}

async function iniciarSisbajudResultado(tab, numeroInformado) {
  // Aba do SISBAJUD: a atual, a imediatamente à direita, ou outra da mesma janela.
  const ehSisbajud = (t) => /^https:\/\/sisbajud\.cnj\.jus\.br\//.test(t.url || '');
  const abas = await chrome.tabs.query({ windowId: tab.windowId });
  const alvo = (ehSisbajud(tab) && tab) || abas.find((t) => t.index === tab.index + 1 && ehSisbajud(t)) || abas.find(ehSisbajud);
  if (!alvo) return 'Abra o SISBAJUD (já logado) na aba à direita do processo e tente de novo.';
  // O nº dos autos é lido na aba imediatamente à esquerda do SISBAJUD (o processo no PROJUDI).
  const esquerda = abas.find((t) => t.index === alvo.index - 1);
  const numero = esquerda ? await numeroDosAutos(esquerda) : '';
  if (!numero) return 'Não achei o nº dos autos na aba à esquerda do SISBAJUD. Deixe o processo aberto nessa aba e tecle S de novo.';
  // Depois de uma execução concluída, só roda de novo com OUTRO processo.
  const { sisbajudResultadoUltimo: ultimo } = await chrome.storage.local.get('sisbajudResultadoUltimo');
  if (ultimo && ultimo === numero) return 'O processo ' + numero + ' já foi feito. Abra os novos autos na aba à esquerda do SISBAJUD e tecle S de novo.';
  // Garante o roteiro na aba (ela pode ter sido aberta antes de a extensão ser recarregada).
  try { await chrome.scripting.executeScript({ target: { tabId: alvo.id }, files: ['modulos/sisbajudpdf/capture-main.js'], world: 'MAIN' }); } catch (e) {}
  try { await chrome.scripting.executeScript({ target: { tabId: alvo.id }, files: ['modulos/sisbajudresultado/capture-pdf-main.js'], world: 'MAIN' }); } catch (e) {}
  try { await chrome.scripting.executeScript({ target: { tabId: alvo.id }, files: ['modulos/sisbajudresultado/content.js'] }); } catch (e) {}
  await chrome.storage.local.set({ sisbajudResultado: { numero, criada: Date.now(), etapa: 'inicio' } });
  await chrome.tabs.update(alvo.id, { active: true });
  return 'Iniciado: SISBAJUD - resultado do processo ' + numero + '.';
}

chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  if (!msg) return;
  if (msg.tipo === 'SISBAJUD_RESULTADO') {
    chrome.tabs.get(msg.tabId).then((tab) => iniciarSisbajudResultado(tab, msg.numero))
      .then((texto) => responder({ texto }), (e) => responder({ texto: 'Erro: ' + ((e && e.message) || e) }));
    return true;
  }
  if (msg.tipo === 'SISBAJUD_RESULTADO_IMPRIMIR' && sender.tab && /^https:\/\/sisbajud\.cnj\.jus\.br\//.test(sender.tab.url || '')) {
    chrome.tabs.create({ url: chrome.runtime.getURL('modulos/sisbajudresultado/imprimir.html'), index: sender.tab.index + 1, openerTabId: sender.tab.id })
      .then(() => responder({ ok: true }), () => responder({ ok: false }));
    return true;
  }
});
