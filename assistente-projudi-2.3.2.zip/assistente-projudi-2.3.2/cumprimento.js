/* cumprimento.js - janela "Ordenar Cumprimentos".
   Pré-preenche tipo, parte, retorno, prazo e orientações conforme o passo do roteiro
   (SISBAJUD, RENAJUD, INFOJUD, CNIB, ofício, mandado). NÃO clica em "Ordenar". */
(() => {
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
  const POLO_AUTOR = /EXEQUENTE|AUTOR|RECLAMANTE|REQUERENTE|PROMOVENTE|CREDOR/;
  const POLO_REU = /EXECUTAD|\bREU\b|RECLAMAD|REQUERID|PROMOVID|DEVEDOR/;
  const botoes = () => Array.from(document.querySelectorAll('input[type="button"], input[type="submit"], button'));
  const ehJanela = () => /Ordenar Cumprimentos/i.test((document.body && document.body.innerText) || '') &&
    /Tipo de Cumprimento/i.test(document.body.innerText) && botoes().some(b => N(b.value || b.textContent) === 'ORDENAR');

  const linhaDe = rot => Array.from(document.querySelectorAll('tr')).find(tr => !tr.querySelector('tr') && N((tr.querySelector('td, th') || {}).textContent || '').replace(/^\*\s*/, '').startsWith(N(rot)));
  const textoRadio = r => {
    const l = r.id && document.querySelector('label[for="' + r.id + '"]');
    return N(l ? l.textContent : (r.nextSibling && r.nextSibling.textContent) || '');
  };
  const destacar = el => { if (el) { el.style.outline = '3px solid #e0a000'; el.style.outlineOffset = '1px'; } };
  const disparar = (el, ...ev) => ev.forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));

  function aplicar(p) {
    const notas = [];
    // Tipo de cumprimento
    const ltipo = linhaDe('Tipo de Cumprimento');
    const sel = ltipo && ltipo.querySelector('select');
    if (sel) {
      // Candidatas: opções com a palavra-chave. Pontuação: modo (+3), contexto (+1 cada),
      // palavras sobrando (-0,3 cada, para preferir a opção mais simples), TRIAGEM/AD HOC/PLANTÃO (-2).
      const VAZIAS = new Set(['DE', 'DA', 'DO', 'DOS', 'DAS', 'E', 'A', 'O', 'POR', 'PARA', 'NO', 'NA', 'EM']);
      const tokens = s => N(s).replace(/E-MAIL/g, 'EMAIL').replace(/[^A-Z0-9 ]/g, ' ').split(' ').filter(w => w && !VAZIAS.has(w));
      const usadas = new Set([].concat(...p.tipos.map(tokens), tokens(p.modo || ''), ...(p.contexto || []).map(tokens)));
      const cands = Array.from(sel.options).filter(o => o.value && p.tipos.some(t => N(o.text).includes(t)))
        .map(o => {
          const t = N(o.text), tk = tokens(o.text);
          let s = 0;
          if (p.modo && t.includes(p.modo)) s += 3;
          (p.contexto || []).forEach(w => { if (tk.includes(w)) s += 1; });
          s -= 0.3 * tk.filter(w => !usadas.has(w)).length;
          if (/^TRIAGEM|AD HOC|PLANTAO/.test(t)) s -= 2;
          if (typeof PREFERIDAS_CUMPRIMENTO !== 'undefined' && PREFERIDAS_CUMPRIMENTO.includes(t)) s += 0.5;
          return { o, s: Math.round(s * 10) / 10 };
        }).sort((a, b) => b.s - a.s);
      const empate = cands.length > 1 && cands[0].s === cands[1].s;
      if (cands.length && !empate) {
        sel.value = cands[0].o.value; disparar(sel, 'change'); notas.push('tipo: ' + cands[0].o.text.trim());
      } else if (cands.length) {
        destacar(sel);
        notas.push('escolha o tipo entre: ' + cands.filter(c => c.s === cands[0].s).map(c => c.o.text.trim()).join(', '));
      } else { destacar(sel); notas.push('escolha o tipo (nenhuma opção com ' + p.tipos.join('/') + ')'); }
    }
    // Referente a(s) parte(s)
    const cbs = Array.from(document.querySelectorAll('input[type="checkbox"]')).filter(cb => {
      const t = N((cb.parentElement && cb.parentElement.textContent) || (cb.nextSibling && cb.nextSibling.textContent) || '');
      return /^\(/.test(t) || /\((EXEQUENTE|EXECUTAD|AUTOR|REU|RECLAMA|REQUER)/.test(t);
    });
    const marcadas = [];
    if (p.polo) cbs.forEach(cb => {
      const t = N((cb.nextSibling && cb.nextSibling.textContent) || (cb.parentElement && cb.parentElement.textContent) || '');
      const quer = p.polo === 'partes' || (p.polo === 'reu' ? POLO_REU.test(t) : POLO_AUTOR.test(t));
      if (cb.checked !== quer) cb.click();
      if (quer) marcadas.push(t.replace(/^\([^)]*\)\s*/, ''));
    });
    if (marcadas.length) notas.push('parte: ' + marcadas.join(', ').toLowerCase());
    else if (cbs.length && p.polo) { destacar(cbs[0].closest('td') || cbs[0]); notas.push('marque a parte'); }
    // Necessita retorno: sim (controle da resposta)
    const lret = linhaDe('Necessita Retorno');
    if (lret) { const sim = Array.from(lret.querySelectorAll('input[type="radio"]')).find(r => /^SIM/.test(textoRadio(r))); if (sim && !sim.checked) sim.click(); }
    // Urgente
    if (p.urgente) {
      const lurg = linhaDe('Urgente');
      const sim = lurg && Array.from(lurg.querySelectorAll('input[type="radio"]')).find(r => /^SIM/.test(textoRadio(r)));
      if (sim && !sim.checked) { sim.click(); notas.push('urgente'); }
    }
    // Prazo
    const lpr = linhaDe('Prazo');
    if (lpr) {
      const txt = lpr.querySelector('input[type="text"], input:not([type])');
      if (txt && p.dias) { txt.value = String(p.dias); disparar(txt, 'input', 'change'); notas.push(p.dias + ' dias ' + (p.corridos ? 'corridos' : 'úteis')); }
      else if (txt) destacar(txt);
      const alvo = Array.from(lpr.querySelectorAll('input[type="radio"]')).find(r => (p.corridos ? /CORRIDOS/ : /UTEIS/).test(textoRadio(r)));
      if (alvo && !alvo.checked) alvo.click();
    }
    // Orientações: o trecho da decisão
    const obs = document.querySelector('textarea');
    if (obs && p.orientacao && !obs.value.trim()) { obs.value = 'Conforme decisão: "' + p.orientacao.trim() + '"'; disparar(obs, 'input', 'change'); }
    return notas.join(' · ') + '. Confira e clique em Ordenar.';
  }

  function barra(msg) {
    let host = document.getElementById('rc-cumprimento-barra');
    if (!host) {
      host = document.createElement('div');
      host.id = 'rc-cumprimento-barra';
      host.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:2147483647;';
      host.attachShadow({ mode: 'open' });
      document.body.appendChild(host);
    }
    host.shadowRoot.innerHTML = `<style>.b{font:12.5px/1.4 "Segoe UI",system-ui,sans-serif;background:#fff;color:#1b2631;border:1px solid #c9d1d8;
      border-top:3px solid #0f5f73;border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.2);padding:8px 10px;max-width:520px}.t{font-weight:700}</style>
      <div class="b"><div class="t">Retorno de Conclusão · cumprimento</div><div id="m"></div></div>`;
    host.shadowRoot.getElementById('m').textContent = msg;
  }

  let feito = false, espera = null;
  async function verificar() {
    if (feito || !ehJanela()) return;
    feito = true;
    try {
      const st = await chrome.storage.local.get('cumprimentoPendente');
      const p = st.cumprimentoPendente;
      if (p && Date.now() - p.ts < 3 * 60 * 1000) {
        await chrome.storage.local.remove('cumprimentoPendente');
        barra(p.rotulo + ' → ' + aplicar(p));
      }
    } catch (e) {}
  }
  verificar();
  new MutationObserver(() => {
    clearTimeout(espera);
    espera = setTimeout(() => {
      if (!feito) verificar();
      else if (!ehJanela()) { feito = false; const b = document.getElementById('rc-cumprimento-barra'); if (b) b.remove(); }
    }, 300);
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
