/* oficio.js - tela "Digitar Documento" com o modelo de OFÍCIO do PROJUDI.
   Segue a skill oficios-judiciais: tipo do ofício, campos obrigatórios por tipo, valores e
   percentuais por extenso, tratamento (Vossa Senhoria / Vossa Excelência) e nada inventado:
   campo obrigatório vazio impede o preenchimento até ser informado.
   Os dados lidos da decisão (Retorno de Conclusão) chegam já preenchidos. */
(() => {
  if (window.top !== window) return;
  const S = OficioSkill, N = S.N;
  const EXT = n => S.extensoInteiro(n);

  // Tipos: os 8 da skill + os de informação usados na vara. Campo: [chave, rótulo, opcional?, opções?]
  const INFO_END = v => 'a informação, a este Juízo, dos endereços e telefones cadastrados em nome de ' + v.EXECUTADO + ' (CPF/CNPJ ' + v.DOC_EXECUTADO + ')';
  const INCLUSAO = v => 'a inclusão do nome de ' + v.EXECUTADO + ' (CPF/CNPJ ' + v.DOC_EXECUTADO + ') no cadastro de inadimplentes, em razão do débito objeto destes autos, no valor de ' + S.reais(v.VALOR);
  const conta = v => v.CONTA_JUDICIAL ? ', com depósito na conta judicial nº ' + v.CONTA_JUDICIAL + (v.AGENCIA ? ', agência ' + v.AGENCIA : '') : ', com repasse a este Juízo';
  const TIPOS = {
    FOLHA: { nome: 'Desconto em folha (empregador)', cargo: 'Diretor(a) de Recursos Humanos', entidade: v => v.EMPRESA + (v.CNPJ_EMPRESA ? ' – CNPJ ' + v.CNPJ_EMPRESA : ''),
      campos: [['EMPRESA', 'Empresa empregadora'], ['CNPJ_EMPRESA', 'CNPJ da empresa', 1], ['PERCENTUAL', 'Percentual (%)'], ['VALOR', 'Valor total da dívida (R$)'], ['CONTA_JUDICIAL', 'Conta judicial', 1], ['AGENCIA', 'Agência', 1]],
      pedido: v => 'o desconto mensal de ' + S.percentual(v.PERCENTUAL) + ' sobre o salário líquido de ' + v.EXECUTADO + ' (CPF ' + v.DOC_EXECUTADO + '), até a quitação integral do débito no valor de ' + S.reais(v.VALOR) + conta(v) + ', a partir da próxima folha de pagamento, comunicando a este Juízo o início do cumprimento da medida' },
    INSS_DESCONTO: { nome: 'INSS – desconto em benefício', cargo: 'Gerente', entidade: () => 'Instituto Nacional do Seguro Social – INSS',
      campos: [['BENEFICIO', 'Nº do benefício'], ['TITULAR', 'Titular do benefício'], ['PERCENTUAL', 'Percentual (%) – máximo 30%'], ['VALOR', 'Valor total da dívida (R$)'], ['CONTA_JUDICIAL', 'Conta judicial', 1], ['AGENCIA', 'Agência', 1]],
      pedido: v => 'o desconto mensal de ' + S.percentual(v.PERCENTUAL) + ' sobre o benefício previdenciário nº ' + v.BENEFICIO + ', de titularidade de ' + v.TITULAR + ', até a quitação integral do débito no valor de ' + S.reais(v.VALOR) + conta(v) },
    DETRAN: { nome: 'DETRAN – restrição veicular', cargo: 'Diretor(a)', entidade: () => 'Departamento de Trânsito do Paraná – DETRAN/PR',
      campos: [['ACAO_VEICULO', 'Providência', 0, ['o registro', 'o cancelamento']], ['RESTRICAO', 'Restrição', 0, ['penhora', 'transferência', 'alienação fiduciária']], ['PLACA', 'Placa'], ['RENAVAM', 'Renavam'], ['PROPRIETARIO', 'Proprietário']],
      pedido: v => v.ACAO_VEICULO + ' da restrição de ' + v.RESTRICAO + ' sobre o veículo de placa ' + v.PLACA + ', Renavam ' + v.RENAVAM + ', de propriedade de ' + v.PROPRIETARIO },
    TABELIONATO: { nome: 'Tabelionato de protestos', cargo: 'Tabelião(ã)', entidade: v => v.TABELIONATO,
      campos: [['TABELIONATO', 'Tabelionato'], ['ACAO', 'Providência', 0, ['a comunicação da penhora', 'o cancelamento do protesto']], ['TITULO', 'Nº do título'], ['VALOR', 'Valor do título (R$)'], ['DATA_PROTESTO', 'Data do protesto'], ['MOTIVO', 'Motivo (cancelamento)', 1]],
      pedido: v => v.ACAO + ' do título nº ' + v.TITULO + ', no valor de ' + S.reais(v.VALOR) + ', protestado em ' + v.DATA_PROTESTO + ', em nome de ' + v.EXECUTADO + (v.MOTIVO ? ', tendo em vista ' + v.MOTIVO : '') },
    CEF: { nome: 'Caixa – conta judicial', cargo: 'Gerente', entidade: v => 'Caixa Econômica Federal – Agência ' + v.AGENCIA,
      campos: [['ACAO', 'Providência', 0, ['a transferência', 'a liberação', 'o bloqueio']], ['VALOR', 'Valor (R$)'], ['CONTA_JUDICIAL', 'Conta judicial'], ['AGENCIA', 'Agência'], ['DESTINO', 'Destino/finalidade', 1]],
      pedido: v => v.ACAO + ' do valor de ' + S.reais(v.VALOR) + ', referente à conta judicial nº ' + v.CONTA_JUDICIAL + ', agência ' + v.AGENCIA + (v.DESTINO ? ', ' + v.DESTINO : '') },
    PENHORA_ROSTO: { nome: 'Penhora no rosto dos autos (Juízo)', juizo: true, cargo: 'Meritíssimo(a) Juiz(a) de Direito', entidade: v => v.VARA_DESTINO + ' da Comarca de ' + v.COMARCA_DESTINO,
      campos: [['PROC_DESTINO', 'Processo onde se penhora'], ['VARA_DESTINO', 'Vara de destino'], ['COMARCA_DESTINO', 'Comarca de destino'], ['VALOR', 'Valor penhorado (R$)']],
      pedido: v => 'o registro da penhora no rosto dos autos nº ' + v.PROC_DESTINO + ', que tramitam perante esse douto Juízo, no valor de ' + S.reais(v.VALOR) + ', determinada nestes autos em favor de ' + v.EXEQUENTE + ' e em face de ' + v.EXECUTADO + ', comunicando a este Juízo quaisquer valores que vierem a ser liberados em favor do(a) executado(a)' },
    CANCELAMENTO: { nome: 'Cancelamento de descontos', cargo: 'Diretor(a) de Recursos Humanos', entidade: v => v.ORGAO,
      campos: [['ORGAO', 'Empresa ou órgão (ex.: INSS)'], ['ONDE', 'Desconto', 0, ['em folha de pagamento', 'no benefício previdenciário']], ['BENEFICIO', 'Nº do benefício (se INSS)', 1], ['TITULAR', 'Titular'], ['MOTIVO', 'Motivo (conforme a decisão)']],
      pedido: v => 'o imediato cancelamento do desconto que vinha sendo realizado ' + v.ONDE + (v.BENEFICIO ? ' nº ' + v.BENEFICIO : '') + ' em nome de ' + v.TITULAR + ', em razão de ' + v.MOTIVO + ', a partir do próximo pagamento' },
    INSS_CNIS: { nome: 'INSS – informações (CNIS)', cargo: 'Gerente', entidade: () => 'Instituto Nacional do Seguro Social – INSS', campos: [],
      pedido: v => 'a remessa a este Juízo das informações constantes do Cadastro Nacional de Informações Sociais (CNIS) em nome de ' + v.EXECUTADO + ' (CPF/CNPJ ' + v.DOC_EXECUTADO + '), em especial vínculos empregatícios, remunerações, benefícios e endereços cadastrados' },
    SERASA_INC: { nome: 'SERASAJUD – inclusão', cargo: '', entidade: () => 'SERASA Experian – SERASAJUD', campos: [['VALOR', 'Valor do débito (R$)']], pedido: INCLUSAO },
    SERASA_EXC: { nome: 'SERASAJUD – exclusão', cargo: '', entidade: () => 'SERASA Experian – SERASAJUD', campos: [],
      pedido: v => 'a exclusão do nome de ' + v.EXECUTADO + ' (CPF/CNPJ ' + v.DOC_EXECUTADO + ') do cadastro de inadimplentes, quanto ao débito objeto destes autos' },
    SPC: { nome: 'SPC Brasil – inclusão', cargo: '', entidade: () => 'SPC Brasil', campos: [['VALOR', 'Valor do débito (R$)']], pedido: INCLUSAO },
    SCPC: { nome: 'SCPC Boa Vista – inclusão', cargo: '', entidade: () => 'Boa Vista Serviços – SCPC', campos: [['VALOR', 'Valor do débito (R$)']], pedido: INCLUSAO },
    CLARO: { nome: 'Claro / Net / Embratel', cargo: '', entidade: () => 'Claro S.A. (Claro / Net / Embratel)', campos: [], pedido: INFO_END },
    OI: { nome: 'Oi', cargo: '', entidade: () => 'Oi S.A.', campos: [], pedido: INFO_END },
    TIM: { nome: 'TIM', cargo: '', entidade: () => 'TIM S.A.', campos: [], pedido: INFO_END },
    VIVO: { nome: 'Vivo / GVT', cargo: '', entidade: () => 'Telefônica Brasil S.A. (Vivo / GVT)', campos: [], pedido: INFO_END },
    NATJUS: { nome: 'NAT-JUS', cargo: '', entidade: () => 'Núcleo de Apoio Técnico do Poder Judiciário – NAT-JUS', campos: [['OBJETO', 'Medicamento/tratamento']],
      pedido: v => 'a emissão de nota técnica sobre o medicamento/tratamento ' + v.OBJETO + ' postulado por ' + v.EXEQUENTE + ' (CPF ' + v.DOC_EXEQUENTE + ')' },
    ALIENADORA: { nome: 'Alienadora fiduciária', cargo: '', entidade: v => v.INSTITUICAO, campos: [['INSTITUICAO', 'Instituição'], ['PLACA', 'Placa'], ['RENAVAM', 'Renavam', 1]],
      pedido: v => 'a informação sobre o contrato de alienação fiduciária do veículo de placa ' + v.PLACA + (v.RENAVAM ? ', Renavam ' + v.RENAVAM : '') + ', em nome de ' + v.EXECUTADO + ' (CPF/CNPJ ' + v.DOC_EXECUTADO + '), com o saldo devedor e a situação do contrato' },
    GENERICO: { nome: 'Genérico', cargo: '', entidade: v => v.ORGAO, campos: [['ORGAO', 'Órgão / entidade'], ['PEDIDO', 'O que se solicita (completa "efetue …")']], pedido: v => v.PEDIDO }
  };

  /* ---------- editor ---------- */
  function editor() {
    const ifr = document.querySelector('iframe.cke_wysiwyg_frame, .cke iframe, iframe[title*="Editor" i]');
    if (ifr) { try { const d = ifr.contentDocument; if (d && d.body) return d.body; } catch (e) {} }
    return document.querySelector('.cke_editable, [contenteditable="true"]');
  }
  const ehTela = () => /Digitar Documento/i.test(document.body.innerText || '') && editor() && /OF[IÍ]CIO/i.test(editor().textContent || '');

  function partes(ed) {
    const t = (ed.innerText || ed.textContent || '').replace(/\u00a0/g, ' ');
    const pega = rot => {
      const m = new RegExp(rot + '\\(?s?\\)?\\s*:\\s*[•·]?\\s*([^\\n(]+?)\\s*\\(([^)]*)\\)', 'i').exec(t);
      if (!m) return { nome: '', doc: '' };
      return { nome: m[1].trim(), doc: (/CPF\/CNPJ:\s*([\d./-]+)/i.exec(m[2]) || /(\d{2,3}\.[\d.\/-]+)/.exec(m[2]) || [])[1] || '' };
    };
    const at = pega('(?:Exequente|Requerente|Autor|Reclamante|Promovente)'), pa = pega('(?:Executado|Requerido|R[ée]u|Reclamado|Promovido)');
    return { EXEQUENTE: at.nome, DOC_EXEQUENTE: at.doc, EXECUTADO: pa.nome, DOC_EXECUTADO: pa.doc, PROCESSO: (/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/.exec(t) || [''])[0] };
  }

  function bloco(ed, re) {
    return Array.from(ed.querySelectorAll('p, div, span, font, strong, b')).filter(e => re.test(N(e.textContent)))
      .sort((a, b) => a.textContent.length - b.textContent.length)[0] || null;
  }
  function trocarBloco(el, texto) {
    if (!el) return false;
    const b = el.closest('p, div') || el;
    if (!texto) { b.remove(); return true; }
    b.textContent = texto; b.style.color = '';
    return true;
  }
  function trocarTexto(ed, de, para) {
    const w = ed.ownerDocument.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let n, ok = false;
    while ((n = w.nextNode())) if (de.test(n.nodeValue)) { n.nodeValue = n.nodeValue.replace(de, para); ok = true; }
    return ok;
  }

  function aplicar(tipo, v, destino, prazo) {
    const ed = editor();
    if (!ed) return { erro: 'Editor não encontrado.' };
    const T = TIPOS[tipo];
    const faltam = T.campos.filter(([k, , opc]) => !opc && !String(v[k] || '').trim()).map(c => c[1]);
    ['EXECUTADO', 'EXEQUENTE'].forEach(k => { if (new RegExp('\\bv\\.' + k + '\\b').test(T.pedido.toString()) && !v[k]) faltam.push(k.toLowerCase() + ' (não lido do cabeçalho)'); });
    if (faltam.length) return { erro: 'Campos obrigatórios não informados (a skill não permite presumir): ' + faltam.join(', ') + '.' };
    const avisos = [];
    if (tipo === 'INSS_DESCONTO' && parseFloat(String(v.PERCENTUAL).replace(',', '.')) > 30) avisos.push('percentual acima do máximo legal de 30% do benefício');
    const feitos = [];
    if (trocarBloco(bloco(ed, /\[NOME DO CARGO/), destino.cargo)) feitos.push('cargo');
    if (trocarBloco(bloco(ed, /\[NOME DO DEPARTAMENTO/), destino.entidade)) feitos.push('destinatário');
    if (trocarBloco(bloco(ed, /ENDERECO FISICO/), destino.endereco || 'Ofício enviado por meio eletrônico')) feitos.push('endereço');
    if (T.juizo) {
      // Destinatário magistrado: Vossa Excelência e "Respeitosamente" (skill, destinatarios.md).
      trocarTexto(ed, /Ao\(À\)\s*Ilmo\(a\)\.\s*Sr\(a\)/, 'Ao(À) Excelentíssimo(a) Senhor(a)');
      trocarTexto(ed, /Prezado\(a\)\s*Senhor\(a\),?/, 'Meritíssimo(a) Senhor(a) Juiz(a),');
      trocarTexto(ed, /Vossa Senhoria/g, 'Vossa Excelência');
      trocarTexto(ed, /Atenciosamente,?/, 'Respeitosamente,');
      feitos.push('tratamento (Vossa Excelência)');
    }
    const par = bloco(ed, /BONS PRESTIMOS/);
    if (par) {
      const p = par.closest('p, div') || par;
      const w = p.ownerDocument.createTreeWalker(p, NodeFilter.SHOW_TEXT); let n, ult = null;
      while ((n = w.nextNode())) {
        n.nodeValue = n.nodeValue.replace(/\s+,/g, ',').replace(/,\s*,/g, ',');
        if (prazo && /\d{1,3}\s*\([^)]*\)\s*dias/i.test(n.nodeValue)) n.nodeValue = n.nodeValue.replace(/\d{1,3}\s*\([^)]*\)\s*dias/i, String(prazo).padStart(2, '0') + ' (' + EXT(prazo) + ') dias');
        if (/efetue/i.test(n.nodeValue)) ult = n;
      }
      // Ao Juízo: "determine" (skill: "que Vossa Excelência se digne a determinar o registro").
      if (ult) { ult.nodeValue = ult.nodeValue.replace(/efetue\s*\S*\s*$/i, (T.juizo ? 'determine ' : 'efetue ') + T.pedido(v) + '.'); feitos.push('pedido'); }
    }
    if (!feitos.includes('pedido')) avisos.push('não encontrei a frase "… efetue" do modelo');
    const desc = document.querySelector('input[name="descricao"], input[id*="descricao" i]');
    if (desc) { desc.value = 'Ofício – ' + destino.entidade; desc.dispatchEvent(new Event('change', { bubbles: true })); }
    return { ok: 'Preenchido: ' + feitos.join(', ') + '.' + (avisos.length ? ' ⚠ ' + avisos.join('; ') + '.' : '') + ' Confira o texto antes de salvar.' };
  }

  /* ---------- leitura de PDFs (abas abertas e autos) ---------- */
  async function garantirLeitor() {
    if (typeof pdfjsLib !== 'undefined') return true;
    const r = await chrome.runtime.sendMessage({ cmd: 'carregarLeitorPdf' });
    return !!(r && r.ok && typeof pdfjsLib !== 'undefined');
  }
  async function baixar(url, nivel) {
    const resp = await fetch(url, { credentials: 'include' });
    const buf = new Uint8Array(await resp.arrayBuffer());
    if (buf[0] === 0x25 && buf[1] === 0x50 && buf[2] === 0x44 && buf[3] === 0x46) return buf;
    if (nivel) return null;
    const m = /<(?:iframe|embed|object)[^>]+(?:src|data)=["']([^"']+)["']/i.exec(new TextDecoder('latin1').decode(buf));
    return m ? baixar(new URL(m[1].replace(/&amp;/g, '&'), url).href, 1) : null;
  }
  async function textoPdf(url) {
    if (!(await garantirLeitor())) throw new Error('leitor de PDF indisponível');
    const dados = await baixar(url, 0);
    if (!dados) throw new Error('o endereço não devolveu um PDF');
    const doc = await pdfjsLib.getDocument({ data: dados, isEvalSupported: false, disableFontFace: true, verbosity: 0 }).promise;
    let t = '';
    for (let i = 1; i <= Math.min(doc.numPages, 8); i++) { const pg = await doc.getPage(i); t += (await pg.getTextContent()).items.map(x => x.str).join(' ') + '\n'; }
    await doc.destroy();
    return t;
  }

  /* ---------- quadro ---------- */
  async function quadro() {
    const ed = editor(); const v0 = partes(ed);
    let st = {}; try { st = await chrome.storage.local.get(['oficiosPendentes', 'oficiosEnderecos']); } catch (e) {}
    const pend = (st.oficiosPendentes || {})[v0.PROCESSO] || null;
    const enderecos = st.oficiosEnderecos || {};

    const host = document.createElement('div');
    host.style.cssText = 'position:fixed;right:16px;top:16px;z-index:2147483647;';
    const raiz = host.attachShadow({ mode: 'open' });
    raiz.innerHTML = `<style>
      .p{font:13px/1.4 "Segoe UI",system-ui,sans-serif;background:#fff;color:#1b2631;border:1px solid #c9d1d8;border-top:3px solid #1a5fa8;
         border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.18);padding:10px 12px;width:390px;max-height:86vh;overflow:auto}
      .t{display:flex;justify-content:space-between;font-weight:700;margin-bottom:4px}
      label{display:block;font-size:12px;color:#56626e;margin-top:6px}
      select,input{width:100%;box-sizing:border-box;font:inherit;font-size:12.5px;padding:4px 6px;border:1px solid #d3d9de;border-radius:5px}
      input.falta{border-color:#e0a000;background:#fff4c2}
      .lin{display:flex;gap:6px;align-items:center;margin-top:6px} .lin input{width:60px}
      button{font:inherit;font-weight:600;padding:5px 10px;border-radius:6px;border:1px solid #1a5fa8;background:#1a5fa8;color:#fff;cursor:pointer;margin:8px 6px 0 0}
      .m{font-size:12px;margin-top:8px;font-weight:600;color:#1a5fa8} .m.e{color:#b42318}
      .dec{font-size:11.5px;color:#56626e;background:#f3f5f7;border-radius:5px;padding:5px 7px;margin:4px 0}
      .min .c{display:none} .min{width:auto} h4{margin:10px 0 0;font-size:12.5px}
      button.s{background:#fff;color:#1a5fa8;margin-top:2px} input.autos{background:#e6f0ff}
      #lista a{display:block;font-size:12px;color:#1a5fa8;cursor:pointer;padding:3px 0;border-bottom:1px solid #eef1f3;overflow-wrap:anywhere}
    </style><div class="p" id="p"><div class="t"><span>Completar ofício</span><span id="min" style="cursor:pointer">–</span></div><div class="c">
      <div class="dec" id="dec" hidden></div>
      <div><button class="s" id="autos">Buscar nos autos</button><button class="s" id="abas">Ler PDF de aba aberta</button></div>
      <div id="lista"></div>
      <label>Tipo de ofício</label><select id="tipo"></select>
      <div id="campos"></div>
      <h4>Destinatário</h4>
      <label>Tratamento / cargo (vazio = linha removida)</label><input id="cargo">
      <label>Entidade / setor</label><input id="ent">
      <label>Endereço físico ou e-mail (fica guardado para esta entidade)</label><input id="end">
      <div class="lin"><label style="margin:0">Prazo (dias)</label><input id="prz" inputmode="numeric" placeholder="05"></div>
      <button id="ap">Preencher o ofício</button>
      <div class="m" id="msg"></div></div></div>`;
    document.body.appendChild(host);
    const $ = id => raiz.getElementById(id);
    Object.entries(TIPOS).forEach(([k, t]) => { const o = document.createElement('option'); o.value = k; o.textContent = t.nome; $('tipo').appendChild(o); });

    const valores = Object.assign({}, v0, { TITULAR: v0.EXECUTADO, PROPRIETARIO: v0.EXECUTADO }, pend ? pend.campos : {});
    const fontes = {};
    if (pend) Object.keys(pend.campos || {}).forEach(k => { fontes[k] = 'decisão' + (pend.data ? ' de ' + pend.data : ''); });

    // Aproveita o texto de um documento: preenche só campos vazios e registra a origem.
    function aproveitar(texto, origem, ehDecisao) {
      const T = N(texto);
      const achados = OficioSkill.extrair(T, v0.PROCESSO);
      const novos = [];
      Object.entries(achados).forEach(([k, val]) => { if (!valores[k]) { valores[k] = val; fontes[k] = origem; novos.push(k); } });
      // Tipo: só se ainda for "Genérico". Decisão pelo trecho determinante; petição pelo texto todo.
      if ($('tipo').value === 'GENERICO') {
        const tr = ehDecisao ? (OficioSkill.trechoDeterminante(T) || T) : T;
        const tp = OficioSkill.classificar(tr);
        if (tp !== 'GENERICO') { $('tipo').value = tp; novos.push('tipo: ' + TIPOS[tp].nome); }
      }
      return novos;
    }
    const ehDec = s => /DECISAO|DESPACHO|SENTENCA|DEFERID|DETERMIN|CONCEDID|HOMOLOGAD/.test(N(s));
    $('tipo').value = 'GENERICO';
    if (pend) {
      $('tipo').value = pend.tipo in TIPOS ? pend.tipo : 'GENERICO';
      $('dec').hidden = false;
      $('dec').textContent = 'Lido da decisão' + (pend.data ? ' de ' + pend.data : '') + ': "' + pend.trecho.slice(0, 260).toLowerCase() + '…"';
    }
    function camposDoTipo(manterDestino) {
      const T = TIPOS[$('tipo').value];
      $('campos').textContent = '';
      T.campos.forEach(([k, rot, opc, ops]) => {
        const l = document.createElement('label'); l.textContent = rot + (opc ? ' (opcional)' : '');
        let i;
        if (ops) { i = document.createElement('select'); ops.forEach(o => { const op = document.createElement('option'); op.value = o; op.textContent = o; i.appendChild(op); }); if (valores[k]) i.value = valores[k]; }
        else { i = document.createElement('input'); i.value = valores[k] || ''; }
        i.dataset.k = k;
        if (fontes[k]) { i.classList.add('autos'); i.title = 'Lido em: ' + fontes[k]; }
        const marca = () => i.classList.toggle('falta', !opc && !String(i.value).trim());
        i.addEventListener('input', () => { valores[k] = i.value; marca(); atualizarDest(); });
        i.addEventListener('change', () => { valores[k] = i.value; atualizarDest(); });
        if (ops) valores[k] = i.value;
        marca();
        $('campos').append(l, i);
      });
      atualizarDest(!manterDestino);
    }
    function atualizarDest(trocouTipo) {
      const T = TIPOS[$('tipo').value];
      if (trocouTipo) $('cargo').value = T.cargo;
      const ent = (T.entidade(valores) || '').replace(/undefined/g, '').trim();
      $('ent').value = ent;
      if (trocouTipo || !$('end').dataset.editado) $('end').value = enderecos[N(ent)] || '';
    }
    $('end').addEventListener('input', () => { $('end').dataset.editado = '1'; });
    $('tipo').addEventListener('change', () => { $('end').dataset.editado = ''; camposDoTipo(); });
    camposDoTipo();
    $('ap').addEventListener('click', () => {
      raiz.querySelectorAll('[data-k]').forEach(i => { valores[i.dataset.k] = i.value.trim(); });
      const destino = { cargo: $('cargo').value.trim(), entidade: $('ent').value.trim(), endereco: $('end').value.trim() };
      const r = aplicar($('tipo').value, valores, destino, parseInt($('prz').value, 10) || null);
      $('msg').className = 'm' + (r.erro ? ' e' : '');
      $('msg').textContent = r.erro || r.ok;
      if (!r.erro && destino.endereco) { enderecos[N(destino.entidade)] = destino.endereco; try { chrome.storage.local.set({ oficiosEnderecos: enderecos }); } catch (e) {} }
    });
    $('min').addEventListener('click', () => $('p').classList.toggle('min'));

    const msg = (t, erro) => { $('msg').className = 'm' + (erro ? ' e' : ''); $('msg').textContent = t; };
    $('abas').addEventListener('click', async () => {
      $('lista').textContent = '';
      const abas = await chrome.runtime.sendMessage({ cmd: 'listarPdfs' });
      if (!abas || !abas.length) { msg('Nenhuma aba com PDF do PROJUDI aberta.', true); return; }
      abas.forEach(t => {
        const a = document.createElement('a'); a.textContent = '📄 ' + t.titulo;
        a.addEventListener('click', async () => {
          msg('Lendo ' + t.titulo + '...');
          try {
            const tx = await textoPdf(t.url);
            if (!tx.trim()) { msg('Esse PDF não tem texto legível (digitalizado).', true); return; }
            const antes = $('tipo').value;
            const n = aproveitar(tx, 'aba "' + t.titulo + '"', true);
            camposDoTipo($('tipo').value === antes);
            msg(n.length ? 'Encontrado: ' + n.join(', ') + '. Confira os campos em azul.' : 'Nenhum dado novo nesse PDF.');
          } catch (e) { msg('Não consegui ler: ' + ((e && e.message) || e), true); }
        });
        $('lista').appendChild(a);
      });
      msg('Escolha o PDF na lista acima.');
    });
    $('autos').addEventListener('click', async () => {
      $('lista').textContent = '';
      msg('Procurando a aba do processo ' + v0.PROCESSO + '...');
      const r = await chrome.runtime.sendMessage({ cmd: 'arquivosDoProcesso', processo: v0.PROCESSO, limite: 8 });
      if (!r || !r.ok || !r.lista.length) {
        msg('Abra o processo ' + v0.PROCESSO + ' em outra aba, na aba Movimentações, e clique de novo. Ou use "Ler PDF de aba aberta".', true);
        return;
      }
      // Decisões primeiro, depois petições, das mais recentes para as mais antigas.
      const lista = r.lista.slice().sort((a, b) => (ehDec(b.titulo) - ehDec(a.titulo)) || b.seq - a.seq);
      const achados = [], antes = $('tipo').value;
      for (const f of lista) {
        msg('Lendo mov. ' + f.seq + ' (' + f.nome + ')...');
        try {
          const tx = await textoPdf(f.url);
          if (tx.trim()) aproveitar(tx, 'mov. ' + f.seq + ' – ' + f.titulo.toLowerCase() + ' (' + f.nome + ')', ehDec(f.titulo)).forEach(k => achados.push(k + ' ← mov. ' + f.seq));
        } catch (e) {}
      }
      camposDoTipo($('tipo').value === antes);
      msg(achados.length ? 'Encontrado nos autos: ' + achados.join('; ') + '. Confira os campos em azul (passe o mouse para ver a origem).' : 'Nada novo encontrado nos ' + lista.length + ' arquivos lidos.');
    });
  }

  let feito = false, espera = null;
  function verificar() { if (feito || !ehTela()) return; feito = true; quadro(); }
  verificar();
  new MutationObserver(() => { clearTimeout(espera); espera = setTimeout(verificar, 600); }).observe(document.body, { childList: true, subtree: true });
})();
