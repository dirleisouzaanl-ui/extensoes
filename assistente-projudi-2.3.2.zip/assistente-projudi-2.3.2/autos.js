/* autos.js - responde, a partir da aba do processo (aba Movimentações aberta), com a lista
   de arquivos das petições e decisões mais recentes, para o quadro "Completar ofício"
   de outra aba ler os dados nos autos. */
(() => {
  if (window.top !== window) return;
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
  const txt = el => ((el && (el.innerText != null ? el.innerText : el.textContent)) || '').trim();
  const dormir = ms => new Promise(r => setTimeout(r, ms));
  const ehLinha = tr => { const c = tr.querySelectorAll(':scope > td'); return c.length >= 4 && parseInt(txt(c[1]), 10) > 0; };
  const urlDe = a => {
    const href = a.getAttribute('href') || '';
    if (href && !/^javascript:|^#/i.test(href)) return a.href;
    const m = /['"]([^'"]*(?:\.do|\.pdf|arquivo)[^'"]*)['"]/i.exec((a.getAttribute('onclick') || '') + ' ' + href);
    return m ? new URL(m[1], location.href).href : null;
  };

  async function coletar(limite) {
    const cab = Array.from(document.querySelectorAll('tr')).find(tr => { const t = N(txt(tr)); return /\bSEQ\b/.test(t) && /\bEVENTO\b/.test(t) && /MOVIMENTADO POR/.test(t) && t.length < 120; });
    if (!cab) return null;
    const linhas = Array.from(cab.closest('table').querySelectorAll(':scope > tbody > tr, :scope > tr')).filter(ehLinha);
    const alvo = linhas.filter(tr => {
      const t = N(txt(tr.querySelectorAll(':scope > td')[3]));
      return /JUNTADA DE PETICAO|PETICAO INICIAL|DEFERID|DECISAO|DESPACHO|SENTENCA|HOMOLOGAD|CONCEDID|DETERMIN/.test(t);
    }).slice(0, limite || 8);
    const res = [];
    for (const tr of alvo) {
      const c = tr.querySelectorAll(':scope > td');
      const detalhes = () => { const d = []; let s = tr.nextElementSibling; while (s && !ehLinha(s)) { d.push(s); s = s.nextElementSibling; } return d; };
      let links = detalhes().flatMap(d => Array.from(d.querySelectorAll('a'))).filter(a => /\.pdf/i.test(txt(a)) || /arquivo|download/i.test(a.getAttribute('href') || ''));
      if (!links.length) {
        (c[0].querySelector('a, img, span, input') || c[0]).click();
        for (let i = 0; i < 16 && !links.length; i++) { await dormir(250); links = detalhes().flatMap(d => Array.from(d.querySelectorAll('a'))).filter(a => /\.pdf/i.test(txt(a)) || /arquivo|download/i.test(a.getAttribute('href') || '')); }
      }
      const ev = txt(c[3]).split('\n'); const por = txt(c[4]).split('\n');
      links.forEach(a => { const u = urlDe(a); if (u) res.push({ seq: parseInt(txt(c[1]), 10), data: txt(c[2]).slice(0, 10), titulo: ev[0], por: por[0] || '', papel: por[1] || '', nome: txt(a), url: u }); });
    }
    return res;
  }

  chrome.runtime.onMessage.addListener((msg, rem, responder) => {
    if (!msg || msg.cmd !== 'coletarArquivos') return;
    const processo = (/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/.exec(txt(document.body)) || [''])[0];
    if (!processo || processo !== msg.processo) { responder({ ok: false }); return; }
    coletar(msg.limite).then(lista => responder(lista ? { ok: true, lista } : { ok: false, erro: 'aba Movimentações fechada' }));
    return true;
  });
})();
