/*
 * config.js — código COMPARTILHADO pelas quatro partes da extensão:
 *   - content script do PROJUDI   (carregado antes do content-projudi.js)
 *   - content script do SISBAJUD  (carregado antes do content-sisbajud.js)
 *   - service worker              (carregado por importScripts no background.js)
 *   - página de opções            (carregado por <script> no options.html)
 *
 * Usamos "self.SISBAJUD = ..." (e não "const") porque "self" existe em todos
 * os ambientes (janela e service worker) e a atribuição não dá erro se o
 * arquivo for carregado de novo depois de recarregar a extensão.
 */

self.SISBAJUD = {
  // Valores usados quando você ainda não salvou nada na página de opções.
  // Ficam em chrome.storage.SYNC (acompanham sua conta Google no Chrome).
  OPCOES_PADRAO: {
    juiz: 'ARTHUR ARAUJO DE OLIVEIRA',  // texto exato da opção "Juiz Solicitante"
    varaCodigo: '8867',                  // código da Vara/Juízo no SISBAJUD
    tipoAcao: 'Ação Cível',              // texto exato de "Tipo/natureza da ação"
    teimosinha: true,                    // marca "Repetir a ordem até a data:"
    diasTeimosinha: 30,                  // hoje + N dias corridos
    pausaMs: 1000,                       // espera após abrir listas/calendário
    confirmarProtocolo: true,            // pergunta antes de clicar em Protocolar
    mostrarPainel: true                  // exibe o painel flutuante no SISBAJUD
  },

  // Faixas aceitas (a página de opções e os scripts respeitam).
  LIMITES: {
    diasTeimosinha: { min: 1, max: 30 },
    pausaMs: { min: 300, max: 5000 }
  },

  // Regras de domínio.
  ehUrlProjudi(endereco) {
    try {
      const u = new URL(endereco);
      return u.protocol === 'https:' &&
             u.hostname.startsWith('projudi') &&
             u.hostname.endsWith('.tjpr.jus.br');
    } catch {
      return false;
    }
  },

  ehUrlSisbajud(endereco) {
    try {
      const u = new URL(endereco);
      return u.protocol === 'https:' && u.hostname === 'sisbajud.cnj.jus.br';
    } catch {
      return false;
    }
  },

  // Lê as opções salvas e completa o que faltar com o padrão.
  async lerOpcoes() {
    const salvas = await chrome.storage.sync.get(self.SISBAJUD.OPCOES_PADRAO);
    return self.SISBAJUD.normalizar(salvas);
  },

  // Garante tipos e faixas, mesmo se algo estranho tiver sido gravado.
  normalizar(op) {
    const L = self.SISBAJUD.LIMITES;
    const P = self.SISBAJUD.OPCOES_PADRAO;
    const faixa = (v, { min, max }, padrao) => {
      const n = Math.round(Number(v));
      return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : padrao;
    };
    const texto = (v, padrao) => (typeof v === 'string' && v.trim() ? v.trim() : padrao);
    return {
      juiz: texto(op.juiz, P.juiz),
      varaCodigo: texto(op.varaCodigo, P.varaCodigo),
      tipoAcao: texto(op.tipoAcao, P.tipoAcao),
      teimosinha: op.teimosinha !== false,
      diasTeimosinha: faixa(op.diasTeimosinha, L.diasTeimosinha, P.diasTeimosinha),
      pausaMs: faixa(op.pausaMs, L.pausaMs, P.pausaMs),
      confirmarProtocolo: op.confirmarProtocolo !== false,
      mostrarPainel: op.mostrarPainel !== false
    };
  },

  // Formato dos dados levados do PROJUDI ao SISBAJUD (chrome.storage.local):
  //   { numProcesso, capturadoEm, origem,
  //     exequentes: [{nome, doc}], executados: [{nome, doc}] }
  // "doc" é CPF ou CNPJ com pontuação; vazio quando a parte não tem.
  CHAVE_DADOS: 'dadosProjudi'
};
