// PROJUDI – Juntadas e Decisões (MV3 / service worker)
const CONFIG = {
  meses: 6,                                   // janela das decisões/despachos
  realces: ['JUIZ', 'ADVOGADO'],              // gruposRealceFiltro<X>
  juntadaRegex: '^(JUNTADA|MANDADO DEVOLVIDO)', // eventos tratados como juntada
  agrupar: true                               // agrupa as abas abertas
};

// Acionada pelo menu da extensão (popup) ou pela tecla 4.
async function rodarJuntadas(tab) {
  if (!/^https:\/\/projudi2?\.tjpr\.jus\.br\/projudi\//.test(tab.url || '')) {
    return badge(tab.id, 'X', '#b00020', 'Abra os autos no PROJUDI.');
  }
  badge(tab.id, '…', '#555', 'Processando…');
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: coletar,
      args: [CONFIG]
    });
    if (result.erro) return badge(tab.id, '!', '#b00020', result.erro);

    const abertas = [];
    let idx = tab.index + 1;
    for (const doc of result.arquivos) {
      const t = await chrome.tabs.create({ url: doc.url, index: idx++, active: false, windowId: tab.windowId });
      abertas.push(t.id);
    }
    if (CONFIG.agrupar && abertas.length) {
      const g = await chrome.tabs.group({ tabIds: abertas });
      await chrome.tabGroups.update(g, { title: result.processo || 'PROJUDI', collapsed: false });
    }
    console.table(result.arquivos);
    badge(tab.id, String(abertas.length), '#1b5e20',
      `Realce: ${result.realce}\n` + result.resumo.join('\n'));
  } catch (e) {
    badge(tab.id, '!', '#b00020', String(e));
  }
}

function badge(tabId, text, color, title) {
  chrome.action.setBadgeText({ tabId, text });
  chrome.action.setBadgeBackgroundColor({ tabId, color });
  chrome.action.setTitle({ tabId, title });
}

// ===== Executado na página dos autos =====
async function coletar(cfg) {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  // 1) Realces
  for (const g of cfg.realces) {
    const cb = document.getElementById('gruposRealceFiltro' + g) ||
               document.querySelector(`input[name="gruposRealceFiltro${g}"]`);
    if (!cb) return { erro: `Checkbox de realce ${g} não encontrado. Abra a aba Movimentações.` };
    if (!cb.checked) cb.click();
  }
  await sleep(300);
  const realceOk = cfg.realces.every(g => document.getElementById('gruposRealceFiltro' + g)?.checked);
  if (!realceOk) return { erro: 'Realce de Magistrado/Advogado não confirmado no HTML.' };

  // 2) Movimentações
  const linhas = [...document.querySelectorAll('tr')].filter(tr =>
    tr.cells.length >= 5 && /^\d+$/.test(tr.cells[1].innerText.trim()) &&
    /^\d{2}\/\d{2}\/\d{4}/.test(tr.cells[2].innerText.trim()));
  if (!linhas.length) return { erro: 'Tabela de movimentações não encontrada.' };

  const parseData = (s) => { const [d, m, a] = s.slice(0, 10).split('/').map(Number); return new Date(a, m - 1, d); };
  const movs = linhas.map(tr => ({
    tr,
    seq: +tr.cells[1].innerText.trim(),
    dataTxt: tr.cells[2].innerText.trim().slice(0, 10),
    data: parseData(tr.cells[2].innerText.trim()),
    evento: tr.cells[3].innerText.trim().split('\n')[0].trim(),
    por: tr.cells[4].innerText.trim(),
    temArquivo: /Arquivos/i.test(tr.cells[0].innerText)
  }));

  const corte = new Date(); corte.setHours(0, 0, 0, 0); corte.setMonth(corte.getMonth() - cfg.meses);
  const decisoes = movs.filter(m => m.temArquivo && /Magistrad/i.test(m.por) && m.data >= corte)
                       .sort((a, b) => b.seq - a.seq);
  const ultimaDec = decisoes.length ? decisoes[0].seq : 0;
  const rx = new RegExp(cfg.juntadaRegex, 'i');
  const juntadas = movs.filter(m => m.temArquivo && !/Magistrad/i.test(m.por) && rx.test(m.evento) &&
                                    (ultimaDec ? m.seq > ultimaDec : m.data >= corte))
                       .sort((a, b) => b.seq - a.seq);

  // 3) Expande "Arquivos" e lê os links
  const linksDe = (tr) => {
    const n = tr.nextElementSibling;
    return n && !(n.cells?.length >= 5 && /^\d+$/.test(n.cells[1]?.innerText.trim()))
      ? [...n.querySelectorAll('a.link')] : [];
  };
  const expandir = async (m) => {
    if (linksDe(m.tr).length) return linksDe(m.tr);
    const toggles = [...m.tr.cells[0].querySelectorAll('a[href^="javascript://nop"]')];
    const t = toggles.find(a => /arquivo/i.test(a.title + a.textContent + (a.querySelector('img')?.alt || '') +
              (a.nextSibling?.textContent || ''))) || toggles[0];
    if (!t) return [];
    t.click();
    for (let i = 0; i < 40 && !linksDe(m.tr).length; i++) await sleep(200);
    return linksDe(m.tr);
  };

  const arquivos = [], resumo = [];
  for (const m of [...decisoes, ...juntadas]) {
    const links = await expandir(m);
    links.forEach(a => arquivos.push({ seq: m.seq, data: m.dataTxt, evento: m.evento,
                                       nome: a.innerText.replace(/\s+/g, ' ').trim(), url: a.href }));
    resumo.push(`Mov. ${m.seq} (${m.dataTxt}) ${m.evento} — ${links.length} arq.`);
  }

  const processo = (document.body.innerText.match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0];
  return { processo, realce: 'Magistrado e Advogado marcados', arquivos, resumo };
}
