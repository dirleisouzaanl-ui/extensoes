/* roteiro.js - na tela "Movimentar Processo" (retorno de conclusão), lê a decisão (PDF)
   e mostra o roteiro de cumprimento, com botão para abrir cada ação do PROJUDI.
   Nada é feito sem o seu clique. */
(() => {
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
  const NUMEROS = { UM: 1, DOIS: 2, TRES: 3, CINCO: 5, DEZ: 10, QUINZE: 15, VINTE: 20, TRINTA: 30, QUARENTA: 40, SESSENTA: 60, NOVENTA: 90 };
  const texto = () => (document.body && document.body.innerText) || '';

  function ehTela() {
    if (!/Movimentar Processo/i.test(texto())) return false;
    // O botão costuma ser <input type="button">, cujo rótulo não aparece no texto da página.
    return Array.from(document.querySelectorAll('input[type="button"], input[type="submit"], button'))
      .some(e => /Finalizar Conclus[aã]o Pendente/i.test(e.value || e.textContent || ''));
  }
  if (!ehTela()) return;

  const processo = (/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/.exec(texto()) || [''])[0];
  const movimentacao = ((/Movimenta[cç][aã]o:\s*([^\n]+)/i.exec(texto()) || [])[1] || '').trim();
  const dataMov = ((/Data:\s*(\d{2}\/\d{2}\/\d{4}[^\n\t]*)/i.exec(texto()) || [])[1] || '').trim();
  const chaveFeitos = 'feitos:' + processo + ':' + dataMov;

  /* ---------------- leitura da decisão ---------------- */
  function linkDecisao() {
    const links = Array.from(document.querySelectorAll('a')).filter(a => /\.pdf/i.test(a.textContent) || /\.pdf|arquivo|download/i.test(a.getAttribute('href') || ''));
    return links[0] || null;
  }
  function urlDoLink(a) {
    const href = a.getAttribute('href') || '';
    if (href && !/^javascript:|^#/i.test(href)) return a.href;
    const m = /['"]([^'"]*(?:\.do|\.pdf|arquivo)[^'"]*)['"]/i.exec((a.getAttribute('onclick') || '') + ' ' + href);
    return m ? new URL(m[1], location.href).href : null;
  }
  async function baixarPdf(url, nivel) {
    const resp = await fetch(url, { credentials: 'include' });
    const buf = new Uint8Array(await resp.arrayBuffer());
    if (buf[0] === 0x25 && buf[1] === 0x50 && buf[2] === 0x44 && buf[3] === 0x46) return buf;
    if (nivel > 0) return null;
    const html = new TextDecoder('latin1').decode(buf);
    const m = /<(?:iframe|embed|object)[^>]+(?:src|data)=["']([^"']+)["']/i.exec(html);
    return m ? baixarPdf(new URL(m[1].replace(/&amp;/g, '&'), url).href, 1) : null;
  }
  async function textoDoPdf(dados) {
    const doc = await pdfjsLib.getDocument({ data: dados, isEvalSupported: false, disableFontFace: true, verbosity: 0 }).promise;
    let t = '';
    for (let i = 1; i <= Math.min(doc.numPages, 10); i++) {
      const p = await doc.getPage(i);
      const c = await p.getTextContent();
      t += c.items.map(x => x.str).join(' ') + '\n';
    }
    await doc.destroy();
    return t;
  }

  /* ---------------- análise do texto ---------------- */
  function prazoDe(frase) {
    let m = /(\d{1,3})\s*(?:\([A-Z ]+\)\s*)?DIAS( UTEIS)?/.exec(frase);
    if (m) return m[1] + ' dias' + (m[2] ? ' úteis' : '');
    m = /PRAZO DE (UM|DOIS|TRES|CINCO|DEZ|QUINZE|VINTE|TRINTA|QUARENTA|SESSENTA|NOVENTA) DIAS( UTEIS)?/.exec(frase);
    if (m) return NUMEROS[m[1]] + ' dias' + (m[2] ? ' úteis' : '');
    if (/PRAZO LEGAL/.test(frase)) return 'prazo legal';
    return '';
  }
  function trechoDe(T, i, tam) {
    const ini = Math.max(0, i - 50);
    return T.slice(ini, Math.min(T.length, i + (tam || 0) + 70)).toLowerCase();
  }

  function analisar(textoDecisao) {
    const T = N(textoDecisao);
    const passos = [];
    // Intimações, frase a frase.
    const frases = T.split(/(?<=[.;:])\s+/);
    let pos = 0;
    const vistos = new Set();
    frases.forEach(f => {
      const ini = T.indexOf(f, pos); pos = ini >= 0 ? ini + f.length : pos;
      if (!/INTIM/.test(f)) return;
      let alvo = ALVOS_INTIMACAO.partes.test(f) ? 'as partes' : '';
      if (!alvo) {
        const a = ALVOS_INTIMACAO.autor.test(f), r = ALVOS_INTIMACAO.reu.test(f);
        alvo = a && r ? 'as partes' : a ? 'o autor' : r ? 'o requerido' : (/INTIMEM-SE/.test(f) ? 'as partes' : 'a parte (conferir quem)');
      }
      const prazo = prazoDe(f);
      const fin = (FINALIDADES.find(([re]) => re.test(f)) || [null, ''])[1];
      const dias = parseInt(prazo, 10) || null;
      const chave = alvo + prazo + fin;
      if (vistos.has(chave)) return;
      vistos.add(chave);
      passos.push({
        acao: 'Intimar Partes',
        intimacao: {
          alvo: alvo === 'o autor' ? 'autor' : alvo === 'o requerido' ? 'reu' : 'partes',
          dias, corridos: /CORRIDOS/.test(f), pessoal: /PESSOALMENTE|INTIMACAO PESSOAL/.test(f),
          urgente: /URGENTE|URGENCIA/.test(f)
        },
        rotulo: (alvo === 'as partes' && !prazo && !fin) ? 'Intimar as partes da decisão' : 'Intimar ' + alvo + (prazo ? ' · ' + prazo : '') + (fin ? ' · ' + fin : ''),
        trecho: f.toLowerCase().slice(0, 260), ordem: ini
      });
    });
    // Demais atos.
    const fraseEm = i => { let ini = 0; for (const f of frases) { const j = T.indexOf(f, ini); if (j <= i && i < j + f.length) return f; ini = j + f.length; } return ''; };
    REGRAS_ATOS.forEach(r => {
      const m = r.se.exec(T);
      if (!m) return;
      const passo = { acao: r.acao, rotulo: r.rotulo, ultimo: !!r.ultimo, trecho: trechoDe(T, m.index, m[0].length), ordem: m.index };
      if (r.cumprimento) {
        const f = fraseEm(m.index);
        // Prazo só se vier depois do comando, na mesma frase (evita pegar o prazo de outra ordem).
        const resto = f ? f.slice(Math.max(0, f.indexOf(m[0]))) : T.slice(m.index, m.index + 200);
        const pz = prazoDe(resto);
        const ctx = f || T.slice(Math.max(0, m.index - 120), m.index + 200);
        const modo = (MODO_CUMPRIMENTO.find(([, re]) => re.test(ctx)) || [''])[0];
        passo.cumprimento = Object.assign({}, r.cumprimento, {
          modo, contexto: CONTEXTO_CUMPRIMENTO.filter(w => new RegExp('\\b' + w + '\\b').test(ctx.replace(/E-MAIL/g, 'EMAIL').replace(/REITERE/g, 'REITERACAO'))),
          dias: parseInt(pz, 10) || null, corridos: /CORRIDOS/.test(f), urgente: /URGENTE|URGENCIA/.test(f), orientacao: f.toLowerCase().slice(0, 400)
        });
        const NOMES_MODO = { DESBLOQUEIO: 'Desbloqueio', TRANSFERENCIA: 'Transferência', 'BUSCA AUTOMATIZADA': 'Busca automatizada', EXCLUSAO: 'Exclusão',
          INCLUSAO: 'Inclusão', BLOQUEIO: 'Bloqueio', CONSULTA: 'Consulta', BUSCA: 'Busca' };
        if (modo && /^(SISBAJUD|RENAJUD|INFOJUD|CNIB|SERASAJUD)$/.test(r.rotulo)) passo.rotulo = NOMES_MODO[modo] + ' ' + r.rotulo + passo.rotulo.slice(r.rotulo.length);
        if (pz) passo.rotulo += ' · ' + pz;
      }
      passos.push(passo);
    });
    // Ofício (skill oficios-judiciais): classifica o tipo e extrai os campos; ficam guardados
    // para a tela "Digitar Documento" deste processo.
    if (typeof OficioSkill !== 'undefined' && /OFICI|DESCONTO EM FOLHA|DESCONTO NO BENEFICIO|PENHORA NO ROSTO/.test(T)) {
      const tr = OficioSkill.trechoDeterminante(T);
      if (tr) {
        const tipo = OficioSkill.classificar(tr);
        const campos = OficioSkill.extrair(tr, processo);
        const p = passos.find(x => x.rotulo === 'Expedir ofício');
        if (p) p.rotulo = 'Expedir ofício (' + tipo.replace(/_/g, ' ').toLowerCase() + ')';
        try {
          chrome.storage.local.get('oficiosPendentes').then(st => {
            const m = st.oficiosPendentes || {};
            Object.keys(m).forEach(k => { if (Date.now() - m[k].ts > 60 * 86400000) delete m[k]; });
            m[processo] = { tipo, campos, trecho: tr, data: dataMov.slice(0, 10), ts: Date.now() };
            chrome.storage.local.set({ oficiosPendentes: m });
          });
        } catch (e) {}
      }
    }
    passos.sort((a, b) => (a.ultimo ? 1 : 0) - (b.ultimo ? 1 : 0) || a.ordem - b.ordem);
    const fim = passos.findIndex(p => p.ultimo);
    const finalizar = { botao: 'Finalizar Conclusão Pendente', rotulo: 'Finalizar a conclusão pendente', trecho: '' };
    if (fim < 0) passos.push(finalizar); else passos.splice(fim, 0, finalizar);
    // Dispositivo: a parte final da decisão.
    const marcas = ['ANTE O EXPOSTO', 'DIANTE DO EXPOSTO', 'ISTO POSTO', 'POSTO ISSO', 'PELO EXPOSTO', 'DIANTE DISSO'];
    let iDisp = -1;
    marcas.forEach(m => { const i = T.lastIndexOf(m); if (i > iDisp) iDisp = i; });
    const dispositivo = (iDisp >= 0 ? T.slice(iDisp) : T.slice(-900)).slice(0, 1400).toLowerCase();
    return { passos, dispositivo };
  }

  /* ---------------- ações na página ---------------- */
  function abrirAcao(passo) {
    if (passo.botao) {
      const b = Array.from(document.querySelectorAll('input[type="button"], input[type="submit"], button'))
        .find(e => N(e.value || e.textContent) === N(passo.botao));
      if (b) { b.click(); return true; }
      return false;
    }
    if (!passo.acao) return false;
    if (passo.intimacao) {
      // A janela "Intimar Partes" lê este pedido e marca partes e prazo (intimacao.js).
      try { chrome.storage.local.set({ intimacaoPendente: Object.assign({ processo, rotulo: passo.rotulo, ts: Date.now() }, passo.intimacao) }); } catch (e) {}
    }
    if (passo.cumprimento) {
      // A janela "Ordenar Cumprimentos" lê este pedido (cumprimento.js).
      try { chrome.storage.local.set({ cumprimentoPendente: Object.assign({ processo, rotulo: passo.rotulo, ts: Date.now() }, passo.cumprimento) }); } catch (e) {}
      if (passo.cumprimento.tipos.includes('OFICIO')) {
        // Guardado também para a tela "Digitar Documento" do ofício (oficio.js).
        try { chrome.storage.local.set({ oficioPendente: { processo, ts: Date.now(), orientacao: passo.cumprimento.orientacao, contexto: passo.cumprimento.contexto, dias: passo.cumprimento.dias } }); } catch (e) {}
      }
    }
    const a = Array.from(document.querySelectorAll('a')).find(e => N(e.textContent).startsWith(N(passo.acao)));
    if (a) { a.click(); return true; }
    return false;
  }

  /* ---------------- quadro ---------------- */
  const host = document.createElement('div');
  host.id = 'retorno-conclusao-painel';
  host.style.cssText = 'position:fixed;right:16px;top:16px;z-index:2147483647;';
  const raiz = host.attachShadow({ mode: 'open' });
  document.body.appendChild(host);
  let estado = { lendo: false, erro: '', resultado: null, feitos: {} };

  function desenhar() {
    const r = estado.resultado;
    raiz.innerHTML = `<style>
      .p{font:13px/1.4 "Segoe UI",system-ui,sans-serif;background:#fff;color:#1b2631;border:1px solid #c9d1d8;border-top:3px solid #0f5f73;
         border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.18);padding:10px 12px;width:380px;max-height:85vh;overflow:auto}
      .t{display:flex;justify-content:space-between;align-items:center;font-weight:700}
      .x{border:0;background:none;font-size:16px;cursor:pointer;color:#56626e}
      .sub{color:#56626e;font-size:12px;margin:2px 0 8px}
      ol{margin:0;padding:0;list-style:none}
      li{border:1px solid #d3d9de;border-left:4px solid #1a5fa8;border-radius:6px;padding:6px 8px;margin-top:6px}
      li.u{border-left-color:#a45a00} li.f{border-left-color:#2c7a37} li.ok{opacity:.55}
      .lin{display:flex;gap:8px;align-items:flex-start}
      .lin input{margin-top:3px}
      .rot{font-weight:600;flex:1}
      .tr{color:#56626e;font-size:11.5px;font-style:italic;margin:3px 0 0 22px}
      button.ab{font:inherit;font-size:12px;font-weight:600;padding:3px 9px;border-radius:5px;border:1px solid #0f5f73;background:#0f5f73;color:#fff;cursor:pointer;white-space:nowrap}
      button.ab:disabled{opacity:.4;cursor:default}
      details{margin-top:10px} summary{cursor:pointer;font-weight:600}
      .disp{white-space:pre-wrap;font-size:12px;background:#f3f5f7;border-radius:6px;padding:8px;margin-top:6px}
      .av{font-size:12px;color:#56626e;margin-top:8px}
      .er{color:#b42318;font-weight:600}
      .min .corpo{display:none} .min{width:auto}
    </style>
    <div class="p" id="p"><div class="t"><span>Roteiro de cumprimento</span><button class="x" id="min">–</button></div>
    <div class="corpo" id="corpo"></div></div>`;
    const corpo = raiz.getElementById('corpo');
    const sub = document.createElement('div'); sub.className = 'sub';
    sub.textContent = processo + (movimentacao ? ' · ' + movimentacao : '');
    corpo.appendChild(sub);
    if (estado.lendo) { const d = document.createElement('div'); d.textContent = 'Lendo a decisão...'; corpo.appendChild(d); }
    if (estado.erro) { const d = document.createElement('div'); d.className = 'er'; d.textContent = estado.erro; corpo.appendChild(d); }
    if (r) {
      const ol = document.createElement('ol');
      r.passos.forEach((p, i) => {
        const li = document.createElement('li');
        const feito = !!estado.feitos[i];
        li.className = (p.ultimo ? 'u' : p.botao ? 'f' : '') + (feito ? ' ok' : '');
        const lin = document.createElement('div'); lin.className = 'lin';
        const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = feito; cb.title = 'Marcar como feito';
        cb.addEventListener('change', () => { estado.feitos[i] = cb.checked; salvarFeitos(); desenhar(); });
        const rot = document.createElement('span'); rot.className = 'rot';
        rot.textContent = (i + 1) + '. ' + p.rotulo + (p.ultimo ? ' (*)' : '');
        const ab = document.createElement('button'); ab.className = 'ab'; ab.type = 'button';
        ab.textContent = p.botao ? 'Finalizar' : 'Abrir';
        ab.disabled = !p.acao && !p.botao;
        ab.title = p.botao || p.acao || 'Faça pelo menu do PROJUDI';
        ab.addEventListener('click', () => { if (!abrirAcao(p)) alert('Não encontrei "' + (p.botao || p.acao) + '" nesta tela.'); });
        lin.append(cb, rot, ab); li.appendChild(lin);
        if (p.trecho) { const t = document.createElement('div'); t.className = 'tr'; t.textContent = '"…' + p.trecho + '…"'; li.appendChild(t); }
        ol.appendChild(li);
      });
      corpo.appendChild(ol);
      const av = document.createElement('div'); av.className = 'av';
      av.textContent = 'Confira o roteiro com a decisão. (*) = ações que o PROJUDI manda realizar por último. A ordem entre "Finalizar" e essas ações deve ser conferida.';
      corpo.appendChild(av);
      const det = document.createElement('details');
      const sm = document.createElement('summary'); sm.textContent = 'Ver o dispositivo da decisão';
      const dp = document.createElement('div'); dp.className = 'disp'; dp.textContent = r.dispositivo;
      det.append(sm, dp); corpo.appendChild(det);
    }
    raiz.getElementById('min').addEventListener('click', () => {
      const p = raiz.getElementById('p'); p.classList.toggle('min');
      raiz.getElementById('min').textContent = p.classList.contains('min') ? '+' : '–';
    });
  }

  function salvarFeitos() { try { chrome.storage.local.set({ [chaveFeitos]: estado.feitos }); } catch (e) {} }

  async function iniciar() {
    try { const st = await chrome.storage.local.get(chaveFeitos); estado.feitos = st[chaveFeitos] || {}; } catch (e) {}
    estado.lendo = true; desenhar();
    try {
      const a = linkDecisao();
      if (!a) throw new Error('Não encontrei o arquivo da decisão (online.pdf) nesta tela.');
      const url = urlDoLink(a);
      if (!url) throw new Error('O link da decisão não pôde ser aberto pela extensão.');
      if (typeof pdfjsLib === 'undefined') {
        const r = await chrome.runtime.sendMessage({ cmd: 'carregarLeitorPdf' });
        if (!r || !r.ok || typeof pdfjsLib === 'undefined') throw new Error('Não consegui carregar o leitor de PDF.');
      }
      const dados = await baixarPdf(url, 0);
      if (!dados) throw new Error('O arquivo da decisão não veio como PDF.');
      const t = await textoDoPdf(dados);
      if (!t.trim()) throw new Error('A decisão não tem texto legível (PDF digitalizado).');
      estado.resultado = analisar(t);
    } catch (e) {
      estado.erro = (e && e.message) || String(e);
    } finally { estado.lendo = false; desenhar(); }
  }
  iniciar();
})();
