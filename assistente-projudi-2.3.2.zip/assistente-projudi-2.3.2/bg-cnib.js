// Assistente PROJUDI 2.2 — módulo PROJUDI → CNIB (antiga extensão PROJUDI → CNIB 1.0.2).
// Leva à aba da CNIB já aberta (ou abre uma) depois da captura no PROJUDI; não navega dentro da CNIB
// (acesso por certificado digital). Também salva a tela da CNIB em PDF como "CNIB - RESULTADO INFRUTÍFERO".
const URL_CNIB = 'https://indisponibilidade.onr.org.br/';

chrome.runtime.onMessage.addListener((msg, sender, resp) => {
  if (!msg) return;
  if (msg.tipo === 'cn-ir-cnib') {
    (async () => {
      const abas = await chrome.tabs.query({ url: 'https://indisponibilidade.onr.org.br/*' });
      const aba = abas.find((t) => t.active) || abas[0];
      if (aba) {
        await chrome.tabs.update(aba.id, { active: true });
        await chrome.windows.update(aba.windowId, { focused: true });
      } else {
        await chrome.tabs.create({ url: URL_CNIB, windowId: sender.tab ? sender.tab.windowId : undefined, active: true });
      }
      resp({ ok: true, reaproveitada: !!aba });
    })().catch((e) => resp({ ok: false, erro: e.message }));
    return true;
  }
  if (msg.tipo === 'cn-imprimir-infrutifero') {
    (async () => {
      if (!sender.tab) throw new Error('aba não identificada');
      if (typeof self.salvarPaginaPdf !== 'function') throw new Error('módulo Salvar PDF indisponível');
      const nome = await self.salvarPaginaPdf(sender.tab.id, { nome: msg.nome || 'CNIB - RESULTADO INFRUTÍFERO', paisagem: false });
      resp({ ok: true, nome });
    })().catch((e) => resp({ ok: false, erro: e.message }));
    return true;
  }
});
