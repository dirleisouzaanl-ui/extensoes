// Assistente PROJUDI 2.1 — módulo Ferramentas (antiga EXTENSAO-PROJUDI 2.9.2), carregado por background.js
// Reúne: Intimações (1/2/3) · Juntadas e Decisões (4) · PROJUDI → SISBAJUD (5)
importScripts('config.js', 'juntadas.js',
  'modulos/novaaba/config.js', 'modulos/novaaba/background.js',   // Abrir em nova aba (↗ / Abrir todos)
  'modulos/renajud/background.js',
  'modulos/onlinepdf.js',
  'modulos/salvarpdf.js',
  'modulos/seeu/background.js',
  'modulos/abrirconclusoes/background.js',
  'modulos/ultimajuntada.js',
  'modulos/buscarapida/background.js');   // Busca rápida de processo                                     // Abrir a última juntada (tecla U)                        // Abrir processos das Conclusões (tecla A)                                   // Extensão SEEU (destaques / captura de modelo)                                         // Salvar página em PDF (tecla 9)                                         // Abrir online.pdf (tecla 8)                                // PROJUDI → RENAJUD // config.js = self.SISBAJUD ; juntadas.js = rodarJuntadas(tab)

const CHAVE = 'intimacoes_estado';
const MODOS = {
  autora: 'Intimação parte autora',
  re: 'Intimação parte ré',
  ambas: 'Intimação ambas as partes'
};

// ===================== INTIMAÇÕES =====================
async function iniciarIntimacao(tab, modo) {
  if (!/^https:\/\/[^/]*tjpr\.jus\.br\//.test(tab.url || '')) return 'Abra a conclusão no PROJUDI.';
  const { [CHAVE]: atual } = await chrome.storage.local.get(CHAVE);
  if (atual && atual.ativo) return 'Já há uma intimação em andamento (use Cancelar).';
  // só começa se a tela tiver o botão "Finalizar Conclusão Pendente"
  let temBotao = false;
  try {
    const r = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: () => /finalizar\s+conclus[aã]o\s+pendente/i.test(
        (document.body?.innerText || '') + ' ' +
        [...document.querySelectorAll('input[type=button],input[type=submit]')].map((e) => e.value).join(' '))
    });
    temBotao = r.some((x) => x.result);
  } catch { /* página sem permissão */ }
  if (!temBotao) return 'Esta tela não tem o botão "Finalizar Conclusão Pendente".';
  const agora = Date.now();
  await chrome.storage.local.set({ [CHAVE]: {
    ativo: true, etapa: 1, tabId: tab.id, inicio: agora, desde: agora, modo,
    log: [hora() + ' Fluxo iniciado: ' + MODOS[modo] + '.']
  } });
  marcar(tab.id, '1', '#1565c0', 'Intimação em andamento…');
  return 'Iniciado: ' + MODOS[modo] + '.';
}

async function cancelarIntimacao() {
  const { [CHAVE]: atual } = await chrome.storage.local.get(CHAVE);
  if (!atual || !atual.ativo) return 'Nenhuma intimação em andamento.';
  await chrome.storage.local.set({ [CHAVE]: { ...atual, ativo: false, etapa: 'cancelado', desde: Date.now(),
    log: [...(atual.log || []), hora() + ' Fluxo cancelado pelo usuário.'] } });
  return 'Intimação cancelada.';
}

// ===================== PROJUDI → SISBAJUD =====================
async function copiarPartes(tab) {
  try {
    const r = await chrome.tabs.sendMessage(tab.id, { tipo: 'COPIAR_PARTES' });
    return r ? r.aviso : 'Abra a tela do processo que mostra as partes.';
  } catch {
    return 'Abra a tela do processo que mostra as partes (e dê F5 se acabou de instalar).';
  }
}

function remetenteEhAbaProjudi(sender) {
  return sender.id === chrome.runtime.id && !!sender.tab && self.SISBAJUD.ehUrlProjudi(sender.url);
}
function remetenteEhPaginaDaExtensao(sender) {
  return sender.id === chrome.runtime.id && typeof sender.url === 'string' &&
         sender.url.startsWith(chrome.runtime.getURL(''));
}
const RE_CNJ = /^\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}$/;
const RE_DOC = /^(\d{3}\.\d{3}\.\d{3}-\d{2}|\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2})?$/;
function limparPartes(lista) {
  return (Array.isArray(lista) ? lista : [])
    .filter((p) => p && typeof p.nome === 'string' && p.nome.trim())
    .map((p) => ({ nome: p.nome.trim().slice(0, 200), doc: typeof p.doc === 'string' && RE_DOC.test(p.doc) ? p.doc : '' }))
    .slice(0, 50);
}
function limparDados(dados, sender) {
  if (!dados || !RE_CNJ.test(dados.numProcesso || '')) return null;
  const executados = limparPartes(dados.executados);
  if (!executados.length) return null;
  const valorCausa = typeof dados.valorCausa === 'string' && /^\d{1,3}(\.\d{3})*,\d{2}$|^\d+,\d{2}$/.test(dados.valorCausa) ? dados.valorCausa : '';
  return { numProcesso: dados.numProcesso, exequentes: limparPartes(dados.exequentes), executados, valorCausa,
           capturadoEm: new Date().toISOString(), origem: sender.url };
}

// ===================== MENSAGENS =====================
chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  const tipo = msg && msg.tipo;

  // --- menu (popup)
  if (tipo === 'MENU') {
    (async () => {
      const tab = msg.tabId != null ? await chrome.tabs.get(msg.tabId) : sender.tab; // barra de botões: usa a aba que pediu
      if (!tab) return 'Aba não encontrada.';
      if (msg.acao === 'lote') {
        const r = await chrome.tabs.sendMessage(tab.id, { tipo: 'MOSTRAR_LOTE' }).catch(() => null);
        return r && r.ok ? '✓ Painel do lote aberto na página.' : 'Abra a tela Análise de Juntadas e dê F5.';
      }
      if (msg.acao === 'prazos') {
        const { prazosCfg: c } = await chrome.storage.local.get('prazosCfg');
        const cfg = { ativo: true, dias: 3, ...(c || {}) };
        cfg.ativo = !cfg.ativo;
        await chrome.storage.local.set({ prazosCfg: cfg });
        return '✓ Painel de prazos ' + (cfg.ativo ? 'LIGADO.' : 'DESLIGADO.');
      }
      if (msg.acao === 'autora' || msg.acao === 're' || msg.acao === 'ambas') return iniciarIntimacao(tab, msg.acao);
      if (msg.acao === 'cancelar') return cancelarIntimacao();
      if (msg.acao === 'juntadas') { await rodarJuntadas(tab); return 'Juntadas e decisões: veja o número no ícone.'; }
      if (msg.acao === 'copiar') return copiarPartes(tab);
      if (msg.acao === 'ultimajuntada') return self.abrirUltimaJuntada(tab);
      if (msg.acao === 'abrirconclusoes') {
        const r = await chrome.tabs.sendMessage(tab.id, { tipo: 'CLICAR_ABRIR_CONCLUSOES' }).catch(() => null);
        return r && r.ok ? '✓ Confirme na página quais processos abrir.' : 'Abra a lista de Conclusões ou de Análise de Juntadas e dê F5.';
      }
      if (msg.acao === 'onlinepdf') return self.abrirOnlinePdf(tab);
      if (msg.acao === 'salvarpdf') return '✓ Salvo: ' + await self.salvarPaginaPdf(tab.id, {});
      if (msg.acao === 'opcoes') { chrome.runtime.openOptionsPage(); return ''; }
      if (msg.acao === 'opcoes-novaaba') { chrome.tabs.create({ url: chrome.runtime.getURL('modulos/novaaba/options.html') }); return ''; }
      return 'Ação desconhecida.';
    })().then((t) => responder({ texto: t })).catch((e) => responder({ texto: 'Erro: ' + e }));
    return true;
  }

  // --- barra de botões: abre o menu da extensão já na página do módulo pedido
  if (tipo === 'ABRIR_PAGINA_MENU') {
    (async () => {
      const PERMITIDAS = ['modulos/mesclar/popup.html', 'modulos/expedir/popup.html',
        'modulos/pdfsrecentes/popup.html', 'modulos/renajud/popup.html', 'modulos/seeu/popup/popup.html',
        'modulos/sisbajudpdf/popup.html', 'modulos/decurso/popup.html', 'modulos/modelos/popup.html',
        'modulos/buscarapida/popup.html', 'modulos/precatorio/popup.html', 'modulos/pendencias/popup.html',
        'modulos/mandados/popup.html', 'modulos/peticao/popup.html', 'popup.html?acao=copiardados', 'modulos/cnib/popup.html'];
      if (!PERMITIDAS.includes(msg.pagina)) return { ok: false, motivo: 'página desconhecida' };
      await chrome.storage.session.set({ paginaInicialMenu: msg.pagina });
      try { await chrome.action.openPopup({ windowId: sender.tab && sender.tab.windowId }); return { ok: true }; }
      catch (e) { await chrome.storage.session.remove('paginaInicialMenu'); return { ok: false, motivo: 'Clique no ícone da extensão (ou Alt+P) para abrir.' }; }
    })().then(responder);
    return true;
  }

  // --- intimações (content script)
  if (tipo === 'INICIAR' && sender.tab) {
    iniciarIntimacao(sender.tab, msg.modo).then((t) => !/^Iniciado/.test(t) && console.warn(t));
    return;
  }
  if (tipo === 'MEU_TAB') {
    responder({ tabId: sender.tab?.id, opener: sender.tab?.openerTabId, frameId: sender.frameId });
    return;
  }
  if (tipo === 'AUTO_CONFIRM') {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id, frameIds: [sender.frameId] },
      world: 'MAIN',
      func: () => { window.confirm = () => true; window.alert = () => {}; }
    }).then(() => responder({ ok: true })).catch((e) => responder({ ok: false, erro: String(e) }));
    return true;
  }
  if (tipo === 'BADGE') {
    marcar(sender.tab?.id, msg.texto, msg.cor, msg.titulo);
    return;
  }

  // --- SISBAJUD
  if (tipo === 'GUARDAR_DADOS') {
    if (!remetenteEhAbaProjudi(sender)) { responder({ ok: false, motivo: 'a mensagem não veio de uma aba do PROJUDI' }); return; }
    const dados = limparDados(msg.dados, sender);
    if (!dados) { responder({ ok: false, motivo: 'dados incompletos (nº do processo ou executados)' }); return; }
    chrome.storage.local.set({ [self.SISBAJUD.CHAVE_DADOS]: dados }).then(() => responder({ ok: true }));
    return true;
  }
  if (tipo === 'LIMPAR_DADOS') {
    if (!remetenteEhPaginaDaExtensao(sender)) { responder({ ok: false, motivo: 'só a página de opções pode limpar os dados' }); return; }
    chrome.storage.local.remove(self.SISBAJUD.CHAVE_DADOS).then(() => responder({ ok: true }));
    return true;
  }
});

// ===================== ATALHOS =====================
chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (!tab) [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  if (cmd === 'intimacao-ambas') iniciarIntimacao(tab, 'ambas');
  if (cmd === 'juntadas') rodarJuntadas(tab);
  if (cmd === 'salvar-pdf') self.salvarPaginaPdf(tab.id, {}).catch((e) => marcar(tab.id, '!', '#b00020', e.message));
});

function marcar(tabId, text, color, title) {
  if (tabId == null) return;
  chrome.action.setBadgeText({ tabId, text: text || '' });
  if (color) chrome.action.setBadgeBackgroundColor({ tabId, color });
  if (title) chrome.action.setTitle({ tabId, title });
}
function hora() { return new Date().toLocaleTimeString('pt-BR'); }
