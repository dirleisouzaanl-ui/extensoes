var statusEl = document.getElementById('status');
var listaEl = document.getElementById('lista');
var btnMerge = document.getElementById('btnMerge');
var progressEl = document.getElementById('progress');
var progressBar = document.getElementById('progress-bar');

// Ordem de seleção
var ordemSelecao = [];

function isPdfTab(tab) {
  if (!tab.url) return false;
  var url = tab.url.toLowerCase();
  // URL termina em .pdf ou contém .pdf?
  if (/\.pdf(\?|#|$)/.test(url)) return true;
  // Título termina em .pdf
  if (tab.title && tab.title.toLowerCase().endsWith('.pdf')) return true;
  // Viewer interno do Chrome
  if (url.startsWith('chrome-extension://') && url.includes('pdf')) return true;
  // blob: URLs (PDFs abertos por sistemas como SISBAJUD)
  if (url.startsWith('blob:')) return true;
  return false;
}

function carregarAbas() {
  ordemSelecao = [];
  listaEl.innerHTML = '<div id="vazio">Carregando...</div>';
  btnMerge.disabled = true;

  chrome.tabs.query({}, function(tabs) {
    var pdfs = tabs.filter(isPdfTab);

    if (pdfs.length === 0) {
      listaEl.innerHTML = '<div id="vazio">Nenhuma aba com PDF encontrada.<br>Abra arquivos PDF no Chrome e clique em 🔄</div>';
      return;
    }

    listaEl.innerHTML = '';
    var cnj = pdfs.map(function(t) { return ((t.title || '') + ' ' + t.url).match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/); }).find(Boolean);
    var campoNome = document.getElementById('nomeArquivo');
    if (cnj && campoNome.value === 'merged') campoNome.value = cnj[0] + ' - PDFs unidos';
    pdfs.forEach(function(tab) {
      var item = document.createElement('div');
      item.className = 'item';
      item.dataset.tabId = tab.id;
      item.dataset.url = tab.url;

      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.id = 'cb_' + tab.id;

      var order = document.createElement('div');
      order.className = 'item-order';
      order.id = 'ord_' + tab.id;

      var info = document.createElement('div');
      info.className = 'item-info';

      var title = document.createElement('div');
      title.className = 'item-title';
      title.textContent = tab.title || 'PDF sem título';

      var url = document.createElement('div');
      url.className = 'item-url';
      url.textContent = tab.url;

      info.appendChild(title);
      info.appendChild(url);
      item.appendChild(cb);
      item.appendChild(order);
      item.appendChild(info);
      listaEl.appendChild(item);

      function toggleItem() {
        var idx = ordemSelecao.indexOf(tab.id);
        if (cb.checked) {
          if (idx === -1) ordemSelecao.push(tab.id);
        } else {
          if (idx !== -1) ordemSelecao.splice(idx, 1);
        }
        atualizarOrdem();
        btnMerge.disabled = ordemSelecao.length < 2;
      }

      cb.addEventListener('change', toggleItem);
      item.addEventListener('click', function(e) {
        if (e.target !== cb) { cb.checked = !cb.checked; toggleItem(); }
      });
    });
  });
}

function atualizarOrdem() {
  document.querySelectorAll('.item-order').forEach(function(el) { el.textContent = ''; });
  ordemSelecao.forEach(function(tabId, idx) {
    var ord = document.getElementById('ord_' + tabId);
    if (ord) ord.textContent = (idx + 1) + 'º';
  });
}

document.getElementById('btnTodos').addEventListener('click', function() {
  ordemSelecao = [];
  document.querySelectorAll('.item input[type="checkbox"]').forEach(function(cb) {
    cb.checked = true;
    var tabId = parseInt(cb.id.replace('cb_', ''));
    ordemSelecao.push(tabId);
  });
  atualizarOrdem();
  btnMerge.disabled = ordemSelecao.length < 2;
});

document.getElementById('btnNenhum').addEventListener('click', function() {
  ordemSelecao = [];
  document.querySelectorAll('.item input[type="checkbox"]').forEach(function(cb) { cb.checked = false; });
  atualizarOrdem();
  btnMerge.disabled = true;
});

document.getElementById('btnRefresh').addEventListener('click', carregarAbas);

document.getElementById('btnMerge').addEventListener('click', async function() {
  if (ordemSelecao.length < 2) return;

  btnMerge.disabled = true;
  progressEl.style.display = 'block';
  progressBar.style.width = '0%';
  statusEl.textContent = 'Iniciando mesclagem...';

  // Coleta URLs na ordem de seleção
  var items = document.querySelectorAll('.item');
  var urlMap = {};
  items.forEach(function(item) {
    urlMap[parseInt(item.dataset.tabId)] = item.dataset.url;
  });

  try {
    var { PDFDocument } = PDFLib;
    var mergedDoc = await PDFDocument.create();

    for (var i = 0; i < ordemSelecao.length; i++) {
      var tabId = ordemSelecao[i];
      var url = urlMap[tabId];
      var pct = Math.round((i / ordemSelecao.length) * 85);
      progressBar.style.width = pct + '%';
      statusEl.textContent = 'Carregando PDF ' + (i + 1) + ' de ' + ordemSelecao.length + '...';

      var arrayBuffer;
      if (url.startsWith('blob:')) {
        // blob: URLs só podem ser lidas dentro da própria aba
        var results = await chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: async function() {
            try {
              var blobUrl = document.querySelector('embed[type="application/pdf"]')?.src
                || document.querySelector('iframe')?.src
                || window.location.href;
              var res = await fetch(blobUrl);
              var buf = await res.arrayBuffer();
              // Converte para base64 para passar pela mensagem
              var bytes = new Uint8Array(buf);
              var binary = '';
              for (var b = 0; b < bytes.length; b++) binary += String.fromCharCode(bytes[b]);
              return btoa(binary);
            } catch(e) { return null; }
          }
        });
        var b64 = results && results[0] && results[0].result;
        if (!b64) throw new Error('Não foi possível ler o PDF da aba ' + (i + 1) + '. Verifique se o PDF está visível na aba.');
        var binary = atob(b64);
        var bytes = new Uint8Array(binary.length);
        for (var b = 0; b < binary.length; b++) bytes[b] = binary.charCodeAt(b);
        arrayBuffer = bytes.buffer;
      } else {
        var response = await fetch(url, { credentials: 'include' });
        if (!response.ok) throw new Error('Falha ao carregar: ' + url);
        arrayBuffer = await response.arrayBuffer();
      }

      var pdfDoc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
      var pageCount = pdfDoc.getPageCount();
      var indices = Array.from({ length: pageCount }, function(_, k) { return k; });
      var pages = await mergedDoc.copyPages(pdfDoc, indices);
      pages.forEach(function(page) { mergedDoc.addPage(page); });
    }

    progressBar.style.width = '95%';
    statusEl.textContent = 'Gerando arquivo final...';

    var mergedBytes = await mergedDoc.save();
    var blob = new Blob([mergedBytes], { type: 'application/pdf' });
    var blobUrl = URL.createObjectURL(blob);

    var nome = (document.getElementById('nomeArquivo').value.trim() || 'merged') + '.pdf';

    await chrome.downloads.download({ url: blobUrl, filename: nome.replace(/[\\/:*?"<>|]/g, '_'), saveAs: false });

    progressBar.style.width = '100%';
    statusEl.textContent = '✅ PDF mesclado salvo como "' + nome + '"';
  } catch (e) {
    statusEl.textContent = '❌ Erro: ' + e.message;
    progressEl.style.display = 'none';
  }

  btnMerge.disabled = false;
});

// Inicia
carregarAbas();
