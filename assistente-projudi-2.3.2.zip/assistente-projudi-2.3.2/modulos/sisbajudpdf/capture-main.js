(() => {
  if (window.__sisbajudPdfInterceptorInstalled) return;
  window.__sisbajudPdfInterceptorInstalled = true;

  const originalCreateObjectURL = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (object) {
    const url = originalCreateObjectURL(object);
    if (object instanceof Blob) {
      window.postMessage({
        source: "sisbajud-pdf-unificador",
        type: "blob-created",
        url
      }, location.origin);
    }
    return url;
  };
})();
