(() => {
  const captured = [];
  let processing = Promise.resolve();

  const formatBytes = (bytes) => {
    if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  async function addCandidate(url) {
    const response = await fetch(url);
    if (!response.ok) return;
    const blob = await response.blob();
    const header = new Uint8Array(await blob.slice(0, 5).arrayBuffer());
    if (String.fromCharCode(...header) !== "%PDF-") return;

    captured.push({
      blob,
      name: `PDF ${captured.length + 1}`,
      size: blob.size,
      capturedAt: Date.now()
    });
    while (captured.length > 2) captured.shift();
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const data = event.data;
    if (data?.source !== "sisbajud-pdf-unificador" || data.type !== "blob-created") return;
    processing = processing.then(() => addCandidate(data.url)).catch(() => {});
  });

  async function merge(order) {
    await processing;
    if (captured.length !== 2) throw new Error("Abra dois PDFs no SISBAJUD antes de unir.");

    const output = await PDFLib.PDFDocument.create();
    for (const index of order) {
      const bytes = await captured[index].blob.arrayBuffer();
      const source = await PDFLib.PDFDocument.load(bytes);
      const pages = await output.copyPages(source, source.getPageIndices());
      pages.forEach((page) => output.addPage(page));
    }

    const result = await output.save();
    const blob = new Blob([result], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `sisbajud-unificado-${new Date().toISOString().slice(0, 10)}.pdf`;
    anchor.style.display = "none";
    document.documentElement.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "status") {
      processing.then(() => sendResponse({
        ok: true,
        documents: captured.map((item, index) => ({
          index,
          name: item.name,
          size: formatBytes(item.size),
          capturedAt: item.capturedAt
        }))
      }));
      return true;
    }

    if (message?.type === "clear") {
      captured.length = 0;
      sendResponse({ ok: true });
      return false;
    }

    if (message?.type === "merge") {
      merge(message.reverse ? [1, 0] : [0, 1])
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: error.message }));
      return true;
    }
  });
})();
