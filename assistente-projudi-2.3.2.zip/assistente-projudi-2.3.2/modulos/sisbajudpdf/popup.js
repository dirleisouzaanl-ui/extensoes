const statusElement = document.querySelector("#status");
const documentsElement = document.querySelector("#documents");
const mergeButton = document.querySelector("#merge");
const clearButton = document.querySelector("#clear");
const reverseCheckbox = document.querySelector("#reverse");
let targetTabId = null;

function setStatus(text, className = "") {
  statusElement.textContent = text;
  statusElement.className = className;
}

function send(tabId, message) {
  return chrome.tabs.sendMessage(tabId, message);
}

async function locateCaptureTab() {
  const tabs = await chrome.tabs.query({ url: "https://sisbajud.cnj.jus.br/*" });
  let best = null;
  for (const tab of tabs) {
    try {
      const response = await send(tab.id, { type: "status" });
      if (response?.ok && (!best || response.documents.length > best.response.documents.length)) {
        best = { tab, response };
      }
    } catch (_) {}
  }
  return best;
}

async function refresh() {
  const match = await locateCaptureTab();
  documentsElement.replaceChildren();
  if (!match) {
    setStatus("Nenhuma página compatível do SISBAJUD foi encontrada.", "error");
    return;
  }

  targetTabId = match.tab.id;
  const documents = match.response.documents;
  for (const documentInfo of documents) {
    const item = document.createElement("li");
    item.textContent = `${documentInfo.name} — ${documentInfo.size}`;
    documentsElement.appendChild(item);
  }

  mergeButton.disabled = documents.length !== 2;
  clearButton.disabled = documents.length === 0;
  setStatus(documents.length === 2
    ? "Dois PDFs prontos para união."
    : `${documents.length} de 2 PDFs capturados.`);
}

mergeButton.addEventListener("click", async () => {
  mergeButton.disabled = true;
  setStatus("Unindo os documentos…");
  try {
    const result = await send(targetTabId, { type: "merge", reverse: reverseCheckbox.checked });
    if (!result?.ok) throw new Error(result?.error || "Não foi possível unir os PDFs.");
    setStatus("PDF unido e enviado para download.", "success");
  } catch (error) {
    setStatus(error.message, "error");
    mergeButton.disabled = false;
  }
});

clearButton.addEventListener("click", async () => {
  await send(targetTabId, { type: "clear" });
  await refresh();
});

refresh().catch(() => setStatus("Erro ao consultar o SISBAJUD.", "error"));
