// Certidão de decurso de prazo (tecla C). Lê as movimentações dos autos, calcula o termo final
// do prazo a partir da intimação escolhida e monta o texto da certidão. Só lê a página.
const $ = (id) => document.getElementById(id);
let movs = [], numero = '';

// ---------- injetada nos autos ----------
async function lerMovimentacoes() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const linhas = () => [...document.querySelectorAll('tr')].filter((tr) =>
    tr.cells.length >= 5 && /^\d+$/.test(tr.cells[1].innerText.trim()) &&
    /^\d{2}\/\d{2}\/\d{4}/.test(tr.cells[2].innerText.trim()));
  if (!linhas().length) {
    const aba = [...document.querySelectorAll('a, li, span, td')]
      .find((el) => /^\s*movimenta[cç][oõ]es\s*$/i.test(el.textContent));
    if (!aba) return null;
    (aba.closest('a') || aba).click();
    for (let i = 0; i < 40 && !linhas().length; i++) await sleep(250);
  }
  const numero = ((document.body.innerText || '').match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0];
  return {
    numero,
    movs: linhas().map((tr) => {
      const t = tr.cells[3].innerText.trim().split('\n').map((s) => s.trim()).filter(Boolean);
      return {
        seq: +tr.cells[1].innerText.trim(), data: tr.cells[2].innerText.trim().slice(0, 10),
        evento: t[0] || '', desc: t.slice(1).join(' '), por: tr.cells[4].innerText.trim().replace(/\s+/g, ' '),
        arquivo: /arquivo/i.test(tr.cells[0].innerText)
      };
    })
  };
}

// ---------- calendário ----------
const d2s = (d) => d.toLocaleDateString('pt-BR');
const s2d = (s) => { const [d, m, a] = s.split('/').map(Number); return new Date(a, m - 1, d); };
function pascoa(a) {
  const f = Math.floor, G = a % 19, C = f(a / 100), H = (C - f(C / 4) - f((8 * C + 13) / 25) + 19 * G + 15) % 30,
    I = H - f(H / 28) * (1 - f(29 / (H + 1)) * f((21 - G) / 11)), J = (a + f(a / 4) + I + 2 - C + f(C / 4)) % 7,
    L = I - J, m = 3 + f((L + 40) / 44), d = L + 28 - 31 * f(m / 4);
  return new Date(a, m - 1, d);
}
const feriadosCache = {};
function feriados(a) {
  if (feriadosCache[a]) return feriadosCache[a];
  const s = new Set(['01/01', '21/04', '01/05', '07/09', '12/10', '02/11', '15/11', '20/11', '08/12', '25/12']
    .map((x) => x + '/' + a));
  const p = pascoa(a);
  for (const off of [-48, -47, -2, 60]) { const d = new Date(p); d.setDate(d.getDate() + off); s.add(d2s(d)); }
  return (feriadosCache[a] = s);
}
const suspenso = (d) => $('art220').checked &&
  ((d.getMonth() === 11 && d.getDate() >= 20) || (d.getMonth() === 0 && d.getDate() <= 20));
const util = (d) => d.getDay() !== 0 && d.getDay() !== 6 && !feriados(d.getFullYear()).has(d2s(d)) && !suspenso(d);
const mais1 = (d) => { const x = new Date(d); x.setDate(x.getDate() + 1); return x; };

function termoFinal(inicio, n, uteis) {
  let d = new Date(inicio), c = 0;
  if (uteis) { while (c < n) { d = mais1(d); if (util(d)) c++; } return d; }
  while (c < n) { d = mais1(d); if (!suspenso(d)) c++; }
  while (!util(d)) d = mais1(d);              // vence em dia sem expediente: prorroga
  return d;
}

// ---------- tela ----------
function atualizar() {
  const m = movs.find((x) => String(x.seq) === $('mov').value);
  if (!m) return;
  const n = Math.max(1, parseInt($('prazo').value, 10) || 10);
  const uteis = document.querySelector('input[name=tipo]:checked').value === 'uteis';
  const fim = termoFinal(s2d(m.data), n, uteis);
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const decorreu = fim < hoje;
  $('resumo').innerHTML = `Intimação: <b>${m.data}</b> (mov. ${m.seq}) → prazo de ${n} dias ${uteis ? 'úteis' : 'corridos'} ` +
    `→ termo final <b>${d2s(fim)}</b> — ` + (decorreu ? '<b style="color:#2e7d32">DECORRIDO</b>' :
    '<b style="color:#b00020">AINDA EM CURSO</b>');
  const depois = movs.filter((x) => x.seq > m.seq && x.arquivo && !/magistrad|juiz/i.test(x.por));
  $('posteriores').innerHTML = depois.length
    ? depois.map((x) => `<li>Mov. ${x.seq} (${x.data}) — ${x.evento} — ${x.por}</li>`).join('')
    : '<li>Nenhuma juntada com arquivo depois da intimação.</li>';
  const ref = (m.evento + ' ' + m.desc).replace(/\s+/g, ' ').trim();
  const manif = depois.length
    ? `[conferir: há ${depois.length} juntada(s) posterior(es) — mov. ${depois.map((x) => x.seq).join(', ')}]`
    : 'sem manifestação nos autos';
  $('texto').value =
`CERTIDÃO

Autos nº ${numero}

Certifico, para os devidos fins, que a intimação registrada no mov. ${m.seq} (${ref}), ocorrida em ${m.data}, deu início ao prazo de ${n} (${n}) dias ${uteis ? 'úteis' : 'corridos'}, o qual ${decorreu ? 'decorreu' : 'decorrerá'} em ${d2s(fim)}, ${manif}.

O referido é verdade e dou fé.

Assis Chateaubriand, ${d2s(hoje)}.`;
}

$('copiar').onclick = async () => {
  await navigator.clipboard.writeText($('texto').value);
  $('status').textContent = '✓ Copiada. Cole com Ctrl+V.';
};
['mov', 'prazo', 'art220'].forEach((id) => $(id).addEventListener('input', atualizar));
document.querySelectorAll('input[name=tipo]').forEach((r) => r.addEventListener('change', atualizar));

// ---------- tela "Intimação Para ..." (o PROJUDI já calculou o prazo) ----------
function lerTelaIntimacao() {
  const limpa = (x) => (x || '').replace(/\s+/g, ' ').trim();
  const corpo = document.body?.innerText || '';
  if (!/Dados da Intima[çc][ãa]o/i.test(corpo) || !/Analisar Decurso/i.test(
    [...document.querySelectorAll('input,button,a')].map((b) => b.value || b.textContent).join(' '))) return null;
  const campos = {};
  for (const r of document.querySelectorAll('td, th, b, strong, label, span')) {
    const k = limpa(r.textContent);
    if (r.children.length > 2 || !/:\s*$/.test(k) || k.length > 40) continue;
    const v = r.nextElementSibling || r.parentElement?.nextElementSibling;
    const kk = k.replace(/:\s*$/, '');
    if (v && !(kk in campos)) campos[kk] = limpa(v.innerText);
  }
  const g = (rx) => { const k = Object.keys(campos).find((x) => rx.test(x)); return k ? campos[k] : ''; };
  const titulo = limpa((corpo.match(/Intima[çc][ãa]o Para ([^\n]+)/i) || [])[1]);
  return {
    numero: (corpo.match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0], intimado: titulo,
    poloAtivo: g(/^Polo Ativo/i), poloPassivo: g(/^Polo Passivo/i), postagem: g(/Data da Postagem/i),
    dataIntimacao: g(/^Data da Intima[çc][ãa]o/i), prazo: g(/Prazo Cumprimento/i), primeiro: g(/1º Dia Prazo|1o Dia Prazo/i),
    ultimo: g(/[ÚU]ltimo Dia Prazo/i).replace(/\s*-\s*Detalhamento.*$/i, ''), situacao: g(/Situa[çc][ãa]o do prazo/i),
    leitor: g(/^Leitor/i), tipo: g(/^Tipo$/i), docRelativo: g(/Documento Relativo/i), expedicao: g(/Movimento Expedi[çc][ãa]o/i)
  };
}

const MES = { janeiro: 1, fevereiro: 2, 'março': 3, marco: 3, abril: 4, maio: 5, junho: 6, julho: 7, agosto: 8, setembro: 9, outubro: 10, novembro: 11, dezembro: 12 };
const dataCurta = (t) => { // "29 de setembro de 2026" → 29/09/2026
  const m = (t || '').match(/(\d{1,2}) de ([a-zç]+) de (\d{4})/i);
  if (m) return `${m[1].padStart(2, '0')}/${String(MES[m[2].toLowerCase()]).padStart(2, '0')}/${m[3]}`;
  return ((t || '').match(/\d{2}\/\d{2}\/\d{4}/) || [''])[0];
};

const MODELOS_DECURSO = [
  ['83284', 'CERTIDÃO - decurso de PRAZO - sem manifestação diversa'],
  ['567762', 'ATO ORD - CERTIDÃO - decurso 30 dias sem IMPUGNAÇÃO'],
  ['530858', 'ATO ORD - CERTIDÃO - decurso 30 dias sem pedido (CUMPRIMENTO DE SENTENÇA)'],
  ['534719', 'CERTIDÃO - aguarda decurso CONTESTAÇÃO após audiência'],
  ['620486', 'CERTIDÃO - ARQUIVAMENTO após decurso do retorno da TURMA RECURSAL'],
  ['221977', 'CERTIDÃO - decurso de PRAZO (alegações finais)'],
  ['187922', 'CERTIDÃO - decurso de PRAZO (embargos/impugnação)'],
  ['472247', 'CERTIDÃO - decurso de PRAZO - IMPENHORABILIDADE'],
  ['221978', 'CERTIDÃO - decurso de PRAZO (impugnação-CONTESTAÇÃO)'],
  ['111089', 'CERTIDÃO - decurso de PRAZO manifestação retorno da TURMA RECURSAL'],
  ['225824', 'CERTIDÃO - decurso de prazo (Oficial de Justiça)'],
  ['99866', 'CERTIDÃO - decurso de PRAZO (sem indicação de bens pelo executado)'],
  ['99867', 'CERTIDÃO - decurso de PRAZO - sem indicação de endereço'],
  ['84894', 'CERTIDÃO - decurso de PRAZO sem pagamento -Ex. Extraj. (03d)'],
  ['395617', 'CERTIDÃO - decurso de PRAZO - SUSPENSÃO'],
  ['454011', 'CERTIDÃO - decurso prazo ANÁLISE GRATUIDADE - PREPARO'],
  ['82013', 'CERTIDÃO - decurso sem contrarrazões'],
  ['75222', 'CERTIDÃO - decurso sem pagamento art523 CPC (15d)']];

async function modoIntimacao(tab) {
  let r;
  try { r = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: lerTelaIntimacao }); }
  catch { return false; }
  const d = r.map((x) => x.result).find(Boolean);
  if (!d) return false;
  numero = d.numero;
  const nomeAtivo = d.poloAtivo.replace(/^•\s*/, '');
  const polo = d.intimado && nomeAtivo.toUpperCase().includes(d.intimado.toUpperCase()) ? 'parte autora' :
    d.intimado && d.poloPassivo.toUpperCase().includes(d.intimado.toUpperCase()) ? 'parte ré' : 'parte';
  const seq = (d.expedicao.match(/seq\.\s*(\d+)/i) || [])[1];
  const ato = d.docRelativo.split(/\s+Registro em/i)[0].trim();
  const leitura = (d.leitor.match(/\(([^)]+)\)/) || [])[1] || '';
  const decorreu = /decurso de prazo/i.test(d.situacao);
  const hoje = new Date().toLocaleDateString('pt-BR');
  document.querySelector('main').innerHTML = `
    <div id="resumo">
      <b>${d.numero}</b> — intimação para <b>${d.intimado}</b> (${polo})<br>
      Ato: ${ato}${seq ? ` (mov. ${seq})` : ''}<br>
      Intimação: ${dataCurta(d.dataIntimacao)}${leitura ? ' — ' + leitura : ''} · Prazo: ${d.prazo}<br>
      1º dia: ${dataCurta(d.primeiro)} · Último dia: <b>${dataCurta(d.ultimo)}</b> ·
      Situação: <b style="color:${decorreu ? '#2e7d32' : '#b00020'}">${d.situacao || '—'}</b>
    </div>
    <label for="modelo">Modelo do PROJUDI (Tipo: Certidão · Descrição: certidão de decurso)</label>
    <select id="modelo">${MODELOS_DECURSO.map(([c, n]) => `<option value="${c}">${n} (${c})</option>`).join('')}
      <option value="">— Documento em branco + texto abaixo —</option></select>
    <div class="linha"><label><input type="checkbox" id="houveManif"> houve manifestação no prazo</label>
      <label><input type="checkbox" id="inserirTexto"> inserir também o texto abaixo no editor</label></div>
    <label for="texto">Certidão (pode editar)</label>
    <textarea id="texto"></textarea>
    <div class="linha">
      <button id="copiar">Copiar certidão</button>
      <button id="analisar" style="background:#2e7d32">Analisar Decurso e preparar a certidão</button>
      <span id="status"></span>
    </div>
    <small>"Analisar Decurso" abre a tela de análise, clica em Adicionar, escolhe Tipo = Certidão, Descrição = Certidão de
      decurso e o Modelo escolhido acima, e clica em Digitar Texto. Para antes de confirmar: a inclusão e a assinatura são suas.</small>`;
  const montar = () => {
    const manif = $('houveManif').checked;
    $('texto').value =
`CERTIDÃO DE DECURSO DE PRAZO

Autos nº ${d.numero}

Certifico, para os devidos fins, que ${d.intimado}, ${polo}, foi intimado(a)${d.tipo ? ' (' + d.tipo.toLowerCase() + ')' : ''} em ${dataCurta(d.dataIntimacao)}${leitura ? ' (' + leitura.toLowerCase() + ')' : ''} do(a) ${ato}${seq ? ' (mov. ' + seq + ')' : ''}, e que o prazo de ${d.prazo}, iniciado em ${dataCurta(d.primeiro)}, encerrou-se em ${dataCurta(d.ultimo)}${manif ? ', tendo havido manifestação nos autos' : ', sem manifestação nos autos'}.

O referido é verdade e dou fé.

Assis Chateaubriand, ${hoje}.`;
  };
  montar();
  $('houveManif').onchange = montar;
  $('copiar').onclick = async () => { await navigator.clipboard.writeText($('texto').value); $('status').textContent = '✓ Copiada.'; };
  $('analisar').onclick = async () => {
    try { await navigator.clipboard.writeText($('texto').value); } catch { /* sem foco */ }
    const cod = $('modelo').value;
    await chrome.storage.local.set({ decursoCertidao: { ativo: true, etapa: 'analisar', tabId: tab.id, clicadoEm: Date.now(),
      texto: $('texto').value, modeloCodigo: cod, modeloNome: cod ? MODELOS_DECURSO.find((m) => m[0] === cod)[1] : '',
      descricao: 'Certidão de decurso', inserirTexto: !cod || $('inserirTexto').checked } });
    const ok = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => {
      const b = [...document.querySelectorAll('input[type=button],input[type=submit],button,a')]
        .find((x) => /^\s*analisar\s+decurso\s*$/i.test(x.value || x.textContent));
      if (!b) return false; b.click(); return true; } });
    if (!ok.some((x) => x.result)) { $('status').textContent = 'Botão "Analisar Decurso" não encontrado.'; return; }
    $('status').textContent = '✓ Abrindo a análise do decurso…';
    setTimeout(() => window.close(), 1200);
  };
  return true;
}

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (await modoIntimacao(tab)) return;
  try {
    const res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: lerMovimentacoes });
    const r = res.map((x) => x.result).find((x) => x && x.movs.length);
    if (!r) throw new Error('Abra os autos do processo no PROJUDI.');
    numero = r.numero; movs = r.movs;
    const intim = movs.filter((x) => /intima|leitura|cita[çc][ãa]o|ciente|ci[êe]ncia/i.test(x.evento + ' ' + x.desc))
      .sort((a, b) => b.seq - a.seq);
    const lista = intim.length ? intim : [...movs].sort((a, b) => b.seq - a.seq);
    $('mov').innerHTML = lista.map((x) =>
      `<option value="${x.seq}">Mov. ${x.seq} — ${x.data} — ${(x.evento + ' ' + x.desc).slice(0, 110)}</option>`).join('');
    atualizar();
  } catch (e) {
    $('mov').innerHTML = `<option>${e.message}</option>`;
  }
})();
