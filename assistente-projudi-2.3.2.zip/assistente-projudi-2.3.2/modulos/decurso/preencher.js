// Decurso de prazo — continua depois de "Analisar Decurso" (pedido gravado pela tecla C):
//   1) tela "Analisar Decurso de Prazo" → clica em Adicionar
//   2) janela "Inserir Arquivo" → Tipo do Arquivo = Certidão (de decurso, se houver), Modelo de decurso
//      se existir → clica em "Digitar Texto"
//   3) editor → insere o texto da certidão e PARA. Confirmar Inclusão / assinar / concluir: só a servidora.
(() => {
  'use strict';
  if (window.__decursoCertidao) return;
  window.__decursoCertidao = true;
  const CHAVE = 'decursoCertidao';
  const limpa = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const visivel = (el) => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  const botao = (rx) => [...document.querySelectorAll('input[type=button],input[type=submit],button,a')]
    .find((b) => visivel(b) && rx.test(limpa(b.value || b.textContent)));
  const disparar = (el) => ['input', 'change', 'blur'].forEach((t) => el.dispatchEvent(new Event(t, { bubbles: true })));
  const rotulo = (el) => { const td = el.closest('td'); return limpa((td?.previousElementSibling?.textContent || '') + ' ' + el.name + ' ' + el.id); };
  let ocupado = false, meuTab = null;

  async function estado() { return (await chrome.storage.local.get(CHAVE))[CHAVE]; }
  async function gravar(p) { const e = (await estado()) || {}; await chrome.storage.local.set({ [CHAVE]: { ...e, ...p } }); }

  function aviso(txt, ok) {
    const b = document.createElement('div');
    b.style.cssText = `position:fixed;left:12px;bottom:12px;z-index:2147483647;max-width:420px;background:#fff;border:2px solid ${ok ? '#2e7d32' : '#e65100'};` +
      'border-radius:6px;padding:8px 10px;font:12px/1.5 Verdana,sans-serif;box-shadow:0 3px 10px rgba(0,0,0,.35)';
    b.innerHTML = `<b style="color:${ok ? '#2e7d32' : '#e65100'}">Certidão de decurso</b><br>${txt}<br><b>Confira, confirme a inclusão e assine você mesma.</b>`;
    (document.body || document.documentElement).appendChild(b);
    setTimeout(() => b.remove(), 20000);
  }

  function inserirNoEditor(texto) {
    const html = texto.split('\n').map((l) => l ? l.replace(/</g, '&lt;') : '<br>').join('<br>');
    const ta = [...document.querySelectorAll('textarea')].find((t) => visivel(t) && !t.disabled);
    if (ta) { ta.focus(); ta.value = texto; disparar(ta); return true; }
    const ce = [...document.querySelectorAll('[contenteditable=true]')].find(visivel);
    if (ce) { ce.focus(); document.execCommand('insertHTML', false, html); return true; }
    if (document.designMode === 'on' || document.body?.isContentEditable) {
      document.body.focus(); document.execCommand('insertHTML', false, html); return true;
    }
    for (const f of document.querySelectorAll('iframe')) {
      try {
        const d = f.contentDocument;
        if (d && (d.designMode === 'on' || d.body?.isContentEditable)) { d.body.focus(); d.execCommand('insertHTML', false, html); return true; }
      } catch { /* outro domínio */ }
    }
    return false;
  }

  async function tick() {
    if (ocupado) return;
    const e = await estado();
    if (!e || !e.ativo) return;
    if (Date.now() - e.clicadoEm > 120000) { await gravar({ ativo: false }); return; }
    if (!meuTab) { try { meuTab = await chrome.runtime.sendMessage({ tipo: 'MEU_TAB' }); } catch { return; } }
    if (!meuTab || (meuTab.tabId !== e.tabId && meuTab.opener !== e.tabId)) return;
    ocupado = true;
    try {
      const corpo = document.body?.innerText || '';
      if (e.etapa === 'analisar' && /Analisar Decurso de Prazo/i.test(corpo)) {
        const add = botao(/^adicionar$/i);
        if (!add) return;
        await gravar({ etapa: 'inserir', clicadoEm: Date.now() });
        add.click();
      } else if (e.etapa === 'inserir' && /Inserir Arquivo/i.test(corpo)) {
        const tipo = [...document.querySelectorAll('select')].find((s) => visivel(s) && /tipo do arquivo/i.test(rotulo(s)));
        if (!tipo) return;
        const ops = [...tipo.options];
        const op = ops.find((o) => /^certid[ãa]o$/i.test(limpa(o.text))) || ops.find((o) => /certid[ãa]o/i.test(o.text));
        if (!op) { await gravar({ ativo: false }); aviso('Não encontrei o tipo "Certidão" na lista Tipo do Arquivo — escolha manualmente e cole o texto (já está copiado).', false); return; }
        tipo.value = op.value; disparar(tipo);
        await new Promise((r) => setTimeout(r, 800));            // Descrição e Modelo habilitam depois do tipo
        const desc = [...document.querySelectorAll('input[type=text], input:not([type])')]
          .find((i) => visivel(i) && !i.disabled && /descri[çc][ãa]o|outros/i.test(rotulo(i)));
        if (desc) { desc.focus(); desc.value = e.descricao || 'Certidão de decurso'; disparar(desc); }
        let om = null;
        if (e.modeloCodigo) {
          for (let i = 0; i < 12 && !om; i++) {               // a lista de modelos pode demorar a carregar
            const modelo = [...document.querySelectorAll('select')].find((s) => visivel(s) && !s.disabled && /modelo/i.test(rotulo(s)));
            const norm = (x) => limpa(x).toLowerCase();
            om = modelo && ([...modelo.options].find((o) => o.value === e.modeloCodigo || o.text.includes(e.modeloCodigo)) ||
              [...modelo.options].find((o) => norm(o.text) === norm(e.modeloNome)) ||
              [...modelo.options].find((o) => norm(o.text).includes(norm(e.modeloNome).slice(0, 35))));
            if (om) { modelo.value = om.value; disparar(modelo); } else await new Promise((r) => setTimeout(r, 300));
          }
          if (!om) aviso(`Modelo "${e.modeloNome}" não encontrado na lista — escolha manualmente.`, false);
        }
        const digitar = botao(/^digitar texto$/i);
        if (!digitar) return;
        await gravar({ etapa: 'editor', clicadoEm: Date.now(), tipoEscolhido: limpa(op.text), modeloEscolhido: om ? limpa(om.text) : '' });
        digitar.click();
      } else if (e.etapa === 'editor') {
        if (!e.inserirTexto) {                                  // o modelo do PROJUDI já traz o texto
          await gravar({ ativo: false, etapa: 'ok' });
          aviso(`Tipo: ${e.tipoEscolhido || '—'} · Descrição: ${e.descricao}${e.modeloEscolhido ? '<br>Modelo: ' + e.modeloEscolhido : ''}`, true);
          return;
        }
        if (!inserirNoEditor(e.texto)) return;
        await gravar({ ativo: false, etapa: 'ok' });
        aviso(`Tipo: ${e.tipoEscolhido || '—'}${e.modeloEscolhido ? ' · Modelo: ' + e.modeloEscolhido : ''}<br>Texto da certidão inserido no editor.`, true);
      }
    } finally { ocupado = false; }
  }

  // Depois que a extensão é recarregada, este script antigo fica sem acesso a ela: para em silêncio.
  const vivo = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };
  const rodarTick = () => { if (!vivo()) { clearInterval(t); return; } Promise.resolve().then(tick).catch(() => {}); };
  chrome.storage.onChanged.addListener((m, area) => { if (area === 'local' && m[CHAVE]) rodarTick(); });
  rodarTick();
  var t = setInterval(rodarTick, 800);
  setTimeout(() => clearInterval(t), 130000);
})();
