// Módulo Salvar página em PDF (tecla 9 / Alt+S) — Page.printToPDF, sem serviço externo.
(() => {
// EXTENSAO-SALVAR-PDF — gera o PDF pelo próprio Chrome (Page.printToPDF), sem enviar a página a terceiros.
// Durante 1–2 s o Chrome mostra a faixa "começou a depurar este navegador": é o aviso normal da API usada.

const RE_CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;

// Lê da página o nº do processo e se ela é larga (tabelas) → paisagem.
async function lerPagina(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({
        cnj: ((document.body?.innerText || '').match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0],
        larga: Math.max(document.documentElement.scrollWidth, document.body?.scrollWidth || 0) > 1150,
        pdf: document.contentType === 'application/pdf'
      })
    });
    return r.result || {};
  } catch { return {}; }
}

function limparNome(n) {
  return (n || 'pagina').replace(/[\\/:*?"<>|]+/g, '_').replace(/\s+/g, ' ').trim().slice(0, 150);
}

function dataHora() {
  const d = new Date(), z = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())} ${z(d.getHours())}h${z(d.getMinutes())}`;
}

async function nomePadrao(tab, info) {
  const titulo = (tab.title || 'pagina').replace(/^Projudi\s*-\s*/i, '').replace(/\.pdf$/i, '').slice(0, 60);
  return limparNome(info.cnj ? `${info.cnj} - ${titulo}` : `${titulo} - ${dataHora()}`);
}

async function salvarPdf(tabId, { paisagem, nome } = {}) {
  const tab = await chrome.tabs.get(tabId);
  if (!/^(https?|file):/.test(tab.url || '')) throw new Error('Esta página não pode ser salva (página interna do Chrome).');
  const info = await lerPagina(tabId);
  if (paisagem === undefined || paisagem === 'auto') paisagem = !!info.larga;
  nome = limparNome(nome || await nomePadrao(tab, info));
  if (!/\.pdf$/i.test(nome)) nome += '.pdf';

  // A aba já É um PDF (visualizador do Chrome): baixa o arquivo original em vez de "imprimir" a tela
  // do visualizador (que sai como uma página escura em branco).
  const ehPdf = info.pdf || (info.pdf === undefined && /(\.pdf([?#]|$))|\/arquivo\.do/i.test(tab.url || ''));
  if (ehPdf) {
    await chrome.downloads.download({ url: tab.url, filename: nome, saveAs: false });
    return nome;
  }

  const alvo = { tabId };
  await chrome.debugger.attach(alvo, '1.3');
  let dados;
  try {
    const r = await chrome.debugger.sendCommand(alvo, 'Page.printToPDF', {
      landscape: !!paisagem,
      printBackground: true,
      paperWidth: 8.27, paperHeight: 11.69,           // A4
      marginTop: 0.4, marginBottom: 0.4, marginLeft: 0.4, marginRight: 0.4,
      scale: paisagem ? 0.8 : 0.9,
      displayHeaderFooter: true,
      headerTemplate: '<span></span>',
      footerTemplate: '<div style="font-size:7px;width:100%;padding:0 10mm;display:flex;justify-content:space-between">' +
        '<span class="url"></span><span>pág. <span class="pageNumber"></span>/<span class="totalPages"></span> — <span class="date"></span></span></div>'
    });
    dados = r.data;
  } finally {
    await chrome.debugger.detach(alvo).catch(() => {});
  }
  await chrome.downloads.download({ url: 'data:application/pdf;base64,' + dados, filename: nome, saveAs: false });
  return nome;
}


  self.salvarPaginaPdf = salvarPdf;
})();
