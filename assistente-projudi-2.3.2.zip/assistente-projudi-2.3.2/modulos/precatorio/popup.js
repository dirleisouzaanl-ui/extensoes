// Requisitos para precatório / RPV (tecla Q). Reúne nos autos de cumprimento de sentença os dados
// para conferir antes do cadastro no SGP: classe, credor(es) e CPF/CNPJ, devedor, advogados,
// trânsito em julgado, cálculo (último juntado e homologação), impugnação e requisição anterior.
const $ = (id) => document.getElementById(id);
let tabId = null, dados = null, movs = [], marcos = {};

async function lerMovs() {   // injetada nos autos
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const linhas = () => [...document.querySelectorAll('tr')].filter((tr) => tr.cells.length >= 5 &&
    /^\d+$/.test(tr.cells[1].innerText.trim()) && /^\d{2}\/\d{2}\/\d{4}/.test(tr.cells[2].innerText.trim()));
  if (!linhas().length) {
    const aba = [...document.querySelectorAll('a, li, span, td')].find((el) => /^\s*movimenta[cç][oõ]es\s*$/i.test(el.textContent));
    if (!aba) return null;
    (aba.closest('a') || aba).click();
    for (let i = 0; i < 40 && !linhas().length; i++) await sleep(250);
  }
  return linhas().map((tr) => {
    const t = tr.cells[3].innerText.trim().split('\n').map((s) => s.trim()).filter(Boolean);
    return { seq: +tr.cells[1].innerText.trim(), data: tr.cells[2].innerText.trim().slice(0, 10), evento: t[0] || '',
      desc: t.slice(1).join(' '), por: tr.cells[4].innerText.trim().replace(/\s+/g, ' '), arquivo: /arquivo/i.test(tr.cells[0].innerText) };
  });
}

async function arquivosDaMov(seq) {   // injetada: expande "Arquivos" da movimentação e devolve os links
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const tr = [...document.querySelectorAll('tr')].find((r) => r.cells.length >= 5 && r.cells[1].innerText.trim() === String(seq));
  if (!tr) return [];
  const links = () => { const n = tr.nextElementSibling; return n && !(n.cells?.length >= 5 && /^\d+$/.test(n.cells[1]?.innerText.trim()))
    ? [...n.querySelectorAll('a[href]')].filter((a) => /arquivo\.do|\.pdf/i.test(a.href)).map((a) => a.href) : []; };
  if (!links().length) { const t = tr.cells[0].querySelector('a'); if (t) t.click(); for (let i = 0; i < 40 && !links().length; i++) await sleep(200); }
  tr.style.outline = '3px solid #1565c0';
  return [...new Set(links())];
}

const ultimo = (rx) => movs.filter((m) => rx.test(m.evento + ' ' + m.desc)).sort((a, b) => b.seq - a.seq)[0];
const fmt = (m) => (m ? `mov. ${m.seq} — ${m.data} — ${m.evento}${m.desc ? ' (' + m.desc.slice(0, 80) + ')' : ''}` : '<span class="alerta">não localizado</span>');

function blocos() {
  const out = {};
  if (!dados) return out;
  dados.texto.split(/\n\n/).forEach((b) => { const [t, ...r] = b.split('\n'); out[t] = r.join('\n'); });
  return out;
}

function montar() {
  const b = blocos();
  const ativo = Object.entries(b).find(([k]) => /POLO ATIVO|EXEQUENTE|AUTOR|REQUERENTE/.test(k));
  const passivo = Object.entries(b).find(([k]) => /POLO PASSIVO|EXECUTAD|RÉU|REQUERID/.test(k));
  const cab = (dados?.texto || '').split('\n\n')[0];
  const classe = (cab.match(/Classe: (.*)/) || [])[1] || '';
  marcos = {
    transito: ultimo(/TRANSIT|TR[ÂA]NSITO EM JULGADO/i),
    homolog: ultimo(/HOMOLOG.*C[ÁA]LCULO|C[ÁA]LCULO.*HOMOLOG|ACOLHID.*C[ÁA]LCULO/i),
    calculo: movs.filter((m) => m.arquivo && /C[ÁA]LCULO|PLANILHA|ATUALIZA[ÇC][ÃA]O|DEMONSTRATIVO/i.test(m.evento + ' ' + m.desc)).sort((a, b) => b.seq - a.seq)[0],
    impug: ultimo(/IMPUGNA/i),
    requis: ultimo(/REQUISI[ÇC][ÃA]O|PRECAT[ÓO]RIO|RPV|PEQUENO VALOR/i)
  };
  const linhas = [
    ['Processo', dados?.numero || '<span class="alerta">não lido</span>'],
    ['Classe', classe ? classe + (/fazenda|p[úu]blica/i.test(classe) ? '' : ' <span class="alerta">(conferir: não parece contra a Fazenda Pública)</span>') : '—'],
    ['Credor(es)', (ativo?.[1] || '<span class="alerta">abra a aba Partes e Outros</span>').replace(/\n/g, '<br>')],
    ['Devedor', (passivo?.[1] || '—').replace(/\n/g, '<br>')],
    ['Trânsito em julgado', fmt(marcos.transito)],
    ['Cálculo homologado', fmt(marcos.homolog)],
    ['Último cálculo juntado', fmt(marcos.calculo)],
    ['Impugnação', marcos.impug ? fmt(marcos.impug) + ' <span class="alerta">(conferir se foi decidida)</span>' : 'nenhuma localizada'],
    ['Requisição anterior', marcos.requis ? fmt(marcos.requis) + ' <span class="alerta">(conferir duplicidade)</span>' : 'nenhuma localizada'],
    ['Valor total (cálculo)', '<input id="valor" placeholder="R$ 0,00">'],
    ['Data do cálculo', '<input id="dataCalc" placeholder="dd/mm/aaaa">']
  ];
  $('quadro').innerHTML = linhas.map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`).join('');
}

function resumo() {
  const limpa = (h) => h.replace(/<br>/g, '\n   ').replace(/<[^>]+>/g, '');
  return [...$('quadro').rows].map((r) => {
    const inp = r.cells[1].querySelector('input');
    return `${r.cells[0].textContent}: ${inp ? (inp.value || '[___]') : limpa(r.cells[1].innerHTML)}`;
  }).join('\n');
}

async function abrirMov(m, nome) {
  if (!m) return st(`${nome} não localizado.`, '#b00020');
  const r = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: arquivosDaMov, args: [m.seq] });
  const urls = [...new Set(r.flatMap((x) => x.result || []))];
  if (!urls.length) return st(`Mov. ${m.seq} sem arquivos legíveis.`, '#b00020');
  const tab = await chrome.tabs.get(tabId);
  for (let i = 0; i < urls.length; i++) await chrome.tabs.create({ url: urls[i], index: tab.index + 1 + i, active: false });
  st(`✓ ${urls.length} arquivo(s) do mov. ${m.seq} aberto(s).`);
}
const st = (t, cor = '#2e7d32') => { $('status').style.color = cor; $('status').textContent = t; };

$('copiar').onclick = async () => { await navigator.clipboard.writeText(resumo()); st('✓ Resumo copiado.'); };
$('abrirCalc').onclick = () => abrirMov(marcos.calculo, 'Cálculo');
$('abrirTj').onclick = () => abrirMov(marcos.homolog || marcos.transito, 'Decisão homologatória / trânsito');

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab.id;
  try {
    const d = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: window.lerDadosProcesso });
    dados = d.map((x) => x.result).filter(Boolean).sort((a, b) => b.partes - a.partes)[0] || null;
    const m = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: lerMovs });
    movs = m.map((x) => x.result).find((x) => x && x.length) || [];
    if (!dados && !movs.length) throw new Error('Abra os autos do processo no PROJUDI.');
    montar();
  } catch (e) { $('quadro').innerHTML = `<tr><td class="alerta">${e.message}</td><td></td></tr>`; }
})();
