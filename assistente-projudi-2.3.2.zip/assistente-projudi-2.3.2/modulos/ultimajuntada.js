// Módulo "Abrir a última juntada dos autos" (tecla U).
// Nos autos (aba Movimentações): localiza a movimentação mais recente COM ARQUIVO que não foi
// feita pelo Magistrado (juntada de parte, advogado, MP, oficial, sistema...), expande "Arquivos"
// e abre os documentos dela em abas ao lado. Só lê e abre: não altera nada no processo.
(() => {
  // ---- injetada na página (roda dentro da aba) ----
  async function coletarUltimaJuntada() {
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const linhasMov = () => [...document.querySelectorAll('tr')].filter((tr) =>
      tr.cells.length >= 5 && /^\d+$/.test(tr.cells[1].innerText.trim()) &&
      /^\d{2}\/\d{2}\/\d{4}/.test(tr.cells[2].innerText.trim()));

    // Se a aba Movimentações não estiver aberta, clica nela e espera a tabela.
    if (!linhasMov().length) {
      const aba = [...document.querySelectorAll('a, li, span, td')]
        .find((el) => /^\s*movimenta[cç][oõ]es\s*$/i.test(el.textContent));
      if (!aba) return null;                       // não são os autos (outro quadro)
      (aba.closest('a') || aba).click();
      for (let i = 0; i < 40 && !linhasMov().length; i++) await sleep(250);
      if (!linhasMov().length) return { erro: 'Tabela de movimentações não carregou.' };
    }

    const movs = linhasMov().map((tr) => ({
      tr, seq: +tr.cells[1].innerText.trim(), data: tr.cells[2].innerText.trim().slice(0, 16),
      evento: tr.cells[3].innerText.trim().split('\n')[0].trim(), por: tr.cells[4].innerText.trim(),
      temArquivo: /arquivo/i.test(tr.cells[0].innerText)
    }));
    const m = movs.filter((x) => x.temArquivo && !/magistrad|juiz/i.test(x.por))
      .sort((a, b) => b.seq - a.seq)[0];
    if (!m) return { erro: 'Nenhuma juntada com arquivo encontrada.' };

    const linksDe = (tr) => {
      const n = tr.nextElementSibling;
      return n && !(n.cells?.length >= 5 && /^\d+$/.test(n.cells[1]?.innerText.trim()))
        ? [...n.querySelectorAll('a[href]')].filter((a) => /arquivo\.do|\.pdf/i.test(a.href)) : [];
    };
    if (!linksDe(m.tr).length) {
      const t = m.tr.cells[0].querySelector('a[href^="javascript"]') || m.tr.cells[0].querySelector('a');
      if (t) t.click();
      for (let i = 0; i < 40 && !linksDe(m.tr).length; i++) await sleep(200);
    }
    m.tr.style.outline = '3px solid #1565c0';
    m.tr.scrollIntoView({ block: 'center' });
    const urls = [...new Set(linksDe(m.tr).map((a) => a.href))];
    if (!urls.length) return { erro: `Mov. ${m.seq} sem arquivos legíveis.` };
    return { seq: m.seq, data: m.data, evento: m.evento, por: m.por, urls };
  }

  self.abrirUltimaJuntada = async function (tab) {
    if (!/^https:\/\/projudi[^/]*\.tjpr\.jus\.br\//.test(tab.url || '')) return 'Abra os autos no PROJUDI.';
    const res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: coletarUltimaJuntada });
    const r = res.map((x) => x.result).find((x) => x && x.urls) || res.map((x) => x.result).find(Boolean);
    if (!r) return 'Abra os autos do processo (aba Movimentações).';
    if (r.erro) return r.erro;
    for (let i = 0; i < r.urls.length; i++) {
      await chrome.tabs.create({ url: r.urls[i], index: tab.index + 1 + i, openerTabId: tab.id, active: i === 0 });
    }
    return `✓ Mov. ${r.seq} (${r.data}) — ${r.evento}: ${r.urls.length} arquivo(s).`;
  };
})();
