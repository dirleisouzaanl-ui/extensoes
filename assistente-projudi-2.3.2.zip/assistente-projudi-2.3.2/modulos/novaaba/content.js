/*
 * content.js — roda DENTRO da página do PROJUDI (depois do config.js).
 *
 * O content script enxerga o HTML, mas NÃO pode abrir abas (a API
 * chrome.tabs não existe aqui). Ele só lê os endereços e MANDA MENSAGENS
 * ao service worker (background.js), que abre as abas:
 *
 *   botão ↗           → {tipo:'ABRIR_NOVA_ABA', url}
 *   "Abrir todos"     → {tipo:'ABRIR_LOTE', urls:[...]}
 *   ◄── resposta {ok, enfileirados, naFila, motivo} via sendResponse
 *
 * As OPÇÕES (limite, confirmação, exibir botão) vêm de chrome.storage.sync,
 * que o content script PODE ler diretamente, sem passar pelo background.
 *
 * O que este script NÃO faz: não clica em nada do sistema, não preenche
 * campos e não envia formulários.
 */

(async () => {
  'use strict';

  const P = self.PROJUDI; // definido em config.js

  // 1) Trava de domínio: host começa com "projudi" e termina em ".tjpr.jus.br".
  if (!P || !P.ehUrlProjudi(location.href)) return;

  // 2) Links-alvo: <a class="link" href="/projudi/processo/conclusao.do?_tj=...">Analisar</a>
  const SELETOR = 'a.link[href*="/projudi/processo/conclusao.do?_tj="]';
  const MARCA = 'data-nova-aba-ok';

  const ehAnalisar = (a) => a.textContent.trim() === 'Analisar';
  const linksAnalisar = () => [...document.querySelectorAll(SELETOR)].filter(ehAnalisar);

  // 2b) Arquivos dos documentos (coluna "Arquivo" da tela Movimentar Processo):
  //   <a onclick="..." target="_blank" href="/projudi/arquivo.do?_tj=..." class="link">online.pdf</a>
  //   O endereço está no href; o onclick do sistema NÃO é executado pelo botão ↗.
  //   Estes links recebem só o ↗ individual — ficam fora do "Abrir todos".
  const SELETOR_ARQUIVO = 'a.link[href*="/projudi/arquivo.do?_tj="]';
  const linksArquivo = () => [...document.querySelectorAll(SELETOR_ARQUIVO)];

  // 2c) Botão "Analisar" da tela "Dados da Conclusão" (aberta pelo "Abrir todos"):
  //   <input type="button" name="analysis" value="Analisar" id="editButton"
  //          onclick="disableScreen(); document.location.href='/projudi/processo/conclusao.do?_tj=...';">
  //   Não é link: o endereço está DENTRO do texto do onclick. A extensão só LÊ
  //   esse texto (como uma string) e recorta o endereço — o onclick do sistema
  //   não é executado e o botão não é clicado.
  const SELETOR_BOTAO_ANALISAR = 'input[type="button"][name="analysis"]';
  const RE_LOCATION = /location\.href\s*=\s*['"]([^'"]+)['"]/;

  function urlDoBotaoAnalisar(botao) {
    const m = (botao.getAttribute('onclick') || '').match(RE_LOCATION);
    if (!m) return null;
    try {
      // Endereço relativo ("/projudi/...") → absoluto, a partir da página atual.
      return new URL(m[1].replace(/&amp;/g, '&'), location.href).href;
    } catch {
      return null;
    }
  }

  const botoesAnalisar = () => [...document.querySelectorAll(SELETOR_BOTAO_ANALISAR)]
    .filter((b) => b.value.trim() === 'Analisar' && urlDoBotaoAnalisar(b));

  // 3) Opções atuais. Começam com o que está salvo e são atualizadas ao vivo
  //    pelo chrome.storage.onChanged (lá embaixo).
  let opcoes = await P.lerOpcoes();

  // Envia uma mensagem e trata o caso de a extensão ter sido recarregada
  // (o content script antigo perde a ligação: recarregue a página).
  async function enviar(mensagem) {
    try {
      return await chrome.runtime.sendMessage(mensagem);
    } catch (erro) {
      console.error('[nova-aba] sem contato com o service worker (recarregue a página):', erro);
      return { ok: false, motivo: 'extensão recarregada — dê F5 na página' };
    }
  }

  function piscar(botao, texto, original, ms = 1500) {
    botao.textContent = texto;
    setTimeout(() => { botao.textContent = original; }, ms);
  }

  // -------------------------------------------------------------------------
  // 4) Botão ↗ individual (igual à versão anterior, agora pela fila).
  // -------------------------------------------------------------------------
  // `obterUrl` devolve o endereço a abrir: o href do link ou, no botão
  // "Analisar", o endereço recortado do onclick.
  function criarBotaoIndividual(link, obterUrl = () => link.href) {
    const botao = document.createElement('button');
    botao.type = 'button'; // nunca submete formulário
    botao.textContent = '↗';
    botao.title = 'Abrir em nova aba à direita (sem sair desta página)';
    botao.style.cssText = 'margin-left:4px;padding:0 4px;font-size:11px;line-height:14px;' +
      'cursor:pointer;border:1px solid #999;border-radius:3px;background:#fff;color:#333';

    botao.addEventListener('click', async (evento) => {
      evento.preventDefault();
      evento.stopPropagation();
      const url = obterUrl();
      if (!url) { console.warn('[nova-aba] endereço não encontrado'); return; }
      const resposta = await enviar({ tipo: 'ABRIR_NOVA_ABA', url });
      if (resposta && resposta.ok) piscar(botao, '✓', '↗', 1200);
      else console.warn('[nova-aba] recusado:', resposta && resposta.motivo);
    });
    return botao;
  }

  function inserirBotoesIndividuais() {
    [...linksAnalisar(), ...linksArquivo()].forEach((link) => {
      if (link.hasAttribute(MARCA)) return;
      link.setAttribute(MARCA, '1');
      link.insertAdjacentElement('afterend', criarBotaoIndividual(link));
    });
    // ↗ ao lado do botão "Analisar" da tela Dados da Conclusão.
    botoesAnalisar().forEach((botao) => {
      if (botao.hasAttribute(MARCA)) return;
      botao.setAttribute(MARCA, '1');
      const seta = criarBotaoIndividual(botao, () => urlDoBotaoAnalisar(botao));
      seta.title = 'Abrir a análise (Movimentar Processo) em nova aba à direita';
      seta.style.padding = '2px 6px';
      botao.insertAdjacentElement('afterend', seta);
    });
  }

  // -------------------------------------------------------------------------
  // 5) Botão flutuante "Abrir todos" (canto inferior direito).
  //    Só aparece no quadro (frame) que tem links "Analisar".
  // -------------------------------------------------------------------------
  let botaoLote = null;
  let enviandoLote = false;

  function rotuloLote() {
    const total = linksAnalisar().length;
    const n = Math.min(total, opcoes.limiteLote);
    const sufixo = opcoes.fluxoCompleto ? ' + análise + PDF' : '';
    return { total, n, texto: (total > n ? `↗ Abrir ${n} de ${total}` : `↗ Abrir todos (${n})`) + sufixo };
  }

  function atualizarBotaoLote() {
    const { total, texto } = rotuloLote();
    const deveMostrar = opcoes.mostrarBotaoLote && total > 0;

    if (!deveMostrar) {
      if (botaoLote) { botaoLote.remove(); botaoLote = null; }
      return;
    }
    if (!botaoLote) {
      botaoLote = document.createElement('button');
      botaoLote.type = 'button';
      botaoLote.id = 'projudi-nova-aba-lote';
      botaoLote.title = 'Abre os "Analisar" desta página em novas abas, um por vez';
      botaoLote.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;' +
        'padding:6px 12px;font:bold 12px Verdana,sans-serif;cursor:pointer;color:#fff;' +
        'background:#6b5b2e;border:0;border-radius:4px;box-shadow:0 2px 6px rgba(0,0,0,.35)';
      botaoLote.addEventListener('click', abrirTodos);
      document.body.appendChild(botaoLote);
    }
    // Só reescreve se mudou: evita que o MutationObserver entre em ciclo.
    if (!enviandoLote && botaoLote.textContent !== texto) botaoLote.textContent = texto;
  }

  async function abrirTodos(evento) {
    evento.preventDefault();
    evento.stopPropagation();
    if (enviandoLote) return;

    const { n } = rotuloLote();
    // Endereços na ordem da tabela, sem repetição, até o limite.
    const urls = [...new Set(linksAnalisar().map((a) => a.href))].slice(0, n);
    if (!urls.length) return;

    if (opcoes.pedirConfirmacao &&
        !window.confirm(opcoes.fluxoCompleto
          ? `Abrir ${urls.length} processo(s) já na análise (Movimentar Processo), cada um com o seu online.pdf ao lado?\n\n` +
            'Equivale a clicar, em cada processo, em "Analisar" na lista, "Analisar" em Dados da Conclusão e abrir o online.pdf.'
          : `Abrir ${urls.length} conclusão(ões) em novas abas?\n\n` +
            'Cada aba equivale a clicar em "Analisar".')) {
      return;
    }

    enviandoLote = true;
    botaoLote.textContent = '… enviando';
    // --- ENVIO DO LOTE: UMA mensagem com todos os endereços ---------------
    // O service worker coloca tudo na fila e abre uma aba por vez.
    const resposta = await enviar({ tipo: 'ABRIR_LOTE', urls, fluxo: opcoes.fluxoCompleto });
    enviandoLote = false;

    if (resposta && resposta.ok) {
      console.log('[nova-aba] lote aceito:', resposta);
      piscar(botaoLote, `✓ ${resposta.enfileirados} na fila`, rotuloLote().texto, 2500);
    } else {
      console.warn('[nova-aba] lote recusado:', resposta && resposta.motivo);
      piscar(botaoLote, '✗ recusado (veja o console)', rotuloLote().texto, 2500);
    }
  }

  // -------------------------------------------------------------------------
  // 5b) "PDFs de todas as abas" — aparece na tela do processo (onde há
  //     "online.pdf"). Um clique abre o online.pdf de CADA aba do PROJUDI
  //     desta janela, cada PDF logo à direita da aba do seu processo.
  // -------------------------------------------------------------------------
  const linksPdf = () => linksArquivo()
    .filter((a) => a.textContent.trim().toLowerCase() === 'online.pdf');

  // A leitura dos PDFs das OUTRAS abas é feita pelo service worker com
  // chrome.scripting.executeScript (ver background.js) — por isso não há
  // listener de mensagem aqui, e as abas abertas antes de recarregar a
  // extensão também são lidas, sem F5.

  let botaoPdfs = null;
  let enviandoPdfs = false;
  const ROTULO_PDFS = '↗ online.pdf de todas as abas';

  function atualizarBotaoPdfs() {
    const deveMostrar = opcoes.mostrarBotaoLote && linksPdf().length > 0;
    if (!deveMostrar) {
      if (botaoPdfs) { botaoPdfs.remove(); botaoPdfs = null; }
      return;
    }
    if (!botaoPdfs) {
      botaoPdfs = document.createElement('button');
      botaoPdfs.type = 'button';
      botaoPdfs.id = 'projudi-nova-aba-pdfs';
      botaoPdfs.textContent = ROTULO_PDFS;
      botaoPdfs.title = 'Abre o online.pdf de cada aba do PROJUDI desta janela';
      botaoPdfs.style.cssText = 'position:fixed;right:16px;z-index:2147483647;' +
        'padding:6px 12px;font:bold 12px Verdana,sans-serif;cursor:pointer;color:#fff;' +
        'background:#1f5f8b;border:0;border-radius:4px;box-shadow:0 2px 6px rgba(0,0,0,.35)';
      botaoPdfs.addEventListener('click', abrirPdfsDasAbas);
      document.body.appendChild(botaoPdfs);
    }
    // Se o botão "Abrir todos" também estiver na página, fica acima dele.
    const bottom = botaoLote ? '56px' : '16px';
    if (botaoPdfs.style.bottom !== bottom) botaoPdfs.style.bottom = bottom;
  }

  async function abrirPdfsDasAbas(evento) {
    evento.preventDefault();
    evento.stopPropagation();
    if (enviandoPdfs) return;
    enviandoPdfs = true;
    botaoPdfs.textContent = '… procurando nas abas';

    try {
      // 1º passo: só contar (o service worker pergunta a cada aba).
      const conta = await enviar({ tipo: 'CONTAR_PDFS_ABAS' });
      if (!conta || !conta.ok) {
        piscar(botaoPdfs, '✗ recusado (veja o console)', ROTULO_PDFS, 2500);
        return;
      }
      const avisoF5 = conta.semResposta
        ? `\n\n${conta.semResposta} aba(s) do PROJUDI não puderam ser lidas (descartadas ou carregando) — clique nelas e tente de novo.`
        : '';
      if (!conta.abrir) {
        botaoPdfs.textContent = ROTULO_PDFS;
        if (avisoF5) window.alert('Nenhum online.pdf novo encontrado.' + avisoF5);
        else piscar(botaoPdfs, 'nenhum online.pdf novo', ROTULO_PDFS, 2500);
        return;
      }
      const limite = conta.total > conta.abrir ? ` (limite: ${conta.abrir} de ${conta.total})` : '';
      if (opcoes.pedirConfirmacao &&
          !window.confirm(`Abrir ${conta.abrir} online.pdf de ${conta.abasComPdf} aba(s) de processo${limite}?${avisoF5}`)) {
        botaoPdfs.textContent = ROTULO_PDFS;
        return;
      }
      // 2º passo: abrir (o service worker coleta de novo e põe na fila).
      const r = await enviar({ tipo: 'ABRIR_PDFS_ABAS' });
      if (r && r.ok) piscar(botaoPdfs, `✓ ${r.enfileirados || 0} na fila`, ROTULO_PDFS, 2500);
      else piscar(botaoPdfs, '✗ recusado (veja o console)', ROTULO_PDFS, 2500);
    } finally {
      enviandoPdfs = false;
    }
  }

  // -------------------------------------------------------------------------
  // 6) Primeira montagem + acompanhamento de mudanças na página.
  // -------------------------------------------------------------------------
  function montar() {
    inserirBotoesIndividuais();
    atualizarBotaoLote();
    atualizarBotaoPdfs();
  }
  montar();

  // Agrupa várias mudanças seguidas numa única remontagem.
  let agendado = false;
  new MutationObserver(() => {
    if (agendado) return;
    agendado = true;
    requestAnimationFrame(() => { agendado = false; montar(); });
  }).observe(document.body, { childList: true, subtree: true });

  // -------------------------------------------------------------------------
  // 7) Opções mudaram na página de opções? Atualiza AO VIVO, sem F5.
  //    chrome.storage.onChanged dispara em TODAS as partes da extensão
  //    (content scripts, service worker, páginas) quando algo é gravado.
  // -------------------------------------------------------------------------
  chrome.storage.onChanged.addListener((mudancas, area) => {
    if (area !== 'sync') return;
    const novas = { ...opcoes };
    for (const [chave, { newValue }] of Object.entries(mudancas)) novas[chave] = newValue;
    opcoes = P.normalizar(novas);
    console.log('[nova-aba] opções atualizadas:', opcoes);
    atualizarBotaoLote();
    atualizarBotaoPdfs();
  });
})();
