// Módulo Abrir em nova aba — isolado para não colidir com os outros módulos
(() => {
/*
 * background.js — o SERVICE WORKER da extensão.
 *
 * Lembrete de como o service worker vive no Manifest V3:
 *   - Não tem página nem acesso ao HTML do PROJUDI.
 *   - O Chrome o ACORDA quando chega um evento (mensagem, clique no ícone)
 *     e o ENCERRA depois de ~30 s ocioso.
 *   - Ao ser encerrado, TODAS as variáveis globais se perdem.
 *
 * Por isso a FILA de abas não fica numa variável: fica em
 * chrome.storage.session (memória do navegador, apagada só quando o Chrome
 * fecha). Se o service worker morrer no meio de um "Abrir todos", ao
 * acordar ele lê a fila salva e continua de onde parou.
 *
 * Mensagens que este arquivo entende:
 *   ABRIR_NOVA_ABA {url}    → vem do botão ↗ (content.js)      → 1 item na fila
 *   ABRIR_LOTE     {urls, fluxo} → vem do botão "Abrir todos"  → N itens na fila
 *                  fluxo=true → FLUXO AUTOMÁTICO (um clique):
 *                  Dados da Conclusão → Movimentar Processo → online.pdf
 *   CONTAR_PDFS_ABAS {}     → botão "PDFs de todas as abas"    → só conta (para confirmar)
 *   ABRIR_PDFS_ABAS  {}     → idem, após a confirmação         → 1 PDF por aba de processo
 *   ESVAZIAR_FILA  {}       → vem da página de opções          → cancela o resto
 *
 * Para os PDFs, o service worker não manda mensagem às abas: ele lê os
 * links direto em cada uma com chrome.scripting.executeScript.
 *
 * Desenho da fila:
 *
 *   content.js ──ABRIR_LOTE──► onMessage ──► enfileirar() ──► storage.session["fila"]
 *                                   │                               │
 *                                   └──► processarFila() ◄──────────┘
 *                                          retira 1 item → tabs.create → espera intervalo → repete
 */

// Traz self.PROJUDI (opções padrão, regra de domínio) do arquivo compartilhado.
// config.js carregado pelo background principal

console.log('[nova-aba] service worker iniciado', new Date().toLocaleTimeString());

// ---------------------------------------------------------------------------
// Trava simples: garante que duas operações na fila (ex.: enfileirar e
// retirar) não leiam e gravem o storage ao mesmo tempo, uma apagando a outra.
// Cada operação espera a anterior terminar (encadeamento de Promises).
// ---------------------------------------------------------------------------
let trava = Promise.resolve();
function comTrava(funcao) {
  const resultado = trava.then(funcao);
  trava = resultado.catch(() => {}); // um erro não pode travar as próximas
  return resultado;
}

async function lerFila() {
  const { fila = [] } = await chrome.storage.session.get('fila');
  return fila;
}

async function gravarFila(fila) {
  await chrome.storage.session.set({ fila });
  // O número no ícone da extensão mostra quantas abas ainda faltam.
  await chrome.action.setBadgeText({ text: fila.length ? String(fila.length) : '' });
}

const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// Conferência do remetente (vale para ABRIR_NOVA_ABA e ABRIR_LOTE).
// O objeto "sender" é preenchido PELO CHROME; a página não o falsifica.
// ---------------------------------------------------------------------------
function remetenteEhAbaProjudi(sender) {
  return sender.id === chrome.runtime.id &&
         !!sender.tab &&
         self.PROJUDI.ehUrlProjudi(sender.url) &&
         self.PROJUDI.ehUrlProjudi(sender.tab.url);
}

function remetenteEhPaginaDaExtensao(sender) {
  return sender.id === chrome.runtime.id &&
         typeof sender.url === 'string' &&
         sender.url.startsWith(chrome.runtime.getURL(''));
}

// ---------------------------------------------------------------------------
// Põe itens na fila. Cada item guarda:
//   url         → endereço a abrir
//   origemTabId → aba da lista de Conclusões (para posicionar à direita dela)
//   windowId    → janela de origem
//   ordem       → 1, 2, 3... posição relativa à aba de origem
// ---------------------------------------------------------------------------
function enfileirar(urls, sender) {
  const itens = urls.map((url, i) =>
    ({ url, origemTabId: sender.tab.id, windowId: sender.tab.windowId, ordem: i + 1 }));
  return enfileirarItens(itens);
}

function enfileirarItens(itens, { naFrente = false } = {}) {
  return comTrava(async () => {
    const fila = await lerFila();
    if (naFrente) fila.unshift(...itens); else fila.push(...itens);
    await gravarFila(fila);
    console.log(`[nova-aba] ${itens.length} item(ns) na fila; total agora: ${fila.length}`);
    return fila.length;
  });
}

// ---------------------------------------------------------------------------
// PDFs de TODAS as abas do PROJUDI da janela.
//
// O service worker LÊ os links diretamente em cada aba com
// chrome.scripting.executeScript (permissão "scripting" + host_permissions).
// Vantagem sobre perguntar ao content script por mensagem: funciona também
// nas abas abertas ANTES de a extensão ser recarregada — sem F5.
//
//   background ──executeScript(lerPdfsDaPagina)──► aba 1 ──► [urls]
//              ──executeScript(lerPdfsDaPagina)──► aba 2 ──► [urls]
//
// A função injetada só LÊ o href dos links "online.pdf": não clica, não
// preenche, não envia nada. Ela roda dentro da página, por isso não enxerga
// nenhuma variável deste arquivo: tudo o que usa precisa estar nela.
// ---------------------------------------------------------------------------
function lerPdfsDaPagina() {
  return [...document.querySelectorAll('a.link[href*="/projudi/arquivo.do?_tj="]')]
    .filter((a) => a.textContent.trim().toLowerCase() === 'online.pdf')
    .map((a) => a.href);
}

async function coletarPdfs(windowId) {
  const todas = await chrome.tabs.query({ windowId });
  const jaAbertas = new Set(todas.map((t) => t.url)); // não reabre PDF já aberto
  const abasProjudi = todas
    .filter((t) => self.PROJUDI.ehUrlProjudi(t.url) && !t.url.includes('/projudi/arquivo.do'))
    .sort((a, b) => a.index - b.index);

  const itens = [];
  const vistos = new Set();
  let abasComPdf = 0;
  let semResposta = 0;

  for (const aba of abasProjudi) {
    let resultados;
    try {
      // allFrames: lê também quadros internos, se a página tiver.
      resultados = await chrome.scripting.executeScript({
        target: { tabId: aba.id, allFrames: true },
        func: lerPdfsDaPagina
      });
    } catch (erro) {
      // Ex.: aba descartada pelo economizador de memória ou ainda carregando.
      console.warn(`[nova-aba] não foi possível ler a aba ${aba.index}:`, erro.message);
      semResposta++;
      continue;
    }
    // Um resultado por quadro: junta todos.
    const urls = resultados.flatMap((r) => (Array.isArray(r.result) ? r.result : []))
      .filter((u) => self.PROJUDI.ehUrlProjudi(u) && !jaAbertas.has(u) && !vistos.has(u));
    if (urls.length) abasComPdf++;
    urls.forEach((url, i) => {
      vistos.add(url);
      // ordem relativa à aba DO PROCESSO: o PDF abre logo à direita dela.
      itens.push({ url, origemTabId: aba.id, windowId, ordem: i + 1 });
    });
  }
  console.log(`[nova-aba] PDFs encontrados: ${itens.length} em ${abasComPdf} aba(s); não lidas: ${semResposta}`);
  return { itens, abasComPdf, semResposta };
}

// Retira o primeiro item ANTES de abrir: se a criação da aba falhar, o item
// não fica preso na fila sendo tentado para sempre.
function retirarPrimeiro() {
  return comTrava(async () => {
    const fila = await lerFila();
    const item = fila.shift();
    await gravarFila(fila);
    return { item, restantes: fila.length };
  });
}

// ---------------------------------------------------------------------------
// Abre UM item à direita da aba de origem, sem tirar o foco.
// ---------------------------------------------------------------------------
async function abrirItem(item) {
  const props = { url: item.url, active: false };

  // A aba de origem pode ter sido movida ou fechada enquanto a fila andava:
  // consultamos a posição ATUAL dela.
  const origem = await chrome.tabs.get(item.origemTabId).catch(() => null);
  if (origem) {
    props.windowId = origem.windowId;
    props.index = origem.index + item.ordem; // 1ª à direita, 2ª depois dela...
    props.openerTabId = origem.id;
    // Fluxo automático: cada processo novo entra DEPOIS da última aba do
    // lote (processo anterior + PDF dele), mantendo a ordem da lista.
    if (item.fluxo) {
      const ultima = await ultimoIndiceDoLote(item.loteId);
      if (ultima !== null) props.index = ultima + 1;
    }
  } else {
    props.windowId = item.windowId;          // origem fechada: abre no fim da janela
  }

  try {
    const aba = await chrome.tabs.create(props);
    console.log(`[nova-aba] aba criada: id ${aba.id}, posição ${aba.index} →`, item.url);
    if (item.loteId) await registrarNoLote(item.loteId, aba.id);
    if (item.fluxo) await marcarEtapa(aba.id, { etapa: 'dados', loteId: item.loteId });
  } catch (erro) {
    // Ex.: a janela também foi fechada. Tenta na janela atual, sem posição.
    console.warn('[nova-aba] não deu na janela de origem, abrindo na atual:', erro.message);
    await chrome.tabs.create({ url: item.url, active: false });
  }
}

// ---------------------------------------------------------------------------
// FLUXO AUTOMÁTICO (um clique na lista de Conclusões)
//
//   aba nova ── carrega "Dados da Conclusão"
//      │  chrome.tabs.onUpdated (status "complete")
//      │  executeScript: LÊ o endereço escrito no onclick do botão Analisar
//      ▼  chrome.tabs.update: a MESMA aba vai para esse endereço
//   mesma aba ── carrega "Movimentar Processo"
//      │  chrome.tabs.onUpdated (status "complete")
//      │  executeScript: LÊ o href do(s) "online.pdf"
//      ▼  PDF entra na FRENTE da fila → abre logo à direita do processo
//
// Nada é clicado nem preenchido: a extensão lê endereços e navega a aba,
// como se você colasse o endereço na barra. O "estado" de cada aba (em que
// etapa ela está) fica em chrome.storage.session, porque o service worker
// pode dormir entre uma etapa e outra.
// ---------------------------------------------------------------------------

// Funções injetadas nas páginas (rodam DENTRO da aba; só leem).
function lerAnalisarDaPagina() {
  const botao = [...document.querySelectorAll('input[type="button"][name="analysis"]')]
    .find((b) => b.value.trim() === 'Analisar');
  if (!botao) return null;
  const m = (botao.getAttribute('onclick') || '').match(/location\.href\s*=\s*['"]([^'"]+)['"]/);
  if (!m) return null;
  try { return new URL(m[1].replace(/&amp;/g, '&'), location.href).href; } catch { return null; }
}

async function lerNaAba(tabId, func) {
  const [r] = await chrome.scripting.executeScript({ target: { tabId }, func });
  return r ? r.result : null;
}

// --- estado das abas do fluxo: { [tabId]: {etapa, loteId} } ----------------
function marcarEtapa(tabId, estado) {
  return comTrava(async () => {
    const { fluxo = {} } = await chrome.storage.session.get('fluxo');
    if (estado) fluxo[tabId] = estado; else delete fluxo[tabId];
    await chrome.storage.session.set({ fluxo });
  });
}
async function etapaDa(tabId) {
  const { fluxo = {} } = await chrome.storage.session.get('fluxo');
  return fluxo[tabId] || null;
}

// --- abas de cada lote (para posicionar o próximo processo) ----------------
function registrarNoLote(loteId, tabId) {
  return comTrava(async () => {
    const { lotes = {} } = await chrome.storage.session.get('lotes');
    (lotes[loteId] = lotes[loteId] || []).push(tabId);
    await chrome.storage.session.set({ lotes });
  });
}
async function ultimoIndiceDoLote(loteId) {
  const { lotes = {} } = await chrome.storage.session.get('lotes');
  let maior = null;
  for (const id of lotes[loteId] || []) {
    const aba = await chrome.tabs.get(id).catch(() => null);
    if (aba && (maior === null || aba.index > maior)) maior = aba.index;
  }
  return maior;
}

// Listener no nível de cima do arquivo: o Chrome ACORDA o service worker
// quando uma aba termina de carregar.
chrome.tabs.onUpdated.addListener(async (tabId, info, aba) => {
  if (info.status !== 'complete') return;
  const estado = await etapaDa(tabId);
  if (!estado) return; // não é aba do fluxo automático

  if (!self.PROJUDI.ehUrlProjudi(aba.url)) {
    await marcarEtapa(tabId, null); // saiu do PROJUDI: abandona
    return;
  }

  try {
    if (estado.etapa === 'dados') {
      const url = await lerNaAba(tabId, lerAnalisarDaPagina);
      if (!url || !self.PROJUDI.ehUrlProjudi(url)) {
        console.warn(`[nova-aba] fluxo: botão Analisar não encontrado na aba ${aba.index}; parei nela`);
        await marcarEtapa(tabId, null);
        return;
      }
      await marcarEtapa(tabId, { ...estado, etapa: 'movimentar' });
      console.log(`[nova-aba] fluxo: aba ${aba.index} → Movimentar Processo`);
      await chrome.tabs.update(tabId, { url }); // navega a MESMA aba
      return;
    }

    if (estado.etapa === 'movimentar') {
      await marcarEtapa(tabId, null); // última etapa desta aba
      const urls = [...new Set((await lerNaAba(tabId, lerPdfsDaPagina)) || [])]
        .filter((u) => self.PROJUDI.ehUrlProjudi(u));
      if (!urls.length) {
        console.warn(`[nova-aba] fluxo: nenhum online.pdf na aba ${aba.index}`);
        return;
      }
      const itens = urls.map((url, i) =>
        ({ url, origemTabId: tabId, windowId: aba.windowId, ordem: i + 1, loteId: estado.loteId }));
      console.log(`[nova-aba] fluxo: aba ${aba.index} → ${urls.length} online.pdf na fila`);
      await enfileirarItens(itens, { naFrente: true }); // PDF tem prioridade
      processarFila();
    }
  } catch (erro) {
    console.error('[nova-aba] fluxo: erro na aba', aba.index, erro);
    await marcarEtapa(tabId, null);
  }
});

// Aba fechada no meio do fluxo: esquece o estado dela.
chrome.tabs.onRemoved.addListener((tabId) => {
  etapaDa(tabId).then((e) => { if (e) marcarEtapa(tabId, null); });
});

// ---------------------------------------------------------------------------
// O "motor" da fila. Só um motor roda por vez (variável "processando").
// Se o service worker for encerrado, "processando" volta a false junto com
// tudo; ao acordar, a chamada no fim deste arquivo religa o motor.
// ---------------------------------------------------------------------------
let processando = false;

async function processarFila() {
  if (processando) return;   // já há um motor rodando
  processando = true;
  try {
    while (true) {
      const { item, restantes } = await retirarPrimeiro();
      if (!item) break;      // fila vazia: fim

      await abrirItem(item);

      if (restantes > 0) {
        // Lê o intervalo a cada volta: se você mudar na página de opções,
        // vale já para a próxima aba. (Máximo 5 s, bem abaixo dos ~30 s em
        // que o Chrome encerraria o service worker ocioso.)
        const { intervaloMs } = await self.PROJUDI.lerOpcoes();
        console.log(`[nova-aba] faltam ${restantes}; aguardando ${intervaloMs} ms`);
        await esperar(intervaloMs);
      }
    }
    console.log('[nova-aba] fila concluída');
  } finally {
    processando = false;
  }
}

// ---------------------------------------------------------------------------
// Recepção das mensagens.
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((mensagem, sender, sendResponse) => {
  const tipo = mensagem && mensagem.tipo;
  console.log('[nova-aba] mensagem recebida:', tipo, 'de:', sender.url);

  // --- 1 link (botão ↗) -------------------------------------------------
  if (tipo === 'ABRIR_NOVA_ABA') {
    if (!remetenteEhAbaProjudi(sender)) {
      sendResponse({ ok: false, motivo: 'a mensagem não veio de uma aba do PROJUDI' });
      return;
    }
    if (!self.PROJUDI.ehUrlProjudi(mensagem.url)) {
      sendResponse({ ok: false, motivo: 'endereço fora do PROJUDI' });
      return;
    }
    enfileirar([mensagem.url], sender).then((naFila) => {
      sendResponse({ ok: true, naFila });
      processarFila(); // sem intervalo antes do 1º item: abre na hora
    });
    return true; // resposta assíncrona (sendResponse chamado depois)
  }

  // --- vários links (botão "Abrir todos") -------------------------------
  if (tipo === 'ABRIR_LOTE') {
    if (!remetenteEhAbaProjudi(sender)) {
      sendResponse({ ok: false, motivo: 'a mensagem não veio de uma aba do PROJUDI' });
      return;
    }
    (async () => {
      const recebidas = Array.isArray(mensagem.urls) ? mensagem.urls : [];
      // Filtra endereços fora do PROJUDI e repetidos.
      const validas = [...new Set(recebidas.filter((u) => self.PROJUDI.ehUrlProjudi(u)))];
      // Aplica o limite AQUI também: o content script não é a última palavra.
      const { limiteLote } = await self.PROJUDI.lerOpcoes();
      const aceitas = validas.slice(0, limiteLote);

      if (!aceitas.length) {
        sendResponse({ ok: false, motivo: 'nenhum endereço válido' });
        return;
      }
      let naFila;
      if (mensagem.fluxo) {
        const loteId = String(Date.now());
        await registrarNoLote(loteId, sender.tab.id); // 1º processo entra logo à direita da lista
        naFila = await enfileirarItens(aceitas.map((url, i) => ({
          url, origemTabId: sender.tab.id, windowId: sender.tab.windowId, ordem: i + 1, fluxo: true, loteId
        })));
      } else {
        naFila = await enfileirar(aceitas, sender);
      }
      sendResponse({ ok: true, enfileirados: aceitas.length, descartados: recebidas.length - aceitas.length, naFila });
      processarFila();
    })();
    return true;
  }

  // --- PDFs de todas as abas: 1º só conta, 2º abre ----------------------
  if (tipo === 'CONTAR_PDFS_ABAS' || tipo === 'ABRIR_PDFS_ABAS') {
    if (!remetenteEhAbaProjudi(sender)) {
      sendResponse({ ok: false, motivo: 'a mensagem não veio de uma aba do PROJUDI' });
      return;
    }
    (async () => {
      const { itens, abasComPdf, semResposta } = await coletarPdfs(sender.tab.windowId);
      const { limiteLote } = await self.PROJUDI.lerOpcoes();
      const aceitos = itens.slice(0, limiteLote);

      if (tipo === 'CONTAR_PDFS_ABAS' || !aceitos.length) {
        sendResponse({ ok: true, total: itens.length, abrir: aceitos.length, abasComPdf, semResposta });
        return;
      }
      const naFila = await enfileirarItens(aceitos);
      sendResponse({ ok: true, enfileirados: aceitos.length, total: itens.length, semResposta, naFila });
      processarFila();
    })();
    return true;
  }

  // --- cancelar o que falta (página de opções) --------------------------
  if (tipo === 'ESVAZIAR_FILA') {
    if (!remetenteEhPaginaDaExtensao(sender)) {
      sendResponse({ ok: false, motivo: 'só a página de opções pode esvaziar a fila' });
      return;
    }
    comTrava(async () => {
      const descartados = (await lerFila()).length;
      await gravarFila([]);
      console.log(`[nova-aba] fila esvaziada (${descartados} item(ns) cancelado(s))`);
      sendResponse({ ok: true, descartados });
    });
    return true;
  }
});

// Clique no ícone da extensão (barra do Chrome) → abre a página de opções.
// (ícone agora abre o menu da EXTENSAO-PROJUDI)

// Ao acordar: se havia fila pendente (o worker morreu no meio), retoma.
processarFila();

})();
