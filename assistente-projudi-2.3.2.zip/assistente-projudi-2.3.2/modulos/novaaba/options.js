/*
 * options.js — a página de opções.
 *
 * Três formas de "conversar" aparecem aqui:
 *
 *   1. chrome.storage.sync.get / set
 *      Lê e grava as OPÇÕES. Não precisa de mensagem: a página de opções,
 *      o content script e o service worker acessam o mesmo storage.
 *
 *   2. chrome.storage.onChanged
 *      Avisa TODAS as partes da extensão quando algo é gravado. É assim que
 *      o content script no PROJUDI percebe a mudança sem F5, e que esta
 *      página vê a fila (storage.session) diminuir enquanto as abas abrem.
 *
 *   3. chrome.runtime.sendMessage({tipo:'ESVAZIAR_FILA'})
 *      Para MEXER na fila usamos mensagem, e não gravação direta: só o
 *      service worker altera a fila, sempre sob a mesma trava, evitando
 *      que esta página e o motor da fila gravem por cima um do outro.
 */

const P = self.PROJUDI;
const $ = (id) => document.getElementById(id);

// Mostra as faixas aceitas e configura os campos numéricos.
$('intervaloMs').min = P.LIMITES.intervaloMs.min;
$('intervaloMs').max = P.LIMITES.intervaloMs.max;
$('limiteLote').min = P.LIMITES.limiteLote.min;
$('limiteLote').max = P.LIMITES.limiteLote.max;
$('faixaIntervalo').textContent =
  `De ${P.LIMITES.intervaloMs.min} a ${P.LIMITES.intervaloMs.max} ms (padrão ${P.OPCOES_PADRAO.intervaloMs}).`;
$('faixaLimite').textContent =
  `De ${P.LIMITES.limiteLote.min} a ${P.LIMITES.limiteLote.max} (padrão ${P.OPCOES_PADRAO.limiteLote}).`;

function preencher(op) {
  $('intervaloMs').value = op.intervaloMs;
  $('limiteLote').value = op.limiteLote;
  $('mostrarBotaoLote').checked = op.mostrarBotaoLote;
  $('pedirConfirmacao').checked = op.pedirConfirmacao;
  $('fluxoCompleto').checked = op.fluxoCompleto;
}

function avisar(texto) {
  $('status').textContent = texto;
  setTimeout(() => { $('status').textContent = ''; }, 2500);
}

// --- Opções: carregar -------------------------------------------------------
P.lerOpcoes().then(preencher);

// --- Opções: salvar ---------------------------------------------------------
$('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const op = P.normalizar({
    intervaloMs: $('intervaloMs').value,
    limiteLote: $('limiteLote').value,
    mostrarBotaoLote: $('mostrarBotaoLote').checked,
    pedirConfirmacao: $('pedirConfirmacao').checked,
    fluxoCompleto: $('fluxoCompleto').checked
  });
  await chrome.storage.sync.set(op);   // dispara onChanged em toda a extensão
  preencher(op);                        // mostra o valor ajustado à faixa
  avisar('Salvo.');
});

// --- Opções: restaurar padrão -----------------------------------------------
$('restaurar').addEventListener('click', async () => {
  await chrome.storage.sync.set(P.OPCOES_PADRAO);
  preencher(P.OPCOES_PADRAO);
  avisar('Padrão restaurado.');
});

// --- Fila: mostrar e acompanhar ao vivo -------------------------------------
function mostrarFila(fila) {
  $('qtdFila').textContent = Array.isArray(fila) ? fila.length : 0;
}
chrome.storage.session.get('fila').then(({ fila }) => mostrarFila(fila));

chrome.storage.onChanged.addListener((mudancas, area) => {
  if (area === 'session' && mudancas.fila) mostrarFila(mudancas.fila.newValue);
  // Se as opções forem alteradas em outra janela, reflete aqui também.
  if (area === 'sync') P.lerOpcoes().then(preencher);
});

// --- Fila: esvaziar (via mensagem ao service worker) ------------------------
$('esvaziar').addEventListener('click', async () => {
  const resposta = await chrome.runtime.sendMessage({ tipo: 'ESVAZIAR_FILA' });
  avisar(resposta && resposta.ok
    ? `${resposta.descartados} aba(s) cancelada(s).`
    : `Não foi possível: ${resposta && resposta.motivo}`);
});
