/*
 * config.js — código COMPARTILHADO pelas três partes da extensão:
 *   - content script  (carregado antes do content.js, pelo manifest)
 *   - service worker  (carregado por importScripts no background.js)
 *   - página de opções (carregado por <script> no options.html)
 *
 * Usamos "self.PROJUDI = ..." (e não "const") porque "self" existe nos
 * três ambientes (janela e service worker) e a atribuição não dá erro se o
 * arquivo for carregado de novo depois de recarregar a extensão.
 */

self.PROJUDI = {
  // Valores usados quando você ainda não salvou nada na página de opções.
  // Ficam em chrome.storage.SYNC (acompanham sua conta Google no Chrome).
  OPCOES_PADRAO: {
    intervaloMs: 800,        // pausa entre uma aba e a próxima no "Abrir todos"
    limiteLote: 10,          // máximo de abas por "Abrir todos"
    mostrarBotaoLote: true,  // exibe o botão flutuante "Abrir todos"
    pedirConfirmacao: true,  // pergunta antes de abrir o lote
    fluxoCompleto: true      // "Abrir todos" já vai até a análise e o online.pdf
  },

  // Faixas aceitas (a página de opções e o service worker respeitam).
  LIMITES: {
    intervaloMs: { min: 200, max: 5000 },
    limiteLote: { min: 1, max: 50 }
  },

  // Regra de domínio: host começa com "projudi" e termina em ".tjpr.jus.br".
  ehUrlProjudi(endereco) {
    try {
      const u = new URL(endereco);
      return u.protocol === 'https:' &&
             u.hostname.startsWith('projudi') &&
             u.hostname.endsWith('.tjpr.jus.br');
    } catch {
      return false;
    }
  },

  // Lê as opções salvas e completa o que faltar com o padrão.
  // chrome.storage.sync.get(objeto) devolve as chaves pedidas; quando a
  // chave não existe, devolve o valor do próprio objeto (o padrão).
  async lerOpcoes() {
    const salvas = await chrome.storage.sync.get(self.PROJUDI.OPCOES_PADRAO);
    return self.PROJUDI.normalizar(salvas);
  },

  // Garante que os números estão dentro das faixas, mesmo se algo estranho
  // tiver sido gravado.
  normalizar(op) {
    const L = self.PROJUDI.LIMITES;
    const P = self.PROJUDI.OPCOES_PADRAO;
    const faixa = (v, { min, max }, padrao) => {
      const n = Math.round(Number(v));
      return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : padrao;
    };
    return {
      intervaloMs: faixa(op.intervaloMs, L.intervaloMs, P.intervaloMs),
      limiteLote: faixa(op.limiteLote, L.limiteLote, P.limiteLote),
      mostrarBotaoLote: op.mostrarBotaoLote !== false,
      pedirConfirmacao: op.pedirConfirmacao !== false,
      fluxoCompleto: op.fluxoCompleto !== false
    };
  }
};
