/**
 * abrir-pdfs-6meses.js — v1.1
 * Expande os "+", espera a lista carregar e devolve os links de arquivo
 * (online.pdf ou qualquer nome) dos últimos N meses cuja movimentação foi
 * feita pelos perfis escolhidos (coluna "Movimentado Por": Magistrado / Advogado).
 */
window.coletarPdfsRecentes = async function (meses = 6, abrirSemData = false, perfis = { magistrado: true, advogado: true }) {
  const CFG = {
    padraoArquivo: /arquivo|download|descarregar|visualizar.*(documento|arquivo)|\.pdf\b|online/i,
    padraoExcluir: /processo\.do|buscaProcesso|logout|imprimir/i,
    padraoExpandir: /plus|mais|expand/i,
    padraoData: /\b(\d{2})\/(\d{2})\/(\d{4})\b/,
    perfis: {
      // Juiz(a) de Direito, Juiz Substituto, Juiz Supervisor, Magistrado(a), Desembargador(a); exclui Juiz Leigo
      magistrado: /magistrad|desembargad|\bju[ií]z(a)?\b(?!\s*leig)/i,
      advogado: /\badvogad[oa]\b/i,
    },
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const corte = new Date();
  corte.setHours(0, 0, 0, 0);
  corte.setMonth(corte.getMonth() - meses);

  const extrairData = (t) => {
    const m = CFG.padraoData.exec(t || '');
    return m ? new Date(+m[3], +m[2] - 1, +m[1]) : null;
  };

  // Linha da movimentação = 1ª linha com data, subindo a partir do link
  const linhaMovimentacao = (a) => {
    let tr = a.closest('tr');
    while (tr) {
      let r = tr;
      for (let i = 0; r && i < 20; i++, r = r.previousElementSibling) {
        if (extrairData(r.textContent)) return r;
      }
      tr = tr.parentElement && tr.parentElement.closest('tr');
    }
    return null;
  };

  // Texto da coluna "Movimentado Por" da linha (fallback: última célula)
  const autorDaLinha = (row) => {
    let tabela = row.closest('table');
    let idx = -1;
    while (tabela && idx < 0) {
      const hdr = [...tabela.querySelectorAll('th, td')]
        .find((c) => /^\s*movimentad[oa]\s+por\s*$/i.test(c.textContent));
      if (hdr) idx = hdr.cellIndex;
      tabela = tabela.parentElement && tabela.parentElement.closest('table');
    }
    const cel = (idx >= 0 && row.cells[idx]) ? row.cells[idx] : row.cells[row.cells.length - 1];
    return cel ? cel.textContent.replace(/\s+/g, ' ').trim() : '';
  };

  const perfilAceito = (autor) =>
    Object.keys(CFG.perfis).some((p) => perfis[p] && CFG.perfis[p].test(autor));

  const linksArquivo = () => [...document.querySelectorAll('a[href]')].filter((a) => {
    const href = a.href;
    if (!href || /^javascript:/i.test(href) || href.endsWith('#')) return false;
    if (CFG.padraoExcluir.test(href)) return false;
    return CFG.padraoArquivo.test(`${href} ${a.getAttribute('onclick') || ''} ${a.textContent || ''} ${a.title || ''}`);
  });

  // Expandir os "+"
  const icones = [...document.querySelectorAll('img')].filter((img) =>
    CFG.padraoExpandir.test(`${img.getAttribute('src') || ''} ${img.title || ''} ${img.alt || ''}`)
    && !img.dataset.ajExp);
  for (const img of icones) {
    img.dataset.ajExp = '1';
    (img.closest('a') || img).click();
    await sleep(300);
  }

  // Esperar a contagem de links estabilizar
  let anterior = -1;
  for (let i = 0; i < 10; i++) {
    const n = linksArquivo().length;
    if (n === anterior) break;
    anterior = n;
    await sleep(500);
  }

  const vistos = new Set();
  const abrir = [];
  let antigos = 0, semData = 0, outrosAutores = 0;
  for (const a of linksArquivo()) {
    if (vistos.has(a.href)) continue;
    vistos.add(a.href);
    const row = linhaMovimentacao(a);
    if (!row) { semData++; if (abrirSemData) abrir.push(a.href); continue; }
    if (!perfilAceito(autorDaLinha(row))) { outrosAutores++; continue; }
    if (extrairData(row.textContent) < corte) { antigos++; continue; }
    abrir.push(a.href);
  }

  return { abrir, antigos, semData, outrosAutores, corte: corte.toLocaleDateString('pt-BR') };
};
