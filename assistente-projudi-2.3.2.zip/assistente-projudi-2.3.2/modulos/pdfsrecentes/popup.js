const statusEl = document.getElementById('status');
const setStatus = (m) => { statusEl.textContent = m; };
const marcado = (id) => document.getElementById(id).checked;

document.getElementById('btnPdfs').addEventListener('click', async () => {
  const meses = Math.max(1, parseInt(document.getElementById('meses').value, 10) || 6);
  const perfis = { magistrado: marcado('magistrado'), advogado: marcado('advogado') };
  if (!perfis.magistrado && !perfis.advogado) return setStatus('Marque Magistrado e/ou Advogado.');
  setStatus('Procurando arquivos...');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!/tjpr\.jus\.br/.test(tab.url || '')) return setStatus('Abra uma tela do PROJUDI antes.');

    await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ['modulos/pdfsrecentes/abrir-pdfs-6meses.js'] });
    const resultados = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: (m, s, p) => (window.coletarPdfsRecentes ? window.coletarPdfsRecentes(m, s, p) : null),
      args: [meses, marcado('semData'), perfis]
    });

    const urls = new Set();
    let antigos = 0, semData = 0, outros = 0, corte = '';
    for (const { result } of resultados) {
      if (!result) continue;
      result.abrir.forEach((u) => urls.add(u));
      antigos += result.antigos; semData += result.semData; outros += result.outrosAutores; corte = result.corte;
    }

    const resumo = `Desde ${corte}\nA abrir: ${urls.size} | Outros autores: ${outros}\nAnteriores: ${antigos} | Sem data: ${semData}`;
    if (!urls.size) return setStatus('Nenhum PDF no período/autor.\n' + resumo);
    if (urls.size > 10 && !confirm(`Abrir ${urls.size} arquivos em novas abas?\n${resumo}`)) return setStatus('Cancelado.\n' + resumo);

    let pos = tab.index + 1;
    for (const url of urls) {
      await chrome.tabs.create({ url, active: false, index: pos++ });
      await new Promise((r) => setTimeout(r, 700));
    }
    setStatus('Concluído.\n' + resumo);
  } catch (e) {
    setStatus('Erro: ' + e.message);
  }
});
