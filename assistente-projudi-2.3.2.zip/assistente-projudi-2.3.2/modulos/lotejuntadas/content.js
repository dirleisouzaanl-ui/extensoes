// Módulo "Lote na Análise de Juntadas" (tecla L). Painel na tela Análise de Juntadas que agrupa as
// linhas pelo tipo de documento (ex.: "ATO CUMPRIDO PELA PARTE OU INTERESSADO — Renúncia de Prazo")
// e marca de uma vez as caixinhas do grupo escolhido. A ação em lote em si (botões do PROJUDI no
// rodapé da tela) continua sendo clicada por você: o painel só marca, desmarca e abre em abas.
(() => {
  'use strict';
  if (window.top !== window || window.__loteJuntadas) return;
  window.__loteJuntadas = true;
  const ID = 'ext-lote-juntadas';
  const CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;
  const limpa = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const ehTela = () => /analisarJuntada/i.test(location.href) ||
    /An[áa]lise de Juntadas/i.test((document.body?.innerText || '').slice(0, 3000));

  // Linhas da lista com caixinha, nº do processo e a célula "Tipo de Documento".
  function linhas() {
    const out = [];
    for (const tabela of document.querySelectorAll('table')) {
      const cab = [...tabela.rows].find((r) => r.querySelector('th')) || tabela.rows[0];
      if (!cab) continue;
      let iTipo = -1;
      [...cab.cells].forEach((c, i) => { if (/tipo\s+de\s+documento/i.test(c.textContent)) iTipo = i; });
      if (iTipo < 0) continue;
      for (const tr of tabela.rows) {
        if (tr === cab || tr.querySelector('th') || tr.querySelector('tr')) continue;
        const cb = tr.querySelector('input[type=checkbox]');
        const num = (tr.textContent.match(CNJ) || [''])[0];
        const cel = tr.cells[iTipo];
        if (!cb || !num || !cel) continue;
        const partes = cel.innerText.split('\n').map(limpa).filter(Boolean);
        const sub = (partes[1] || '').split(/\s+de\s+|\s+-\s+/i)[0];   // "Renúncia de Prazo de X..." → "Renúncia"
        const sub2 = /^(Ren[úu]ncia de Prazo|Manifesta[çc][ãa]o|Peti[çc][ãa]o|Contesta[çc][ãa]o|Comprovante)/i
          .exec(partes[1] || '');
        out.push({ tr, cb, num, grupo: limpa(partes[0] + (partes[1] ? ' — ' + (sub2 ? sub2[1] : sub) : '')) });
      }
    }
    return out;
  }

  function marcar(grupo, valor) {
    let n = 0;
    for (const l of linhas()) {
      if (grupo && l.grupo !== grupo) continue;
      if (l.cb.checked !== valor) { l.cb.click(); n++; }
    }
    return n;
  }

  function montar() {
    if (document.getElementById(ID) || !document.body || !ehTela()) return;
    const ls = linhas();
    if (!ls.length) return;
    const grupos = {};
    ls.forEach((l) => { grupos[l.grupo] = (grupos[l.grupo] || 0) + 1; });
    const p = document.createElement('div');
    p.id = ID;
    p.style.cssText = 'position:fixed;left:20px;bottom:70px;z-index:2147483647;width:380px;background:#fff;' +
      'border:2px solid #5a6e3a;border-radius:6px;padding:8px 10px;font:12px Verdana,sans-serif;color:#222;' +
      'box-shadow:0 3px 10px rgba(0,0,0,.3)';
    p.innerHTML =
      '<div style="font-weight:bold;color:#5a6e3a;margin-bottom:6px">Lote — marcar juntadas por tipo ' +
      '<a href="#" id="ext-lote-fechar" style="float:right;color:#999;text-decoration:none">✕</a></div>' +
      '<select id="ext-lote-grupo" style="width:100%;font:11px Verdana">' +
      Object.entries(grupos).sort((a, b) => b[1] - a[1])
        .map(([g, n]) => `<option value="${g.replace(/"/g, '&quot;')}">(${n}) ${g}</option>`).join('') + '</select>' +
      '<div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">' +
      '<button type="button" id="ext-lote-marcar">Marcar este tipo</button>' +
      '<button type="button" id="ext-lote-limpar">Desmarcar todas</button>' +
      '<button type="button" id="ext-lote-abrir">Abrir marcadas em abas</button></div>' +
      '<div id="ext-lote-status" style="margin-top:6px;color:#555"></div>';
    document.body.appendChild(p);
    const st = (t) => { p.querySelector('#ext-lote-status').textContent = t; };
    p.querySelector('#ext-lote-fechar').onclick = (e) => { e.preventDefault(); p.remove(); };
    p.querySelector('#ext-lote-marcar').onclick = () => {
      const g = p.querySelector('#ext-lote-grupo').value;
      const n = marcar(g, true);
      const tot = linhas().filter((l) => l.cb.checked).length;
      st(`${n} marcada(s) agora · ${tot} marcada(s) no total. Use os botões do PROJUDI no rodapé para a ação em lote.`);
    };
    p.querySelector('#ext-lote-limpar').onclick = () => { marcar(null, false); st('Todas desmarcadas.'); };
    p.querySelector('#ext-lote-abrir').onclick = () => {
      const bt = document.getElementById('ext-abrir-conclusoes');   // botão verde do módulo "Abrir processos"
      if (bt) bt.click(); else st('Botão "Abrir processos em abas novas" não encontrado (recarregue com F5).');
    };
  }

  // Tecla L do menu: mostra (ou recria) o painel.
  chrome.runtime.onMessage.addListener((m, _s, resp) => {
    if (!m || m.tipo !== 'MOSTRAR_LOTE') return;
    document.getElementById(ID)?.remove();
    montar();
    resp({ ok: !!document.getElementById(ID) });
  });

  if (ehTela()) {
    montar();
    const obs = new MutationObserver(() => { if (document.getElementById(ID)) obs.disconnect(); else montar(); });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => obs.disconnect(), 30000);
  }
})();
