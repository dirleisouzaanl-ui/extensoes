// Módulo "Painel de prazos" (tecla R liga/desliga). Em qualquer lista do PROJUDI que tenha uma
// coluna de data-limite (Prazo, Data Final, Vencimento, Dt. Retorno, Data Limite...), colore as linhas:
//   vermelho = vencido · laranja = vence hoje · amarelo = vence nos próximos N dias úteis.
// Mostra um contador no canto. Só lê e colore a página: não altera nada no processo.
(() => {
  'use strict';
  if (window.__painelPrazos) return;
  window.__painelPrazos = true;

  const CHAVE = 'prazosCfg';
  const PADRAO = { ativo: true, dias: 3 };
  const RX_COLUNA = /prazo|data\s*final|data\s*limite|vencimento|dt\.?\s*retorno|fim\s+do\s+prazo|t[ée]rmino/i;
  const COR = { vencido: '#ffd6d6', hoje: '#ffe0b2', breve: '#fff7c2' };
  let cfg = { ...PADRAO };

  const hoje = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
  const lerData = (t) => { const m = /(\d{2})\/(\d{2})\/(\d{4})/.exec(t || ''); return m ? new Date(+m[3], +m[2] - 1, +m[1]) : null; };
  function diasUteisAte(d) {            // nº de dias úteis de amanhã até d (fins de semana excluídos)
    let n = 0; const x = hoje();
    while (x < d) { x.setDate(x.getDate() + 1); if (x.getDay() % 6) n++; }
    return n;
  }

  function colunaPrazo(tabela) {
    const cab = [...tabela.rows].find((r) => r.querySelector('th')) || tabela.rows[0];
    if (!cab) return null;
    let col = 0;
    for (const c of cab.cells) {
      if (RX_COLUNA.test(c.textContent)) return { cab, col };
      col += c.colSpan || 1;
    }
    return null;
  }

  function celulaNaColuna(tr, col) {
    let i = 0;
    for (const c of tr.cells) { if (col >= i && col < i + (c.colSpan || 1)) return c; i += c.colSpan || 1; }
    return null;
  }

  function limpar() {
    document.querySelectorAll('tr[data-prazo]').forEach((tr) => { tr.style.background = tr.dataset.bgOriginal || ''; delete tr.dataset.prazo; });
    document.getElementById('ext-prazos-contador')?.remove();
  }

  function aplicar() {
    if (!cfg.ativo || !document.body) { limpar(); return; }
    const cont = { vencido: 0, hoje: 0, breve: 0 };
    const h = hoje();
    for (const tabela of document.querySelectorAll('table')) {
      const achou = colunaPrazo(tabela);
      if (!achou) continue;
      for (const tr of tabela.rows) {
        if (tr === achou.cab || tr.querySelector('th')) continue;
        const d = lerData(celulaNaColuna(tr, achou.col)?.textContent);
        if (!d) continue;
        const tipo = d < h ? 'vencido' : +d === +h ? 'hoje' : diasUteisAte(d) <= cfg.dias ? 'breve' : null;
        if (!('bgOriginal' in tr.dataset)) tr.dataset.bgOriginal = tr.style.background || '';
        if (tipo) { tr.style.background = COR[tipo]; tr.dataset.prazo = tipo; cont[tipo]++; }
        else if (tr.dataset.prazo) { tr.style.background = tr.dataset.bgOriginal; delete tr.dataset.prazo; }
      }
    }
    const total = cont.vencido + cont.hoje + cont.breve;
    let box = document.getElementById('ext-prazos-contador');
    if (!total) { box?.remove(); return; }
    if (!box) {
      box = document.createElement('div');
      box.id = 'ext-prazos-contador';
      box.title = 'Painel de prazos (EXTENSAO-PROJUDI) — tecla R no menu liga/desliga';
      box.style.cssText = 'position:fixed;top:8px;right:8px;z-index:2147483646;background:#fff;border:1px solid #999;' +
        'border-radius:5px;padding:4px 8px;font:bold 11px Verdana;box-shadow:0 2px 5px rgba(0,0,0,.25)';
      document.body.appendChild(box);
    }
    const tag = (cor, n, txt) => `<span style="background:${cor};padding:1px 5px;border-radius:3px;margin-left:4px">${n} ${txt}</span>`;
    const html = 'Prazos:' + tag(COR.vencido, cont.vencido, 'vencido(s)') + tag(COR.hoje, cont.hoje, 'hoje') +
      tag(COR.breve, cont.breve, `até ${cfg.dias} dia(s) úteis`);
    if (box.dataset.html !== html) { box.innerHTML = html; box.dataset.html = html; } // evita laço com o observador
  }

  let agendado = false;
  const agendar = () => { if (agendado) return; agendado = true; setTimeout(() => { agendado = false; aplicar(); }, 400); };

  chrome.storage.local.get(CHAVE).then((r) => { cfg = { ...PADRAO, ...(r[CHAVE] || {}) }; aplicar(); }).catch(() => {});
  chrome.storage.onChanged.addListener((m, area) => {
    if (area === 'local' && m[CHAVE]) { cfg = { ...PADRAO, ...(m[CHAVE].newValue || {}) }; aplicar(); }
  });
  const deFora = (muts) => muts.some((m) => !(m.target.closest && m.target.closest('#ext-prazos-contador')) &&
    ![...m.addedNodes].every((n) => n.id === 'ext-prazos-contador'));
  new MutationObserver((muts) => { if (deFora(muts)) agendar(); }).observe(document.documentElement, { childList: true, subtree: true });
})();
