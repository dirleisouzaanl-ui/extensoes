// Leitor de petição (tecla I). Lê o texto da petição (PDF) e destaca o que a parte pede.
// Fontes: a aba atual, se for um PDF; ou, nos autos, a última juntada com arquivo que não é do Magistrado.
import * as pdfjs from '../mandados/lib/pdf.min.mjs';
pdfjs.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('modulos/mandados/lib/pdf.worker.min.mjs');

const $ = (id) => document.getElementById(id);
const st = (t, cor = '#555') => { $('status').style.color = cor; $('status').textContent = t; };
let resultados = [];

// Categorias de pedido (a primeira lista é a mais frequente no Juizado).
const CATEGORIAS = [
  ['Desistência', /desist[êe]ncia|desistir da (a[çc][ãa]o|demanda)/i, true],
  ['Acordo', /\bacordo\b|transa[çc][ãa]o|composi[çc][ãa]o amig[áa]vel|homologa[çc][ãa]o do acordo/i, true],
  ['Pagamento / quitação', /comprovante de pagamento|informa (o )?pagamento|quita[çc][ãa]o|dep[óo]sito judicial|guia de dep[óo]sito|efetuou o pagamento/i, true],
  ['Alvará / levantamento', /alvar[áa]|levantamento|transfer[êe]ncia d[eo]s? valor|dados banc[áa]rios|chave pix/i, true],
  ['SISBAJUD / RENAJUD / bloqueio', /sisbajud|bacenjud|penhora on-?line|bloqueio de (valores|ativos)|renajud|infojud|serasajud|\bcnib\b/i, true],
  ['Início do cumprimento de sentença', /cumprimento de senten[çc]a|art\.?\s*523|intima[çc][ãa]o do executado para pagamento/i, true],
  ['Extinção / arquivamento', /extin[çc][ãa]o|arquivamento|satisfa[çc][ãa]o d[ao] (obriga[çc][ãa]o|cr[ée]dito)/i, true],
  ['Novo endereço / citação', /novo endere[çc]o|indica[çc][ãa]o de endere[çc]o|pesquisa de endere[çc]o|\bsiel\b|infoseg|nova cita[çc][ãa]o/i, true],
  ['Dilação / suspensão de prazo', /dila[çc][ãa]o (do |de )?prazo|suspens[ãa]o do (processo|feito)|sobrestamento/i, false],
  ['Recurso / embargos', /recurso inominado|embargos de declara[çc][ãa]o|contrarraz[õo]es|agravo/i, false],
  ['Substabelecimento / habilitação', /substabelec|habilita[çc][ãa]o|ren[úu]ncia (ao|de) mandato/i, false],
  ['Renúncia de prazo', /ren[úu]ncia (ao|de) prazo/i, false],
  ['Audiência', /redesigna[çc][ãa]o|aus[êe]ncia justificada|audi[êe]ncia/i, false],
  ['Justiça gratuita', /justi[çc]a gratuita|gratuidade/i, false],
  ['Cálculo / impugnação', /impugna[çc][ãa]o|c[áa]lculo|planilha/i, false],
  ['Ciência / nada a requerer', /nada (mais )?a requerer|ciente|concorda/i, false]
];

// ---------- sugestão de conclusão (Tipo + Agrupador) ----------
// Cada regra: teste no texto → tipo de conclusão do PROJUDI + agrupador(es) preferido(s), em ordem.
const REGRAS = [
  [/desist[êe]ncia|desistir/i, (t) => ['SENTENÇA',
    /recurso inominado/i.test(t) ? ['DESISTÊNCIA - RECURSO INOMINADO'] :
    /embargos de declara/i.test(t) ? ['DESISTÊNCIA - EMBARGOS DE DECLARAÇÃO'] :
    /penhora|bloqueio|sisbajud|renajud/i.test(t) ? ['DESISTÊNCIA - BAIXA DE PENHORA E BLOQUEIO'] :
    /certid[ãa]o de cr[ée]dito/i.test(t) ? ['DESISTÊNCIA POR INEXISTÊNCIA DE BENS + CERTIDÃO DE CRÉDITO'] : ['DESISTÊNCIA'],
    'pedido de desistência → sentença homologatória']],
  [/\bacordo\b|transa[çc][ãa]o|composi[çc][ãa]o amig/i, (t) => [/descumpr|n[ãa]o cumprid|inadimpl/i.test(t) ? 'DESPACHO' : 'SENTENÇA',
    /descumpr|n[ãa]o cumprid|inadimpl/i.test(t) ? ['DESPACHO - PROSSEGUIMENTO DA EXECUÇÃO - ACORDO NÃO CUMPRIDO'] : ['HOMOLOGAÇÃO DE ACORDO', 'ACORDO'],
    'acordo → homologação (ou prosseguimento, se descumprido)']],
  [/embargos de declara[çc][ãa]o/i, (t) => [/senten[çc]a/i.test(t) ? 'SENTENÇA - EMBARGOS DE DECLARAÇÃO' : 'DECISÃO',
    [/contrarraz/i.test(t) ? 'EMBARGOS DE DECLARAÇÃO - COM CONTRARRAZÕES' : 'EMBARGOS DE DECLARAÇÃO'], 'embargos de declaração']],
  [/recurso inominado|contrarraz[õo]es ao recurso/i, () => ['DESPACHO - ANÁLISE DE RECURSO', ['ANÁLISE DE RECURSO', 'ALVARÁ + ANÁLISE DE RECURSO'], 'recurso inominado → juízo de admissibilidade']],
  [/(comprovante de pagamento|efetuou o pagamento|informa (o )?pagamento|pagamento (integral|do d[ée]bito|da condena)|quita[çc][ãa]o|satisfa[çc][ãa]o|extin[çc][ãa]o (do feito|da execu|pelo pagamento))/i, (t) => /alvar[áa]|levantamento|chave pix|dados banc/i.test(t)
    ? ['SENTENÇA', ['ALVARÁ + ARQUIVAMENTO', 'ALVARÁ'], 'pagamento + levantamento → extinção pela satisfação com alvará']
    : ['SENTENÇA', ['EXTINÇÃO PELO PAGAMENTO', 'EXTINÇÃO'], 'pagamento → extinção pela satisfação']],
  [/alvar[áa]|levantamento|chave pix|dados banc[áa]rios/i, (t) => ['DECISÃO',
    /renajud/i.test(t) ? ['ALVARÁ + RENAJUD'] : /desbloq|bacenjud|sisbajud/i.test(t) ? ['ALVARÁ + DESLOQUEIO BACENJUD', 'ALVARÁ + DESBLOQUEIO BACENJUD'] :
    /remanescente/i.test(t) ? ['ALVARÁ + CUMPRIMENTO DE SENTENÇA REMANESCENTE'] : ['ALVARÁ'], 'pedido de alvará/levantamento']],
  [/exce[çc][ãa]o de pr[ée]-?executividade/i, () => ['DECISÃO', ['EXCEÇÃO DE PRÉ-EXECUTIVIDADE'], 'exceção de pré-executividade']],
  [/embargos (à|a) execu[çc][ãa]o/i, (t) => ['SENTENÇA', [/impugna/i.test(t) ? 'EMBARGOS À EXECUÇÃO - COM IMPUGNAÇÃO' : 'EMBARGOS À EXECUÇÃO'], 'embargos à execução']],
  [/desconsidera[çc][ãa]o da personalidade/i, () => ['DECISÃO', ['DESCONSIDERAÇÃO DA PERSONALIDADE JURÍDICA'], 'incidente de desconsideração']],
  [/sisbajud|bacenjud|penhora on-?line|bloqueio de (valores|ativos)/i, () => ['DECISÃO', ['SISBAJUD', 'PENHORA ON LINE', 'BLOQUEIO'], 'pedido de bloqueio de valores']],
  [/renajud/i, () => ['DECISÃO', ['RENAJUD'], 'pedido de restrição de veículo']],
  [/\bcnib\b|indisponibilidade de bens/i, () => ['DECISÃO', ['DILIGÊNCIAS - (CNIB) CENTRAL NACIONAL DE INDISPONIBILIDADE DE BENS'], 'pedido de indisponibilidade (CNIB)']],
  [/serasajud/i, (t) => ['DECISÃO', [/baixa|exclus/i.test(t) ? 'BAIXA DA INSCRIÇÃO SERASAJUD - CREDOR/EXEQUENTE' : 'SERASAJUD'], 'SERASAJUD']],
  [/adjudica/i, () => ['DECISÃO', ['ADJUDICAÇÃO'], 'pedido de adjudicação']],
  [/avalia[çc][ãa]o/i, () => ['DECISÃO', ['AVALIAÇÃO'], 'pedido de avaliação']],
  [/venda (do|de) bem|aliena[çc][ãa]o (por iniciativa|particular)/i, () => ['DECISÃO', ['AUTORIZAÇÃO PARA VENDA DO BEM PENHORADO'], 'venda do bem penhorado']],
  [/certid[ãa]o de (d[íi]vida|cr[ée]dito)/i, () => ['DESPACHO', ['CERTIDÃO DE DÍVIDA / CRÉDITO'], 'pedido de certidão de crédito']],
  [/pesquisa de endere[çc]o|busca de endere[çc]o|\bsiel\b|infoseg/i, () => ['DESPACHO - DILIGÊNCIA', ['BUSCA DE ENDEREÇOS'], 'pedido de busca de endereço']],
  [/whats\s?app/i, () => ['DESPACHO - DILIGÊNCIA', ['CITAÇÃO/INTIMAÇÃO (WHATSAPP)'], 'citação/intimação por WhatsApp']],
  [/cita[çc][ãa]o por edital|edital/i, () => ['DECISÃO', ['CITAÇÃO POR EDITAL'], 'citação por edital']],
  [/novo endere[çc]o|indica(r|[çc][ãa]o de)? endere[çc]o|nova cita[çc][ãa]o/i, () => ['DESPACHO - DILIGÊNCIA', ['DILIGÊNCIAS DIVERSAS'], 'novo endereço / nova citação']],
  [/cumprimento de senten[çc]a|art\.?\s*523/i, (t) => ['DESPACHO - EXECUÇÃO DE TÍTULO',
    [/fazer|n[ãa]o fazer|entregar/i.test(t) ? 'CUMPRIMENTO DE SENTENÇA- OBRIGAÇÃO DE FAZER/NÃO FAZER/ENTREGAR COISA' :
      /provis[óo]rio/i.test(t) ? 'CUMPRIMENTO PROVISÓRIO DE SENTENÇA' : 'CUMPRIMENTO DE SENTENÇA - QUANTIA CERTA'], 'início do cumprimento de sentença']],
  [/execu[çc][ãa]o de t[íi]tulo extrajudicial/i, () => ['DESPACHO - EXECUÇÃO DE TÍTULO', ['EXECUÇÃO DE TÍTULO EXTRAJUDICIAL'], 'execução de título extrajudicial']],
  [/descumpr\w* (da )?(decis[ãa]o )?liminar|descumprimento/i, () => ['DECISÃO', ['DESCUMPRIMENTO DA DECISÃO LIMINAR'], 'descumprimento de liminar']],
  [/tutela de urg[êe]ncia|liminar|urgente/i, () => ['DECISÃO - PEDIDO DE URGÊNCIA', ['DECISÃO - PEDIDO DE URGÊNCIA'], 'pedido de urgência']],
  [/justi[çc]a gratuita|gratuidade|hipossufici/i, (t) => ['DECISÃO', [/recurs/i.test(t) ? 'ANÁLISE RECURSAL - HIPOSSUFICIÊNCIA' : 'ANÁLISE DE AJG - HIPOSSUFICIÊNCIA - CUSTAS PROCESSUAIS'], 'justiça gratuita']],
  [/parcelamento (das )?custas/i, () => ['DESPACHO', ['CUSTAS - REQUER PARCELAMENTO'], 'parcelamento de custas']],
  [/emenda (à|a) (peti[çc][ãa]o )?inicial/i, () => ['DESPACHO', ['EMENDA À PETIÇÃO INICIAL'], 'emenda à inicial']],
  [/dila[çc][ãa]o (do |de )?prazo/i, () => ['DESPACHO', ['DILAÇÃO DE PRAZO'], 'pedido de dilação de prazo']],
  [/redesigna[çc][ãa]o|designa[çc][ãa]o de audi[êe]ncia/i, () => ['DESPACHO', ['DESIGNAÇÃO AUDIÊNCIA DE CONCILIAÇÃO/INSTRUÇÃO'], 'audiência']],
  [/arquivamento/i, () => ['DECISÃO - ARQUIVAMENTO', ['ARQUIVAMENTO'], 'pedido de arquivamento']]
];
function sugerirConclusao(t) {
  for (const [rx, f] of REGRAS) if (rx.test(t)) { const [tipo, agrupadores, motivo] = f(t); return { tipo, agrupadores, motivo }; }
  return { tipo: 'DESPACHO', agrupadores: ['DILIGÊNCIAS DIVERSAS'], motivo: 'sem pedido típico identificado' };
}

// Injetada na tela de envio para conclusão: escolhe Tipo e Agrupador e PARA (não envia).
function preencherConclusao(tipo, agrupadores) {
  const norm = (x) => (x || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim().toUpperCase();
  const sels = [...document.querySelectorAll('select')].filter((s) => s.offsetParent !== null && !s.disabled);
  const tem = (s, rx) => [...s.options].some((o) => rx.test(norm(o.text)));
  const selTipo = sels.find((s) => tem(s, /^SENTENCA$/) && tem(s, /^DESPACHO$/));
  const selAgr = sels.find((s) => s !== selTipo && s.options.length > 20);
  const out = [];
  const marcar = (s) => { s.style.outline = '3px solid #2e7d32'; ['input', 'change'].forEach((t) => s.dispatchEvent(new Event(t, { bubbles: true }))); };
  if (selTipo) {
    const o = [...selTipo.options].find((x) => norm(x.text) === norm(tipo));
    if (o) { selTipo.value = o.value; marcar(selTipo); out.push('Tipo: ' + o.text.trim()); }
  }
  if (selAgr) {
    let o = null;
    for (const a of agrupadores) {
      o = [...selAgr.options].find((x) => norm(x.text) === norm(a)) || [...selAgr.options].find((x) => norm(x.text).startsWith(norm(a)));
      if (o) break;
    }
    if (o) { selAgr.value = o.value; marcar(selAgr); out.push('Agrupador: ' + o.text.trim()); }
  }
  return selTipo || selAgr ? out : null;
}

// ---------- injetada nos autos: arquivos da última juntada ----------
async function ultimaJuntada() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const rows = () => [...document.querySelectorAll('tr')].filter((tr) => tr.cells.length >= 5 &&
    /^\d+$/.test(tr.cells[1].innerText.trim()) && /^\d{2}\/\d{2}\/\d{4}/.test(tr.cells[2].innerText.trim()));
  if (!rows().length) {
    const aba = [...document.querySelectorAll('a, li, span, td')].find((el) => /^\s*movimenta[cç][oõ]es\s*$/i.test(el.textContent));
    if (!aba) return null;
    (aba.closest('a') || aba).click();
    for (let i = 0; i < 40 && !rows().length; i++) await sleep(250);
  }
  const numero = ((document.body.innerText || '').match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0];
  const tr = rows().filter((r) => /arquivo/i.test(r.cells[0].innerText) && !/magistrad|juiz/i.test(r.cells[4].innerText) &&
      !/mandado|oficial de justi|certid[ãa]o|intima[çc][ãa]o|expedi[çc][ãa]o/i.test(r.cells[3].innerText))
    .sort((a, b) => +b.cells[1].innerText - +a.cells[1].innerText)[0];
  if (!tr) return { numero, erro: 'Nenhuma petição com arquivo encontrada.' };
  const links = () => { const n = tr.nextElementSibling; return n && !(n.cells?.length >= 5 && /^\d+$/.test(n.cells[1]?.innerText.trim()))
    ? [...n.querySelectorAll('a[href]')].filter((a) => /arquivo\.do|\.pdf/i.test(a.href)).map((a) => a.href) : []; };
  if (!links().length) { const t = tr.cells[0].querySelector('a'); if (t) t.click(); for (let i = 0; i < 40 && !links().length; i++) await sleep(200); }
  tr.style.outline = '3px solid #1565c0';
  return { numero, seq: tr.cells[1].innerText.trim(), data: tr.cells[2].innerText.trim().slice(0, 10),
    evento: tr.cells[3].innerText.trim().split('\n')[0], por: tr.cells[4].innerText.trim().replace(/\s+/g, ' '),
    urls: [...new Set(links())].slice(0, 3) };
}

async function textoPdf(url) {
  const r = await fetch(url, { credentials: 'include' });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const doc = await pdfjs.getDocument({ data: new Uint8Array(await r.arrayBuffer()) }).promise;
  let t = '';
  for (let p = 1; p <= Math.min(doc.numPages, 15); p++) t += (await (await doc.getPage(p)).getTextContent()).items.map((i) => i.str).join(' ') + '\n';
  return t.replace(/\s+/g, ' ').trim();
}

function analisar(t) {
  if (!t || t.length < 60) return { semTexto: true, tags: [], pedidos: [] };
  // o pedido costuma vir no fim: "Diante do exposto / Ante o exposto / Isto posto, requer..."
  const fim = t.search(/(diante|ante|pelo|em face) d?o? ?exposto|isto posto|posto isso|nestes termos|pelo exposto/i);
  const foco = fim > 0 ? t.slice(fim) : t.slice(-2500);
  const frases = foco.split(/(?<=[.;])\s+(?=[A-Za-zÀ-ú(a-z]\)|[A-ZÀ-Ú0-9])/).map((f) => f.trim())
    .filter((f) => /requer|pugna|pleiteia|postula|pede|seja (determinad|deferid|expedid|intimad|homologad)/i.test(f) &&
      !/^(nestes|nesses|termos em que)\b.*pede deferimento|^pede deferimento/i.test(f));
  const pedidos = (frases.length ? frases : foco.split(/(?<=\.)\s+/).slice(0, 3)).slice(0, 5).map((f) => f.slice(0, 300));
  const base = foco + ' ' + t.slice(0, 1500);
  const tags = CATEGORIAS.filter(([, rx]) => rx.test(base)).map(([n, , forte]) => ({ n, forte }));
  return { semTexto: false, tags, pedidos, conclusao: sugerirConclusao(foco + ' ' + t.slice(0, 1500)) };
}

function render() {
  const realce = (s) => s.replace(/</g, '&lt;').replace(/(requer\w*|pugna\w*|pleiteia|postula\w*|seja \w+)/gi, '<mark>$1</mark>');
  $('saida').innerHTML = resultados.map((r) => `<div class="card">
    <div class="tit">${r.numero || ''}${r.seq ? ` — mov. ${r.seq} (${r.data}) — ${r.evento}` : ''}</div>
    ${r.por ? `<div style="color:#666">${r.por}</div>` : ''}
    ${r.erro ? `<div style="color:#b00020">${r.erro}</div>` : r.semTexto ? '<div style="color:#b00020">PDF sem texto legível (digitalizado) — abra para ler.</div>' :
    `<div>${r.tags.length ? r.tags.map((t) => `<span class="tag ${t.forte ? 'forte' : ''}">${t.n}</span>`).join('') : '<span class="tag">Manifestação genérica</span>'}</div>
     <ul class="ped">${r.pedidos.map((p) => `<li>${realce(p)}</li>`).join('')}</ul>
     <div style="margin-top:4px;padding:4px 6px;background:#eef7ee;border-radius:4px">
       <b>Conclusão sugerida:</b> ${r.conclusao.tipo} · <b>Agrupador:</b> ${r.conclusao.agrupadores[0]}
       <span style="color:#666">(${r.conclusao.motivo})</span></div>`}
    ${r.url ? `<button class="sec" data-url="${r.url}">Abrir PDF</button>` : ''}</div>`).join('') || '';
  $('saida').querySelectorAll('button[data-url]').forEach((b) => b.onclick = () => chrome.tabs.create({ url: b.dataset.url }));
}

async function lerAba(tab) {
  const ehPdf = /\.pdf([?#]|$)|\/arquivo\.do/i.test(tab.url || '');
  if (ehPdf) {
    const num = ((tab.title || '') + ' ').match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/);
    const t = await textoPdf(tab.url);
    const n = num ? num[0] : (t.match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0];
    resultados.push({ numero: n, evento: tab.title, url: tab.url, ...analisar(t) });
    return;
  }
  const r = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: ultimaJuntada });
  const d = r.map((x) => x.result).find((x) => x && (x.urls || x.erro));
  if (!d) return;
  if (d.erro) { resultados.push(d); return; }
  let t = '';
  for (const u of d.urls) { try { t += ' ' + await textoPdf(u); } catch { /* arquivo ilegível */ } }
  resultados.push({ ...d, url: d.urls[0], ...analisar(t) });
}

$('estaAba').onclick = async () => {
  resultados = []; render(); st('Lendo…');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try { await lerAba(tab); st('✓ Pronto.', '#2e7d32'); } catch (e) { st('✗ ' + e.message, '#b00020'); }
  if (!resultados.length) st('Abra os autos ou o PDF da petição.', '#b00020');
  render();
};
$('todasAbas').onclick = async () => {
  resultados = []; render();
  const abas = (await chrome.tabs.query({ currentWindow: true }))
    .filter((t) => /^https:\/\/projudi[^/]*\.tjpr\.jus\.br\//.test(t.url || '') && !/arquivo\.do/.test(t.url));
  for (let i = 0; i < abas.length; i++) { st(`Aba ${i + 1} de ${abas.length}…`); try { await lerAba(abas[i]); } catch { /* sem autos */ } render(); }
  st(`✓ ${resultados.length} petição(ões) lida(s).`, '#2e7d32');
};
$('copiar').onclick = async () => {
  const t = resultados.map((r) => `${r.numero}${r.seq ? ' — mov. ' + r.seq + ' (' + r.data + ')' : ''}: ` +
    (r.erro || (r.semTexto ? 'PDF sem texto' : (r.tags.map((x) => x.n).join(', ') || 'manifestação genérica')))).join('\n');
  await navigator.clipboard.writeText(t || 'Nada lido.'); st('✓ Resumo copiado.', '#2e7d32');
};
async function guardarSugestao() {
  const r = resultados.find((x) => x.conclusao);
  if (r) await chrome.storage.local.set({ sugestaoConclusao: { ...r.conclusao, numero: r.numero, quando: Date.now() } });
}
$('preencherConc').onclick = async () => {
  const { sugestaoConclusao: s } = await chrome.storage.local.get('sugestaoConclusao');
  if (!s) return st('Leia uma petição primeiro.', '#b00020');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const r = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: preencherConclusao, args: [s.tipo, s.agrupadores] });
  const out = r.map((x) => x.result).find(Boolean);
  st(out && out.length ? '✓ ' + out.join(' · ') + ' — confira e envie você mesma.' : 'Abra a tela de envio para conclusão (com Tipo e Agrupador).', out && out.length ? '#2e7d32' : '#b00020');
};
new MutationObserver(guardarSugestao).observe($('saida'), { childList: true });
$('estaAba').click();
