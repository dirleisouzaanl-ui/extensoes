// Pendências das abas abertas (tecla E). Percorre as abas do PROJUDI desta janela, lê nos autos o quadro
// "Pendências" (ex.: "Cumprimentos para Expedir: Bloqueio Sisbajud: 01") e mostra tudo numa lista só.
const $ = (id) => document.getElementById(id);
let resultados = [];

function lerPendencias() {   // injetada em cada aba
  const limpa = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const numero = ((document.body?.innerText || '').match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0];
  if (!numero) return null;
  const titulo = [...document.querySelectorAll('legend, h2, h3, h4, h5, b, strong, span, td')]
    .find((el) => /^\s*pend[êe]ncias\s*$/i.test(el.textContent));
  if (!titulo) return { numero, autos: false, itens: [] };
  const caixa = titulo.closest('fieldset') || titulo.parentElement;
  const itens = (caixa.innerText || '').split('\n').map(limpa)
    .filter((l) => l && !/^pend[êe]ncias$/i.test(l));
  // junta "Rótulo:" com o valor da linha seguinte quando vierem separados
  const out = [];
  for (const l of itens) { if (out.length && /:$/.test(out[out.length - 1])) out[out.length - 1] += ' ' + l; else out.push(l); }
  return { numero, autos: true, itens: out };
}

function render() {
  const so = $('soCom').checked;
  const lista = resultados.filter((r) => !so || r.itens.length);
  $('corpo').innerHTML = lista.length ? lista.map((r, i) =>
    `<tr><td class="num">${r.numero}</td><td>${r.itens.length ? r.itens.map((x) => x.replace(/</g, '&lt;')).join('<br>')
      : `<span class="vazio">${r.autos ? 'sem pendências' : 'aba não é a tela dos autos'}</span>`}</td>` +
    `<td><button data-tab="${r.tabId}">Ir</button></td></tr>`).join('')
    : '<tr><td colspan="3" class="vazio">Nenhuma pendência nas abas abertas.</td></tr>';
  $('corpo').querySelectorAll('button').forEach((b) => b.onclick = () => chrome.tabs.update(+b.dataset.tab, { active: true }));
}

$('soCom').onchange = render;
$('copiar').onclick = async () => {
  const t = resultados.filter((r) => r.itens.length).map((r) => `${r.numero}\n   ${r.itens.join('\n   ')}`).join('\n\n');
  await navigator.clipboard.writeText(t || 'Nenhuma pendência.');
  $('status').textContent = '✓ Copiado.';
};

(async () => {
  const abas = (await chrome.tabs.query({ currentWindow: true }))
    .filter((t) => /^https:\/\/projudi[^/]*\.tjpr\.jus\.br\//.test(t.url || '') && !/arquivo\.do/.test(t.url))
    .sort((a, b) => a.index - b.index);
  const vistos = new Set();
  for (const t of abas) {
    try {
      const r = await chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, func: lerPendencias });
      const d = r.map((x) => x.result).filter(Boolean).sort((a, b) => b.itens.length - a.itens.length || b.autos - a.autos)[0];
      if (d && !vistos.has(d.numero)) { vistos.add(d.numero); resultados.push({ ...d, tabId: t.id }); }
    } catch { /* aba descartada ou sem permissão */ }
  }
  const com = resultados.filter((r) => r.itens.length).length;
  $('status').textContent = `${resultados.length} processo(s) lido(s) · ${com} com pendência.`;
  render();
})();
