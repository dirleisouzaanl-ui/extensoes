// EXPEDIR OFÍCIO AGENTE COPILOT — une as abas PDF selecionadas em um único arquivo.
const NOME_ARQUIVO = 'EXTRAÇÃO DE DADOS OFÍCIOSCOPILOT E ALVARÁS.pdf';
const $ = (id) => document.getElementById(id);
const barra = document.querySelector('#barra div');

function status(txt, cor = '#555') { $('status').style.color = cor; $('status').textContent = txt; }

// Confirma, dentro da própria aba, se o que está aberto é um PDF.
async function ehPdf(tab) {
  const url = (tab.url || '').toLowerCase();
  if (/\.pdf([?#]|$)/.test(url) || /\/arquivo\.do/.test(url) || (tab.title || '').toLowerCase().endsWith('.pdf')) return true;
  if (!/^(https?|file|blob):/.test(url)) return false;
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => document.contentType });
    return r && r.result === 'application/pdf';
  } catch { return false; }
}

async function abasPdf(somenteSelecionadas) {
  const q = { currentWindow: true };
  if (somenteSelecionadas) q.highlighted = true;
  const abas = (await chrome.tabs.query(q)).sort((a, b) => a.index - b.index); // ordem das abas
  const pdfs = [];
  for (const t of abas) if (await ehPdf(t)) pdfs.push(t);
  return pdfs;
}

async function lerBytes(tab) {
  if ((tab.url || '').startsWith('blob:')) {
    // blob: só pode ser lido dentro da própria aba
    const [r] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        const u = document.querySelector('embed[type="application/pdf"]')?.src || location.href;
        const b = new Uint8Array(await (await fetch(u)).arrayBuffer());
        let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
        return btoa(s);
      }
    });
    const bin = atob(r.result); const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out.buffer;
  }
  const resp = await fetch(tab.url, { credentials: 'include' }); // usa o login do PROJUDI/SEEU
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  return resp.arrayBuffer();
}

async function unir(abas) {
  $('repetir').hidden = true; $('todas').hidden = true;
  $('titulo').textContent = `${abas.length} PDF(s), nesta ordem:`;
  $('lista').innerHTML = '';
  abas.forEach((t) => { const li = document.createElement('li'); li.textContent = t.title || t.url; $('lista').appendChild(li); });

  const { PDFDocument } = PDFLib;
  const final = await PDFDocument.create();
  let paginas = 0;
  for (let i = 0; i < abas.length; i++) {
    status(`Lendo ${i + 1} de ${abas.length}…`);
    barra.style.width = Math.round((i / abas.length) * 85) + '%';
    try {
      const doc = await PDFDocument.load(await lerBytes(abas[i]), { ignoreEncryption: true });
      const pags = await final.copyPages(doc, doc.getPageIndices());
      pags.forEach((p) => final.addPage(p));
      paginas += pags.length;
    } catch (e) {
      throw new Error(`não consegui ler "${abas[i].title || abas[i].url}" (${e.message}).` +
        ((abas[i].url || '').startsWith('file:') ? ' Ative "Permitir acesso a URLs de arquivo" na extensão.' : ''));
    }
  }
  status('Gerando o arquivo…');
  barra.style.width = '95%';
  const blob = new Blob([await final.save()], { type: 'application/pdf' });
  await chrome.downloads.download({
    url: URL.createObjectURL(blob), filename: NOME_ARQUIVO, saveAs: false, conflictAction: 'overwrite'
  });
  barra.style.width = '100%';
  status(`✓ ${NOME_ARQUIVO} salvo (${abas.length} arquivos, ${paginas} páginas).`, '#2e7d32');
  $('repetir').hidden = false;
}

async function iniciar(somenteSelecionadas = true) {
  try {
    const abas = await abasPdf(somenteSelecionadas);
    if (abas.length < 2) {
      $('titulo').textContent = somenteSelecionadas
        ? (abas.length ? 'Só 1 aba PDF selecionada.' : 'Nenhuma aba PDF selecionada.')
        : 'Menos de 2 abas PDF nesta janela.';
      status('Selecione 2 ou mais abas PDF com Ctrl+clique e abra de novo.', '#b00020');
      $('todas').hidden = !somenteSelecionadas;
      return;
    }
    $('repetir').onclick = () => unir(abas).catch((e) => status('✗ ' + e.message, '#b00020'));
    await unir(abas);
  } catch (e) {
    status('✗ ' + e.message, '#b00020');
  }
}

$('todas').onclick = () => iniciar(false);
iniciar(true);
