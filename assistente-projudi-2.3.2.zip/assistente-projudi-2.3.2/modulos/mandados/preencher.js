// Retorno de mandado — preenche o formulário que aparece após "Analisar Retorno" (mesma página):
//   Marcar Leitura: Recebido pela parte? (Sim/Não) · Iniciar prazo a partir da (juntada / leitura) · Data · Horário
//   Informações do Cumprimento: Resultado
// Usa o pedido gravado pelo menu (tecla N). Preenche e PARA: não clica em Salvar — a gravação é da servidora.
(() => {
  'use strict';
  if (window.__retornoMandado) return;
  window.__retornoMandado = true;
  const CHAVE = 'retornoMandado';
  const limpa = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const visivel = (el) => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const disparar = (el) => ['input', 'change', 'blur'].forEach((t) => el.dispatchEvent(new Event(t, { bubbles: true })));
  const marcar = (el) => { if (el) { el.style.outline = '3px solid #2e7d32'; el.style.outlineOffset = '1px'; } };
  const TEXTOS = 'input[type=text], input:not([type])';
  let meuTab = null, rodando = false;

  // texto que vem logo depois do radio (até o próximo campo)
  function textoApos(r) {
    if (r.id) { const l = document.querySelector(`label[for="${CSS.escape(r.id)}"]`); if (l) return limpa(l.textContent); }
    let s = '', n = r.nextSibling;
    while (n && !(n.nodeType === 1 && (n.matches('input,select,textarea') || n.querySelector?.('input,select')))) { s += n.textContent || ''; n = n.nextSibling; }
    return limpa(s) || limpa(r.closest('label')?.textContent);
  }
  // linha (tr) cujo rótulo (1ª célula) casa com rx
  const linha = (rx) => [...document.querySelectorAll('tr')].find((tr) => visivel(tr) && tr.cells.length > 1 &&
    rx.test(limpa(tr.cells[0].textContent)) && tr.querySelector('input,select'));
  const radiosVisiveis = () => [...document.querySelectorAll('input[type=radio]')].filter(visivel);
  function radioSimNao(sim) {
    const rx = sim ? /^sim$/i : /^n[ãa]o$/i;
    const tr = linha(/Recebido pela parte/i);
    return (tr && [...tr.querySelectorAll('input[type=radio]')].find((r) => rx.test(textoApos(r)))) ||
      radiosVisiveis().find((r) => rx.test(textoApos(r)));
  }
  const radioPrazo = (base) => radiosVisiveis().find((r) => (base === 'juntada' ? /juntada/i : /leitura/i).test(textoApos(r)));
  const nomeId = (i) => (i.name || '') + ' ' + (i.id || '');
  const rotuloAntes = (i) => limpa(i.closest('td')?.previousElementSibling?.textContent);
  const campoData = () => (linha(/^\*?\s*Data\s*:?$/i)?.querySelector(TEXTOS)) ||
    [...document.querySelectorAll(TEXTOS)].find((i) => visivel(i) && (/^\*?\s*Data\s*:?$/i.test(rotuloAntes(i)) ||
      (/data/i.test(nomeId(i)) && /leitura|intima|prazo/i.test(nomeId(i)))));
  const campoHora = () => [...document.querySelectorAll(TEXTOS)]
    .find((i) => visivel(i) && (/hor/i.test(nomeId(i)) || /Hor[áa]rio/i.test(rotuloAntes(i))));
  const campoResultado = () => linha(/Resultado/i)?.querySelector('select') ||
    [...document.querySelectorAll('select')].find((s) => visivel(s) && [...s.options].some((o) => /\((PI|NE|NEL|PO)\)\s*$/.test(limpa(o.text))));

  async function esperar(fn, ms) {
    for (let t = 0; t < ms; t += 200) { const v = fn(); if (v) return v; await sleep(200); }
    return null;
  }
  async function habilitado(el, ms = 4000) {
    for (let t = 0; t < ms && el && el.disabled; t += 200) await sleep(200);
    return !!el && !el.disabled;
  }
  function escrever(el, v) {
    el.focus(); el.value = v; disparar(el);
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true })); marcar(el);
  }

  function aviso(linhas, ok) {
    let b = document.getElementById('ext-retorno-aviso');
    if (!b) {
      b = document.createElement('div'); b.id = 'ext-retorno-aviso';
      b.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:2147483647;max-width:460px;background:#fff;border:2px solid;' +
        'border-radius:6px;padding:8px 10px;font:12px/1.5 Verdana,sans-serif;box-shadow:0 3px 10px rgba(0,0,0,.35)';
      document.body.appendChild(b);
    }
    b.style.borderColor = ok ? '#2e7d32' : '#e65100';
    b.innerHTML = `<b style="color:${ok ? '#2e7d32' : '#e65100'}">Retorno de mandado — ${ok ? 'preenchido' : 'preenchido com pendências'}</b><br>` +
      linhas.map((l) => l.replace(/</g, '&lt;')).join('<br>') + '<br><b>Confira e clique em Salvar você mesma.</b> ' +
      '<a href="#" id="ext-retorno-fechar">fechar</a>';
    b.querySelector('#ext-retorno-fechar').onclick = (ev) => { ev.preventDefault(); b.remove(); };
  }

  // Sequência da servidora: Sim/Não → (espera) → Data de leitura da parte → (espera) → Data/Horário → Resultado.
  // O pedido só é encerrado no fim: se a página recarregar entre as etapas, continua de onde parou.
  const PAUSA = 2500;
  async function preencher(e) {
    const sim = e.cumprido === 'SIM';
    const r = await esperar(() => radioSimNao(sim), 5000);
    if (!r) return false;                                         // formulário ainda não apareceu
    const log = [], pend = [];
    const fim = async () => { await chrome.storage.local.set({ [CHAVE]: { ...e, ativo: false } }); aviso([...log, ...pend], !pend.length); return true; };

    // 1) Recebido pela parte? — Sim ou Não
    await habilitado(r);
    if (!r.checked) { r.click(); marcar(r.parentElement); await sleep(PAUSA); }
    log.push(`Recebido pela parte: ${sim ? 'Sim' : 'Não'}`);

    if (sim) {
      // 2) Iniciar prazo a partir da — Data de leitura da parte
      const rp = await esperar(() => { const x = radioPrazo(e.prazoBase); return x && !x.disabled ? x : null; }, 8000);
      if (rp) {
        if (!rp.checked) { rp.click(); marcar(rp.parentElement); await sleep(PAUSA); }
        log.push(`Iniciar prazo a partir da: ${e.prazoBase === 'juntada' ? 'data da juntada nos autos' : 'data de leitura da parte'}`);
      } else pend.push('"Iniciar prazo a partir da": opção não habilitou — marque manualmente.');

      // 3) Data (e Horário, se a certidão trouxer)
      const d = await esperar(() => { const x = campoData(); return x && !x.disabled ? x : null; }, 8000);
      if (d) {
        if (e.prazoBase === 'juntada' && d.value) log.push(`Data: ${d.value} (preenchida pelo sistema)`);
        else { escrever(d, e.data); log.push(`Data: ${e.data}`); }
        const h = campoHora();
        if (h && e.hora && !h.disabled && !(e.prazoBase === 'juntada' && h.value)) { escrever(h, e.hora); log.push(`Horário: ${e.hora}`); }
        await sleep(800);
      } else pend.push(`Data: campo não habilitou — informe ${e.data}.`);
    }

    // 4) Resultado
    const sel = await esperar(campoResultado, 4000);
    const op = sel && [...sel.options].find((o) => new RegExp('\\(' + e.resultado + '\\)\\s*$', 'i').test(limpa(o.text)));
    if (op) { sel.value = op.value; disparar(sel); marcar(sel); log.push(`Resultado: ${limpa(op.text)}`); }
    else { marcar(sel); pend.push(`Resultado ${e.resultado}: opção não encontrada — escolha manualmente.`); }
    return fim();
  }

  async function verificar() {
    if (rodando) return;
    const { [CHAVE]: e } = await chrome.storage.local.get(CHAVE);
    if (!e || !e.ativo) return;
    if (Date.now() - e.clicadoEm > 120000) { await chrome.storage.local.set({ [CHAVE]: { ...e, ativo: false } }); return; }
    if (!meuTab) { try { meuTab = await chrome.runtime.sendMessage({ tipo: 'MEU_TAB' }); } catch { return; } }
    if (!meuTab || (meuTab.tabId !== e.tabId && meuTab.opener !== e.tabId)) return;
    rodando = true;
    try {
      for (let i = 0; i < 8; i++) {                               // até ~40 s esperando o formulário
        const atual = (await chrome.storage.local.get(CHAVE))[CHAVE];
        if (!atual || !atual.ativo) break;
        if (await preencher(atual)) break;
      }
    } finally { rodando = false; }
  }

  chrome.storage.onChanged.addListener((m, area) => { if (area === 'local' && m[CHAVE]?.newValue?.ativo) verificar(); });
  verificar();
})();
