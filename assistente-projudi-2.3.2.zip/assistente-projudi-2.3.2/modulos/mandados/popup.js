// Análise do retorno de mandados (tecla N). Localiza nos autos as movimentações de mandado devolvido /
// certidão do oficial, lê o texto do PDF (pdf.js, local) e classifica: POSITIVO, NEGATIVO, PARCIAL.
import * as pdfjs from './lib/pdf.min.mjs';
pdfjs.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('modulos/mandados/lib/pdf.worker.min.mjs');

const $ = (id) => document.getElementById(id);
const st = (t, cor = '#555') => { $('status').style.color = cor; $('status').textContent = t; };
let linhas = [];

// ---------- injetadas nos autos ----------
async function lerMandados(limite) {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const rows = () => [...document.querySelectorAll('tr')].filter((tr) => tr.cells.length >= 5 &&
    /^\d+$/.test(tr.cells[1].innerText.trim()) && /^\d{2}\/\d{2}\/\d{4}/.test(tr.cells[2].innerText.trim()));
  if (!rows().length) {
    const aba = [...document.querySelectorAll('a, li, span, td')].find((el) => /^\s*movimenta[cç][oõ]es\s*$/i.test(el.textContent));
    if (!aba) return null;
    (aba.closest('a') || aba).click();
    for (let i = 0; i < 40 && !rows().length; i++) await sleep(250);
  }
  const numero = ((document.body.innerText || '').match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0];
  const alvo = rows().filter((tr) => /arquivo/i.test(tr.cells[0].innerText) &&
      /mandado|oficial de justi|dilig[êe]ncia (positiva|negativa)/i.test(tr.cells[3].innerText + ' ' + tr.cells[4].innerText))
    .sort((a, b) => +b.cells[1].innerText - +a.cells[1].innerText).slice(0, limite);
  const out = [];
  for (const tr of alvo) {
    const links = () => { const n = tr.nextElementSibling; return n && !(n.cells?.length >= 5 && /^\d+$/.test(n.cells[1]?.innerText.trim()))
      ? [...n.querySelectorAll('a[href]')].filter((a) => /arquivo\.do|\.pdf/i.test(a.href)).map((a) => a.href) : []; };
    if (!links().length) { const t = tr.cells[0].querySelector('a'); if (t) t.click(); for (let i = 0; i < 40 && !links().length; i++) await sleep(200); }
    out.push({ numero, seq: tr.cells[1].innerText.trim(), data: tr.cells[2].innerText.trim().slice(0, 10),
      evento: tr.cells[3].innerText.trim().split('\n')[0], urls: [...new Set(links())] });
  }
  return { numero, mandados: out };
}

// Tela "Mandado - Processo": lê os campos (rótulo: valor) e os links de "Documento(s) Retornado(s)" e "Mandado".
function lerTelaMandado() {
  const limpa = (x) => (x || '').replace(/\s+/g, ' ').trim();
  if (!/Mandado\s*-\s*Processo/i.test(document.body?.innerText || '') &&
      !/Documento\(s\)\s*Retornado/i.test(document.body?.innerText || '')) return null;
  const rotulos = [...document.querySelectorAll('td, th, b, strong, label, span')]
    .filter((e) => e.children.length <= 2 && /:\s*$/.test(limpa(e.textContent)) && limpa(e.textContent).length < 60);
  const campos = {}, links = {};
  for (const r of rotulos) {
    const k = limpa(r.textContent).replace(/:\s*$/, '');
    const v = r.nextElementSibling || r.parentElement?.nextElementSibling;
    if (!v || k in campos) continue;
    campos[k] = limpa(v.innerText);
    const ls = [...v.querySelectorAll('a[href]')].filter((a) => /arquivo|\.pdf|download/i.test(a.href + ' ' + a.textContent));
    if (ls.length) links[k] = ls.map((a) => a.href);
  }
  const numero = ((document.body.innerText || '').match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0];
  const pega = (rx) => { const k = Object.keys(campos).find((x) => rx.test(x)); return k ? campos[k] : ''; };
  const pegaLinks = (rx) => { const k = Object.keys(links).find((x) => rx.test(x)); return k ? links[k] : []; };
  return {
    numero,
    seq: pega(/Identificador do Cumprimento/i), status: pega(/^Status$/i), natureza: pega(/Natureza do Mandado/i),
    parte: pega(/Referente a\(s\) parte/i), endereco: pega(/^Endere[çc]os?$/i), audiencia: pega(/^Audi[êe]ncia$/i),
    expedicao: pega(/Data da Expedi[çc][ãa]o/i), prazoOficial: pega(/Prazo \(Referente ao Oficial/i),
    oficial: pega(/Oficial de Justi[çc]a/i).split(/Dt Distribui/i)[0].trim(), retorno: pega(/Data do Retorno/i),
    retornados: pegaLinks(/Documento\(s\) Retornado/i), mandado: pegaLinks(/^Mandado$/i)
  };
}

// Datas da certidão do oficial (numéricas e por extenso), com o trecho em volta; marca as que estão
// junto de "citei / intimei / cumpri / dirigi-me / diligenciei".
const MESES = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
function datasDaCertidao(t) {
  const out = [];
  const add = (d, m, a, i, len) => {
    a = a < 100 ? 2000 + a : a;
    if (!(d >= 1 && d <= 31 && m >= 1 && m <= 12 && a >= 2000 && a <= 2100)) return;
    const ctx = t.slice(Math.max(0, i - 160), i + len + 120);
    const ini = Math.max(t.lastIndexOf('. ', i), t.lastIndexOf('; ', i)) + 1;
    let fim = t.indexOf('. ', i + len); if (fim < 0) fim = t.length;
    const frase = t.slice(ini, fim);                           // a frase inteira que contém a data
    const antes = t.slice(Math.max(ini, i - 45), i);            // logo antes da data
    const hora = (t.slice(i, i + len + 40).match(/(\d{1,2})\s*[h:]\s*(\d{2})/i) || []);
    out.push({ data: `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}/${a}`, hora: hora[1] ? `${hora[1]}h${hora[2]}` : '',
      ato: /citei|intimei|notifiquei|cumpri|dirigi-me|diligenciei|compareci|procedi|deixei de|n[ãa]o (foi )?localizad|n[ãa]o encontrei/i.test(frase) &&
        !/audi[êe]ncia|designad|para o dia|redesignad|sess[ãa]o|prazo/i.test(antes),
      ctx: ctx.replace(/\s+/g, ' ').trim() });
  };
  for (const m of t.matchAll(/\b(\d{1,2})\s*[\/.]\s*(\d{1,2})\s*[\/.]\s*(\d{2,4})\b/g)) add(+m[1], +m[2], +m[3], m.index, m[0].length);
  const rx = new RegExp('\\b(\\d{1,2}|1º|primeiro)\\s*(?:\\([^)]*\\)\\s*)?(?:dias?\\s+)?(?:do\\s+m[êe]s\\s+)?de\\s+(' + MESES.join('|') + ')\\s+(?:do\\s+ano\\s+)?(?:de\\s+)?(\\d{4})', 'gi');
  for (const m of t.matchAll(rx)) add(/\d/.test(m[1]) ? parseInt(m[1], 10) : 1, MESES.indexOf(m[2].toLowerCase()) + 1, +m[3], m.index, m[0].length);
  const vistos = new Set();
  return out.filter((x) => { const k = x.data + x.ctx.slice(0, 40); if (vistos.has(k)) return false; vistos.add(k); return true; });
}

// Opções do campo "Resultado" na tela Analisar Retorno (PROJUDI/TJPR).
const OPCOES = [['PI', 'Parte Citada/Intimada'], ['PP', 'Penhora Positiva'], ['PO', 'Positivo Outros'],
  ['PEL', 'Positivo Exclusivamente Eletrônico'], ['NE', 'Negativa de Endereço'], ['NBR', 'Negativa de Bens'],
  ['NPRP', 'Negativa de Penhora Reforço Policial'], ['NO', 'Negativa Outros'], ['NEL', 'Negativo Eletrônico'],
  ['REC', 'Mandado Recolhido'], ['DEV', 'Mandado Devolvido']];
const POSITIVOS = ['PI', 'PP', 'PO', 'PEL'];
function sugerirCodigo(t, res) {
  const eletr = /whats\s?app|aplicativo de mensagens|e-?mail|videochamada|meio eletr[ôo]nico|telefone celular/i.test(t);
  if (/recolhid/i.test(t)) return 'REC';
  if (/devolv\w* (o presente mandado )?sem cumprimento/i.test(t)) return 'DEV';
  if (res === 'NEGATIVO') {
    if (eletr && !/dirigi-me|compareci|diligenciei no endere/i.test(t)) return 'NEL';
    if (/refor[çc]o policial/i.test(t)) return 'NPRP';
    if (/n[ãa]o (encontrei|localizei|foram (encontrados|localizados)) bens|inexist[êe]ncia de bens|bens penhor[áa]veis/i.test(t)) return 'NBR';
    if (/n[ãa]o (foi )?(localizad|encontrad)|mudou[- ]se|desconhecid|n[ãa]o (mais )?reside|endere[çc]o|paradeiro/i.test(t)) return 'NE';
    return 'NO';
  }
  if (/penhorei|procedi [àa] penhora|auto de penhora/i.test(t)) return 'PP';
  if (eletr && !/dirigi-me|compareci|pessoalmente/i.test(t) && /citei|intimei|notifiquei/i.test(t)) return 'PEL';
  if (/citei|intimei|notifiquei|exarou|ciente|contraf[ée]/i.test(t)) return 'PI';
  return res === 'INDEFINIDO' || res === 'SEM-TEXTO' ? 'PI' : 'PO';
}

// ---------- leitura e classificação ----------
async function textoPdf(url) {
  const r = await fetch(url, { credentials: 'include' });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const doc = await pdfjs.getDocument({ data: new Uint8Array(await r.arrayBuffer()) }).promise;
  let t = '';
  for (let p = 1; p <= Math.min(doc.numPages, 6); p++) {
    const c = await (await doc.getPage(p)).getTextContent();
    t += c.items.map((i) => i.str).join(' ') + '\n';
  }
  return t.replace(/\s+/g, ' ').trim();
}

const RX_NEG = /negativ|n[ãa]o (foi |restou )?(poss[íi]vel|localizad|encontrad)|deixei de (citar|intimar|cumprir|penhorar|proceder)|mudou[- ]se|desconhecid|n[ãa]o (mais )?reside|endere[çc]o (inexistente|insuficiente|incompleto)|n[ãa]o logrei|frustrad|paradeiro (ignorado|desconhecido)|inexist[êe]ncia de bens|n[ãa]o encontrei bens/i;
const RX_POS = /positiv|citei|intimei|notifiquei|cumpri o (presente )?mandado|procedi [àa] (cita|intima|penhora|avalia|notifica)|dei ci[êe]ncia|exarou|apos(ta|tou) (sua |a )?(nota de )?ciente|recebeu a contraf[ée]|aceitou a contraf[ée]|penhorei|arrestei|avaliei|afixei|bem e fielmente cumprido/i;

function classificar(t) {
  if (!t || t.length < 40) return { res: 'SEM-TEXTO', ato: '', trecho: '' };
  const neg = RX_NEG.test(t), pos = RX_POS.test(t);
  const res = /parcialmente/i.test(t) || (neg && pos) ? 'PARCIAL' : neg ? 'NEGATIVO' : pos ? 'POSITIVO' : 'INDEFINIDO';
  const ato = ((t.match(/mandado de ([a-zçãõéêíóú]+(?: e [a-zçãõéêíóú]+)?)/i) || [])[1] || '').toUpperCase();
  const i = t.search(/certifico/i);
  const trecho = (i >= 0 ? t.slice(i, i + 320) : t.slice(0, 320)) + '…';
  return { res, ato, trecho };
}

// ---------- tela ----------
function render() {
  $('corpo').innerHTML = linhas.map((l, i) => `<tr><td><b>${l.numero}</b><br>mov. ${l.seq} — ${l.data}</td>` +
    `<td>${l.ato || '—'}</td><td><span class="res ${l.res}">${l.res}</span></td>` +
    `<td class="trecho">${(l.erro || l.trecho || '').replace(/</g, '&lt;')}</td>` +
    `<td>${l.url ? `<button data-i="${i}">Abrir</button>` : ''}</td></tr>`).join('') ||
    '<tr><td colspan="5">Nenhum mandado com arquivo encontrado.</td></tr>';
  $('corpo').querySelectorAll('button').forEach((b) => b.onclick = () => chrome.tabs.create({ url: linhas[+b.dataset.i].url, active: true }));
}

async function analisarAba(tabId, limite) {
  const r = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: lerMandados, args: [limite] });
  const d = r.map((x) => x.result).find((x) => x && x.mandados.length);
  if (!d) return;
  for (const m of d.mandados) {
    const base = { numero: m.numero, seq: m.seq, data: m.data, url: m.urls[0] };
    try {
      let txt = '';
      for (const u of m.urls) { txt += ' ' + await textoPdf(u); if (/certifico/i.test(txt)) break; }
      linhas.push({ ...base, ...classificar(txt) });
    } catch (e) { linhas.push({ ...base, res: 'INDEFINIDO', erro: 'Não consegui ler o PDF: ' + e.message }); }
    render();
  }
}

$('estaAba').onclick = async () => {
  linhas = []; render(); st('Lendo os mandados destes autos…');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try { await analisarAba(tab.id, 10); st(`✓ ${linhas.length} mandado(s) analisado(s).`, '#2e7d32'); }
  catch (e) { st('✗ ' + e.message, '#b00020'); }
  render();
};
$('todasAbas').onclick = async () => {
  linhas = []; render();
  const abas = (await chrome.tabs.query({ currentWindow: true }))
    .filter((t) => /^https:\/\/projudi[^/]*\.tjpr\.jus\.br\//.test(t.url || '') && !/arquivo\.do/.test(t.url));
  for (let i = 0; i < abas.length; i++) {
    st(`Aba ${i + 1} de ${abas.length}…`);
    try { await analisarAba(abas[i].id, 1); } catch { /* aba sem autos */ }
  }
  st(`✓ ${linhas.length} mandado(s) em ${abas.length} aba(s).`, '#2e7d32');
  render();
};
$('copiar').onclick = async () => {
  const t = linhas.map((l) => `${l.numero} — mov. ${l.seq} (${l.data}) — ${l.ato || 'mandado'}: ${l.res}`).join('\n');
  await navigator.clipboard.writeText(t || 'Nenhum mandado analisado.');
  st('✓ Resumo copiado.', '#2e7d32');
};
async function modoTelaMandado() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let r;
  try { r = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: lerTelaMandado }); }
  catch { return false; }
  const m = r.map((x) => x.result).find(Boolean);
  if (!m) return false;
  st('Lendo a certidão do oficial…');
  let txt = '', erro = '';
  for (const u of m.retornados) { try { txt += ' ' + await textoPdf(u); } catch (e) { erro = e.message; } }
  const cls = classificar(txt);
  const datas = datasDaCertidao(txt);
  const doAto = datas.filter((d) => d.ato);
  const principal = (doAto[0] || datas[0]);
  let ato = cls.ato;
  if (!ato && m.mandado[0]) { try { ato = classificar(await textoPdf(m.mandado[0])).ato; } catch { /* sem texto */ } }
  const linhasCampo = [
    ['Processo', `${m.numero} — cumprimento ${m.seq}`], ['Natureza', m.natureza || ato], ['Parte', m.parte],
    ['Endereço', m.endereco], ['Status', m.status], ['Audiência', m.audiencia], ['Expedição', m.expedicao],
    ['Prazo do oficial', m.prazoOficial], ['Oficial', m.oficial], ['Data do retorno', m.retorno],
    ['Resultado', `<span class="res ${cls.res}">${cls.res}</span>${erro ? ' — ' + erro : ''}`],
    ['Data da diligência', principal ? `<b>${principal.data}</b>${principal.hora ? ' às ' + principal.hora : ''}` : '<span class="res INDEFINIDO">não localizada no texto</span>'],
    ['Datas na certidão', datas.length ? datas.map((d) => `${d.ato ? '<b>' : ''}${d.data}${d.hora ? ' ' + d.hora : ''}${d.ato ? '</b>' : ''} — <span class="trecho">${d.ctx.slice(0, 200).replace(/</g, '&lt;')}</span>`).join('<br>') : '—'],
    ['Trecho', `<span class="trecho">${(cls.trecho || '').replace(/</g, '&lt;')}</span>`]
  ];
  document.querySelector('table thead').innerHTML = '';
  $('corpo').innerHTML = linhasCampo.map(([k, v]) => `<tr><td style="width:150px;font-weight:bold;color:#1565c0">${k}</td><td>${v || '—'}</td></tr>`).join('') +
    (m.retornados[0] ? `<tr><td></td><td><button id="abrirCert">Abrir certidão</button></td></tr>` : '') +
    `<tr><td style="font-weight:bold;color:#2e7d32">Preencher o retorno</td><td>
       Data <input id="fData" value="${principal ? principal.data : ''}" style="width:90px">
       Hora <input id="fHora" value="${principal && principal.hora ? principal.hora.replace('h', ':') : ''}" style="width:50px">
       &nbsp; Recebido pela parte <select id="fSn"><option>SIM</option><option>NÃO</option></select>
       <br>Iniciar prazo a partir da <select id="fPrazo"><option value="leitura">Data de leitura da parte</option><option value="juntada">Data da juntada nos autos</option></select>
       <br>Resultado <select id="fRes">${OPCOES.map(([c, n]) => `<option value="${c}">${n} (${c})</option>`).join('')}</select>
       <br><button id="analisar" style="margin-top:6px;background:#2e7d32">Preencher Analisar Retorno</button>
       <span class="trecho"> — preenche os campos e para antes de salvar</span></td></tr>`;
  const bt = document.getElementById('abrirCert');
  if (bt) bt.onclick = () => chrome.tabs.create({ url: m.retornados[0], active: true });
  const codIni = sugerirCodigo(txt, cls.res);
  $('fRes').value = codIni; $('fSn').value = POSITIVOS.includes(codIni) ? 'SIM' : 'NÃO';
  $('fRes').onchange = () => { $('fSn').value = POSITIVOS.includes($('fRes').value) ? 'SIM' : 'NÃO'; };
  $('analisar').onclick = async () => {
    const data = $('fData').value.trim();
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(data)) return st('Informe a data no formato dd/mm/aaaa.', '#b00020');
    await chrome.storage.local.set({ retornoMandado: { ativo: true, tabId: tab.id, clicadoEm: Date.now(), numero: m.numero,
      data, hora: /^\d{1,2}:\d{2}$/.test($('fHora').value.trim()) ? $('fHora').value.trim().padStart(5, '0') : '',
      prazoBase: $('fPrazo').value, cumprido: $('fSn').value === 'SIM' ? 'SIM' : 'NAO', resultado: $('fRes').value } });
    // Se o formulário (Recebido pela parte? / Resultado) já está na tela, só preenche — NÃO clica em nada
    // (o botão desse formulário grava). Se não está, clica em "Analisar Retorno" para abri-lo.
    const r = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: () => {
      const vis = (e) => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
      const temForm = /Recebido pela parte/i.test(document.body.innerText || '') &&
        [...document.querySelectorAll('input[type=radio]')].some(vis);
      if (temForm) return 'form';
      const b = [...document.querySelectorAll('input[type=button], input[type=submit], button, a')]
        .find((x) => vis(x) && /^\s*analisar\s+retorno\s*$/i.test(x.value || x.textContent));
      if (!b) return ''; b.click(); return 'clicou'; } });
    const res = r.map((x) => x.result);
    if (res.includes('form')) st('✓ Preenchendo os campos… confira e salve.', '#2e7d32');
    else if (res.includes('clicou')) st('✓ Abrindo "Analisar Retorno"… os campos serão preenchidos.', '#2e7d32');
    else { await chrome.storage.local.remove('retornoMandado'); return st('Nem o formulário nem o botão "Analisar Retorno" estão nesta tela.', '#b00020'); }
    setTimeout(() => window.close(), 1200);
  };
  linhas = [{ numero: m.numero, seq: m.seq, data: principal ? principal.data : '', ato: m.natureza || ato, res: cls.res }];
  $('copiar').onclick = async () => {
    const t = [`Processo: ${m.numero} (cumprimento ${m.seq})`, `Mandado: ${m.natureza || ato}`, `Parte: ${m.parte}`,
      `Oficial: ${m.oficial}`, `Resultado: ${cls.res}`,
      `Data da diligência: ${principal ? principal.data + (principal.hora ? ' às ' + principal.hora : '') : '[não localizada]'}`,
      `Audiência: ${m.audiencia || '—'}`].join('\n');
    await navigator.clipboard.writeText(t); st('✓ Resumo copiado.', '#2e7d32');
  };
  st(txt.length < 40 ? 'Certidão sem texto legível (digitalizada?) — abra o PDF.' : '✓ Certidão lida.', txt.length < 40 ? '#b00020' : '#2e7d32');
  return true;
}

(async () => { if (!(await modoTelaMandado())) $('estaAba').click(); })();
