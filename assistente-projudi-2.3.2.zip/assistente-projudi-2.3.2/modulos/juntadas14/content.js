// Projudi - Análise de Juntadas (extensão Chrome) v1.4.0
// Botões: abrir processos, abrir juntadas em guias novas e dispensar juntadas marcadas.

(function () {
  'use strict';

  // Número CNJ: 0002777-50.2024.8.16.0048
  const CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;
  const ID_ABRIR = 'tm-abrir-processos';
  const ID_DISPENSAR = 'tm-dispensar-juntadas';
  const ID_JUNTADAS = 'tm-abrir-juntadas';
  const NOSSOS = [ID_ABRIR, ID_DISPENSAR, ID_JUNTADAS, 'tm-abrir-juntada-pendente'];

  /* ---------------- utilidades ---------------- */

  function urlDoLink(a) {
    const href = a.getAttribute('href') || '';
    if (href && href !== '#' && !/^javascript:/i.test(href)) return a.href;
    // Link via javascript/onclick: tenta achar um endereço .do dentro do código
    const codigo = (a.getAttribute('onclick') || '') + ' ' + href;
    const m = codigo.match(/['"]([^'"]*\.do[^'"]*)['"]/);
    return m ? new URL(m[1], location.href).href : null;
  }

  function linksDeProcesso() {
    return [...document.querySelectorAll('a')].filter(a => CNJ.test(a.textContent));
  }

  // Uma entrada por LINHA da tabela (cada linha é uma juntada)
  function linhasDaTabela() {
    const linhas = [];
    const vistas = new Set();
    for (const a of linksDeProcesso()) {
      const tr = a.closest('tr');
      if (!tr || vistas.has(tr)) continue;
      vistas.add(tr);
      const cb = tr.querySelector('input[type="checkbox"]');
      linhas.push({ tr, link: a, numero: a.textContent.match(CNJ)[0], cb, marcado: !!(cb && cb.checked) });
    }
    return linhas;
  }

  function estilizar(b, cor, bottom) {
    Object.assign(b.style, {
      position: 'fixed', right: '20px', bottom: bottom + 'px', zIndex: 99999,
      padding: '10px 16px', background: cor, color: '#fff',
      border: 'none', borderRadius: '6px', fontWeight: 'bold',
      fontSize: '13px', cursor: 'pointer', boxShadow: '0 2px 6px rgba(0,0,0,.3)',
      minWidth: '250px'
    });
  }

  /* ---------------- 1. abrir processos ---------------- */

  function coletarParaAbrir() {
    const todos = [];
    const vistos = new Set();
    let semUrl = 0;
    for (const l of linhasDaTabela()) {
      if (vistos.has(l.numero)) continue; // mesmo processo com duas juntadas abre uma vez só
      const url = urlDoLink(l.link);
      if (!url) { semUrl++; continue; }
      vistos.add(l.numero);
      todos.push({ numero: l.numero, url, marcado: l.marcado });
    }
    const marcados = todos.filter(i => i.marcado);
    return { lista: marcados.length ? marcados : todos, soMarcados: marcados.length > 0, semUrl };
  }

  function abrir() {
    const { lista, soMarcados, semUrl } = coletarParaAbrir();
    if (!lista.length) {
      alert(semUrl
        ? 'Encontrei os números dos processos, mas não consegui ler o endereço dos links (' + semUrl + ').\nEnvie o HTML de um link para ajustar o script.'
        : 'Nenhum número de processo encontrado nesta página.');
      return;
    }
    const msg = (soMarcados ? 'Abrir os ' + lista.length + ' processos MARCADOS' : 'Abrir TODOS os ' + lista.length + ' processos da página')
      + ' em guias novas?\n\n' + lista.map(i => i.numero).join('\n');
    if (!confirm(msg)) return;
    chrome.runtime.sendMessage({ tipo: 'JUNTADAS14_ABRIR', urls: lista.map(i => i.url) });
  }

  /* ---------------- 1b. abrir juntadas ---------------- */

  const PISTA_JUNTADA = /juntada|analis|documento|arquivo|visualiz|movimenta/i;

  function descricaoDe(el) {
    const img = el.querySelector ? el.querySelector('img') : null;
    return [el.getAttribute('title'), el.getAttribute('alt'), el.getAttribute('href'), el.getAttribute('onclick'),
      img && img.getAttribute('title'), img && img.getAttribute('alt'), img && img.getAttribute('src'), el.textContent]
      .filter(Boolean).join(' ');
  }

  // Na linha da juntada, procura o link que abre a própria juntada (não o do processo)
  function urlDaJuntada(l) {
    const urlProcesso = urlDoLink(l.link);
    const candidatos = [...l.tr.querySelectorAll('a, [onclick]')]
      .filter(el => el !== l.link && !CNJ.test(el.textContent || ''))
      .map(el => ({ el, url: urlDoLink(el), desc: descricaoDe(el) }))
      .filter(c => c.url && c.url !== urlProcesso);
    const melhor = candidatos.find(c => /analis/i.test(c.desc))
      || candidatos.find(c => /juntada/i.test(c.desc))
      || candidatos.find(c => PISTA_JUNTADA.test(c.desc));
    return melhor ? melhor.url : null;
  }

  function abrirJuntadas() {
    const linhas = linhasDaTabela();
    const marcadas = linhas.filter(l => l.marcado);
    const alvo = marcadas.length ? marcadas : linhas;
    const lista = [];
    const vistas = new Set();
    for (const l of alvo) {
      const url = urlDaJuntada(l);
      if (url && !vistas.has(url)) { vistas.add(url); lista.push({ numero: l.numero, url }); }
    }

    if (!lista.length) {
      const copiar = confirm('Não consegui identificar o link que abre a juntada nas linhas da tabela.\n\n'
        + 'Clique em OK para copiar o HTML da primeira linha. Depois cole na conversa com o Claude para ajustar a extensão.\n'
        + '(Antes de colar, troque os nomes das partes por XXX.)');
      if (copiar && linhas[0]) navigator.clipboard.writeText(linhas[0].tr.outerHTML)
        .then(() => alert('HTML copiado. Cole na conversa com Ctrl+V.'))
        .catch(() => alert('Não foi possível copiar automaticamente.'));
      return;
    }

    const msg = (marcadas.length ? 'Abrir as ' + lista.length + ' juntadas MARCADAS' : 'Abrir TODAS as ' + lista.length + ' juntadas da página')
      + ' em guias novas?\n\n' + lista.map(i => i.numero).join('\n')
      + (lista.length < alvo.length ? '\n\nAtenção: ' + (alvo.length - lista.length) + ' linha(s) sem link de juntada identificado.' : '');
    if (!confirm(msg)) return;
    chrome.runtime.sendMessage({ tipo: 'JUNTADAS14_ABRIR', urls: lista.map(i => i.url) });
  }

  /* ---------------- 2. dispensar juntadas ---------------- */

  const DISPENSA = /dispens/i;

  function textoDe(el) {
    return ((el.value || '') + ' ' + (el.textContent || '') + ' ' + (el.title || '') + ' ' + (el.getAttribute('alt') || '')).trim();
  }

  // Procura o comando de dispensa do próprio Projudi
  function acharComandoDispensa() {
    const candidatos = [...document.querySelectorAll('input[type="button"], input[type="submit"], input[type="image"], button, a')]
      .filter(el => !NOSSOS.includes(el.id) && DISPENSA.test(textoDe(el)));
    if (candidatos.length) return { tipo: 'botao', el: candidatos[0] };

    for (const sel of document.querySelectorAll('select')) {
      const opt = [...sel.options].find(o => DISPENSA.test(o.textContent));
      if (opt) return { tipo: 'select', el: sel, opt };
    }
    return null;
  }

  function dispensar() {
    const marcadas = linhasDaTabela().filter(l => l.marcado);
    if (!marcadas.length) {
      alert('Marque as caixinhas das juntadas que deseja dispensar.\n\nPor segurança, a dispensa nunca é aplicada a todas as juntadas sem seleção.');
      return;
    }

    const cmd = acharComandoDispensa();
    if (!cmd) {
      alert('Não encontrei nesta página o comando de dispensa do Projudi.\nEnvie um print (ou o HTML) da parte de baixo da tabela, onde ficam os botões de ação, para ajustar o script.');
      return;
    }

    const msg = 'DISPENSAR ' + marcadas.length + ' juntada(s) marcada(s)?\n\n'
      + marcadas.map(l => l.numero).join('\n')
      + '\n\nConfira a lista antes de confirmar.';
    if (!confirm(msg)) return;

    if (cmd.tipo === 'botao') {
      cmd.el.click(); // o Projudi pode pedir uma confirmação própria em seguida
      return;
    }

    // Comando em lista de ações: seleciona "Dispensar" e procura o botão de executar
    cmd.el.value = cmd.opt.value;
    cmd.el.dispatchEvent(new Event('change', { bubbles: true }));
    const escopo = cmd.el.form || document;
    const exec = [...escopo.querySelectorAll('input[type="button"], input[type="submit"], button')]
      .find(el => !NOSSOS.includes(el.id) && /executar|confirmar|aplicar|ok|salvar|enviar/i.test(textoDe(el)));
    if (exec) exec.click();
    else alert('Selecionei a ação "' + cmd.opt.textContent.trim() + '". Clique agora no botão do Projudi para executá-la.');
  }

  /* ---------------- botões ---------------- */

  // Só a tela da lista (Análise de Juntadas) recebe os três botões
  function ehTelaDeJuntadas() {
    return /analisarJuntada/i.test(location.href);
  }

  /* ---------------- 3. dentro do processo: abrir a juntada pendente ---------------- */

  const ID_PENDENTE = 'tm-abrir-juntada-pendente';

  // No processo, procura a linha "Análise de Juntadas: Há N pendência(s)..." e o link dela
  function linkDaPendencia() {
    const rotulos = [...document.querySelectorAll('td, th, label, span, b, strong, div')]
      .filter(el => el.children.length < 3 && /^\s*An[aá]lise de Juntadas:?\s*$/i.test(el.textContent));
    for (const r of rotulos) {
      const linha = r.closest('tr') || r.parentElement;
      if (!linha) continue;
      const link = [...linha.querySelectorAll('a, [onclick]')].find(a => /pend[eê]ncia|juntada/i.test(a.textContent + ' ' + (a.title || '')) || a.querySelector('img'));
      if (link) return link;
    }
    // Alternativa: qualquer link com o texto "pendência(s) de análise de juntada"
    return [...document.querySelectorAll('a')].find(a => /pend[eê]ncia.*an[aá]lise de juntada/i.test(a.textContent)) || null;
  }

  function criarBotaoProcesso() {
    if (document.getElementById(ID_PENDENTE)) return true;
    if (!document.body || ehTelaDeJuntadas()) return false;
    const link = linkDaPendencia();
    if (!link) return false;
    const b = document.createElement('button');
    b.id = ID_PENDENTE;
    b.type = 'button';
    b.textContent = 'Abrir análise da juntada pendente';
    b.title = 'Abre a análise da juntada pendente deste processo.';
    estilizar(b, '#2f5d8a', 66);
    b.addEventListener('click', () => link.click());
    document.body.appendChild(b);
    return true;
  }

  function criarBotoes() {
    if (document.getElementById(ID_ABRIR)) return true;
    if (!document.body || !ehTelaDeJuntadas()) return false;
    if (!linhasDaTabela().length) return false;

    const bAbrir = document.createElement('button');
    bAbrir.id = ID_ABRIR;
    bAbrir.type = 'button';
    bAbrir.textContent = 'Abrir processos em guias novas';
    bAbrir.title = 'Abre todos os processos da página. Se houver linhas marcadas, abre só as marcadas.';
    estilizar(bAbrir, '#5a6e3a', 20);
    bAbrir.addEventListener('click', abrir);

    const bDisp = document.createElement('button');
    bDisp.id = ID_DISPENSAR;
    bDisp.type = 'button';
    bDisp.textContent = 'Dispensar juntadas marcadas';
    bDisp.title = 'Dispensa somente as juntadas com a caixinha marcada, após confirmação.';
    estilizar(bDisp, '#a23b2a', 112);
    bDisp.addEventListener('click', dispensar);

    const bJunt = document.createElement('button');
    bJunt.id = ID_JUNTADAS;
    bJunt.type = 'button';
    bJunt.textContent = 'Abrir juntadas em guias novas';
    bJunt.title = 'Abre cada juntada da lista. Se houver linhas marcadas, abre só as marcadas.';
    estilizar(bJunt, '#2f5d8a', 66);
    bJunt.addEventListener('click', abrirJuntadas);

    document.body.appendChild(bDisp);
    document.body.appendChild(bJunt);
    document.body.appendChild(bAbrir);
    return true;
  }

  // A tabela pode carregar depois da página: tenta por até 15 segundos
  let tentativas = 0;
  const timer = setInterval(() => {
    const ok = ehTelaDeJuntadas() ? criarBotoes() : criarBotaoProcesso();
    if (ok || ++tentativas > 30) clearInterval(timer);
  }, 500);
})();
