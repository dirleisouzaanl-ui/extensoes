// Projudi - Abrir processos da tela Conclusões (extensão; origem: script Tampermonkey v1.1)
(function () {
  'use strict';
  if (window.top !== window) return;

  const CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;
  const ID_BOTAO = 'ext-abrir-conclusoes';

  // Acionamento pelo menu da EXTENSAO-PROJUDI (tecla A)
  chrome.runtime.onMessage.addListener((m, _s, resp) => {
    if (!m || m.tipo !== 'CLICAR_ABRIR_CONCLUSOES') return;
    criarBotao();
    const b = document.getElementById(ID_BOTAO);
    if (!b) { resp({ ok: false }); return; }
    b.click();
    resp({ ok: true });
  });

  // Uma entrada por linha da lista: em Conclusões o link é o "Analisar"; em Análise de Juntadas
  // é o link (lápis/número) da célula do processo. Se houver linhas marcadas, só elas.
  function coletar() {
    const linhas = [...document.querySelectorAll('tr')].filter((tr) =>
      CNJ.test(tr.textContent) && !tr.querySelector('tr') && tr.querySelector('a[href]'));
    const marcadas = linhas.filter((tr) => tr.querySelector('input[type=checkbox]:checked'));
    const alvo = marcadas.length ? marcadas : linhas;
    const ok = (a) => a && /^https?:/i.test(a.href) && !/\.pdf|arquivo\.do/i.test(a.href);
    const lista = [];
    const vistos = new Set();
    let semNumero = 0, totalLinks = 0;
    for (const tr of alvo) {
      const numero = tr.textContent.match(CNJ)[0];
      const links = [...tr.querySelectorAll('a[href]')];
      const a = links.find((x) => /^\s*Analisar\s*$/i.test(x.textContent) && ok(x)) ||
        links.find((x) => x.textContent.includes(numero) && ok(x)) ||
        [...tr.cells].filter((c) => c.textContent.includes(numero))
          .map((c) => [...c.querySelectorAll('a[href]')].find(ok)).find(Boolean);
      if (!a) { semNumero++; continue; }
      totalLinks++;
      if (vistos.has(a.href)) continue; // mesmo link em duas linhas abre uma vez só
      vistos.add(a.href);
      lista.push({ numero, url: a.href });
    }
    return { lista, semNumero, totalLinks, marcadas: marcadas.length };
  }

  const ehParalisados = () => /paralisad/i.test(location.href) ||
    /Busca por Processos Paralisados/i.test(document.body ? document.body.innerText.slice(0, 3000) : '');

  async function abrir(ev) {
    const b = ev.currentTarget;
    let { lista, semNumero } = coletar();
    if (!lista.length) {
      alert(semNumero
        ? 'Encontrei processos na lista, mas nenhum link para abri-los.'
        : 'Nenhum processo encontrado nesta página.');
      return;
    }
    const { marcadas } = coletar();
    // Paralisados: a lista pode ter centenas de processos — pergunta quantos abrir, a partir do primeiro.
    if (ehParalisados() && !marcadas && lista.length > 1) {
      const resp = prompt('A lista de Processos Paralisados desta página tem ' + lista.length + ' processos.\n' +
        'Quantos abrir, a partir do primeiro da lista?', String(Math.min(lista.length, 20)));
      if (resp === null) return;
      const qtd = Math.max(0, Math.min(lista.length, parseInt(resp, 10) || 0));
      if (!qtd) return;
      lista = lista.slice(0, qtd);
    }
    if (!confirm('Abrir ' + (marcadas ? 'os ' + lista.length + ' processos MARCADOS' : 'os ' + lista.length + ' processos desta página') + ' em abas novas?\n\n' +
      lista.map((i) => i.numero).join('\n'))) return;
    b.disabled = true;
    b.textContent = 'Abrindo ' + lista.length + '…';
    try {
      const r = await chrome.runtime.sendMessage({ tipo: 'ABRIR_CONCLUSOES', urls: lista.map((i) => i.url) });
      b.textContent = r && r.ok ? '✓ ' + r.abertas + ' abertos' : '✗ ' + ((r && r.erro) || 'erro');
    } catch (e) {
      b.textContent = '✗ recarregue a página (F5)';
    }
    setTimeout(() => { b.disabled = false; b.textContent = 'Abrir processos em abas novas'; }, 4000);
  }

  function ehTelaDeConclusoes() {
    return /conclusao|analisarJuntada|paralisad/i.test(location.href) ||
      /Conclus[õo]es|An[áa]lise de Juntadas|Processos Paralisados/i.test(document.body ? document.body.innerText.slice(0, 3000) : '');
  }

  function criarBotao() {
    if (document.getElementById(ID_BOTAO)) return true;
    if (!document.body || !ehTelaDeConclusoes()) return false;
    if (!coletar().totalLinks) return false;
    const b = document.createElement('button');
    b.id = ID_BOTAO;
    b.type = 'button';
    b.textContent = 'Abrir processos em abas novas';
    b.title = 'Abre em abas novas cada processo desta lista (Conclusões, Análise de Juntadas ou Processos Paralisados). Se houver linhas marcadas, só elas.';
    Object.assign(b.style, {
      position: 'fixed', left: '20px', bottom: '20px', zIndex: '2147483647',
      padding: '10px 16px', background: '#5a6e3a', color: '#fff',
      border: 'none', borderRadius: '6px', fontWeight: 'bold',
      fontSize: '13px', cursor: 'pointer', boxShadow: '0 2px 6px rgba(0,0,0,.3)'
    });
    b.addEventListener('click', abrir);
    document.body.appendChild(b);
    return true;
  }

  // A tabela pode carregar depois da página: tenta já e observa mudanças por até 30 segundos
  if (criarBotao()) return;
  const obs = new MutationObserver(() => { if (criarBotao()) obs.disconnect(); });
  obs.observe(document.documentElement, { childList: true, subtree: true });
  setTimeout(() => obs.disconnect(), 30000);
})();
