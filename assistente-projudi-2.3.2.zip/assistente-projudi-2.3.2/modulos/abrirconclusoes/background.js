// Módulo Abrir processos das Conclusões — isolado
(() => {
// Abre as abas pedidas pelo botão da página, em segundo plano, à direita da aba de Conclusões.
const ATRASO_MS = 700; // intervalo entre uma aba e outra (não sobrecarregar o PROJUDI)
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  if (msg.tipo !== 'ABRIR_CONCLUSOES' || !sender.tab) return;
  (async () => {
    const urls = (msg.urls || []).filter((u) => /^https:\/\/[^/]*tjpr\.jus\.br\//.test(u));
    let pos = sender.tab.index + 1;
    for (let i = 0; i < urls.length; i++) {
      await chrome.tabs.create({ url: urls[i], active: false, index: pos++, windowId: sender.tab.windowId, openerTabId: sender.tab.id });
      if (i < urls.length - 1) await esperar(ATRASO_MS);
    }
    responder({ ok: true, abertas: urls.length });
  })().catch((e) => responder({ ok: false, erro: e.message }));
  return true;
});

})();
