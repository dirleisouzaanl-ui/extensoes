// RENAJUD (SERPRO) — preenchimento da inserção de restrição
// Mapeado em 10/10/2026 (RENAJUD 2.5.4), tela restricoes-insercao.jsf:
//  form-incluir-restricao:campo-placa (maxlength 7), :campo-chassi (21), :campo-cpf-cnpj (18),
//  :select-sem-restricao_input (checkbox), :botao-pesquisar
// As telas seguintes (lista de veículos e formulário da restrição) são preenchidas por rótulo,
// pois não puderam ser mapeadas sem um veículo retornado. A extensão NUNCA clica em
// Confirmar/Salvar/Incluir: a conferência e a confirmação são sempre da usuária.
(function () {
  if (window.__prRenajud || window.top !== window) return;
  window.__prRenajud = true;

  const $ = (id) => document.getElementById(id);
  const F = 'form-incluir-restricao:';
  const visivel = (el) => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));

  // ---------- rótulo de cada campo ----------
  function rotuloDe(el) {
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l && l.textContent.trim()) return l.textContent;
    }
    const pl = el.closest('label');
    if (pl) return pl.textContent;
    // PrimeFaces: label do componente pai (id sem sufixo _input / _focus)
    const base = (el.id || '').replace(/_(input|focus)$/, '');
    if (base !== el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(base)}"]`);
      if (l) return l.textContent;
    }
    // célula anterior em layout de tabela / texto imediatamente anterior
    const td = el.closest('td');
    if (td) {
      if (td.previousElementSibling && td.previousElementSibling.textContent.trim()) return td.previousElementSibling.textContent;
      const tr = td.parentElement, idx = [...tr.children].indexOf(td);
      const trAnt = tr.previousElementSibling;
      if (trAnt && trAnt.children[idx]) return trAnt.children[idx].textContent;
    }
    let p = el.previousElementSibling;
    while (p && !p.textContent.trim()) p = p.previousElementSibling;
    if (p) return p.textContent;
    return el.title || el.placeholder || el.name || el.id || '';
  }

  function campos() {
    return [...document.querySelectorAll('input, select, textarea')]
      .filter((e) => e.type !== 'hidden' || (e.tagName === 'SELECT'))
      .filter((e) => e.type !== 'submit' && e.type !== 'button')
      .filter((e) => visivel(e) || (e.tagName === 'SELECT' && visivel(e.closest('.ui-selectonemenu'))) || (e.type === 'radio' && visivel(e.closest('.ui-radiobutton, td, label'))))
      .map((e) => ({ el: e, rot: PR.norm(rotuloDe(e)) }));
  }

  // ---------- etapa 1: pesquisa ----------
  function preencherPesquisa(d) {
    const ex = d.executados[d.executadoSel || 0];
    // Com placa informada no popup, pesquisa só pela placa; senão, pelo CPF/CNPJ do executado
    const placa = (d.placaManual || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    PR.setValue($(F + 'campo-placa'), placa);
    const okPlaca = !!placa;
    const okDoc = !placa && ex && PR.setValue($(F + 'campo-cpf-cnpj'), PR.digits(ex.documento));
    if (placa) PR.setValue($(F + 'campo-cpf-cnpj'), '');
    const btn = $(F + 'botao-pesquisar');
    if (btn) { btn.classList.add('pr-destaque'); btn.focus(); }
    PR.toast(`Pesquisa preenchida${okDoc ? ' | CPF/CNPJ ' + ex.documento : ''}${okPlaca ? ' | placa ' + placa : ''}. Confira e clique em Pesquisar.`);
  }

  // ---------- etapa 2: formulário da restrição ----------
  function marcarTipo(lista, tipo) {
    const alvo = PR.norm(tipo).slice(0, 6); // "transf", "licenc", "circul", "penhor"
    // select
    const sel = lista.find((c) => c.el.tagName === 'SELECT' && [...c.el.options].some((o) => PR.norm(o.text).includes(alvo)) && /restri|tipo/.test(c.rot + ' tipo'));
    if (sel) { const o = [...sel.el.options].find((o) => PR.norm(o.text).includes(alvo)); return PR.setValue(sel.el, o.text); }
    // radio / checkbox com o texto do tipo no rótulo
    const rd = lista.find((c) => (c.el.type === 'radio' || c.el.type === 'checkbox') && c.rot.includes(alvo));
    if (rd) {
      const box = rd.el.closest('.ui-radiobutton, .ui-chkbox');
      if (box) box.querySelector('.ui-radiobutton-box, .ui-chkbox-box')?.click(); else rd.el.click();
      return true;
    }
    // PrimeFaces: clicar no label
    const lbl = [...document.querySelectorAll('label')].find((l) => visivel(l) && PR.norm(l.textContent).startsWith(alvo));
    if (lbl) { lbl.click(); return true; }
    return false;
  }

  function preencherRestricao(d) {
    const lista = campos().filter((c) => !c.el.id.startsWith(F + 'campo-') && !c.el.id.startsWith('form-busca-avancada'));
    const feito = [], falta = [];
    const achar = (re, tipos) => lista.find((c) => re.test(c.rot) && (!tipos || tipos.includes(c.el.tagName)) && c.el.type !== 'radio' && c.el.type !== 'checkbox');
    const tenta = (nome, re, valor, tipos) => {
      if (!valor) return;
      const c = achar(re, tipos);
      if (c && (c.el.value === '' || c.el.tagName === 'SELECT') && PR.setValue(c.el, valor)) feito.push(nome); else if (!c) falta.push(nome);
      else feito.push(nome + ' (já preenchido)');
    };

    if (marcarTipo(lista, d.tipoRestricao)) feito.push('Tipo: ' + d.tipoRestricao); else falta.push('Tipo de restrição');

    const proc = achar(/processo/, ['INPUT']);
    if (proc) {
      const v = proc.el.maxLength && proc.el.maxLength < 25 && proc.el.maxLength >= 20 ? d.processoDigitos : d.processo;
      PR.setValue(proc.el, v); feito.push('Nº do processo');
    } else falta.push('Nº do processo');

    tenta('Valor', /valor/, d.valorCausa, ['INPUT']);
    tenta('Magistrado', /magistrad|juiz(?!ado)/, d.juiz, ['INPUT', 'SELECT']);
    tenta('Órgão/Juízo', /orgao|juizo|vara|unidade/, d.juizo, ['SELECT', 'INPUT']);
    tenta('Comarca', /comarca|municipio/, d.comarca, ['SELECT', 'INPUT']);

    PR.toast(`Preenchido: ${feito.join(', ') || 'nada'}${falta.length ? ' | Não localizado: ' + falta.join(', ') : ''}. CONFIRA antes de confirmar.`, falta.length ? 'aviso' : 'ok');
  }

  // ---------- diagnóstico: copiar mapa de campos ----------
  async function mapear() {
    const mapa = campos().map((c) => ({
      tag: c.el.tagName, type: c.el.type, id: c.el.id, name: c.el.name, rotulo: rotuloDe(c.el).replace(/\s+/g, ' ').trim().slice(0, 80),
      maxlength: c.el.maxLength > 0 ? c.el.maxLength : undefined,
      opcoes: c.el.tagName === 'SELECT' ? [...c.el.options].map((o) => o.text.trim()).slice(0, 30) : undefined
    }));
    const botoes = [...document.querySelectorAll('button, input[type=submit], a.ui-button')].filter(visivel).map((b) => (b.id || '') + ' = ' + (b.textContent || b.value).trim());
    const txt = JSON.stringify({ url: location.pathname, campos: mapa, botoes }, null, 2);
    try { await navigator.clipboard.writeText(txt); PR.toast('Mapa dos campos copiado. Cole no chat para ajuste fino.'); }
    catch (e) { console.log(txt); PR.toast('Mapa no console (F12).', 'aviso'); }
  }

  // ---------- painel ----------
  async function montarPainel() {
    if ($('pr-painel')) return;
    const d = await PR.load();
    const esc = (s) => String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const p = document.createElement('div');
    p.id = 'pr-painel';
    p.className = 'pr-painel';
    const ex = d && d.executados[d.executadoSel || 0];
    p.innerHTML = `
      <div class="pr-tit">PROJUDI → RENAJUD <span class="pr-x" title="Minimizar">–</span></div>
      <div class="pr-corpo">
        ${d ? `
          <div><b>Proc.:</b> ${esc(d.processo)}</div>
          <div><b>Executado:</b> ${esc(ex ? ex.nome : '—')}</div>
          <div><b>CPF/CNPJ:</b> ${esc(ex ? ex.documento : '—')}</div>
          <div><b>Placa:</b> ${esc(d.placaManual || (d.placas[0] || '—'))}</div>
          <div><b>Valor:</b> ${esc(d.valorCausa || '—')} &nbsp; <b>Tipo:</b> ${esc(d.tipoRestricao)}</div>
          <div><b>Juiz:</b> ${esc(d.juiz || '—')}</div>
          <div class="pr-bts">
            <button type="button" id="pr-b1">1. Preencher pesquisa</button>
            <button type="button" id="pr-b2">2. Preencher restrição</button>
            <button type="button" id="pr-b3" class="pr-sec">Mapear campos</button>
          </div>
          <div class="pr-nota">A extensão só pesquisa; nunca insere restrição.</div>`
        : '<div>Nenhum processo capturado. Abra o processo no PROJUDI e clique em <b>Capturar p/ RENAJUD</b>.</div>'}
      </div>`;
    document.body.appendChild(p);
    p.querySelector('.pr-x').onclick = () => p.classList.toggle('pr-min');
    if (d) {
      $('pr-b1').onclick = async () => preencherPesquisa(await PR.load());
      $('pr-b2').onclick = async () => preencherRestricao(await PR.load());
      $('pr-b3').onclick = mapear;
    }
  }

  // ---------- pesquisa sem resultado: imprimir comprovante ----------
  // Mensagem mapeada: #messages li > span.ui-messages-error-detail "A pesquisa não retornou resultados."
  const TITULO_SEM_VEICULO = 'RENAJUD - inexistência de veículos licenciados';
  async function imprimirSemResultado() {
    const d = await PR.load();
    const ex = d && d.executados[d.executadoSel || 0];
    const docPesq = (($(F + 'campo-cpf-cnpj') || {}).value || '').trim();
    const placa = (($(F + 'campo-placa') || {}).value || '').trim();

    // cabeçalho só para impressão, com a identificação do processo
    let cab = $('pr-cab-impressao');
    if (!cab) { cab = document.createElement('div'); cab.id = 'pr-cab-impressao'; document.body.prepend(cab); }
    const mesmoDoc = ex && docPesq && PR.digits(docPesq) === PR.digits(ex.documento);
    cab.textContent = [
      d && d.processo ? 'Processo: ' + d.processo : '',
      docPesq ? 'CPF/CNPJ pesquisado: ' + (mesmoDoc ? ex.nome + ' — ' + ex.documento : docPesq) : '',
      placa ? 'Placa pesquisada: ' + placa : '',
      'Resultado: a pesquisa não retornou veículos',
      'Data/hora: ' + new Date().toLocaleString('pt-BR')
    ].filter(Boolean).join('  |  ');

    const tituloOriginal = document.title;
    document.title = TITULO_SEM_VEICULO; // nome sugerido do PDF em "Salvar como PDF"
    const restaurar = () => { document.title = tituloOriginal; window.removeEventListener('afterprint', restaurar); };
    window.addEventListener('afterprint', restaurar);
    setTimeout(() => window.print(), 300);
  }

  // cada mensagem é tratada uma única vez (o ajax do JSF recria o nó a cada pesquisa)
  function mensagemNova() {
    return [...document.querySelectorAll('.ui-messages-error-detail, .ui-messages-warn-detail, .ui-messages-info-detail')]
      .find((s) => !s.dataset.prVisto && visivel(s) && /nao retornou resultados/.test(PR.norm(s.textContent)));
  }

  const vigiarResultado = () => {
    if (!/restricoes-insercao/.test(location.pathname)) return;
    const m = mensagemNova();
    if (!m) return;
    m.dataset.prVisto = '1';
    imprimirSemResultado();
  };
  new MutationObserver(vigiarResultado).observe(document.body, { childList: true, subtree: true });
  vigiarResultado(); // caso a página tenha sido recarregada já com a mensagem

  // ---------- pesquisa automática (pedido vindo do PROJUDI) ----------
  let executando = false;
  async function pesquisaAutomatica() {
    if (executando) return;
    const o = await new Promise((res) => chrome.storage.local.get(PR.KEY_AUTO, (x) => res(x[PR.KEY_AUTO])));
    if (!o || Date.now() - o.ts > PR.AUTO_VALIDADE) return;
    if (!/restricoes-insercao/.test(location.pathname)) { location.href = '/renajud/restrito/restricoes-insercao.jsf'; return; }
    executando = true;
    try {
      const campo = await PR.waitFor(() => $(F + 'campo-cpf-cnpj'), 10000);
      const btn = $(F + 'botao-pesquisar');
      if (!campo || !btn) { PR.toast('Tela de inserção do RENAJUD não localizada (sessão expirada?).', 'erro'); return; }
      await new Promise((res) => chrome.storage.local.remove(PR.KEY_AUTO, res)); // consome o pedido uma única vez
      PR.setValue($(F + 'campo-placa'), '');
      PR.setValue($(F + 'campo-chassi'), '');
      PR.setValue(campo, o.documento);
      // marca mensagens antigas para não confundir com o resultado desta pesquisa
      document.querySelectorAll('.ui-messages-error-detail, .ui-messages-warn-detail, .ui-messages-info-detail').forEach((s) => { s.dataset.prVisto = '1'; });
      await PR.sleep(300);
      btn.click();
      PR.toast(`Pesquisando ${o.documento} (${o.processo})...`);
    } finally {
      executando = false;
    }
  }

  montarPainel();
  // atualiza o painel quando o PROJUDI ou o popup gravam novos dados
  chrome.storage.onChanged.addListener((ch) => {
    if (ch[PR.KEY]) { const p = $('pr-painel'); if (p) p.remove(); montarPainel(); }
    if (ch[PR.KEY_AUTO] && ch[PR.KEY_AUTO].newValue) pesquisaAutomatica();
  });
  pesquisaAutomatica(); // aba aberta/recarregada depois do pedido
})();
