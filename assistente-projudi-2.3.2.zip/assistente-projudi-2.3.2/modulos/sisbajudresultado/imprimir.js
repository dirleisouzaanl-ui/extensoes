// Página "SISBAJUD - resultado": mostra o PDF exportado do SISBAJUD e abre a impressão.
// O título da página dá o nome do arquivo ao "Salvar como PDF". Depois, aguarda o usuário.
import * as pdfjs from '../mandados/lib/pdf.min.mjs';
pdfjs.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('modulos/mandados/lib/pdf.worker.min.mjs');

const $ = (id) => document.getElementById(id);
const st = (t, cor = '#555') => { $('status').style.color = cor; $('status').textContent = t; };
$('imprimir').addEventListener('click', () => window.print());

(async () => {
  const { sisbajudResultadoPdf: d } = await chrome.storage.local.get('sisbajudResultadoPdf');
  if (!d || !d.b64) { st('Nenhum PDF do SISBAJUD para imprimir.', '#b00020'); return; }
  await chrome.storage.local.remove('sisbajudResultadoPdf');
  const bin = atob(d.b64), bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  try {
    const doc = await pdfjs.getDocument({ data: bytes, isEvalSupported: false }).promise;
    for (let n = 1; n <= doc.numPages; n++) {
      st('Preparando página ' + n + ' de ' + doc.numPages + '…');
      const pagina = await doc.getPage(n);
      const vp = pagina.getViewport({ scale: 2 });
      const canvas = document.createElement('canvas');
      canvas.width = Math.ceil(vp.width); canvas.height = Math.ceil(vp.height);
      await pagina.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise;
      const img = new Image();
      img.src = canvas.toDataURL('image/png');
      await img.decode().catch(() => {});
      $('paginas').appendChild(img);
    }
    st('Processo ' + (d.numero || '') + ' — ' + doc.numPages + ' página(s). A impressão está aberta: imprima ou salve.', '#2e7d32');
    setTimeout(() => window.print(), 300);
  } catch (e) {
    st('Não consegui ler o PDF: ' + ((e && e.message) || e), '#b00020');
  }
})();
