/*
 * SISBAJUD — Resultado da ordem (tecla S do menu do Assistente PROJUDI).
 * Roda na página do SISBAJUD. Quando há uma tarefa gravada pelo menu
 * (chrome.storage.local "sisbajudResultado"), faz, em ordem:
 *   1. menu ☰ → Ordem judicial
 *   2. aba "Busca por filtros de pesquisa" → campo "Número do Processo"
 *   3. cola o número dos autos e clica em Consultar
 *   4. Ações (…) da primeira ordem da lista
 *   5. Detalhar
 *   6. Visualizar série
 *   7. Exportar PDF
 *   8. abre a impressão do PDF com o nome "SISBAJUD - resultado"
 *   9. para e aguarda o usuário (imprimir ou salvar)
 * Nunca clica em nada além desses botões.
 */
(() => {
  'use strict';
  if (window.top !== window || window.__sisbajudResultado) return;
  window.__sisbajudResultado = true;

  const CHAVE = 'sisbajudResultado';
  const VALIDADE = 5 * 60 * 1000;           // 5 min (dá tempo de fazer o login)
  const dorme = (ms) => new Promise((r) => setTimeout(r, ms));
  const N = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim().toUpperCase();
  const visivel = (el) => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';

  let tarefa = null, rodando = false, painel = null;

  // ---------- painel de andamento ----------
  function aviso(texto, cor = '#1565c0') {
    if (!painel) {
      painel = document.createElement('div');
      painel.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:2147483647;max-width:360px;' +
        'font:13px/1.35 "Segoe UI",system-ui,sans-serif;background:#fff;color:#1b2631;border:1px solid #c9d1d8;' +
        'border-left:4px solid #1565c0;border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.18);padding:8px 10px;';
      document.documentElement.appendChild(painel);
    }
    painel.style.borderLeftColor = cor;
    painel.textContent = 'SISBAJUD - resultado: ' + texto;
  }
  const fecharAviso = (ms = 6000) => setTimeout(() => { if (painel) { painel.remove(); painel = null; } }, ms);

  // ---------- localizar elementos ----------
  const clicaveis = () => [...document.querySelectorAll('button, a, [role="button"], [role="menuitem"], [role="tab"], .mat-tab-label, .mat-mdc-tab, mat-list-item, .mat-list-item, li')].filter(visivel);
  // Texto exato; senão, texto que termina com o procurado (ícones do Material entram no texto, ex.: "search Detalhar").
  const porTexto = (texto, { exato = true } = {}) => {
    const alvo = N(texto), lista = clicaveis(), txt = (e) => N(e.innerText || e.textContent);
    return lista.find((e) => txt(e) === alvo) ||
      lista.find((e) => { const t = txt(e); return t.endsWith(' ' + alvo) && t.length <= alvo.length + 30; }) ||
      (exato ? null : lista.find((e) => { const t = txt(e); return t.includes(alvo) && t.length <= alvo.length + 40; })) || null;
  };
  function campoNumeroProcesso() {
    const porPh = [...document.querySelectorAll('input')].find((i) => visivel(i) && /N[uú]mero do Processo/i.test(i.placeholder || ''));
    if (porPh) return porPh;
    for (const ff of document.querySelectorAll('mat-form-field, .mat-form-field, .mat-mdc-form-field')) {
      const l = ff.querySelector('mat-label, label');
      const i = ff.querySelector('input');
      if (l && i && visivel(i) && /N[uú]mero do Processo/i.test(l.textContent)) return i;
    }
    return null;
  }
  // Tela "Ordens Judiciais": título visível + uma das duas abas de consulta.
  // Há na tela um texto visível igual a `alvo` (procura nos próprios textos da página)?
  const temTextoVisivel = (alvo) => {
    const A = N(alvo);
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      const t = N(n.nodeValue);
      if (t && (t === A || (t.length <= A.length + 3 && t.startsWith(A))) && visivel(n.parentElement)) return true;
    }
    return false;
  };
  const naTelaOrdens = () => temTextoVisivel('Busca por filtros de pesquisa') || temTextoVisivel('Consulta pelo número de protocolo') ||
    (temTextoVisivel('Ordens Judiciais') && !!campoNumeroProcesso());
  // Endereço da tela Ordens Judiciais, aprendido quando ela aparece (pela extensão ou por você).
  const CHAVE_URL = 'sisbajudUrlOrdens';
  let urlAprendida = '';
  chrome.storage.local.get(CHAVE_URL).then((d) => { urlAprendida = d[CHAVE_URL] || ''; }).catch(() => {});
  setInterval(() => {
    try {
      if (!chrome.runtime || !chrome.runtime.id) return;
      if (naTelaOrdens() && location.href !== urlAprendida) { urlAprendida = location.href; chrome.storage.local.set({ [CHAVE_URL]: urlAprendida }).catch(() => {}); }
    } catch (e) {}
  }, 2000);

  // Item "Ordem judicial" do menu lateral: o link (ou item de lista) que o contém.
  function itemOrdemJudicial() {
    const alvo = 'ORDEM JUDICIAL';
    const folhas = [...document.querySelectorAll('a, span, div, li, mat-list-item, [role="menuitem"], button')].filter((e) => {
      const t = N(e.innerText || e.textContent);
      return (t === alvo || (t.endsWith(' ' + alvo) && t.length <= alvo.length + 25)) && ![...e.children].some((c) => N(c.innerText || c.textContent).endsWith(alvo) && c !== e && N(c.innerText || c.textContent).length < t.length);
    });
    const el = folhas[0];
    return el ? (el.closest('a[href], [routerlink], [ng-reflect-router-link], mat-list-item, [role="menuitem"], button, a') || el) : null;
  }
  function botaoMenu() {
    return [...document.querySelectorAll('button, mat-icon, [role="button"]')].filter(visivel)
      .find((b) => /^MENU$/.test(N(b.innerText || b.textContent)) || /menu/i.test(b.getAttribute('aria-label') || '')) || null;
  }
  // Abre Ordens Judiciais: clica no item do menu (abrindo o ☰ se preciso); se a tela não
  // trocar, vai pelo endereço do link. Até `ms` milissegundos (dá tempo do login).
  async function abrirOrdemJudicial(ms) {
    const fim = Date.now() + ms;
    let tentativa = 0;
    while (Date.now() < fim && tarefa) {
      if (naTelaOrdens()) return true;
      let item = itemOrdemJudicial();
      if (!item || !visivel(item)) { const m = botaoMenu(); if (m) { m.click(); await dorme(900); } item = itemOrdemJudicial(); }
      if (item) {
        tentativa++;
        const alvoClique = item.querySelector('a[href]') || item;
        alvoClique.click();
        if (await esperar(naTelaOrdens, 5000, 250)) return true;
        const link = item.closest('a[href]') || item.querySelector('a[href]');
        const href = link && link.getAttribute('href');
        if (href && !/^(#|javascript:)/i.test(href) && tentativa >= 1) { location.assign(new URL(href, location.href).href); return 'navegando'; }
      }
      await dorme(800);
    }
    return naTelaOrdens();
  }
  const naTelaSerie = () => /ID DA SERIE/.test(N(document.body.innerText).slice(0, 6000)) || /TEIMOSINHA\s*>?\s*DETALHES/.test(N(document.body.innerText).slice(0, 3000));
  // Linhas da tabela de resultado (mat-table em <table> ou em <mat-row>), sem o cabeçalho.
  function linhasResultado() {
    const linhas = [...document.querySelectorAll('tr.mat-row, tr.mat-mdc-row, mat-row, .mat-row, .mat-mdc-row, tbody tr, [role="row"]')]
      .filter((tr) => visivel(tr) && !tr.querySelector('th, [role="columnheader"]') && !/mat-header|mdc-data-table__header/.test(tr.className || ''));
    return [...new Set(linhas)].filter((tr) => botaoAcoes(tr));
  }
  // Botão "…" da coluna Ações: o que abre o menu (Detalhar / Abrir em nova guia).
  function botaoAcoes(tr) {
    const todos = [...tr.querySelectorAll('button, a, [role="button"], mat-icon, i, span, svg')].filter(visivel);
    const txt = (b) => N(b.innerText || b.textContent);
    const sobe = (e) => e.closest('button, a, [role="button"]') || e;
    let b = todos.find((x) => x.getAttribute('aria-haspopup') || /mat-(mdc-)?menu-trigger/.test(x.className || '') || x.hasAttribute('mattooltip') && /A[CÇ][OÕ]ES/.test(N(x.getAttribute('mattooltip'))));
    if (!b) b = todos.find((x) => /^(\.{2,}|…|⋯|⋮|MORE_HORIZ|MORE_VERT|MORE)$/.test(txt(x)));
    if (!b) b = todos.find((x) => /ellipsis|more|dots|kebab|acoes|actions/i.test((x.getAttribute('class') || '') + ' ' + (x.getAttribute('fonticon') || '') + ' ' + (x.getAttribute('svgicon') || '') + ' ' + (x.getAttribute('data-icon') || '')));
    if (!b) {   // último recurso: o último botão da última célula da linha
      const celulas = tr.querySelectorAll('td, mat-cell, [role="cell"], [role="gridcell"]');
      const ult = celulas[celulas.length - 1];
      const bs = ult ? [...ult.querySelectorAll('button, a, [role="button"]')].filter(visivel) : [];
      b = bs[bs.length - 1];
    }
    return b ? sobe(b) : null;
  }

  // Campo do Angular Material: cola o valor como se fosse digitado.
  // Preenche o campo e confere se o valor ficou: tenta o nº formatado e só os dígitos,
  // digitando caractere a caractere (o campo pode ter máscara).
  const soDig = (x) => String(x || '').replace(/\D/g, '');
  async function colar(el, valor) {
    const tentativas = [valor, soDig(valor)];
    for (const v of tentativas) {
      el.focus(); el.click(); el.select();
      document.execCommand('selectAll'); document.execCommand('delete');
      for (const ch of v) { document.execCommand('insertText', false, ch); await dorme(15); }
      el.dispatchEvent(new Event('change', { bubbles: true }));
      if (soDig(el.value) === soDig(valor)) { el.dispatchEvent(new Event('blur', { bubbles: true })); return true; }
    }
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, valor);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return soDig(el.value) === soDig(valor);
  }

  async function esperar(fn, ms = 20000, passo = 300) {
    const fim = Date.now() + ms;
    while (Date.now() < fim) {
      if (!tarefa) return null;
      try { const r = await fn(); if (r) return r; } catch (e) {}
      await dorme(passo);
    }
    return null;
  }

  async function gravar(etapa) { tarefa = { ...tarefa, etapa }; await chrome.storage.local.set({ [CHAVE]: tarefa }); }
  async function encerrar(texto, cor) { aviso(texto, cor); tarefa = null; await chrome.storage.local.remove(CHAVE); fecharAviso(cor === '#b00020' ? 15000 : 6000); }

  // ---------- PDF exportado ----------
  // capture-pdf-main.js (contexto da página) manda o próprio conteúdo de cada PDF gerado
  // (Blob, fetch, XHR ou link data:). O capture-main.js antigo só manda o endereço do Blob.
  const pdfs = [], blobs = [];
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.origin !== location.origin) return;
    const d = ev.data;
    if (d && d.source === 'sisbajud-resultado' && d.type === 'pdf' && d.buffer) pdfs.push({ buffer: d.buffer, em: Date.now() });
    if (d && d.source === 'sisbajud-pdf-unificador' && d.type === 'blob-created') blobs.push({ url: d.url, em: Date.now() });
  });
  const ehPdf = (u) => String.fromCharCode(...u.slice(0, 5)) === '%PDF-';
  const base64 = (bytes) => {
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(bin);
  };
  async function pdfDoBlob(desde) {
    const vistos = new Set();
    const achado = await esperar(async () => {
      const p = pdfs.find((x) => x.em >= desde);
      if (p) return new Uint8Array(p.buffer);
      for (const b of blobs.filter((x) => x.em >= desde && !vistos.has(x.url))) {
        vistos.add(b.url);
        try { const u = new Uint8Array(await (await fetch(b.url)).arrayBuffer()); if (ehPdf(u)) return u; } catch (e) {}
      }
      return null;
    }, 40000, 400);
    return achado && ehPdf(achado) ? base64(achado) : null;
  }

  // ---------- roteiro ----------
  async function rodar() {
    if (rodando || !tarefa) return;
    rodando = true;
    try {
      aviso('processo ' + tarefa.numero + '…');
      // Se você já estiver adiante (detalhe da ordem ou série aberta), continua dali.
      // Cada execução começa do zero: recarrega o SISBAJUD e reabre Ordem judicial,
      // para não aproveitar a lista, o detalhe ou a série do processo anterior.
      if (tarefa.etapa === 'inicio' && !tarefa.recarregado) {
        try { urlAprendida = (await chrome.storage.local.get(CHAVE_URL))[CHAVE_URL] || urlAprendida; } catch (e) {}
        tarefa = { ...tarefa, recarregado: true, viaUrl: !!urlAprendida };
        await chrome.storage.local.set({ [CHAVE]: tarefa });
        aviso('recarregando o SISBAJUD…');
        if (urlAprendida) {
          const novo = new URL(urlAprendida), atual = new URL(location.href);
          if (novo.origin + novo.pathname + novo.search === atual.origin + atual.pathname + atual.search) { location.hash = novo.hash; location.reload(); }
          else location.assign(urlAprendida);
        } else location.reload();
        return;
      }

      // 1. Ordem judicial (pelo menu ☰), se ainda não estiver na tela
      if (['inicio'].includes(tarefa.etapa) && !naTelaOrdens()) {
        aviso('abrindo Ordem judicial…');
        try { urlAprendida = (await chrome.storage.local.get(CHAVE_URL))[CHAVE_URL] || urlAprendida; } catch (e) {}
        if (urlAprendida && location.href !== urlAprendida && !tarefa.viaUrl) {
          await gravar('inicio'); tarefa = { ...tarefa, viaUrl: true }; await chrome.storage.local.set({ [CHAVE]: tarefa });
          location.assign(urlAprendida);   // a página recarrega e o roteiro continua sozinho
          return;
        }
        const ok = await abrirOrdemJudicial(urlAprendida ? 20000 : 90000);
        if (ok === 'navegando') return;          // a página recarrega e o roteiro continua sozinho
        if (!ok) return encerrar('não consegui abrir Ordem judicial. Abra uma vez ☰ → Ordem judicial: a extensão guarda o endereço e, das próximas vezes, vai direto. Depois tecle S de novo.', '#b00020');
      }

      // 2 e 3. Filtro "Número do Processo" + Consultar
      if (['inicio'].includes(tarefa.etapa)) {
        const aba = porTexto('Busca por filtros de pesquisa');
        if (aba) { aba.click(); await dorme(600); }
        const campo = await esperar(campoNumeroProcesso, 10000);
        if (!campo) return encerrar('campo "Número do Processo" não encontrado.', '#b00020');
        if (!await colar(campo, tarefa.numero)) return encerrar('não consegui colar o nº ' + tarefa.numero + ' no campo "Número do Processo".', '#b00020');
        await dorme(400);
        const consultar = porTexto('Consultar', { exato: false });
        if (!consultar) return encerrar('botão Consultar não encontrado.', '#b00020');
        aviso('consultando ' + tarefa.numero + '…');
        await gravar('consultado');
        consultar.click();
      }

      // 4 e 5. Ações (…) da primeira ordem → Detalhar
      if (tarefa.etapa === 'consultado') {
        const dig = (x) => String(x || '').replace(/\D/g, '');
        const alvoNum = dig(tarefa.numero);
        const doProcesso = (tr) => dig(tr.innerText).includes(alvoNum);
        const temCnj = (tr) => /\d{7}-?\d{2}\.?\d{4}\.?\d\.?\d{2}\.?\d{4}/.test(tr.innerText || '');
        // Espera a lista do processo pedido (as linhas que mostram outro processo são descartadas).
        const linhas = await esperar(() => {
          const l = linhasResultado();
          if (!l.length) return null;
          const certas = l.filter(doProcesso);
          if (certas.length) return certas;
          return l.some(temCnj) ? null : l;   // a lista não mostra o nº: aceita as linhas
        }, 30000);
        if (!linhas) {
          const qtd = [...document.querySelectorAll('tbody tr, mat-row, [role="row"]')].filter(visivel).length;
          return encerrar(qtd ? 'a lista tem ' + qtd + ' linha(s), mas não achei o botão "…" de Ações. Clique em … → Detalhar e tecle S de novo.'
            : 'nenhuma ordem encontrada para ' + tarefa.numero + '.', '#b00020');
        }
        if (linhas.length > 1) aviso(linhas.length + ' ordens na lista; abrindo a primeira…');
        botaoAcoes(linhas[0]).click();
        const detalhar = await esperar(() => porTexto('Detalhar'), 8000);
        if (!detalhar) return encerrar('opção Detalhar não apareceu.', '#b00020');
        await gravar('detalhe');
        detalhar.click();
      }

      // 6. Visualizar série
      if (tarefa.etapa === 'detalhe') {
        aviso('abrindo a série…');
        const serie = await esperar(() => porTexto('Visualizar série', { exato: false }), 25000);
        if (!await esperar(() => soDig(document.body.innerText).includes(soDig(tarefa.numero)), 15000, 400))
          return encerrar('a ordem aberta não é do processo ' + tarefa.numero + ' (a consulta não filtrou pelo número). Nada foi exportado.', '#b00020');
        await gravar('serie');
        if (serie) {
          serie.click();
          await esperar(naTelaSerie, 25000);
        } else {
          aviso('esta ordem não tem série; exportando o detalhe da ordem…', '#ef6c00');
        }
      }

      // 7. Exportar PDF
      if (tarefa.etapa === 'serie') {
        const exp = await esperar(() => porTexto('Exportar PDF', { exato: false }), 20000);
        // A série carrega os dados depois do título: espera o nº do processo aparecer na tela.
        const doProcessoNaTela = () => soDig(document.body.innerText).includes(soDig(tarefa.numero));
        if (!await esperar(doProcessoNaTela, 20000, 400)) return encerrar('a tela aberta não é do processo ' + tarefa.numero + '; nada foi exportado.', '#b00020');
        if (!exp) return encerrar('botão Exportar PDF não encontrado.', '#b00020');
        aviso('exportando o PDF…');
        const desde = Date.now();
        exp.click();
        const b64 = await pdfDoBlob(desde);
        if (!b64) return encerrar('o PDF não chegou. Use o botão Exportar PDF manualmente.', '#b00020');

        // 8. Impressão com o nome "SISBAJUD - resultado"
        await chrome.storage.local.set({ sisbajudResultadoPdf: { b64, numero: tarefa.numero, em: Date.now() } });
        await chrome.runtime.sendMessage({ tipo: 'SISBAJUD_RESULTADO_IMPRIMIR' }).catch(() => {});
        // 9. Aguarda o usuário (a janela de impressão fica aberta na aba nova)
        await chrome.storage.local.set({ sisbajudResultadoUltimo: tarefa.numero });   // próxima execução: só com outro nº copiado
        return encerrar('pronto. A impressão abriu em outra aba e aguarda você.', '#2e7d32');
      }
    } catch (e) {
      await encerrar('erro: ' + ((e && e.message) || e), '#b00020');
    } finally {
      rodando = false;
    }
  }

  async function carregar() {
    const t = (await chrome.storage.local.get(CHAVE))[CHAVE];
    if (!t || !t.numero || Date.now() - (t.criada || 0) > VALIDADE) return;
    tarefa = t;
    rodar();
  }
  chrome.storage.onChanged.addListener((m, area) => {
    if (area === 'local' && m[CHAVE] && m[CHAVE].newValue && (!tarefa || m[CHAVE].newValue.criada !== tarefa.criada)) carregar();
  });
  carregar();
})();
