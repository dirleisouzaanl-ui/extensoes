// SISBAJUD - resultado: roda no contexto da página (MAIN) e avisa o content script
// sempre que o SISBAJUD produz um PDF, por qualquer caminho: Blob (URL.createObjectURL),
// fetch, XMLHttpRequest ou link "data:application/pdf". O conteúdo é lido na hora,
// antes que a página descarte o arquivo.
(() => {
  if (window.__sisbajudResultadoPdf) return;
  window.__sisbajudResultadoPdf = true;

  const avisar = (buf, via) => {
    try {
      const b = new Uint8Array(buf, 0, Math.min(5, buf.byteLength));
      if (String.fromCharCode(...b) !== '%PDF-') return;
      window.postMessage({ source: 'sisbajud-resultado', type: 'pdf', via, buffer: buf }, location.origin);
    } catch (e) {}
  };
  const deBlob = (blob, via) => { if (blob && blob.size > 4) blob.arrayBuffer().then((b) => avisar(b, via), () => {}); };

  // 1) Blob → URL
  const criar = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (obj) {
    if (obj instanceof Blob) deBlob(obj, 'blob');
    return criar(obj);
  };

  // 2) fetch
  const f = window.fetch;
  if (f) window.fetch = function (...args) {
    return f.apply(this, args).then((resp) => {
      try {
        const tipo = resp.headers.get('content-type') || '';
        if (/pdf|octet-stream/i.test(tipo)) resp.clone().arrayBuffer().then((b) => avisar(b, 'fetch'), () => {});
      } catch (e) {}
      return resp;
    });
  };

  // 3) XMLHttpRequest
  const abrir = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (...args) {
    this.addEventListener('load', () => {
      try {
        const r = this.response;
        if (r instanceof ArrayBuffer) avisar(r.slice(0), 'xhr');
        else if (r instanceof Blob) deBlob(r, 'xhr');
      } catch (e) {}
    });
    return abrir.apply(this, args);
  };

  // 4) link data:application/pdf (download direto)
  const decodificar = (href) => {
    const m = /^data:application\/pdf[^,]*;base64,(.*)$/i.exec(href || '');
    if (!m) return;
    const bin = atob(m[1]), u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    avisar(u.buffer, 'data');
  };
  const clicar = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () { try { decodificar(this.href); } catch (e) {} return clicar.apply(this, arguments); };
  const abrirJanela = window.open;
  window.open = function (url, ...resto) { try { decodificar(String(url || '')); } catch (e) {} return abrirJanela.call(this, url, ...resto); };
})();
