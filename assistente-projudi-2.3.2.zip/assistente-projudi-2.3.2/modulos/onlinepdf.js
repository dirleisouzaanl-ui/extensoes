// Módulo "Abrir online.pdf" (tecla 8) — recriado.
// Na tela "Dados da Conclusão": segue o botão Analisar (mesma aba) e abre o(s) online.pdf
// em aba(s) ao lado. Se a tela já tiver online.pdf, abre direto. Só LÊ endereços: não clica
// em nada que altere o processo.
(() => {
  // --- funções injetadas na página (rodam dentro da aba) ---
  function lerPdfs() {
    return [...document.querySelectorAll('a[href*="/projudi/arquivo.do"]')]
      .filter((a) => a.textContent.trim().toLowerCase() === 'online.pdf')
      .map((a) => a.href);
  }
  function lerAnalisar() {
    const bt = [...document.querySelectorAll('input[type="button"], input[type="submit"], button')]
      .find((b) => /^analisar$/i.test((b.value || b.textContent || '').trim()) &&
        /location\.href/.test(b.getAttribute('onclick') || ''));
    if (!bt) return null;
    const m = (bt.getAttribute('onclick') || '').match(/location\.href\s*=\s*['"]([^'"]+)['"]/);
    if (!m) return null;
    try { return new URL(m[1].replace(/&amp;/g, '&'), location.href).href; } catch { return null; }
  }

  async function lerEmTodosQuadros(tabId, func) {
    const r = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func });
    return r.map((x) => x.result).filter(Boolean);
  }

  function esperarCarregar(tabId, ms = 30000) {
    return new Promise((ok, falha) => {
      const fim = setTimeout(() => { chrome.tabs.onUpdated.removeListener(ouvir); falha(new Error('tempo esgotado')); }, ms);
      function ouvir(id, info) {
        if (id === tabId && info.status === 'complete') {
          clearTimeout(fim); chrome.tabs.onUpdated.removeListener(ouvir); ok();
        }
      }
      chrome.tabs.onUpdated.addListener(ouvir);
    });
  }

  async function abrirPdfs(tab, urls) {
    const unicos = [...new Set(urls)];
    for (let i = 0; i < unicos.length; i++) {
      await chrome.tabs.create({ url: unicos[i], index: tab.index + 1 + i, openerTabId: tab.id, active: i === 0 });
    }
    return unicos.length;
  }

  self.abrirOnlinePdf = async function (tab) {
    if (!/^https:\/\/projudi[^/]*\.tjpr\.jus\.br\//.test(tab.url || '')) return 'Abra a conclusão no PROJUDI.';
    let pdfs = (await lerEmTodosQuadros(tab.id, lerPdfs)).flat();
    if (!pdfs.length) {
      const url = (await lerEmTodosQuadros(tab.id, lerAnalisar))[0];
      if (!url) return 'Nesta tela não há online.pdf nem botão Analisar.';
      const carregou = esperarCarregar(tab.id);
      await chrome.tabs.update(tab.id, { url });
      await carregou;
      pdfs = (await lerEmTodosQuadros(tab.id, lerPdfs)).flat();
      if (!pdfs.length) return 'Análise aberta, mas não encontrei online.pdf.';
    }
    const n = await abrirPdfs(await chrome.tabs.get(tab.id), pdfs);
    return `✓ ${n} online.pdf aberto(s).`;
  };
})();
