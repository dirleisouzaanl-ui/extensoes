// Utilidades compartilhadas (PROJUDI e CNIB) — objeto CN (separado do PR do módulo RENAJUD)
var CN = window.CN || {};
window.CN = CN;

CN.KEY = 'cn_dados';
CN.KEY_AUTO = 'cn_auto_preencher'; // pedido de preenchimento automático pendente
CN.AUTO_VALIDADE = 120000;         // ms
CN.TIPO_PROCESSO = 'Processo de execução judicial ou cumprimento de sentença';

CN.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
CN.digits = (s) => String(s || '').replace(/\D/g, '');
CN.norm = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();

CN.waitFor = async (fn, timeout = 8000, step = 200) => {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    try { const v = fn(); if (v) return v; } catch (e) { /* tenta de novo */ }
    await CN.sleep(step);
  }
  return null;
};

CN.save = (dados) => new Promise((r) => chrome.storage.local.set({ [CN.KEY]: dados }, r));
CN.load = () => new Promise((r) => chrome.storage.local.get(CN.KEY, (o) => r(o[CN.KEY] || null)));

CN.toast = (msg, tipo = 'ok', ms = 6000) => {
  const d = document.createElement('div');
  d.className = 'cn-toast cn-' + tipo;
  d.textContent = msg;
  document.body.appendChild(d);
  setTimeout(() => d.remove(), ms);
};

// Preenche input/select disparando os eventos que Angular/React/jQuery/PrimeFaces escutam
CN.setValue = (el, valor) => {
  if (!el) return false;
  el.focus();
  if (el.tagName === 'SELECT') {
    const alvo = CN.norm(valor);
    const opt = [...el.options].find((o) => CN.norm(o.text) === alvo) ||
                [...el.options].find((o) => CN.norm(o.text).includes(alvo)) ||
                [...el.options].find((o) => o.value === String(valor));
    if (!opt) return false;
    el.value = opt.value;
  } else if (el.type === 'checkbox' || el.type === 'radio') {
    if (!el.checked) el.click();
    return true;
  } else {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, valor);
  }
  ['input', 'keyup', 'change'].forEach((ev) => el.dispatchEvent(new Event(ev, { bubbles: true })));
  el.dispatchEvent(new Event('blur', { bubbles: true }));
  return true;
};

// ---------- área de transferência ----------
CN.RE_CNJ = /\d{7}-?\d{2}\.?\d{4}\.?\d\.?\d{2}\.?\d{4}/;
CN.RE_DOC = /\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}|\d{3}\.?\d{3}\.?\d{3}-?\d{2}/g;

CN.fmtCNJ = (s) => {
  const d = CN.digits(s);
  return d.length === 20 ? `${d.slice(0, 7)}-${d.slice(7, 9)}.${d.slice(9, 13)}.${d[13]}.${d.slice(14, 16)}.${d.slice(16)}` : '';
};

CN.novoDados = (o) => Object.assign({
  capturadoEm: new Date().toISOString(), origem: '', processo: '', processoDigitos: '',
  classe: '', comarca: '', juizo: '', juiz: '', valorCausa: '',
  partes: [], executados: [], valorDivida: 'Não', segredo: 'Não', tipoProcesso: CN.TIPO_PROCESSO
}, o);

// Aceita: (1) JSON (objeto da extensão ou objeto simples); (2) linhas "Rótulo: valor"
// — vários executados = pares "Executado:" + "CPF/CNPJ:" repetidos; (3) texto livre com o nº CNJ.
CN.parseTexto = (txt) => {
  txt = String(txt || '').trim();
  if (!txt) return null;
  let obj = null;
  try { const j = JSON.parse(txt); if (j && typeof j === 'object' && !Array.isArray(j)) obj = j; } catch (e) { /* não é JSON */ }

  if (obj && Array.isArray(obj.executados) && obj.processo) {
    const d = CN.novoDados(obj);
    d.processo = CN.fmtCNJ(d.processo) || d.processo;
    d.processoDigitos = CN.digits(d.processo);
    d.executados = d.executados.map((e) => Object.assign({ incluir: CN.digits(e.documento).length >= 11 }, e));
    d.origem = 'area-de-transferencia';
    return d;
  }

  const campo = [];
  if (obj) Object.entries(obj).forEach(([k, v]) => campo.push([CN.norm(k), String(v == null ? '' : v).trim()]));
  else txt.split(/\r?\n/).forEach((l) => {
    const m = l.match(/^\s*([^:\t]{2,40}?)\s*[:\t]\s*(.+)$/);
    if (m) campo.push([CN.norm(m[1]), m[2].trim()]);
  });
  const pega = (re) => { const c = campo.find(([k]) => re.test(k)); return c ? c[1] : ''; };

  const processo = CN.fmtCNJ((pega(/processo|autos/).match(CN.RE_CNJ) || txt.match(CN.RE_CNJ) || [''])[0]);
  if (!processo) return null;
  const semCnj = txt.replace(new RegExp(CN.RE_CNJ.source, 'g'), ' ');

  // executados: cada "CPF/CNPJ" fecha um par com o nome lido antes dele
  const executados = [];
  let nome = '';
  campo.forEach(([k, v]) => {
    if (/execut|^nome|devedor|requerid|^parte/.test(k)) nome = v;
    else if (/cpf|cnpj|documento/.test(k) && CN.digits(v).length >= 11) {
      executados.push({ polo: 'Executado', nome: nome || '(não informado)', documento: v, incluir: true });
      nome = '';
    }
  });
  if (!executados.length && !campo.length) {
    (semCnj.match(CN.RE_DOC) || []).forEach((doc) => executados.push({ polo: 'Executado', nome: '(não informado)', documento: doc, incluir: true }));
  }

  const simNao = (v, padrao) => (/^s/i.test(CN.norm(v)) ? 'Sim' : (/^n/i.test(CN.norm(v)) ? 'Não' : padrao));
  return CN.novoDados({
    origem: 'area-de-transferencia',
    processo,
    processoDigitos: CN.digits(processo),
    comarca: pega(/comarca|municipio/),
    juizo: pega(/juizo|orgao|vara|unidade/),
    juiz: pega(/magistrad|^juiz$|^juiz /),
    valorCausa: pega(/^valor$|valor da causa|valor do debito/),
    valorDivida: simNao(pega(/valor da divida|informar valor/), 'Não'),
    segredo: simNao(pega(/segredo/), 'Não'),
    partes: executados.slice(),
    executados
  });
};

// Texto do botão "Copiar dados" do popup (lido de volta por CN.parseTexto)
CN.textoParaCopiar = (d) => {
  const l = [['Processo', d.processo], ['Valor da dívida', d.valorDivida], ['Valor', d.valorCausa], ['Segredo de justiça', d.segredo]];
  d.executados.filter((e) => e.incluir).forEach((e) => { l.push(['Executado', e.nome], ['CPF/CNPJ', e.documento]); });
  return l.map(([k, v]) => `${k}: ${v || ''}`).join('\n');
};
