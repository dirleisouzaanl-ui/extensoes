// CNIB 2.0 (ONR, indisponibilidade.onr.org.br) — preenchimento da tela "Enviar Ordem", etapa 1 — v1.0.1
// Mapeado em 15/10/2026 (aplicação Blazor, rota /ordem/cadastro), testado nos autos 0002198-73.2022.8.16.0048:
//  - nº do processo em 3 campos: #numberProcess1blazor (NNNNNNN-DD.AAAA, maxlength 15), #numberProcess2blazor
//    (J.TR, já vem 8.16), #numberProcess3blazor (OOOO); formato "Padronizado" = #inlineRadio1;
//  - "Nome do Processo" = select #InputNomeProcesso (é onde fica o tipo);
//  - radios name=KnowValue e name=SecretJustice: os ids estão INVERTIDOS no valor da dívida
//    (#hasKnownDebit = "Não", #hasntKnownDebit = "Sim") — por isso a escolha é sempre pelo texto do label;
//  - valor da dívida: #InputValorDivida; CPF/CNPJ: #txtCpfCnpjInputPerson (máscara 999.999.999-99 / 99.999.999/9999-99);
//  - o "+" é span.btn-add-person (não é botão); a lista fica na tabela "Adicionados por você".
// Sem os ids (tela alterada), os campos são localizados por rótulo, placeholder, aria-label e texto.
// Comportamento observado em 14/10/2026:
//  - o campo CPF/CNPJ tem máscara que embaralha os dígitos quando o formato muda de CPF para CNPJ
//    durante a digitação; por isso o documento é inserido de uma só vez (a máscara escolhe pelo total de dígitos);
//  - a inclusão na lista exige o botão "+", que consulta o servidor da CNIB e devolve o nome;
//  - o servidor oscila ("Ocorreu um erro" / "Houve falha na conexão com a internet"): os documentos são
//    incluídos um por vez e, ao repetir, os que já estão na lista são pulados.
// A extensão NUNCA clica em Enviar/Próximo/Avançar/Confirmar/Assinar: o envio da ordem é sempre da usuária.
(function () {
  if (window.__cnCnib || window.top !== window) return;
  window.__cnCnib = true;

  const $ = (id) => document.getElementById(id);
  const visivel = (el) => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  const noPainel = (el) => !!(el && el.closest && el.closest('#cn-painel, .cn-toast'));
  const segue = (a, b) => !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
  const PROIBIDO = /enviar|proxim|avancar|confirm|assinar|salvar|concluir|finaliz|protocol|cancelar|sair|excluir|remover/;
  const SEL_CTRL = 'input:not([type=hidden]), select, textarea, mat-select, ng-select, [role=combobox], [role=radiogroup], [role=listbox]';
  const RE_ERRO = /ocorreu um erro|falha na conexao|reestabelecer a conexao|restabelecer a conexao/;

  // ---------- localização ----------
  // elementos de rótulo (os mais internos) cujo texto casa com a expressão
  function rotulos(re) {
    const todos = [...document.querySelectorAll('label, legend, mat-label, span, p, div, h3, h4, h5, h6, strong, b, th, td, dt')]
      .filter((e) => !noPainel(e) && visivel(e))
      .filter((e) => { const t = CN.norm(e.textContent); return t.length > 0 && t.length <= 90 && re.test(t); });
    return todos.filter((e) => !todos.some((o) => o !== e && e.contains(o)));
  }

  // sobe até 5 níveis a partir do rótulo e devolve os controles que vêm depois dele
  function controlesApos(rot) {
    let n = rot;
    for (let i = 0; i < 6 && n; i++, n = n.parentElement) {
      const c = [...n.querySelectorAll(SEL_CTRL)].filter((x) => !noPainel(x) && (visivel(x) || x.type === 'radio') && (rot.contains(x) || segue(rot, x)));
      if (c.length) return c;
    }
    return [];
  }

  const atributos = (e) => CN.norm([e.placeholder, e.getAttribute('aria-label'), e.name, e.id, e.getAttribute('formcontrolname'), e.title].join(' '));

  function acharInput(re) {
    const ins = [...document.querySelectorAll('input:not([type=hidden]):not([type=radio]):not([type=checkbox]):not([type=button]):not([type=submit]), textarea')]
      .filter((e) => visivel(e) && !noPainel(e));
    const porAttr = ins.find((e) => re.test(atributos(e)));
    if (porAttr) return porAttr;
    for (const r of rotulos(re)) {
      const f = r.getAttribute('for');
      if (f && $(f) && ins.includes($(f))) return $(f);
      const x = controlesApos(r).find((c) => ins.includes(c));
      if (x) return x;
    }
    return null;
  }

  function textoOpcao(x) {
    if (x.id) { const l = document.querySelector(`label[for="${CSS.escape(x.id)}"]`); if (l && l.textContent.trim()) return l.textContent; }
    const c = x.closest('label, mat-radio-button, .mat-mdc-radio-button, .mat-radio-button, [role=radio]');
    if (c && c.textContent.trim()) return c.textContent;
    if (x.getAttribute('aria-label')) return x.getAttribute('aria-label');
    let s = x.nextSibling;
    while (s && !String(s.textContent || '').trim()) s = s.nextSibling;
    return s ? s.textContent : x.value;
  }

  // escolhe uma opção (select, radio, combobox ou botões de alternância) junto ao rótulo
  async function escolher(reRot, reOpc) {
    for (const r of rotulos(reRot)) {
      const ctrl = controlesApos(r)[0];
      if (!ctrl) continue;
      if (ctrl.type === 'radio' || ctrl.getAttribute('role') === 'radiogroup') {
        const caixa = ctrl.type === 'radio' ? (ctrl.closest('[role=radiogroup], mat-radio-group, fieldset') || r.parentElement) : ctrl;
        const grupo = ctrl.type === 'radio' && ctrl.name
          ? [...document.querySelectorAll(`input[type=radio][name="${CSS.escape(ctrl.name)}"]`)]
          : [...caixa.querySelectorAll('input[type=radio], [role=radio]')];
        const alvo = grupo.find((x) => reOpc.test(CN.norm(textoOpcao(x))));
        if (alvo) { alvo.click(); return textoOpcao(alvo).trim(); }
        continue;
      }
      if (ctrl.tagName === 'SELECT') {
        const o = [...ctrl.options].find((o) => reOpc.test(CN.norm(o.text)));
        if (o && CN.setValue(ctrl, o.text)) return o.text.trim();
        continue;
      }
      if (ctrl.matches('mat-select, ng-select, [role=combobox], [role=listbox]')) {
        ctrl.click();
        const op = await CN.waitFor(() => [...document.querySelectorAll('[role=option], mat-option, .ng-option')]
          .find((o) => visivel(o) && !noPainel(o) && reOpc.test(CN.norm(o.textContent))), 4000);
        if (op) { op.click(); return op.textContent.trim(); }
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      }
    }
    // Sim/Não como botões ou rótulos clicáveis
    for (const r of rotulos(reRot)) {
      let n = r;
      for (let i = 0; i < 4 && n; i++, n = n.parentElement) {
        const b = [...n.querySelectorAll('button, [role=button], [role=radio], mat-button-toggle, mat-radio-button, label')]
          .find((b) => visivel(b) && !noPainel(b) && segue(r, b) && reOpc.test(CN.norm(b.textContent)) && !PROIBIDO.test(CN.norm(b.textContent)));
        if (b) { b.click(); return b.textContent.trim(); }
      }
    }
    return null;
  }

  // textos visíveis fora do painel e fora de campos de digitação
  function textos(filtro) {
    const out = [];
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const p = n.parentElement;
      if (!p || noPainel(p) || p.closest('script, style, textarea') || !n.nodeValue.trim()) continue;
      if (filtro(n.nodeValue) && visivel(p)) out.push(p);
    }
    return out;
  }

  const naLista = (dig) => textos((t) => { const d = CN.digits(t); return d.length >= 11 && d.length <= 22 && d.includes(dig); }).length > 0;
  const errosVisiveis = () => textos((t) => RE_ERRO.test(CN.norm(t)));
  const conexaoCaiu = () => textos((t) => /falha na conexao|reestabelecer a conexao|restabelecer a conexao/.test(CN.norm(t))).length > 0;

  function botaoMais(campo) {
    let n = campo.parentElement;
    for (let i = 0; i < 5 && n; i++, n = n.parentElement) {
      const b = [...n.querySelectorAll('button, [role=button], a, mat-icon, i')]
        .filter((b) => visivel(b) && !noPainel(b) && segue(campo, b))
        .find((b) => {
          const t = CN.norm(b.textContent), a = CN.norm((b.getAttribute('aria-label') || '') + ' ' + (b.title || '') + ' ' + b.className);
          if (PROIBIDO.test(t)) return false;
          return t === '+' || /^(add|adicionar|incluir)$/.test(t) || /adicion|inclu|\badd\b|plus/.test(a);
        });
      if (b) return b.closest('button, [role=button], a') || b;
    }
    return null;
  }

  // radio do grupo `name` cujo label casa com reOpc (ids da CNIB não são confiáveis)
  function radioPorNome(name, reOpc) {
    const r = [...document.querySelectorAll(`input[type=radio][name="${CSS.escape(name)}"]`)].find((x) => reOpc.test(CN.norm(textoOpcao(x))));
    if (!r) return null;
    if (!r.checked) r.click();
    return textoOpcao(r).trim();
  }

  // ---------- inclusão de um CPF/CNPJ ----------
  async function incluirDocumento(ex) {
    const dig = CN.digits(ex.documento);
    if (naLista(dig)) return 'já estava na lista';
    if (conexaoCaiu()) return 'não tentado: CNIB sem conexão';
    const campo = $('txtCpfCnpjInputPerson') || acharInput(/cpf|cnpj|documento/);
    if (!campo) return 'campo CPF/CNPJ não localizado';
    CN.setValue(campo, '');
    await CN.sleep(200);
    CN.setValue(campo, dig); // de uma só vez: a máscara define CPF ou CNPJ pelo total de dígitos
    await CN.sleep(400);
    if (CN.digits(campo.value) !== dig) { CN.setValue(campo, ex.documento); await CN.sleep(400); }
    if (CN.digits(campo.value) !== dig) { campo.classList.add('cn-destaque'); return `a máscara alterou os dígitos (${campo.value}); digite à mão e clique no +`; }
    const b = document.querySelector('span.btn-add-person') || botaoMais(campo);
    if (!b) { campo.classList.add('cn-destaque'); return 'preenchido; botão + não localizado, clique você'; }
    const antes = new Set(errosVisiveis());
    b.click();
    const r = await CN.waitFor(() => {
      if (naLista(dig)) return 'ok';
      const novo = errosVisiveis().find((e) => !antes.has(e));
      return novo ? novo.textContent.replace(/\s+/g, ' ').trim().slice(0, 90) : null;
    }, 90000, 500);
    if (r === 'ok') { CN.setValue(campo, ''); campo.classList.remove('cn-destaque'); return 'incluído'; }
    return r ? 'CNIB respondeu: ' + r : 'sem resposta da CNIB em 90 s';
  }

  // ---------- ordem ----------
  let ocupado = false;
  async function preencherOrdem(d) {
    if (ocupado) return;
    ocupado = true;
    const res = $('cn-res');
    const linhas = [];
    const mostra = (s) => { linhas.push(s); if (res) res.textContent = linhas.join('\n'); };
    const bt = $('cn-b1'); if (bt) bt.disabled = true;
    try {
      if (res) res.textContent = '';
      const p1 = $('numberProcess1blazor'), p3 = $('numberProcess3blazor');
      const proc = p1 ? null : acharInput(/processo/);
      if (p1 && p3 && d.processo.length === 25) {
        if ($('inlineRadio1') && !$('inlineRadio1').checked) { $('inlineRadio1').click(); await CN.sleep(300); }
        CN.setValue(p1, d.processo.slice(0, 15));
        CN.setValue(p3, d.processo.slice(-4));
        const p2 = $('numberProcess2blazor');
        mostra('✓ Processo ' + d.processo + (p2 && p2.value && p2.value !== d.processo.slice(16, 20) ? ` (atenção: J.TR na tela = ${p2.value})` : ''));
      } else if (proc) {
        const v = proc.maxLength >= 20 && proc.maxLength < 25 ? d.processoDigitos : d.processo;
        CN.setValue(proc, v); mostra('✓ Processo ' + d.processo);
      } else mostra('✗ Campo do processo não localizado');

      const reTipo = /execucao judicial|cumprimento de sentenca/;
      const selTipo = $('InputNomeProcesso');
      const opTipo = selTipo && [...selTipo.options].find((o) => reTipo.test(CN.norm(o.text)));
      const tipo = opTipo && CN.setValue(selTipo, opTipo.text) ? opTipo.text.trim()
        : await escolher(/^tipo|tipo de (processo|acao|ordem|feito)|nome do processo/, reTipo);
      await CN.sleep(300);
      mostra(tipo ? '✓ Tipo: ' + tipo : '✗ Tipo do processo não localizado');

      const divSim = d.valorDivida === 'Sim';
      const reSN = (sim) => (sim ? /^sim$/ : /^nao$/);
      const vd = radioPorNome('KnowValue', reSN(divSim)) || await escolher(/valor da divida|informar (o )?valor/, reSN(divSim));
      mostra(vd ? '✓ Valor da dívida: ' + vd : '✗ Valor da dívida não localizado');
      if (divSim && d.valorCausa) {
        await CN.sleep(400);
        const v = $('InputValorDivida') || acharInput(/^valor|valor da divida|montante/);
        if (v && CN.setValue(v, d.valorCausa)) mostra('✓ Valor: ' + d.valorCausa); else mostra('✗ Campo do valor não localizado');
      }

      const sg = radioPorNome('SecretJustice', reSN(d.segredo === 'Sim')) || await escolher(/segredo de justica|segredo/, reSN(d.segredo === 'Sim'));
      mostra(sg ? '✓ Segredo de justiça: ' + sg : '✗ Segredo de justiça não localizado');

      for (const ex of d.executados.filter((e) => e.incluir)) {
        mostra(`… ${ex.documento} (${ex.nome}): consultando`);
        const r = await incluirDocumento(ex);
        linhas.pop();
        mostra(`${r === 'incluído' || r === 'já estava na lista' ? '✓' : '✗'} ${ex.documento} (${ex.nome}): ${r}`);
        if (/sem conexao|sem resposta/.test(CN.norm(r))) {
          mostra('CNIB instável: clique em Aguardar (ou F5) e depois em "Preencher ordem" de novo — os já incluídos são pulados.');
          break;
        }
        await CN.sleep(800);
      }
      const falhou = linhas.some((l) => l.startsWith('✗'));
      mostra(falhou ? 'Complete à mão o que ficou com ✗.' : 'Confira e avance você na CNIB.');
      CN.toast(falhou ? 'Ordem preenchida em parte. Veja o painel.' : 'Ordem preenchida. Confira antes de avançar.', falhou ? 'aviso' : 'ok');
    } finally {
      ocupado = false;
      if (bt) bt.disabled = false;
    }
  }

  // ---------- área de transferência ----------
  async function aplicarTexto(txt) {
    const d = CN.parseTexto(txt);
    if (!d) { CN.toast('A área de transferência não contém número de processo (CNJ).', 'erro'); return; }
    if (!d.executados.some((e) => e.incluir)) CN.toast('Nenhum CPF/CNPJ encontrado no texto colado.', 'aviso');
    await CN.save(d); // o painel é refeito pelo storage.onChanged
    CN.toast('Dados colados. Clique em "Preencher ordem".');
  }

  async function colar() {
    let txt = null;
    try { txt = await navigator.clipboard.readText(); } catch (e) { /* leitura bloqueada pelo navegador */ }
    if (txt !== null) return aplicarTexto(txt);
    const cx = $('cn-cola');
    if (cx) { cx.hidden = false; cx.focus(); }
    CN.toast('O navegador bloqueou a leitura direta. Pressione Ctrl+V na caixa do painel.', 'aviso');
  }

  // ---------- diagnóstico: copiar mapa de campos ----------
  function rotuloProximo(el) {
    if (el.id) { const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`); if (l) return l.textContent; }
    const l = el.closest('label, mat-form-field'); if (l && l.textContent.trim()) return l.textContent;
    let n = el;
    for (let i = 0; i < 4 && n; i++, n = n.parentElement) {
      let p = n.previousElementSibling;
      while (p && !p.textContent.trim()) p = p.previousElementSibling;
      if (p) return p.textContent;
    }
    return '';
  }

  async function mapear() {
    const campos = [...document.querySelectorAll(SEL_CTRL)].filter((e) => !noPainel(e) && (visivel(e) || e.type === 'radio')).map((e) => ({
      tag: e.tagName, type: e.type, id: e.id, name: e.name, formcontrolname: e.getAttribute('formcontrolname') || undefined,
      placeholder: e.placeholder || undefined, aria: e.getAttribute('aria-label') || undefined,
      rotulo: rotuloProximo(e).replace(/\s+/g, ' ').trim().slice(0, 80), maxlength: e.maxLength > 0 ? e.maxLength : undefined,
      opcao: e.type === 'radio' ? textoOpcao(e).replace(/\s+/g, ' ').trim().slice(0, 60) : undefined,
      opcoes: e.tagName === 'SELECT' ? [...e.options].map((o) => o.text.trim()).slice(0, 30) : undefined
    }));
    const botoes = [...document.querySelectorAll('button, [role=button], a.btn, input[type=submit]')].filter((b) => visivel(b) && !noPainel(b))
      .map((b) => [b.id, (b.textContent || b.value || '').replace(/\s+/g, ' ').trim().slice(0, 40), b.getAttribute('aria-label'), b.title].filter(Boolean).join(' | '));
    const txt = JSON.stringify({ url: location.pathname + location.hash, campos, botoes }, null, 2);
    try { await navigator.clipboard.writeText(txt); CN.toast('Mapa dos campos copiado. Cole no chat para ajuste fino.'); }
    catch (e) { console.log(txt); CN.toast('Mapa no console (F12).', 'aviso'); }
  }

  // ---------- painel ----------
  let montando = false;
  async function montarPainel() {
    if ($('cn-painel') || montando) return;
    montando = true;
    try { await montarPainel2(); } finally { montando = false; }
  }
  async function montarPainel2() {
    const d = await CN.load();
    if ($('cn-painel')) return;
    const esc = (s) => String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const p = document.createElement('div');
    p.id = 'cn-painel';
    p.className = 'cn-painel';
    p.innerHTML = `
      <div class="cn-tit">PROJUDI → CNIB <span class="cn-x" title="Minimizar">–</span></div>
      <div class="cn-corpo">
        ${d ? `
          <div><b>Proc.:</b> ${esc(d.processo)}</div>
          <div><b>Executados:</b></div>
          ${d.executados.map((e) => `<div class="cn-ex${e.incluir ? '' : ' cn-fora'}">${esc(e.nome)} — ${esc(e.documento || 'sem CPF/CNPJ')}</div>`).join('') || '<div class="cn-ex">—</div>'}
          <div><b>Valor da dívida:</b> ${esc(d.valorDivida)}${d.valorDivida === 'Sim' ? ' (' + esc(d.valorCausa || '—') + ')' : ''} &nbsp; <b>Segredo:</b> ${esc(d.segredo)}</div>
          <div class="cn-bts">
            <button type="button" id="cn-b1">Preencher ordem</button>
            <button type="button" id="cn-b2" class="cn-sec">Colar da área de transferência</button>
            <button type="button" id="cn-b3" class="cn-sec">Mapear campos</button>
            <button type="button" id="cn-b4" class="cn-sec">Imprimir – CNIB - RESULTADO INFRUTÍFERO</button>
          </div>
          <div class="cn-res" id="cn-res"></div>
          <div class="cn-nota">A extensão só preenche; nunca envia a ordem.</div>`
        : `<div>Nenhum processo capturado. Use o botão "Enviar para a CNIB" no PROJUDI ou copie os dados e clique abaixo.</div>
          <div class="cn-bts"><button type="button" id="cn-b2" class="cn-sec">Colar da área de transferência</button>
          <button type="button" id="cn-b4" class="cn-sec">Imprimir – CNIB - RESULTADO INFRUTÍFERO</button></div>`}
        <textarea id="cn-cola" class="cn-cola" hidden placeholder="Pressione Ctrl+V aqui"></textarea>
      </div>`;
    document.body.appendChild(p);
    p.querySelector('.cn-x').onclick = () => p.classList.toggle('cn-min');
    if (d) {
      $('cn-b1').onclick = async () => preencherOrdem(await CN.load());
      $('cn-b3').onclick = mapear;
    }
    $('cn-b2').onclick = colar;
    $('cn-b4').onclick = imprimirInfrutifero;
    $('cn-cola').addEventListener('paste', (e) => { e.preventDefault(); aplicarTexto(e.clipboardData.getData('text')); });
  }

  // ---------- imprimir o resultado negativo ----------
  // Salva a tela atual em PDF como "CNIB - RESULTADO INFRUTÍFERO.pdf" (pasta Downloads), sem o painel.
  // No Assistente PROJUDI o PDF é gerado direto; sozinha, a extensão abre a impressão do navegador
  // já com esse nome sugerido (escolha "Salvar como PDF").
  const NOME_INFRUTIFERO = 'CNIB - RESULTADO INFRUTÍFERO';
  function imprimirPeloNavegador() {
    const t = document.title;
    document.title = NOME_INFRUTIFERO;
    const volta = () => { document.title = t; window.removeEventListener('afterprint', volta); };
    window.addEventListener('afterprint', volta);
    window.print();
    setTimeout(volta, 60000);
  }
  function imprimirInfrutifero() {
    const b = $('cn-b4');
    if (b) { b.disabled = true; b.textContent = 'Gerando o PDF...'; }
    const fim = () => { if (b) { b.disabled = false; b.textContent = 'Imprimir – CNIB - RESULTADO INFRUTÍFERO'; } };
    try {
      chrome.runtime.sendMessage({ tipo: 'cn-imprimir-infrutifero', nome: NOME_INFRUTIFERO }, (r) => {
        fim();
        if (chrome.runtime.lastError || !r) { imprimirPeloNavegador(); return; }
        if (r.ok) CN.toast('✓ Salvo em Downloads: ' + r.nome, 'ok', 7000);
        else { CN.toast('Não foi possível gerar o PDF direto (' + (r.erro || '') + '). Abrindo a impressão.', 'aviso', 7000); imprimirPeloNavegador(); }
      });
    } catch (e) { fim(); imprimirPeloNavegador(); }
  }

  // ---------- preenchimento automático (pedido vindo do PROJUDI) ----------
  async function preenchimentoAutomatico() {
    const o = await new Promise((res) => chrome.storage.local.get(CN.KEY_AUTO, (x) => res(x[CN.KEY_AUTO])));
    if (!o || Date.now() - o.ts > CN.AUTO_VALIDADE || ocupado) return;
    const pronto = await CN.waitFor(() => $('txtCpfCnpjInputPerson') || (acharInput(/cpf|cnpj|documento/) && acharInput(/processo/)), 8000);
    if (!pronto) { CN.toast('Abra a tela "Enviar Ordem" da CNIB e clique em "Preencher ordem" no painel.', 'aviso', 9000); return; }
    await new Promise((res) => chrome.storage.local.remove(CN.KEY_AUTO, res)); // consome o pedido uma única vez
    preencherOrdem(await CN.load());
  }

  // a CNIB é uma aplicação de página única: o painel é recolocado se a tela o remover
  new MutationObserver(() => { if (!$('cn-painel') && document.body) montarPainel(); }).observe(document.documentElement, { childList: true, subtree: true });
  montarPainel();
  chrome.storage.onChanged.addListener((ch) => {
    if (ch[CN.KEY]) { const p = $('cn-painel'); if (p) p.remove(); montarPainel(); }
    if (ch[CN.KEY_AUTO] && ch[CN.KEY_AUTO].newValue) preenchimentoAutomatico();
  });
  preenchimentoAutomatico();
})();
