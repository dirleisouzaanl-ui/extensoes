const $ = (id) => document.getElementById(id);
const CAMPOS = ['processo', 'valorDivida', 'valorCausa', 'segredo'];
let dados = null;
const esc = (s) => String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function render() {
  const tem = !!dados;
  ['salvar', 'abrir', 'copiar'].forEach((b) => { $(b).hidden = !tem; });
  $('vazio').hidden = tem; $('f').hidden = !tem;
  if (!tem) return;
  CAMPOS.forEach((c) => { $(c).value = dados[c] || ''; });
  $('executados').innerHTML = dados.executados.length
    ? dados.executados.map((e, i) => `<label><input type="checkbox" data-i="${i}" ${e.incluir ? 'checked' : ''} ${CN.digits(e.documento).length < 11 ? 'disabled' : ''}>
        <span>${esc(e.nome)} — ${esc(e.documento || 'sem CPF/CNPJ')}</span></label>`).join('')
    : '<span class="vazio">Nenhum executado.</span>';
}

async function salvar() {
  CAMPOS.forEach((c) => { dados[c] = $(c).value.trim(); });
  dados.processo = CN.fmtCNJ(dados.processo) || dados.processo;
  dados.processoDigitos = CN.digits(dados.processo);
  document.querySelectorAll('#executados input[type=checkbox]').forEach((cb) => { dados.executados[cb.dataset.i].incluir = cb.checked; });
  await CN.save(dados);
  $('msg').textContent = 'Dados salvos.';
}

$('salvar').onclick = salvar;
$('abrir').onclick = async () => {
  await salvar();
  const [aba] = await chrome.tabs.query({ url: 'https://indisponibilidade.onr.org.br/*' });
  if (aba) { await chrome.tabs.update(aba.id, { active: true }); await chrome.windows.update(aba.windowId, { focused: true }); }
  else chrome.tabs.create({ url: 'https://indisponibilidade.onr.org.br/' });
};
$('capturar').onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $('msg').textContent = 'Capturando...';
  chrome.tabs.sendMessage(tab.id, { tipo: 'cn-capturar' }, (r) => {
    if (chrome.runtime.lastError || !r) { $('msg').textContent = 'Abra a tela do processo no PROJUDI nesta aba.'; return; }
    if (!r.ok) { $('msg').textContent = 'Erro: ' + r.erro; return; }
    dados = r.dados; render(); $('msg').textContent = 'Capturado.';
  });
};
$('colar').onclick = async () => {
  try {
    const d = CN.parseTexto(await navigator.clipboard.readText());
    if (!d) { $('msg').textContent = 'A área de transferência não contém número de processo (CNJ).'; return; }
    dados = d; await CN.save(d); render();
    $('msg').textContent = 'Dados colados e salvos.';
  } catch (e) { $('msg').textContent = 'Não foi possível ler a área de transferência: ' + e.message; }
};
$('copiar').onclick = async () => {
  await salvar();
  await navigator.clipboard.writeText(CN.textoParaCopiar(dados));
  $('msg').textContent = 'Dados copiados para a área de transferência.';
};

CN.load().then((d) => { dados = d; render(); });
