// Busca rápida (tecla B): normaliza o número e pede ao background para abrir os autos em aba nova.
const $ = (id) => document.getElementById(id);
const FORO = '8160048';   // J.TR.OOOO padrão: TJPR, comarca de Assis Chateaubriand

function normalizar(t) {
  const s = (t || '').trim();
  let m = s.match(/(\d{1,7})-(\d{2})\.(\d{4})(?:\.(\d)\.(\d{2})\.(\d{4}))?/);
  let dig = m ? m[1].padStart(7, '0') + m[2] + m[3] + (m[4] ? m[4] + m[5] + m[6] : FORO) : s.replace(/\D/g, '');
  if (dig.length === 13) dig += FORO;
  if (dig.length !== 20) return '';
  return `${dig.slice(0, 7)}-${dig.slice(7, 9)}.${dig.slice(9, 13)}.${dig[13]}.${dig.slice(14, 16)}.${dig.slice(16)}`;
}
function atualizar() {
  const n = normalizar($('num').value);
  $('norm').textContent = n ? '→ ' + n : ($('num').value ? 'Número incompleto' : '');
  $('norm').style.color = n ? '#2e7d32' : '#b00020';
  $('ir').disabled = !n;
  return n;
}
async function ir() {
  const n = atualizar();
  if (!n) return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $('ir').disabled = true; $('norm').textContent = 'Abrindo…';
  const r = await chrome.runtime.sendMessage({ tipo: 'BUSCA_RAPIDA', numero: n, tabId: tab.id }).catch(() => null);
  if (r && r.ok) window.close(); else { $('norm').textContent = '✗ ' + ((r && r.erro) || 'erro'); $('ir').disabled = false; }
}
$('num').addEventListener('input', atualizar);
$('num').addEventListener('keydown', (e) => { if (e.key === 'Enter') ir(); });
$('ir').onclick = ir;
(async () => {   // número copiado? já preenche
  try { const c = await navigator.clipboard.readText(); if (normalizar(c)) { $('num').value = c.trim().slice(0, 60); atualizar(); $('num').select(); } } catch { /* sem permissão */ }
})();
