// Busca rápida — executa nas páginas do PROJUDI quando há um pedido pendente para ESTA aba:
// menu "Processo" → preenche o número → Pesquisar → abre o processo encontrado. Só navega e lê.
(() => {
  'use strict';
  if (window.__buscaRapida) return;
  window.__buscaRapida = true;
  const CHAVE = 'buscaRapida';
  const TOPO = window.top === window;
  const limpa = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const txt = (el) => limpa(el.value || el.innerText || el.textContent);
  let meuTab = null, ocupado = false;

  const ler = async () => (await chrome.storage.local.get(CHAVE))[CHAVE];
  const gravar = async (p) => { const e = (await ler()) || {}; await chrome.storage.local.set({ [CHAVE]: { ...e, ...p, desde: Date.now() } }); };
  const visivel = (el) => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);

  function campoNumero() {
    return [...document.querySelectorAll('input[type=text], input:not([type])')].find((i) => {
      if (!visivel(i) || i.disabled) return false;
      const td = i.closest('td'); const ant = td && td.previousElementSibling;
      return /n[uú]mero/i.test((ant ? ant.textContent : '') + ' ' + i.name + ' ' + i.id + ' ' + (i.title || ''));
    });
  }
  const botaoPesquisar = () => [...document.querySelectorAll('input[type=submit], input[type=button], button')]
    .find((b) => visivel(b) && /^(pesquisar|buscar|consultar|ok)$/i.test(txt(b)));
  const ehAutos = (n) => (document.body.innerText || '').includes(n) &&
    [...document.querySelectorAll('a, li, span, td')].some((el) => /^\s*movimenta[cç][oõ]es\s*$/i.test(el.textContent));

  async function tick() {
    if (ocupado) return;
    const e = await ler();
    if (!e || !e.ativo) return;
    if (Date.now() - e.desde > 60000) { await gravar({ ativo: false }); return; }
    if (!meuTab) { try { meuTab = await chrome.runtime.sendMessage({ tipo: 'MEU_TAB' }); } catch { return; } }
    if (!meuTab || meuTab.tabId !== e.tabId) return;
    ocupado = true;
    try {
      if (ehAutos(e.numero)) { await gravar({ ativo: false, etapa: 'ok' }); return; }
      if (e.etapa === 'menu' && TOPO) {
        if (campoNumero() && botaoPesquisar()) { await gravar({ etapa: 'form', navegouEm: 0 }); return; }
        const menu = [...document.querySelectorAll('a')].find((a) => /^\s*processo\s*$/i.test(a.textContent));
        if (!menu) return;
        await gravar({ etapa: 'form', navegouEm: Date.now() });
        menu.click();
      } else if (e.etapa === 'form') {
        if (performance.timeOrigin < (e.navegouEm || 0)) return;
        const c = campoNumero(), b = botaoPesquisar();
        if (!c || !b) return;
        c.focus(); c.value = e.numero;
        ['input', 'change', 'blur'].forEach((t) => c.dispatchEvent(new Event(t, { bubbles: true })));
        await gravar({ etapa: 'resultado', navegouEm: Date.now() });
        b.click();
      } else if (e.etapa === 'resultado') {
        if (performance.timeOrigin < e.navegouEm && Date.now() - e.navegouEm < 5000) return;
        const ln = [...document.querySelectorAll('a[href]')].find((a) => a.textContent.includes(e.numero) && !/^javascript/i.test(a.getAttribute('href')))
          || [...document.querySelectorAll('a')].find((a) => a.textContent.includes(e.numero));
        if (!ln) return;
        await gravar({ ativo: false, etapa: 'ok' });
        ln.click();
      }
    } finally { ocupado = false; }
  }

  chrome.storage.onChanged.addListener((m, area) => { if (area === 'local' && m[CHAVE]) tick(); });
  tick();
  const t = setInterval(() => { try { tick(); } catch { clearInterval(t); } }, 800);
  setTimeout(() => clearInterval(t), 90000);
})();
