// Módulo Busca rápida — isolado. Abre aba nova no PROJUDI e grava o pedido; o content script
// (buscarapida/content.js) faz a busca pelo menu "Processo" e abre os autos.
(() => {
  const CHAVE = 'buscaRapida';
  chrome.runtime.onMessage.addListener((msg, _s, responder) => {
    if (!msg || msg.tipo !== 'BUSCA_RAPIDA') return;
    (async () => {
      const origem = await chrome.tabs.get(msg.tabId).catch(() => null);
      const host = origem && /^https:\/\/projudi[^/]*\.tjpr\.jus\.br/.exec(origem.url || '');
      const base = host ? host[0] : 'https://projudi2.tjpr.jus.br';
      const nova = await chrome.tabs.create({ url: base + '/projudi/', index: origem ? origem.index + 1 : undefined, active: true });
      await chrome.storage.local.set({ [CHAVE]: { ativo: true, numero: msg.numero, etapa: 'menu', tabId: nova.id, desde: Date.now() } });
      responder({ ok: true });
    })().catch((e) => responder({ ok: false, erro: e.message }));
    return true;
  });
})();
