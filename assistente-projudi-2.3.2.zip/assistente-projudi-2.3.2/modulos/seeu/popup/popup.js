// popup.js — guarda as escolhas no chrome.storage.local.
const elAtivo = document.getElementById('ativo');
const elTermos = document.getElementById('termos');
const elStatus = document.getElementById('status');

chrome.storage.local.get({ ativo: true, termos: [] }, (dados) => {
  elAtivo.checked = !!dados.ativo;
  elTermos.value = (dados.termos || []).join('\n');
});

function salvar(mensagem) {
  const termos = elTermos.value.split('\n').map((t) => t.trim()).filter(Boolean);
  chrome.storage.local.set({ ativo: elAtivo.checked, termos }, () => {
    elStatus.textContent = mensagem;
    setTimeout(() => (elStatus.textContent = ''), 1500);
  });
}

elAtivo.addEventListener('change', () => salvar(elAtivo.checked ? 'Ligado.' : 'Desligado.'));
document.getElementById('salvar').addEventListener('click', () => salvar('Termos salvos.'));

// ---- Módulo PROJUDI: liga/desliga próprio (chave projudiAtivo) ----
const elProjudiAtivo = document.getElementById('projudiAtivo');
const elStatusProjudi = document.getElementById('statusProjudi');

chrome.storage.local.get({ projudiAtivo: true }, (dados) => {
  elProjudiAtivo.checked = dados.projudiAtivo !== false;
});

elProjudiAtivo.addEventListener('change', () => {
  chrome.storage.local.set({ projudiAtivo: elProjudiAtivo.checked }, () => {
    elStatusProjudi.textContent = elProjudiAtivo.checked ? 'Ligado.' : 'Desligado.';
    setTimeout(() => (elStatusProjudi.textContent = ''), 1500);
  });
});
