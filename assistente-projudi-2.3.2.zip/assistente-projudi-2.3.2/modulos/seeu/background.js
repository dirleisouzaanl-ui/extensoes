// Módulo Extensão SEEU — isolado
(() => {
// background.js — service worker mínimo.
// Na instalação, grava as configurações padrão sem apagar as já existentes.
//   ativo / termos  → módulo SEEU (destaque de incidentes)
//   projudiAtivo    → módulo PROJUDI (captura de modelo de documento)
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get({ ativo: true, termos: [], projudiAtivo: true }, (dados) => {
    chrome.storage.local.set({ ativo: dados.ativo, termos: dados.termos, projudiAtivo: dados.projudiAtivo });
  });
});

})();
