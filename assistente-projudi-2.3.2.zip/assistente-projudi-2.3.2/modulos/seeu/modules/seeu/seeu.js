// seeu.js — destaque de incidentes por termos (somente leitura).
// REGRA: esta extensão só LÊ a página. Não clica, não preenche campos,
// não envia formulários e não altera dados do sistema. Ela apenas marca
// as linhas com um atributo visual e mostra um contador.

(() => {
  if (globalThis.__extensaoSeeuLiberada !== true) return; // guard.js não liberou

  // ------------------------------------------------------------------
  // SELETORES — conferidos com o HTML real fornecido em 10/10/2026:
  //   <table class="resultTable"> com <th>Nº do Incidente</th> no <thead>;
  //   linhas de dados: <tr id="incidenteConcedido_29_"> no <tbody>
  //     (o id se repete entre linhas; por isso usamos "começa com");
  //   linhas ocultas de detalhe: <tr id="rowIncidenteincidente0"> — ignoradas,
  //     pois o id começa com "row";
  //   1ª célula de cada linha traz um <script> do SEEU — o texto dele é ignorado.
  const SELETOR_TABELA = 'table.resultTable';
  const CABECALHO_IDENTIFICADOR = 'Nº do Incidente';
  const SELETOR_LINHAS = ':scope > tbody > tr[id^="incidente"]';
  // ------------------------------------------------------------------

  const COR_DESTAQUE = '#fff3a0';
  const ATTR = 'data-seeu-destaque';
  const ID_CONTADOR = 'extensao-seeu-contador';
  const ID_ESTILO = 'extensao-seeu-estilo';

  let config = { ativo: true, termos: [] };
  let agendado = null;

  const normalizar = (s) =>
    (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ');

  // Texto das células, sem o conteúdo de <script>/<style> (funciona mesmo
  // se a tabela estiver numa aba oculta, quando innerText não é confiável).
  function textoDaLinha(linha) {
    const partes = [];
    const walker = document.createTreeWalker(linha, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => {
        const pai = n.parentNode && n.parentNode.nodeName;
        return pai === 'SCRIPT' || pai === 'STYLE'
          ? NodeFilter.FILTER_REJECT
          : NodeFilter.FILTER_ACCEPT;
      }
    });
    while (walker.nextNode()) partes.push(walker.currentNode.nodeValue);
    return partes.join(' ');
  }

  // A cor vem de uma folha de estilo da extensão; as células não têm o
  // estilo próprio alterado, então nada precisa ser "restaurado" depois.
  function garantirEstilo() {
    if (document.getElementById(ID_ESTILO)) return;
    const st = document.createElement('style');
    st.id = ID_ESTILO;
    st.textContent =
      'tr[' + ATTR + '] > td { background-color: ' + COR_DESTAQUE + ' !important; }';
    (document.head || document.documentElement).appendChild(st);
  }

  function tabelasDeIncidentes() {
    return [...document.querySelectorAll(SELETOR_TABELA)].filter((t) =>
      [...t.querySelectorAll(':scope > thead th')].some(
        (th) => th.textContent.trim() === CABECALHO_IDENTIFICADOR
      )
    );
  }

  function atualizarContador(qtd, haTabela) {
    let el = document.getElementById(ID_CONTADOR);
    if (!config.ativo || !haTabela) {
      if (el) el.remove();
      return;
    }
    if (!el) {
      el = document.createElement('div');
      el.id = ID_CONTADOR;
      Object.assign(el.style, {
        position: 'fixed', right: '12px', bottom: '12px', zIndex: '2147483647',
        background: '#1f3a5f', color: '#fff', font: '12px/1.4 Arial, sans-serif',
        padding: '6px 10px', borderRadius: '6px', boxShadow: '0 2px 6px rgba(0,0,0,.3)',
        pointerEvents: 'none' // não intercepta cliques na página
      });
      document.body.appendChild(el);
    }
    const texto = qtd === 1 ? '1 incidente destacado' : qtd + ' incidentes destacados';
    if (el.textContent !== texto) el.textContent = texto;
  }

  function aplicar() {
    observador.disconnect();
    try {
      document.querySelectorAll('tr[' + ATTR + ']').forEach((tr) => tr.removeAttribute(ATTR));
      const tabelas = tabelasDeIncidentes();
      const termos = config.termos.map(normalizar).filter(Boolean);
      let qtd = 0;
      if (config.ativo && termos.length) {
        garantirEstilo();
        tabelas.forEach((tabela) => {
          tabela.querySelectorAll(SELETOR_LINHAS).forEach((linha) => {
            const texto = normalizar(textoDaLinha(linha));
            if (termos.some((t) => texto.includes(t))) {
              linha.setAttribute(ATTR, '');
              qtd++;
            }
          });
        });
      }
      atualizarContador(qtd, tabelas.length > 0);
    } finally {
      observar();
    }
  }

  function agendar() {
    clearTimeout(agendado);
    agendado = setTimeout(aplicar, 300);
  }

  // Observa a tela para aplicar o destaque quando a tabela surgir depois.
  const observador = new MutationObserver(agendar);
  function observar() {
    if (document.body) observador.observe(document.body, { childList: true, subtree: true });
  }

  function carregarConfig() {
    chrome.storage.local.get({ ativo: true, termos: [] }, (dados) => {
      config = { ativo: !!dados.ativo, termos: Array.isArray(dados.termos) ? dados.termos : [] };
      aplicar();
    });
  }

  chrome.storage.onChanged.addListener((mudancas, area) => {
    if (area === 'local' && (mudancas.ativo || mudancas.termos)) carregarConfig();
  });

  carregarConfig();
})();
