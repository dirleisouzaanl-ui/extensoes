// projudi.js — PROJUDI: captura de Modelo de Documento.
// Origem: userscript "PROJUDI -> EPROC - Transferencia de Modelo de Documento"
// v2.1 (Tampermonkey), restrito ao PROJUDI. Na tela de visualização do
// Modelo de Documento, o botão "Capturar para EPROC" lê Descrição, Tipo de
// Documento, Competência e o texto do ato e copia o texto para a área de
// transferência. Só LÊ a página do PROJUDI; nada é preenchido ou enviado.
// Liga/desliga pelo popup (chave projudiAtivo).

(function () {
  'use strict';

  if (globalThis.__extensaoSeeuLiberada !== true) return; // guard.js não liberou
  if (globalThis.__extensaoSistema !== 'projudi') return;

  const COMUM = globalThis.ExtensaoComum;
  if (!COMUM) return;

  /* ============================================================
   * CONFIGURACAO - AJUSTE AQUI CONFORME O HTML REAL DA TELA
   * Use "Inspecionar elemento" (botao direito) nos campos reais
   * do PROJUDI para confirmar/corrigir estes valores.
   * ============================================================ */
  const CONFIG = {
    origem: {
      // Tela de VISUALIZACAO "Modelo de Documento" (nao a de edicao).
      // td.resultBorder e exclusivo dessa tela, entao serve como detector confiavel.
      detectar: () => !!document.querySelector('td.resultBorder'),
      labelDescricao: 'Descrição:',
      labelTipoDocumento: 'Tipo de Documento:',
      labelCompetencia: 'Tipo de Competência:',
      // Container que guarda todo o conteudo (cabecalho + corpo + assinatura)
      seletorContainerConteudo: 'td.resultBorder',
      // Dentro do container, os paragrafos do CORPO do ato vem como
      // <div style="text-align: justify;">...</div> (pode haver mais de um)
      seletorParagrafosCorpo: 'div[style*="text-align: justify"]',
    },
  };

  /* ============================================================
   * HELPERS DE LEITURA
   * ============================================================ */

  // Igual ao findFieldByLabel, mas serve tanto para campos de formulario (input/select/textarea)
  // quanto para telas somente-texto, onde o valor e apenas o conteudo textual ao lado do rotulo.
  function getValueNearLabel(labelText) {
    const candidatos = document.querySelectorAll('label, td, span, div, strong, b, th, p');
    const alvo = labelText.trim().toLowerCase();

    for (const el of candidatos) {
      const txt = el.textContent.trim().toLowerCase();
      if (txt !== alvo && !txt.startsWith(alvo)) continue;
      if (el.querySelector('input,select,textarea')) continue;

      // Caso 1: rotulo e valor estao no MESMO elemento (ex.: "Descrição: ATO ORD...")
      if (txt.length > alvo.length) {
        const bruto = el.textContent.trim();
        return bruto.slice(labelText.length).trim().replace(/^:\s*/, '');
      }

      // Caso 2: campo de formulario (input/select/textarea) em elemento irmao
      let sib = el.nextElementSibling;
      while (sib) {
        const field = sib.matches('input,select,textarea') ? sib : sib.querySelector('input,select,textarea');
        if (field) return getFieldValue(field);
        if (sib.textContent.trim()) return sib.textContent.trim();
        sib = sib.nextElementSibling;
      }

      // Caso 3: rotulo e valor em celulas irmas do elemento pai (ex.: <td>Label</td><td>Valor</td>)
      const parent = el.parentElement;
      if (parent && parent.nextElementSibling) {
        const irmaoPai = parent.nextElementSibling;
        const field = irmaoPai.matches('input,select,textarea') ? irmaoPai : irmaoPai.querySelector('input,select,textarea');
        if (field) return getFieldValue(field);
        if (irmaoPai.textContent.trim()) return irmaoPai.textContent.trim();
      }
    }
    return '';
  }

  function getFieldValue(field) {
    if (!field) return '';
    if (field.tagName === 'SELECT') {
      const opt = field.options[field.selectedIndex];
      return opt ? opt.textContent.trim() : '';
    }
    return (field.value || '').trim();
  }


  /* ============================================================
   * BOTAO FLUTUANTE
   * ============================================================ */
  function criarBotaoFlutuante(texto, cor, onClick) {
    const btn = document.createElement('button');
    btn.textContent = texto;
    Object.assign(btn.style, {
      position: 'fixed',
      bottom: '20px',
      right: '20px',
      zIndex: 999999,
      padding: '12px 18px',
      background: cor,
      color: '#fff',
      border: 'none',
      borderRadius: '8px',
      fontSize: '14px',
      fontWeight: 'bold',
      cursor: 'pointer',
      boxShadow: '0 2px 8px rgba(0,0,0,.3)',
      fontFamily: 'Arial, sans-serif',
    });
    btn.addEventListener('click', onClick);
    document.body.appendChild(btn);
    return btn;
  }

  /* ============================================================
   * ACAO: CAPTURAR (tela PROJUDI)
   * ============================================================ */
  function capturar() {
    const container = document.querySelector(CONFIG.origem.seletorContainerConteudo);
    const paragrafos = container
      ? Array.from(container.querySelectorAll(CONFIG.origem.seletorParagrafosCorpo))
      : [];

    const dados = {
      descricao: getValueNearLabel(CONFIG.origem.labelDescricao),
      tipoDocumento: getValueNearLabel(CONFIG.origem.labelTipoDocumento),
      competencia: getValueNearLabel(CONFIG.origem.labelCompetencia),
      corpo: paragrafos.map((p) => p.innerText.trim()).join('\n\n'),
      timestamp: Date.now(),
    };

    if (!dados.corpo) {
      alert(
        'Não encontrei o texto do ato (nenhum parágrafo casou com o seletor configurado).\n\n' +
          'Abra o console (F12), inspecione o(s) elemento(s) que contêm o texto da certidão e ajuste ' +
          'CONFIG.origem.seletorContainerConteudo / seletorParagrafosCorpo no script.'
      );
      return;
    }

    COMUM.copiarTexto(dados.corpo);
    alert(
      'Capturado com sucesso!\n\n' +
        `Descrição: ${dados.descricao || '(vazio)'}\n` +
        `Tipo: ${dados.tipoDocumento || '(vazio)'}\n` +
        `Competência: ${dados.competencia || '(vazio)'}\n\n` +
        'O texto do ato está na área de transferência — cole (Ctrl+V) no EPROC.'
    );
  }

  /* ============================================================
   * INICIALIZACAO - respeita o liga/desliga do popup (projudiAtivo)
   * ============================================================ */
  let ativo = true;
  let botao = null;
  let iniciado = false;
  let configLida = false;

  function montarBotao() {
    if (botao || !ativo || !iniciado || !configLida) return;
    if (CONFIG.origem.detectar()) {
      botao = criarBotaoFlutuante('📋 Capturar para EPROC', '#1a73e8', capturar);
    }
  }

  function removerBotao() {
    if (botao) botao.remove();
    botao = null;
  }

  COMUM.aoMudar(['projudiAtivo'], (mudancas) => {
    ativo = mudancas.projudiAtivo.newValue !== false;
    if (!ativo) removerBotao();
    else montarBotao();
  });

  COMUM.lerConfig({ projudiAtivo: true }, (dados) => {
    ativo = dados.projudiAtivo !== false;
    configLida = true;
    montarBotao();
  });

  function iniciar() {
    setTimeout(() => {
      iniciado = true;
      montarBotao();
    }, 800);
  }

  // document_idle pode ocorrer antes ou depois do evento "load".
  if (document.readyState === 'complete') iniciar();
  else window.addEventListener('load', iniciar);
})();
