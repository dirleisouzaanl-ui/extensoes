// comum.js — funções compartilhadas entre os módulos.
// Expõe globalThis.ExtensaoComum (somente no mundo isolado da extensão).

(() => {
  if (globalThis.__extensaoSeeuLiberada !== true) return; // guard.js não liberou

  // Lê chaves do chrome.storage.local com valores padrão.
  function lerConfig(padroes, callback) {
    chrome.storage.local.get(padroes, callback);
  }

  // Chama callback(mudancas) quando alguma das chaves mudar.
  function aoMudar(chaves, callback) {
    chrome.storage.onChanged.addListener((mudancas, area) => {
      if (area !== 'local') return;
      if (chaves.some((c) => Object.prototype.hasOwnProperty.call(mudancas, c))) callback(mudancas);
    });
  }

  // Copia texto para a área de transferência de forma síncrona
  // (equivalente ao GM_setClipboard), devolvendo o foco ao elemento anterior.
  function copiarTexto(texto) {
    const anterior = document.activeElement;
    const ta = document.createElement('textarea');
    ta.value = texto == null ? '' : String(texto);
    ta.setAttribute('readonly', '');
    Object.assign(ta.style, { position: 'fixed', top: '-1000px', left: '-1000px', opacity: '0' });
    (document.body || document.documentElement).appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    ta.remove();
    if (anterior && typeof anterior.focus === 'function') {
      try { anterior.focus(); } catch (e) { /* ignora */ }
    }
    if (!ok && navigator.clipboard) navigator.clipboard.writeText(ta.value).catch(() => {});
    return ok;
  }

  Object.defineProperty(globalThis, 'ExtensaoComum', {
    value: Object.freeze({ lerConfig, aoMudar, copiarTexto }),
    writable: false,
    configurable: false
  });
})();
