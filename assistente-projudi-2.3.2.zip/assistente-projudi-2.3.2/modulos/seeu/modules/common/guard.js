// guard.js — script de proteção. Roda ANTES dos demais content scripts.
// Só libera a extensão quando o endereço for um dos sistemas autorizados
// (sempre em https). Os content scripts do mesmo bloco do manifest
// compartilham o mesmo "mundo isolado", por isso as flags abaixo são
// visíveis para os scripts do módulo.
//
//   __extensaoSeeuLiberada  true/false — endereço autorizado (nome mantido
//                           para o módulo SEEU continuar funcionando igual)
//   __extensaoSistema       'seeu' | 'projudi' | null

(() => {
  const HOSTS_PERMITIDOS = {
    'seeu.pje.jus.br': 'seeu',
    'projudi2.tjpr.jus.br': 'projudi'
  };

  const sistema =
    location.protocol === 'https:' &&
    Object.prototype.hasOwnProperty.call(HOSTS_PERMITIDOS, location.hostname)
      ? HOSTS_PERMITIDOS[location.hostname]
      : null;
  const liberado = sistema !== null;

  Object.defineProperty(globalThis, '__extensaoSeeuLiberada', {
    value: liberado,
    writable: false,
    configurable: false
  });
  Object.defineProperty(globalThis, '__extensaoSistema', {
    value: sistema,
    writable: false,
    configurable: false
  });

  if (!liberado) {
    console.warn('[Extensão SEEU] bloqueada: endereço não autorizado (' + location.hostname + ').');
  }
})();
