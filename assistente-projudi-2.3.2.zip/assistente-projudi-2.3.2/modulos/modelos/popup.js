// Modelos rápidos (tecla T). Lista de modelos de texto guardados no navegador; ao usar, preenche as
// variáveis com os dados dos autos abertos e insere no campo de texto onde o cursor estava
// (ou copia para colar com Ctrl+V). Teclas 1–9 usam direto o modelo correspondente.
const $ = (id) => document.getElementById(id);
const CHAVE = 'modelosRapidos';
const INICIAIS = [
  { nome: 'Certidão — decurso sem manifestação', texto: 'CERTIDÃO\n\nAutos nº {{processo}}\n\nCertifico que decorreu o prazo sem manifestação da parte intimada.\n\nO referido é verdade e dou fé.\n\n{{comarca}}, {{data_extenso}}.' },
  { nome: 'Ato ordinatório — manifestar em 5 dias', texto: 'ATO ORDINATÓRIO\n\nAutos nº {{processo}}\n\nNos termos da Portaria do Juízo, intime-se a parte autora ({{autor}}) para, no prazo de 5 (cinco) dias, manifestar-se sobre o prosseguimento do feito.\n\n{{comarca}}, {{data_extenso}}.' },
  { nome: 'Certidão — juntada', texto: 'CERTIDÃO\n\nAutos nº {{processo}}\n\nCertifico que juntei aos autos o documento que segue.\n\n{{comarca}}, {{data_extenso}}.' }
];
let modelos = [], atual = -1, dados = { processo: '[___]', autor: '[___]', reu: '[___]' };

const st = (t, cor = '#2e7d32') => { $('status').style.color = cor; $('status').textContent = t; };
async function gravar() { await chrome.storage.local.set({ [CHAVE]: modelos }); }

function render() {
  $('lista').innerHTML = modelos.map((m, i) =>
    `<div data-i="${i}" class="${i === atual ? 'sel' : ''}">${i < 9 ? `<kbd>${i + 1}</kbd>` : ''}${m.nome.replace(/</g, '&lt;')}</div>`).join('');
  $('lista').querySelectorAll('div').forEach((d) => d.onclick = () => selecionar(+d.dataset.i));
}
function selecionar(i) {
  atual = i; render();
  $('nome').value = modelos[i]?.nome || ''; $('texto').value = modelos[i]?.texto || '';
}

function preencher(t) {
  const hoje = new Date();
  const ext = hoje.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' });
  const v = { ...dados, data: hoje.toLocaleDateString('pt-BR'), data_extenso: ext, comarca: 'Assis Chateaubriand' };
  return t.replace(/\{\{(\w+)\}\}/g, (m, k) => (k in v ? v[k] : m));
}

// Injetada na página: insere o texto no campo onde estava o cursor (textarea, input ou editor em iframe).
function inserirNaPagina(texto) {
  const alvo = (doc) => {
    let el = doc.activeElement;
    while (el && el.tagName === 'IFRAME') { try { doc = el.contentDocument; el = doc.activeElement; } catch { return null; } }
    if (!el || el === doc.body && !doc.body.isContentEditable) {
      el = doc.querySelector('textarea, [contenteditable=true]');
      if (!el) for (const f of doc.querySelectorAll('iframe')) {
        try { const b = f.contentDocument.body; if (b && (b.isContentEditable || f.contentDocument.designMode === 'on')) return { doc: f.contentDocument, el: b }; } catch { /* outro domínio */ }
      }
    }
    return el ? { doc, el } : null;
  };
  const a = alvo(document);
  if (!a) return false;
  const { doc, el } = a;
  el.focus();
  if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
    const i = el.selectionStart ?? el.value.length, f = el.selectionEnd ?? i;
    el.value = el.value.slice(0, i) + texto + el.value.slice(f);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  }
  return doc.execCommand('insertText', false, texto);
}

async function usar(i) {
  const m = modelos[i ?? atual];
  if (!m) return st('Escolha um modelo.', '#b00020');
  const texto = preencher(i === undefined ? $('texto').value : m.texto);
  await navigator.clipboard.writeText(texto);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let ok = false;
  try {
    const r = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: inserirNaPagina, args: [texto] });
    ok = r.some((x) => x.result);
  } catch { /* página sem permissão */ }
  st(ok ? '✓ Inserido no campo (e copiado).' : '✓ Copiado — clique no campo do PROJUDI e cole com Ctrl+V.');
  if (ok) setTimeout(() => window.close(), 900);
}

$('usar').onclick = () => usar();
$('salvar').onclick = async () => {
  const m = { nome: $('nome').value.trim() || 'Sem nome', texto: $('texto').value };
  if (atual >= 0) modelos[atual] = m; else { modelos.push(m); atual = modelos.length - 1; }
  await gravar(); render(); st('Modelo salvo.');
};
$('novo').onclick = () => { atual = -1; render(); $('nome').value = ''; $('texto').value = ''; $('nome').focus(); };
$('excluir').onclick = async () => {
  if (atual < 0 || !confirm(`Excluir o modelo "${modelos[atual].nome}"?`)) return;
  modelos.splice(atual, 1); await gravar(); selecionar(Math.min(atual, modelos.length - 1)); st('Excluído.');
};
document.addEventListener('keydown', (e) => {
  if (/^(INPUT|TEXTAREA)$/.test(e.target.tagName)) return;
  if (/^[1-9]$/.test(e.key) && modelos[+e.key - 1]) { e.preventDefault(); usar(+e.key - 1); }
});

(async () => {
  const r = await chrome.storage.local.get(CHAVE);
  modelos = r[CHAVE] || INICIAIS;
  if (!r[CHAVE]) await gravar();
  selecionar(0);
  // dados do processo aberto (número e primeira parte de cada polo)
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: window.lerDadosProcesso });
    const d = res.map((x) => x.result).filter(Boolean).sort((a, b) => b.partes - a.partes)[0];
    if (d) {
      const nomeDepois = (rx) => { const m = d.texto.split(/\n\n/).find((b) => rx.test(b)); const l = m && m.split('\n')[1]; return l ? l.replace(/^\d+\.\s*/, '').split(' — ')[0] : '[___]'; };
      dados = { processo: d.numero, autor: nomeDepois(/POLO ATIVO|EXEQUENTE|AUTOR|REQUERENTE/), reu: nomeDepois(/POLO PASSIVO|EXECUTAD|RÉU|REQUERID/) };
      st(`Processo ${d.numero} detectado.`, '#555');
    }
  } catch { /* fora do PROJUDI */ }
})();
