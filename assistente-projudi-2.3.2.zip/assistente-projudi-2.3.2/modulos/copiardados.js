// Módulo "Copiar dados do processo" (tecla D) — carregado pelo popup.
// Lê nos autos: número, classe, assunto, valor da causa e as partes (polo ativo/passivo,
// CPF/CNPJ e advogados) e devolve um texto pronto para colar. Só lê a página.
window.lerDadosProcesso = async function () {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const limpa = (s) => (s || '').replace(/\s+/g, ' ').trim();
  const CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;
  const numero = ((document.body?.innerText || '').match(CNJ) || [''])[0];
  if (!numero) return null;

  const titulos = () => [...document.querySelectorAll('h2,h3,h4,h5,legend')]
    .filter((h) => /polo\s+(ativo|passivo)|exequente|executad|autor|r[ée]u|requerent|requerid/i.test(h.textContent) &&
      h.textContent.trim().length < 40);
  // Partes não visíveis: abre a aba "Partes e Outros" e espera.
  if (!titulos().length) {
    const aba = [...document.querySelectorAll('a, li, span, td')]
      .find((el) => /^\s*partes\s+e\s+outros\s*$/i.test(el.textContent));
    if (aba) { (aba.closest('a') || aba).click(); for (let i = 0; i < 30 && !titulos().length; i++) await sleep(250); }
  }

  // Campo "Rótulo: valor" do cabeçalho dos autos.
  const campo = (rx) => {
    const el = [...document.querySelectorAll('td, th, label, span, b, strong, dt')]
      .find((e) => e.children.length <= 1 && rx.test(limpa(e.textContent)));
    if (!el) return '';
    const viz = el.nextElementSibling || el.parentElement?.nextElementSibling;
    return limpa(viz?.innerText || '');
  };
  const classe = campo(/^Classe Processual:?$/i);
  const assunto = campo(/^Assunto Principal:?$/i);
  const valor = campo(/^Valor da Causa:?$/i);

  const tabelaDepois = (h) => {
    let n = h.nextElementSibling;
    while (n && n.tagName !== 'TABLE') {
      const t = n.querySelector && n.querySelector('table');
      if (t) return t;
      if (/^H\d$/.test(n.tagName)) return null;
      n = n.nextElementSibling;
    }
    return n;
  };
  const polos = [];
  for (const h of titulos()) {
    const tab = tabelaDepois(h);
    if (!tab) continue;
    const cab = [...tab.rows].find((r) => r.querySelector('th')) || tab.rows[0];
    const idx = (rx) => [...cab.cells].findIndex((c) => rx.test(limpa(c.textContent)));
    const iNome = idx(/^Nome/i), iDoc = idx(/CPF|CNPJ/i), iAdv = idx(/Advogad/i);
    const partes = [];
    for (const tr of tab.rows) {
      if (tr === cab || !tr.getClientRects().length || tr.cells.length < 3) continue;
      const nome = limpa((tr.cells[iNome >= 0 ? iNome : 1]?.innerText || '').replace(/\(.*?\)/g, ''));
      if (!nome || /^nome$/i.test(nome)) continue;
      const doc = limpa(tr.cells[iDoc]?.innerText || '');
      const advs = iAdv >= 0 ? [...tr.cells[iAdv].querySelectorAll('li')].map((li) => limpa(li.innerText))
        .filter(Boolean) : [];
      if (iAdv >= 0 && !advs.length && limpa(tr.cells[iAdv].innerText)) advs.push(limpa(tr.cells[iAdv].innerText));
      partes.push({ nome, doc, advs });
    }
    if (partes.length) polos.push({ titulo: limpa(h.textContent).toUpperCase(), partes });
  }

  const L = [`Processo: ${numero}`];
  if (classe) L.push(`Classe: ${classe}`);
  if (assunto) L.push(`Assunto: ${assunto}`);
  if (valor) L.push(`Valor da causa: ${valor}`);
  for (const p of polos) {
    L.push('', p.titulo);
    p.partes.forEach((x, i) => {
      L.push(`${i + 1}. ${x.nome}${x.doc ? ' — CPF/CNPJ: ' + x.doc : ' — CPF/CNPJ: [não informado]'}`);
      if (x.advs.length) L.push(`   Adv.: ${x.advs.join('; ')}`);
    });
  }
  return { numero, texto: L.join('\n'), partes: polos.reduce((n, p) => n + p.partes.length, 0) };
};
