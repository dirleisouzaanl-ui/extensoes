// Assistente PROJUDI 2.1 — módulo "Análise de Juntadas" (antiga extensão Projudi - Análise de Juntadas 1.4.0).
// Abre as guias pedidas pela página, uma a uma, sem tirar o foco da Análise de Juntadas.
chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  if (!msg || msg.tipo !== 'JUNTADAS14_ABRIR' || !Array.isArray(msg.urls)) return;
  const origem = sender.tab;
  msg.urls.forEach((url, i) => {
    setTimeout(() => chrome.tabs.create({ url, active: false, windowId: origem ? origem.windowId : undefined }), i * 700);
  });
  responder({ ok: true, total: msg.urls.length });
});
