/* regras.js - regras de classificação da Análise de Juntadas.
   Cada regra olha o TÍTULO da movimentação (ex.: "JUNTADA DE PETIÇÃO DE MANIFESTAÇÃO DA PARTE")
   e a DESCRIÇÃO (ex.: "Referente ao evento JUNTADA DE PENHORA NÃO REALIZADA BACENJUD/SISBAJUD").
   A primeira regra que casar vale. Para ajustar, edite ou acrescente regras aqui. */
var REGRAS_TRIAGEM = [
  // --- urgências primeiro ---
  { cat: 'Urgência (liminar/tutela/medicamento)', cor: 'vermelho', urgente: true,
    em: 'tudo', se: /LIMINAR|TUTELA DE URGENCIA|TUTELA ANTECIPADA|MEDICAMENTO|URGENTE/,
    enc: 'Concluir com urgência ao magistrado.' },

  // --- recursos e impugnações ---
  { cat: 'Recurso inominado', cor: 'roxo', em: 'tudo', se: /RECURSO INOMINADO/,
    enc: 'Certificar preparo e tempestividade; intimar para contrarrazões.' },
  { cat: 'Embargos de declaração', cor: 'roxo', em: 'tudo', se: /EMBARGOS DE DECLARACAO/,
    enc: 'Intimar a parte contrária (se houver efeito modificativo) e concluir.' },
  { cat: 'Impugnação ao cumprimento', cor: 'roxo', em: 'tudo', se: /IMPUGNACAO/,
    enc: 'Intimar o exequente para manifestação e, após, concluir.' },

  // --- acordo, pagamento, extinção ---
  { cat: 'Acordo / desistência / extinção', cor: 'verde', em: 'tudo', se: /ACORDO|DESISTENCIA|EXTINCAO|QUITACAO/,
    enc: 'Concluir para homologação/sentença.' },
  { cat: 'Comprovante de pagamento ou depósito', cor: 'verde', em: 'tudo', se: /COMPROVANTE|PAGAMENTO|DEPOSITO JUDICIAL|GUIA/,
    enc: 'Intimar o credor sobre o depósito; havendo pedido, preparar alvará.' },

  // --- cumprimento de sentença ---
  { cat: 'Pedido de diligência (constrição)', cor: 'azul', em: 'titulo', se: /REQUERIMENTO DE DILIGENCIA/,
    enc: 'Analisar o pedido (SISBAJUD, RENAJUD, INFOJUD, endereço) e concluir ou cumprir por ato ordinatório.' },
  { cat: 'Resposta à penhora não realizada', cor: 'azul', em: 'descricao', se: /PENHORA NAO REALIZADA|SISBAJUD|BACENJUD|RENAJUD|INFOJUD/,
    enc: 'Verificar o pedido do credor (nova tentativa, outro meio ou suspensão) e dar andamento.' },
  { cat: 'Manifestação sobre alvará', cor: 'verde', em: 'descricao', se: /ALVARA/,
    enc: 'Verificar ciência ou levantamento; nada pendente: aguardar prazo ou arquivar.' },

  // --- representação ---
  { cat: 'Procuração / substabelecimento / habilitação', cor: 'cinza', em: 'tudo', se: /PROCURACAO|SUBSTABELECIMENTO|HABILITACAO/,
    enc: 'Cadastrar o advogado no processo e dar ciência.' },

  // --- prazos de cumprimento ---
  { cat: 'Carta precatória (prazo de cumprimento)', cor: 'laranja', em: 'titulo', se: /CARTA PRECATORIA/,
    enc: 'Conferir o retorno da carta; vencido o prazo, oficiar ao juízo deprecado.' },
  { cat: 'Mandado / ofício (prazo de cumprimento)', cor: 'laranja', em: 'titulo', se: /EXPEDICAO DE (MANDADO|OFICIO)/,
    enc: 'Conferir cumprimento ou resposta; vencido o prazo, reiterar.' },

  // --- respostas a atos ---
  { cat: 'Resposta a ato ordinatório', cor: 'cinza', em: 'descricao', se: /ATO ORDINATORIO/,
    enc: 'Ler a manifestação e cumprir o ato seguinte ou concluir.' },
  { cat: 'Resposta a despacho / decisão', cor: 'cinza', em: 'descricao', se: /DESPACHO|DECISAO|DEFERIDO|INDEFERIDO|SENTENCA/,
    enc: 'Ler a manifestação e concluir, se exigir decisão.' },
  { cat: 'Audiência', cor: 'laranja', em: 'tudo', se: /AUDIENCIA/,
    enc: 'Conferir intimações e pauta da audiência.' },

  // --- genéricas ---
  { cat: 'Manifestação da parte', cor: 'cinza', em: 'titulo', se: /MANIFESTACAO/,
    enc: 'Ler a petição e classificar manualmente.' },
  { cat: 'Cumprimento de intimação', cor: 'cinza', em: 'titulo', se: /CUMPRIMENTO DE INTIMACAO/,
    enc: 'Ler a petição: ciência simples arquiva-se; pedido novo exige andamento.' }
];

/* Regras aplicadas ao TEXTO DA PETIÇÃO (PDF), quando você clica em "Ler petições".
   Se uma delas casar, substitui a classificação feita pelo título/descrição.
   Ordem importa: pedidos vêm antes de "ciência", porque uma petição pode dar ciência e pedir algo. */
var REGRAS_TEXTO = [
  { cat: 'Pedido de constrição (SISBAJUD/RENAJUD/INFOJUD)', cor: 'azul', se: /SISBAJUD|BACENJUD|RENAJUD|INFOJUD|PENHORA ON ?LINE|TEIMOSINHA|BLOQUEIO DE (VALORES|ATIVOS)/,
    enc: 'Cumprir a diligência pedida ou concluir, conforme o caso.' },
  { cat: 'Pedido de alvará / levantamento', cor: 'verde', se: /EXPEDICAO D[OE] ALVARA|LEVANTAMENTO D[OA]S? (VALOR|QUANTIA|DEPOSITO|SALDO)|TRANSFERENCIA DO VALOR/,
    enc: 'Conferir depósito e dados bancários; preparar o alvará.' },
  { cat: 'Acordo / quitação / extinção', cor: 'verde', se: /ACORDO|QUITACAO|SATISFACAO DA OBRIGACAO|EXTINCAO D[OA] (EXECUCAO|FEITO|PROCESSO)/,
    enc: 'Concluir para homologação ou sentença de extinção.' },
  { cat: 'Pedido de suspensão / arquivamento', cor: 'cinza', se: /SUSPENSAO D[OA] (PROCESSO|EXECUCAO|FEITO)|ARQUIVAMENTO PROVISORIO|ART\.? ?921/,
    enc: 'Concluir ou cumprir a suspensão por ato ordinatório.' },
  { cat: 'Novo endereço / citação', cor: 'azul', se: /NOVO ENDERECO|ENDERECO ATUALIZADO|CITACAO NO ENDERECO|PESQUISA DE ENDERECO/,
    enc: 'Expedir citação ou intimação no novo endereço.' },
  { cat: 'Cálculo / atualização do débito', cor: 'azul', se: /PLANILHA|MEMORIA DE CALCULO|ATUALIZACAO DO DEBITO|CALCULO ATUALIZADO/,
    enc: 'Intimar o devedor sobre o cálculo ou prosseguir com a constrição.' },
  { cat: 'Ciência / renúncia de prazo', cor: 'verde', se: /RENUNCI\w* (A|AO) PRAZO|RENUNCI\w* PRAZO|CIENTE|DA CIENCIA|DAR CIENCIA|TOMAR CIENCIA|NADA (A|MAIS) REQUERER/,
    enc: 'Sem pedido novo: dispensar a análise ou aguardar o prazo.' }
];
