/*
 * content-projudi.js — roda DENTRO da página do PROJUDI (depois do config.js).
 *
 * Coloca o botão flutuante "→ SISBAJUD" na tela do processo que mostra as
 * partes (títulos H4 "Exequente"/"Executado" seguidos de tabela). Um clique
 * LÊ o nº do processo e TODAS as partes de cada polo e manda ao service
 * worker, que guarda em chrome.storage.local:
 *
 *   botão "→ SISBAJUD" → {tipo:'GUARDAR_DADOS', dados}
 *   ◄── resposta {ok, motivo}
 *
 * O que este script NÃO faz: não clica em nada do sistema, não preenche
 * campos e não envia formulários. Só lê o texto da página.
 */

(async () => {
  'use strict';

  const S = self.SISBAJUD; // definido em config.js
  if (!S || !S.ehUrlProjudi(location.href)) return;

  const RE_CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;
  const RE_CNPJ = /\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}/;
  const RE_CPF = /\d{3}\.\d{3}\.\d{3}-\d{2}/;
  const RE_ATIVO = /exequente|autor|requerente|polo\s+ativo/i;
  const RE_PASSIVO = /executad|réu|requerid|polo\s+passivo/i;
  // Títulos dos quadros de partes: H4 ("Exequente"/"Executado") ou "Polo Ativo"/"Polo Passivo".
  const titulos = () => [...document.querySelectorAll('h2, h3, h4, h5, legend')]
    .filter((h) => h.textContent.trim().length < 40);

  // -------------------------------------------------------------------------
  // 1) Leitura das partes.
  //    Estrutura do PROJUDI: <h4>Exequente</h4> ... <table> com uma linha por
  //    parte; nome na 2ª célula; CPF/CNPJ em qualquer célula da linha.
  // -------------------------------------------------------------------------
  function tabelaDepoisDo(h4) {
    let irmao = h4.nextElementSibling;
    while (irmao && irmao.tagName !== 'TABLE' && irmao.tagName !== 'H4') {
      // A tabela às vezes vem dentro de um <div>.
      const dentro = irmao.querySelector && irmao.querySelector('table');
      if (dentro) return dentro;
      irmao = irmao.nextElementSibling;
    }
    return irmao && irmao.tagName === 'TABLE' ? irmao : null;
  }

  function lerLinha(tr) {
    if (!tr.getClientRects().length) return null; // linha de detalhe oculta (+) não é parte
    const celulas = tr.querySelectorAll('td');
    if (celulas.length < 2) return null;

    // CNPJ antes do CPF: o texto sem espaços junta CNPJ quebrado em linhas.
    const corrido = tr.textContent.replace(/\s+/g, '');
    const doc = (corrido.match(RE_CNPJ) || corrido.match(RE_CPF) || [''])[0];

    // Nome: 2ª célula, sem observações entre parênteses
    // (ex.: "(citação e intimação online via DJE)").
    const nome = celulas[1].textContent
      .replace(/\s+/g, ' ')
      .replace(/\s*\(.*?\)\s*/g, ' ')
      .trim();
    if (!nome || nome === 'Nome' || nome.length < 3 || nome.length > 200) return null;
    return { nome, doc };
  }

  // Aba "Informações Gerais": linhas "Exequente:" / "Executado:" com a parte em <li> e o
  // "CPF/CNPJ:" na mesma linha. Uma parte por linha; linha sem rótulo continua o polo anterior.
  function lerPartesInformacoesGerais(exequentes, executados) {
    let destino = null;
    for (const tr of document.querySelectorAll('tr')) {
      if (tr.querySelector('tr') || !tr.getClientRects().length) continue;
      const celulas = [...tr.children].filter((c) => /^T[DH]$/.test(c.tagName));
      if (celulas.length < 2) continue;
      const rotulo = celulas[0].textContent.replace(/\s+/g, ' ').trim();
      if (rotulo) {
        destino = !/:\s*$/.test(rotulo) || rotulo.length > 40 ? null
          : RE_ATIVO.test(rotulo) ? exequentes : RE_PASSIVO.test(rotulo) ? executados : null;
      }
      if (!destino) continue;
      const li = tr.querySelector('li');
      let nome = (li ? li.textContent : celulas[1].textContent)
        .replace(/\s+/g, ' ').replace(/\s*\(.*?\)\s*/g, ' ').replace(/^[•·\-\s]+/, '').trim();
      nome = nome.replace(/\s*(CPF|CNPJ|RG|Idade)\b.*$/i, '').trim();
      if (!nome || nome.length < 3 || nome.length > 200) continue;
      const corrido = tr.textContent.replace(/\s+/g, '');
      const doc = (corrido.match(RE_CNPJ) || corrido.match(RE_CPF) || [''])[0];
      if (!destino.some((p) => p.nome === nome && p.doc === doc)) destino.push({ nome, doc });
    }
  }

  // "Valor da Causa: R$ 986,64" (aba Informações Gerais) → "986,64".
  function lerValorCausa() {
    for (const c of document.querySelectorAll('td, th, label, span, b, strong')) {
      if (!/^Valor da Causa\s*:?$/i.test(c.textContent.replace(/\s+/g, ' ').trim())) continue;
      const alvo = c.nextElementSibling || c.parentElement;
      const m = (alvo ? alvo.textContent : '').match(/R\$\s*([\d.]+,\d{2})/);
      if (m) return m[1];
    }
    const m = (document.body.innerText || '').match(/Valor da Causa\s*:?\s*R\$\s*([\d.]+,\d{2})/i);
    return m ? m[1] : '';
  }

  function lerPartes() {
    const exequentes = [];
    const executados = [];
    for (const h4 of titulos()) {
      const titulo = h4.textContent.trim();
      const destino = RE_ATIVO.test(titulo) ? exequentes
        : RE_PASSIVO.test(titulo) ? executados : null;
      if (!destino) continue;
      const tabela = tabelaDepoisDo(h4);
      if (!tabela) continue;
      for (const tr of tabela.querySelectorAll('tr')) {
        const parte = lerLinha(tr);
        // Sem repetição (mesmo nome + mesmo documento).
        if (parte && !destino.some((p) => p.nome === parte.nome && p.doc === parte.doc)) {
          destino.push(parte);
        }
      }
    }
    if (!executados.length) lerPartesInformacoesGerais(exequentes, executados);
    return { exequentes, executados };
  }

  // O nº do processo pode estar em outro quadro (frame) da mesma página.
  function lerNumeroProcesso() {
    const tentativas = [document];
    try { if (window.top !== window) tentativas.push(window.top.document); } catch { /* outro domínio */ }
    try { if (window.parent !== window) tentativas.push(window.parent.document); } catch { /* idem */ }
    for (const doc of tentativas) {
      const m = (doc.body && (doc.body.innerText || doc.body.textContent) || '').match(RE_CNJ);
      if (m) return m[0];
    }
    return '';
  }

  const temPartes = () => titulos().some((h) => RE_ATIVO.test(h.textContent) || RE_PASSIVO.test(h.textContent)) ||
    [...document.querySelectorAll('td, th')].some((c) => /^(Executad[oa]s?|R[ée]u|Requerid[oa]s?|Polo Passivo)\s*:$/i.test(c.textContent.replace(/\s+/g, ' ').trim()));

  // -------------------------------------------------------------------------
  // 2) Mensagem ao service worker.
  // -------------------------------------------------------------------------
  async function enviar(mensagem) {
    try {
      return await chrome.runtime.sendMessage(mensagem);
    } catch (erro) {
      console.error('[sisbajud] sem contato com o service worker (recarregue a página):', erro);
      return { ok: false, motivo: 'extensão recarregada — dê F5 na página' };
    }
  }

  // -------------------------------------------------------------------------
  // 3) Botão flutuante.
  // -------------------------------------------------------------------------
  const ROTULO = '→ SISBAJUD: copiar partes';
  let botao = null;
  let ocupado = false;

  let ultimoAviso = '';
  function piscar(texto, ms = 3000) {
    ultimoAviso = texto;
    if (!botao) return;
    botao.textContent = texto;
    setTimeout(() => { if (botao) botao.textContent = ROTULO; }, ms);
  }

  async function copiar(evento) {
    evento.preventDefault();
    evento.stopPropagation();
    if (ocupado) return;
    ocupado = true;
    try {
      const { exequentes, executados } = lerPartes();
      const numProcesso = lerNumeroProcesso();
      if (!numProcesso) { piscar('✗ nº do processo não encontrado'); return; }
      if (!executados.length) { piscar('✗ nenhum executado encontrado'); return; }

      const semDoc = executados.filter((p) => !p.doc).length;
      const valorCausa = lerValorCausa();
      const dados = { numProcesso, exequentes, executados, valorCausa, capturadoEm: new Date().toISOString() };
      const r = await enviar({ tipo: 'GUARDAR_DADOS', dados });
      if (r && r.ok) {
        console.log('[sisbajud] dados guardados:', dados);
        piscar(`✓ ${numProcesso} — ${executados.length} executado(s)` +
          (semDoc ? ` (${semDoc} sem CPF/CNPJ)` : '') + (valorCausa ? ` — valor R$ ${valorCausa}` : ' — valor da causa não encontrado'), 4000);
      } else {
        piscar('✗ recusado (veja o console)');
        console.warn('[sisbajud] recusado:', r && r.motivo);
      }
    } finally {
      ocupado = false;
    }
  }

  function atualizarBotao(opcoes) {
    const deveMostrar = opcoes.mostrarPainel && temPartes();
    if (!deveMostrar) {
      if (botao) { botao.remove(); botao = null; }
      return;
    }
    if (botao) return;
    botao = document.createElement('button');
    botao.type = 'button'; // nunca submete formulário
    botao.id = 'sisbajud-copiar-partes';
    botao.textContent = ROTULO;
    botao.title = 'Guarda o nº do processo e as partes para preencher a minuta no SISBAJUD';
    botao.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;' +
      'padding:6px 12px;font:bold 12px Verdana,sans-serif;cursor:pointer;color:#fff;' +
      'background:#4a7c2e;border:0;border-radius:4px;box-shadow:0 2px 6px rgba(0,0,0,.35)';
    botao.addEventListener('click', copiar);
    document.body.appendChild(botao);
  }

  // Acionamento pelo menu da extensão única (opção 5).
  chrome.runtime.onMessage.addListener((msg, _s, responder) => {
    if (!msg || msg.tipo !== 'COPIAR_PARTES' || !temPartes()) return;
    copiar({ preventDefault() {}, stopPropagation() {} })
      .then(() => responder({ ok: /^✓/.test(ultimoAviso), aviso: ultimoAviso }));
    return true;
  });

  let opcoes = await S.lerOpcoes();
  atualizarBotao(opcoes);

  // Agrupa várias mudanças seguidas numa única verificação.
  let agendado = false;
  new MutationObserver(() => {
    if (agendado) return;
    agendado = true;
    requestAnimationFrame(() => { agendado = false; atualizarBotao(opcoes); });
  }).observe(document.body, { childList: true, subtree: true });

  // Opções mudaram? Atualiza AO VIVO, sem F5.
  chrome.storage.onChanged.addListener((mudancas, area) => {
    if (area !== 'sync') return;
    S.lerOpcoes().then((op) => { opcoes = op; atualizarBotao(opcoes); });
  });
})();
