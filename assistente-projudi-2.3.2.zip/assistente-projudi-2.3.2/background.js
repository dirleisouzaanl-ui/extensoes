// Assistente PROJUDI 2.0 — service worker único (MV3).
// Cada módulo continua no seu arquivo; os comandos não se confundem porque
//   bg-assistente.js responde a mensagens com "cmd" (alvará, leitor de PDF, ofícios) e
//   bg-ferramentas.js responde a mensagens com "tipo" (intimações, juntadas, SISBAJUD, RENAJUD, PDFs, SEEU...).
importScripts('bg-ferramentas.js', 'bg-assistente.js', 'bg-juntadas.js', 'bg-cnib.js', 'bg-sisbajud-resultado.js');
