// Menu do Assistente PROJUDI: clique ou tecle o número/a letra.
const TECLAS = { 1: 'autora', 2: 're', 3: 'ambas', 4: 'juntadas', 5: 'copiar', 6: 'renajud', 7: 'opcoes-novaaba', 8: 'onlinepdf', 9: 'salvarpdf',
  m: 'mesclar', M: 'mesclar', o: 'expedir', O: 'expedir', p: 'pdfsrecentes', P: 'pdfsrecentes', a: 'abrirconclusoes', A: 'abrirconclusoes', j: 'abrirconclusoes', J: 'abrirconclusoes', u: 'ultimajuntada', U: 'ultimajuntada',
  b: 'sisbajudpdf', B: 'sisbajudpdf', e: 'seeu', E: 'seeu',
  d: 'copiardados', D: 'copiardados', c: 'decurso', C: 'decurso', r: 'prazos', R: 'prazos', k: 'lote', K: 'lote',
  t: 'modelos', T: 'modelos', f: 'buscarapida', F: 'buscarapida', q: 'precatorio', Q: 'precatorio',
  h: 'pendencias', H: 'pendencias', g: 'cnib', G: 'cnib', n: 'mandados', N: 'mandados', i: 'peticao', I: 'peticao', s: 'sisbajudresultado', S: 'sisbajudresultado' };
const PAGINAS = { mesclar: 'modulos/mesclar/popup.html', expedir: 'modulos/expedir/popup.html', seeu: 'modulos/seeu/popup/popup.html',
  pdfsrecentes: 'modulos/pdfsrecentes/popup.html', sisbajudpdf: 'modulos/sisbajudpdf/popup.html',
  decurso: 'modulos/decurso/popup.html', modelos: 'modulos/modelos/popup.html', buscarapida: 'modulos/buscarapida/popup.html',
  precatorio: 'modulos/precatorio/popup.html', pendencias: 'modulos/pendencias/popup.html',
  mandados: 'modulos/mandados/popup.html', peticao: 'modulos/peticao/popup.html', cnib: 'modulos/cnib/popup.html' };
const status = document.getElementById('status');

async function executar(acao) {
  if (acao === 'copiardados') return copiarDados();
  if (acao === 'renajud') { location.href = 'modulos/renajud/popup.html'; return; }
  if (PAGINAS[acao]) { location.href = PAGINAS[acao]; return; }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  status.style.color = '#555';
  status.textContent = 'Executando…';
  let copiado = '';
  const r = acao === 'sisbajudresultado'
    ? await chrome.runtime.sendMessage({ tipo: 'SISBAJUD_RESULTADO', tabId: tab.id, numero: copiado }).catch(() => null)
    : await chrome.runtime.sendMessage({ tipo: 'MENU', acao, tabId: tab.id }).catch(() => null);
  const texto = (r && r.texto) || '';
  const ok = /^(Iniciado|✓|Juntadas|Intimação cancelada)/.test(texto);
  status.style.color = ok ? '#2e7d32' : '#b00020';
  status.textContent = texto;
  if (ok && acao !== 'cancelar') setTimeout(() => window.close(), 900);
}

document.querySelectorAll('[data-acao]').forEach((el) =>
  el.addEventListener('click', () => executar(el.dataset.acao)));

document.addEventListener('keydown', (ev) => {
  const acao = TECLAS[ev.key];
  if (acao) { ev.preventDefault(); executar(acao); }
});

// Aberto pela barra de botões: vai direto à página do módulo pedido (uma única vez).
chrome.storage.session.get('paginaInicialMenu').then(({ paginaInicialMenu: p }) => {
  if (!p) return;
  chrome.storage.session.remove('paginaInicialMenu');
  const m = /^popup\.html\?acao=(\w+)$/.exec(p);   // ação do próprio menu (ex.: copiar dados)
  if (m) { executar(m[1]); return; }
  location.href = p;
}).catch(() => {});

// Tecla D — lê os dados nos autos e copia para a área de transferência.
async function copiarDados() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  status.style.color = '#555';
  status.textContent = 'Lendo os dados do processo…';
  try {
    const res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: window.lerDadosProcesso });
    const r = res.map((x) => x.result).filter(Boolean).sort((a, b) => b.partes - a.partes)[0];
    if (!r) throw new Error('Abra os autos do processo no PROJUDI.');
    await navigator.clipboard.writeText(r.texto);
    status.style.color = '#2e7d32';
    status.textContent = `✓ Copiado: ${r.numero} — ${r.partes} parte(s). Cole com Ctrl+V.` +
      (r.partes ? '' : ' (abra a aba Partes e Outros para incluir as partes)');
  } catch (e) {
    status.style.color = '#b00020';
    status.textContent = '✗ ' + e.message;
  }
}
