/* decurso-detalhe.js - tela "Intimação Para ..." (aberta a partir do Decurso de Prazo).
   Resume: quem foi intimado, prazo, se houve cumprimento (manifestação) e a sugestão:
   "Analisar Decurso" ou "Dispensar". Destaca o botão sugerido; o clique é seu.
   Também expõe lerDetalheDecurso(), usada pela lista para conferir as manifestações. */
var lerDetalheDecurso = function (doc) {
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
  const campos = {};
  doc.querySelectorAll('td, th, label, span, div').forEach(el => {
    if (el.children.length > 2) return;
    const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!/[:?]$/.test(t) || t.length > 45) return;
    const prox = el.nextElementSibling;
    if (prox && !(N(t) in campos)) campos[N(t).replace(/:$/, '')] = (prox.textContent || '').replace(/\s+/g, ' ').trim();
  });
  const texto = (doc.body && doc.body.textContent) || '';
  const m = /Intima[cç][aã]o Para\s+([^\n\r]+?)\s{2,}|Intima[cç][aã]o Para\s+(.+?)(?:Processo:|$)/i.exec(texto.replace(/[ \t]+/g, ' '));
  const intimado = m ? (m[1] || m[2] || '').trim() : '';
  const pega = k => campos[N(k)] || '';
  const cumprimento = pega('Data Cumprimento');
  return {
    intimado,
    processo: (/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/.exec(pega('Processo') || texto) || [''])[0],
    dataIntimacao: pega('Data da Intimação'),
    prazo: pega('Prazo Cumprimento'),
    ultimoDia: pega('Último Dia Prazo').replace(/\s*-\s*Detalhamento.*$/i, ''),
    situacao: pega('Situação do prazo'),
    cumprimento,
    manifestou: /\d{2}\/\d{2}\/\d{4}|\d{1,2} de \w+ de \d{4}/i.test(cumprimento),
    pessoal: /SIM/.test(N(pega('Pessoal?'))),
    documento: pega('Documento Relativo'),
    expedicao: pega('Movimento Expedição'),
    leitor: pega('Leitor')
  };
};

(() => {
  if (window.top !== window) return;
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
  const botoes = () => Array.from(document.querySelectorAll('input[type="button"], input[type="submit"], button'));
  const botao = nome => botoes().find(b => N(b.value || b.textContent) === N(nome));
  if (!/Intima[cç][aã]o Para/i.test(document.body.innerText || '') || !botao('Analisar Decurso')) return;

  const d = lerDetalheDecurso(document);
  // A movimentação que gerou o prazo: o "Documento Relativo" (ato intimado) e, na falta, a expedição.
  const origem = d.documento || d.expedicao;
  const r = (typeof REGRAS_DECURSO !== 'undefined' && REGRAS_DECURSO.find(x => x.se.test(N(origem)))) ||
    { cat: 'Não classificada', enc: 'Verificar o processo e dar o andamento cabível.' };
  const soCiencia = /AUDIENCIA|CIENCIA SIMPLES/.test(N(r.cat));
  let sugestao, acao;
  if (d.manifestou) { sugestao = 'Houve cumprimento em ' + d.cumprimento + ': analisar o decurso e dar andamento à manifestação.'; acao = 'Analisar Decurso'; }
  else if (soCiencia) { sugestao = r.enc; acao = 'Dispensar'; }
  else { sugestao = 'Sem cumprimento registrado. ' + r.enc; acao = 'Analisar Decurso'; }

  const alvo = botao(acao);
  if (alvo) { alvo.style.outline = '3px solid #2c7a37'; alvo.style.outlineOffset = '2px'; }

  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;right:16px;top:16px;z-index:2147483647;';
  const raiz = host.attachShadow({ mode: 'open' });
  raiz.innerHTML = `<style>
    .p{font:13px/1.4 "Segoe UI",system-ui,sans-serif;background:#fff;color:#1b2631;border:1px solid #c9d1d8;border-top:3px solid #0f5f73;
       border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.18);padding:10px 12px;width:330px}
    .t{font-weight:700;margin-bottom:6px} dl{display:grid;grid-template-columns:auto 1fr;gap:2px 10px;margin:0 0 8px;font-size:12.5px}
    dt{color:#56626e} dd{margin:0} .ok{color:#2c7a37;font-weight:600} .no{color:#a45a00;font-weight:600}
    .s{background:#e3f3e5;border-left:4px solid #2c7a37;padding:6px 8px;border-radius:4px}
  </style><div class="p"><div class="t">Decurso de prazo</div><dl id="dl"></dl><div class="s" id="s"></div></div>`;
  const dl = raiz.getElementById('dl');
  [['Intimado', d.intimado + (d.pessoal ? ' (pessoal)' : '')], ['Ato', r.cat], ['Intimação', d.dataIntimacao], ['Prazo', d.prazo + (d.ultimoDia ? ' · até ' + d.ultimoDia : '')],
   ['Cumprimento', d.manifestou ? d.cumprimento : 'não registrado']].forEach(([k, v]) => {
    if (!v) return;
    const dt = document.createElement('dt'); dt.textContent = k;
    const dd = document.createElement('dd'); dd.textContent = v;
    if (k === 'Cumprimento') dd.className = d.manifestou ? 'ok' : 'no';
    dl.append(dt, dd);
  });
  raiz.getElementById('s').textContent = sugestao + ' Botão sugerido: "' + acao + '" (destacado em verde).';
  document.body.appendChild(host);
})();
