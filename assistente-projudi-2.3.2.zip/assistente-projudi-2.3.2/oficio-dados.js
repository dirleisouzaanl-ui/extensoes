/* oficio-dados.js - critérios da skill oficios-judiciais (classificação em tipos e campos por tipo),
   usados pelo roteiro (lê a decisão) e pela tela de edição do ofício. */
var OficioSkill = (() => {
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();

  // Classificação (skill, Etapa 2) + tipos de informação usados na vara.
  function classificar(trecho) {
    const t = N(trecho);
    if (/PENHORA NO ROSTO/.test(t)) return 'PENHORA_ROSTO';
    if (/(CANCEL|CESS|SUSPEN|EXCLU)\w*\s+(?:(?:O|A|OS|AS|D[OA]S?)\s+)?(DESCONTO|CONSIGNA)/.test(t) || /(DESCONTO|CONSIGNACAO)\w*\s+\w*\s*(CANCELAD|CESSAD)/.test(t)) return 'CANCELAMENTO';
    if (/DESCONTO|CONSIGNA/.test(t) && /BENEFICIO|INSS|APOSENTADORIA|PENSAO/.test(t)) return 'INSS_DESCONTO';
    if (/DESCONTO|FOLHA DE PAGAMENTO/.test(t) && /EMPRESA|EMPREGADOR|SALARIO|FOLHA|VENCIMENTOS|REMUNERACAO/.test(t)) return 'FOLHA';
    if (/CNIS|INSS|PREVJUD/.test(t)) return 'INSS_CNIS';
    if (/VEICULO|RENAVAM|PLACA|DETRAN/.test(t) && /ALIENACAO FIDUCIARIA|ALIENANTE|CREDOR FIDUCIARIO/.test(t) && !/DETRAN/.test(t)) return 'ALIENADORA';
    if (/VEICULO|RENAVAM|PLACA|DETRAN/.test(t)) return 'DETRAN';
    if (/PROTESTO|TABELIONATO|TABELIAO/.test(t)) return 'TABELIONATO';
    if (/SERASA/.test(t)) return /EXCLU|BAIXA|RETIRADA/.test(t) ? 'SERASA_EXC' : 'SERASA_INC';
    if (/\bSPC\b/.test(t)) return 'SPC';
    if (/SCPC|BOA VISTA/.test(t)) return 'SCPC';
    if (/CLARO|EMBRATEL|\bNET\b/.test(t)) return 'CLARO';
    if (/\bTIM\b/.test(t)) return 'TIM';
    if (/\bVIVO\b|GVT/.test(t)) return 'VIVO';
    if (/\bOI\b/.test(t)) return 'OI';
    if (/NAT-?JUS|NOTA TECNICA/.test(t)) return 'NATJUS';
    if (/CONTA JUDICIAL|CAIXA ECONOMICA|\bCEF\b|TRANSFERENCIA D[OE]S? VALOR/.test(t)) return 'CEF';
    return 'GENERICO';
  }

  // Extração (skill, Etapa 3): só o que está escrito na decisão; nada é presumido.
  function extrair(trecho, processoAtual) {
    const t = N(trecho), c = {};
    const m = (re, i) => { const r = re.exec(t); return r ? (r[i || 1] || '').trim() : ''; };
    c.PERCENTUAL = m(/(\d{1,2}(?:,\d{1,2})?)\s*%/) || m(/(\d{1,2}) POR CENTO/);
    c.VALOR = m(/(?:DEBITO|VALOR|QUANTIA|IMPORTANCIA|TOTAL|MONTANTE)[^R]{0,40}R\$\s*([\d.]+,\d{2})/) || m(/R\$\s*([\d.]+,\d{2})/);
    c.PLACA = m(/\b([A-Z]{3}-?\d[A-Z0-9]\d{2})\b/);
    c.RENAVAM = m(/RENAVAM\D{0,12}(\d{9,11})/);
    c.BENEFICIO = m(/BENEFICIO[^0-9]{0,30}(\d{3}[\d.\-\/]{5,})/) || m(/\bNB\D{0,5}(\d[\d.\-\/]{6,})/);
    c.CONTA_JUDICIAL = m(/CONTA JUDICIAL[^0-9]{0,15}([\d.\-\/]{4,})/);
    c.AGENCIA = m(/AGENCIA[^0-9]{0,8}(\d{3,5})/);
    c.CNPJ_EMPRESA = m(/(?:EMPRESA|EMPREGADOR|EMPREGADORA)[^0-9]{0,80}(\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2})/);
    c.EMPRESA = m(/(?:EMPRESA|EMPREGADORA?)\s+([A-Z0-9 .&\-]{3,80}?(?:LTDA|S\/A|S\.A\.?|EIRELI|\bME\b|EPP))/);
    const outros = (t.match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/g) || []).filter(p => p !== processoAtual);
    c.PROC_DESTINO = /PENHORA NO ROSTO/.test(t) ? (outros[0] || '') : '';
    c.TABELIONATO = m(/(\d+\s*º?\s*TABELIONATO[^,.;]{0,60})/) || m(/(TABELIONATO DE PROTESTO[^,.;]{0,60})/);
    c.MOTIVO = m(/EM RAZAO D[AEO]S?\s+([^,.;]{3,80})/) || (/QUITACAO/.test(t) ? 'quitação do débito' : '');
    if (/VEICULO|RENAVAM|PLACA|DETRAN/.test(t)) {
      const r = m(/RESTRICAO (?:DE |DO TIPO )?(TRANSFERENCIA|PENHORA|CIRCULACAO|LICENCIAMENTO|ALIENACAO FIDUCIARIA)/);
      c.RESTRICAO = { TRANSFERENCIA: 'transferência', PENHORA: 'penhora', 'ALIENACAO FIDUCIARIA': 'alienação fiduciária' }[r] || '';
      if (/(CANCEL|BAIXA|RETIRADA|LEVANTAMENTO|LIBERACAO)\w*\s+(?:D[AO]S?\s+)?(RESTRIC|BLOQUEIO|PENHORA)/.test(t)) c.ACAO_VEICULO = 'o cancelamento';
    }
    Object.keys(c).forEach(k => { if (!c[k]) delete c[k]; });
    return c;
  }

  // Trecho determinante: frase com "oficie-se/expeça-se ofício" e a seguinte.
  function trechoDeterminante(textoN) {
    const frases = textoN.split(/(?<=[.;])\s+/);
    const i = frases.findIndex(f => /OFICI|DESCONTO|PENHORA NO ROSTO/.test(f));
    return i < 0 ? '' : frases.slice(i, i + 2).join(' ');
  }

  // Valores e percentuais por extenso (skill: "sempre em algarismos e por extenso").
  const U = ['zero', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez', 'onze', 'doze', 'treze', 'quatorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'];
  const D = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
  const C = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
  function ate999(n) {
    if (n === 100) return 'cem';
    const c = Math.floor(n / 100), r = n % 100, p = [];
    if (c) p.push(C[c]);
    if (r) p.push(r < 20 ? U[r] : D[Math.floor(r / 10)] + (r % 10 ? ' e ' + U[r % 10] : ''));
    return p.join(' e ');
  }
  function inteiro(n) {
    if (n === 0) return 'zero';
    const n0 = n;
    const grupos = [['', ''], ['mil', 'mil'], ['milhão', 'milhões'], ['bilhão', 'bilhões']];
    const partes = []; let i = 0;
    while (n > 0) {
      const g = n % 1000;
      if (g) {
        const nome = i === 0 ? '' : (i === 1 ? 'mil' : (g === 1 ? grupos[i][0] : grupos[i][1]));
        partes.unshift(i === 1 && g === 1 ? 'mil' : (ate999(g) + (nome ? ' ' + nome : '')));
      }
      n = Math.floor(n / 1000); i++;
    }
    // "e" só antes do último grupo quando ele é menor que cem ou é centena redonda (mil e quinhentos; nove mil cento e treze).
    const ultimoGrupo = n0 % 1000;
    let s = partes[0];
    for (let k = 1; k < partes.length; k++) {
      const ultimo = k === partes.length - 1;
      s += (ultimo && (ultimoGrupo < 100 || ultimoGrupo % 100 === 0) ? ' e ' : ' ') + partes[k];
    }
    return s;
  }
  function reais(txt) {
    const v = String(txt || '').replace(/[^\d,]/g, '');
    if (!v) return '';
    const [r, c = '0'] = v.split(',');
    const nr = parseInt(r, 10) || 0, nc = parseInt((c + '0').slice(0, 2), 10) || 0;
    const fmt = nr.toLocaleString('pt-BR') + ',' + String(nc).padStart(2, '0');
    let ext = nr ? inteiro(nr) + (nr === 1 ? ' real' : (nr % 1000000 === 0 ? ' de reais' : ' reais')) : '';
    if (nc) ext += (ext ? ' e ' : '') + inteiro(nc) + (nc === 1 ? ' centavo' : ' centavos');
    return 'R$ ' + fmt + ' (' + (ext || 'zero reais') + ')';
  }
  function percentual(txt) {
    const v = String(txt || '').replace('%', '').trim();
    if (!v) return '';
    const [i, d] = v.split(',');
    return v + '% (' + inteiro(parseInt(i, 10) || 0) + (d ? ' vírgula ' + inteiro(parseInt(d, 10)) : '') + ' por cento)';
  }
  return { classificar, extrair, trechoDeterminante, reais, percentual, extensoInteiro: inteiro, N };
})();
