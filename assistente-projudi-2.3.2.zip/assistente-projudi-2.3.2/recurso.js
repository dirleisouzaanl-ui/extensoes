/* recurso.js - aba Movimentações: certidão de preparo do recurso inominado,
   com o cálculo e o modelo da skill prazo-juizado-tjpr (calendario.js).
   Localiza recurso, decisão recorrida, DJEN e leitura do recorrente; conta o prazo de
   10 dias úteis pela leitura e pelo DJEN (vale o que vencer primeiro); confere o preparo
   (48 horas, gratuidade, Fazenda Pública) e monta a certidão. O PROJUDI serve de conferência. */
(() => {
  if (window.top !== window) return;
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
  const DATA = /(\d{2}\/\d{2}\/\d{4})(?:\s+(\d{2}:\d{2}))?/;
  const dormir = ms => new Promise(r => setTimeout(r, ms));
  const txt = el => ((el && (el.innerText != null ? el.innerText : el.textContent)) || '').trim();
  const soData = s => (DATA.exec(s || '') || [''])[0].slice(0, 10);
  const hora = s => (/\d{2}\/\d{2}\/\d{4}\s+(\d{2}:\d{2})/.exec(s || '') || [])[1] || '';
  const FAZENDA = /ESTADO D[OE]|MUNICIPIO|PREFEITURA|UNIAO|FAZENDA|AUTARQUIA|PARANAPREVIDENCIA|INSTITUTO|DETRAN|DEPARTAMENTO DE|PROCURADORIA/;
  const PRAZO = 10;

  /* ---------- movimentações ---------- */
  const ehLinha = tr => { const c = tr.querySelectorAll(':scope > td'); return c.length >= 4 && parseInt(txt(c[1]), 10) > 0; };
  function tabela() {
    const cab = Array.from(document.querySelectorAll('tr')).find(tr => {
      const t = N(txt(tr));
      return /\bSEQ\b/.test(t) && /\bDATA\b/.test(t) && /\bEVENTO\b/.test(t) && /MOVIMENTADO POR/.test(t) && t.length < 120;
    });
    if (!cab) return null;
    const corpo = cab.closest('table');
    const linhas = [];
    Array.from(corpo.querySelectorAll(':scope > tbody > tr, :scope > tr')).forEach(tr => {
      if (tr === cab) return;
      if (!ehLinha(tr)) { if (linhas.length) linhas[linhas.length - 1].detalhes.push(tr); return; }
      const c = tr.querySelectorAll(':scope > td');
      const ev = txt(c[3]).split('\n').map(s => s.trim()).filter(Boolean);
      const por = txt(c[4]).split('\n').map(s => s.trim()).filter(Boolean);
      linhas.push({ tr, seq: parseInt(txt(c[1]), 10), data: txt(c[2]), titulo: ev[0] || '', descricao: ev.slice(1).join(' '), por: por[0] || '', papel: por[1] || '', toggle: c[0], detalhes: [] });
    });
    return linhas;
  }
  async function expandir(l, marca) {
    const visivel = d => d.style.display !== 'none' && !d.hidden && getComputedStyle(d).display !== 'none';
    const releia = () => { l.detalhes = []; let s = l.tr.nextElementSibling; while (s && !ehLinha(s)) { l.detalhes.push(s); s = s.nextElementSibling; } };
    const tem = () => l.detalhes.some(d => visivel(d) && marca.test(N(txt(d))));
    releia();
    if (tem()) return true;
    (l.toggle.querySelector('a, img, span, input') || l.toggle).click();
    for (let i = 0; i < 24; i++) { await dormir(250); releia(); if (tem()) return true; }
    return false;
  }
  const arquivos = l => l.detalhes.flatMap(d => Array.from(d.querySelectorAll('a')).map(txt)).filter(t => /\.\w{3,4}$/i.test(t));

  function poloDe(t) {
    for (let el = t, nivel = 0; el && nivel < 4; el = el.parentElement, nivel++) {
      for (let p = el.previousElementSibling; p; p = p.previousElementSibling) {
        const s = txt(p);
        if (s && s.length < 40 && !/\d/.test(s)) return s;
        if (p.querySelector && p.querySelector('table')) break;
      }
    }
    return '';
  }
  function intimacoes(l) {
    const res = [];
    l.detalhes.forEach(d => d.querySelectorAll('table').forEach(t => {
      const linhas = Array.from(t.querySelectorAll('tr'));
      const cab = linhas.find(tr => /DATA DE LEITURA/.test(N(txt(tr))));
      if (!cab) return;
      const polo = poloDe(t);
      const nomes = Array.from(cab.querySelectorAll('th, td')).map(c => N(txt(c)));
      const i = n => nomes.findIndex(x => x.includes(n));
      linhas.filter(tr => tr !== cab && tr.querySelectorAll('td').length >= nomes.length - 1).forEach(tr => {
        const c = Array.from(tr.querySelectorAll('td')).map(txt);
        if (!c[i('NOME')]) return;
        res.push({ polo, nome: c[i('NOME')], prazo: c[i('PRAZO')], leitura: c[i('LEITURA')], cumprimento: c[i('CUMPRIMENTO')], decurso: c[i('DECURSO')], status: c[i('STATUS')], leitor: c[i('LEITOR')] });
      });
    }));
    return res;
  }

  /* ---------- análise ---------- */
  async function analisar(seqInformado) {
    const linhas = tabela();
    if (!linhas || !linhas.length) return { erro: 'Abra a aba Movimentações do processo.' };
    const notas = [];
    let rec = seqInformado ? linhas.find(l => l.seq === seqInformado)
      : linhas.find(l => /RECURSO INOMINADO|INTERPOSICAO DE RECURSO|INTERPOSTO RECURSO/.test(N(l.titulo + ' ' + l.descricao)));
    if (!rec) {
      for (const l of linhas.slice(0, 20).filter(l => /JUNTADA DE PETICAO/.test(N(l.titulo)))) {
        await expandir(l, /ARQUIVO/);
        if (arquivos(l).some(a => /RECURSO/.test(N(a)) && !/CONTRARRAZ/.test(N(a)))) { rec = l; break; }
      }
    }
    if (!rec) return { erro: 'Não localizei o recurso. Informe o seq. da juntada do recurso.' };
    await expandir(rec, /ARQUIVO/);

    // Decisão recorrida
    const ref = /REFERENTE AO EVENTO\s+(.+?)\s*\((\d{2}\/\d{2}\/\d{4})\)/.exec(N(rec.descricao));
    let dec = ref ? linhas.find(l => l.seq < rec.seq && N(l.titulo).includes(ref[1].trim()) && l.data.startsWith(ref[2])) : null;
    if (!dec) dec = linhas.find(l => l.seq < rec.seq && /SENTENCA|JULGAD|HOMOLOGAD|PROCEDENTE|IMPROCEDENTE|EXTINT/.test(N(l.titulo)) && /MAGISTRADO|JUIZ/.test(N(l.papel)));
    if (!dec) notas.push('decisão recorrida não identificada');
    const djen = dec ? ((/DJEN EM (\d{2}\/\d{2}\/\d{4})/.exec(N(dec.descricao)) || [])[1] || '') : '';

    // Leitura do recorrente
    let int = null, confSeq = null, todas = [];
    if (dec) {
      const rel = linhas.filter(l => l.seq > dec.seq && new RegExp('\\(SEQ\\.? ' + dec.seq + '\\)').test(N(l.descricao)) && /INTIMACAO/.test(N(l.titulo)));
      const alvo = rel.find(l => /CONFIRMADA/.test(N(l.titulo))) || rel[0];
      if (alvo && await expandir(alvo, /DATA DE LEITURA/)) {
        confSeq = /CONFIRMADA/.test(N(alvo.titulo)) ? alvo.seq : null;
        todas = intimacoes(alvo);
        const dRec = (DATA.exec(rec.data) || [''])[0];
        int = todas.find(x => x.cumprimento && dRec && x.cumprimento.replace(/\s+/g, ' ').startsWith(dRec.slice(0, 16)))
          || todas.find(x => rec.por && N(x.leitor).includes(N(rec.por))) || null;
        if (!int) notas.push('recorrente não identificado na intimação (seq. ' + alvo.seq + '): conferir');
      } else notas.push('intimação da decisão não localizada: contagem só pelo DJEN');
    }
    const recorrente = int ? int.nome : '';
    const poloRec = int ? int.polo : '';
    const recorridos = int ? [...new Set(todas.filter(x => x.polo && x.polo !== int.polo).map(x => x.nome))] : [];

    // Prazo (skill): pela leitura e pelo DJEN; vale o que vencer primeiro
    const leitura = int ? soData(int.leitura) : '';
    const pL = leitura ? PrazoJE.calcular(PRAZO, 'inicio', leitura) : null;
    const pD = djen ? PrazoJE.calcular(PRAZO, 'djen', djen) : null;
    const usado = pL && pD ? (pL.vencimentoData <= pD.vencimentoData ? pL : pD) : (pL || pD);
    const coincidem = pL && pD && pL.vencimento === pD.vencimento;
    const dInterp = PrazoJE.parse(rec.data);
    let tempestivo = null, antesInicio = false;
    if (usado && dInterp) {
      tempestivo = dInterp <= usado.vencimentoData;
      antesInicio = dInterp <= PrazoJE.parse(usado.inicio);
    }
    // Conferência com o PROJUDI
    let projudi = null;
    if (int) {
      const dec2 = PrazoJE.parse(int.decurso);
      if (/CUMPRIDA/.test(N(int.status)) && !dec2) projudi = true;
      else if (dec2) projudi = dInterp <= dec2;
    }
    if (projudi !== null && tempestivo !== null && projudi !== tempestivo) notas.push('o PROJUDI indica ' + (projudi ? 'cumprimento no prazo' : 'decurso antes do recurso') + ', diferente do cálculo: conferir');

    // Preparo
    const fazenda = /PROCURADOR/.test(N(rec.papel)) || FAZENDA.test(N(recorrente));
    const limite = dInterp ? new Date(dInterp.getTime() + 48 * 3600000) : null;
    if (limite && hora(rec.data)) { const [h, m] = hora(rec.data).split(':'); limite.setHours(+h, +m); }
    const lim48 = limite ? { data: PrazoJE.br(limite), hora: hora(rec.data) } : null;
    const grat = linhas.find(l => /GRATUIDADE|JUSTICA GRATUITA|ASSISTENCIA JUDICIARIA/.test(N(l.titulo + ' ' + l.descricao)) && /DEFERID|CONCEDID/.test(N(l.titulo + ' ' + l.descricao)));
    const guiaMov = linhas.find(l => l.seq >= rec.seq - 3 && /PAGAMENTO DE GUIA|GUIA DE RECOLHIMENTO|PREPARO/.test(N(l.titulo + ' ' + l.descricao)));
    let guiaArq = null;
    for (const l of linhas.filter(l => l.seq >= rec.seq && l.seq <= rec.seq + 3)) {
      await expandir(l, /ARQUIVO/);
      const a = arquivos(l).find(a => /GUIA|PREPARO|COMPROVANTE|CUSTAS|FUNJUS|RECOLHIMENTO/.test(N(a)));
      if (a) { guiaArq = { seq: l.seq, nome: a }; break; }
    }
    const pagaEm = guiaMov ? ((/(?:PAG[OA]|PAGAMENTO)[^0-9]{0,20}(\d{2}\/\d{2}\/\d{4})/.exec(N(guiaMov.descricao)) || [])[1] || '') : '';
    let preparo;
    if (fazenda) preparo = { tipo: 'fazenda', resumo: 'Fazenda Pública: dispensada do preparo', ok: true };
    else if (guiaMov || guiaArq) preparo = { tipo: 'recolhido', resumo: 'guia/comprovante: ' + [guiaArq && 'mov. ' + guiaArq.seq + ' (' + guiaArq.nome + ')', guiaMov && 'mov. ' + guiaMov.seq + ' (' + guiaMov.titulo.toLowerCase() + ')'].filter(Boolean).join('; ') + ' — conferir nº, valor e data (até ' + (lim48 ? lim48.data + ' ' + lim48.hora : '48 h') + ')', ok: null };
    else if (grat) preparo = { tipo: 'gratuidade', resumo: 'gratuidade deferida no mov. ' + grat.seq + ': conferir se alcança o recorrente', ok: null };
    else preparo = { tipo: 'nao', resumo: 'sem guia nem gratuidade localizadas; prazo de 48 h até ' + (lim48 ? lim48.data + ' ' + lim48.hora : '?'), ok: false };

    return { rec, dec, djen, int, confSeq, recorrente, poloRec, recorridos, leitura, pL, pD, usado, coincidem, tempestivo, antesInicio, projudi,
      fazenda, lim48, grat, guiaMov, guiaArq, pagaEm, preparo, notas };
  }

  /* ---------- certidão (modelo da skill) ---------- */
  function certidao(r) {
    const cab = txt(document.body);
    const autos = (/Processo\s+(\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4})/.exec(cab) || /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/.exec(cab) || [])[1] || (/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/.exec(cab) || ['[NÚMERO]'])[0];
    const usuario = ((/Usu[aá]rio:\s*([^\n\t]+)/.exec(cab) || [])[1] || '').replace(/\s*Atribui.*$/, '').trim() || 'Dirlei de Souza';
    const cargo = ((/Atribui[cç][aã]o:\s*([^(\n\t]+)/.exec(cab) || [])[1] || '').trim() || 'Analista Judiciário';
    const comarca = ((/Atua[cç][aã]o:[^\n]*? de ([A-ZÁÉÍÓÚÂÊÔÃÕÇ][^\n\t]+?)(?:\s{2,}|\n|\t|$)/.exec(cab) || [])[1] || 'Assis Chateaubriand').trim();
    const ehSent = r.dec && /SENTENCA|JULGAD|PROCEDENTE|IMPROCEDENTE|EXTINT|HOMOLOGAD/.test(N(r.dec.titulo));
    const tipo = r.dec ? (ehSent ? 'sentença' : 'decisão') : '[sentença/decisão]';
    const art = tipo === 'sentença' || tipo === 'decisão' ? 'a' : '[a]';
    const polo = r.poloRec ? r.poloRec.toLowerCase() : '';
    // Gênero só quando o nome deixa claro (entes públicos e pessoas jurídicas comuns); senão, colchetes.
    const nr = N(r.recorrente);
    const g = /^(ESTADO|MUNICIPIO|INSTITUTO|DEPARTAMENTO|BANCO|CONDOMINIO)/.test(nr) ? 'o' : /^(PREFEITURA|UNIAO|FAZENDA|AUTARQUIA|CAIXA|EMPRESA|COMPANHIA|SOCIEDADE|COOPERATIVA)/.test(nr) ? 'a' : null;
    const papelPolo = polo ? (/REQUERID|RECLAMAD|REU/.test(N(polo)) ? 'requerid' : /EXECUTAD/.test(N(polo)) ? 'executad' : /EXEQUENTE/.test(N(polo)) ? 'exequente' : 'requerente') : '';
    const flex = (base, gg) => /ENTE$/.test(base.toUpperCase()) ? base : base + (gg || '[o/a]');
    const qual = papelPolo ? (g ? g + ' ' + flex(papelPolo, g) : '[o/a] ' + flex(papelPolo, null)) : '[o requerente/a requerida]';
    const oa = g || '[o/a]', OA = g ? g : '[o/a]';
    const repr = /PROCURADOR/.test(N(r.rec.papel)) ? 'por seu procurador ' + r.rec.por : 'por seu advogado ' + (r.rec.por || '[NOME]') + ' (OAB/[UF] [Nº])';
    const L = [];
    L.push('CERTIDÃO DE PREPARO', '', 'Autos nº ' + autos, 'Recorrente: ' + (r.recorrente || '[NOME]'), 'Recorrido: ' + (r.recorridos.length ? r.recorridos.join('; ') : '[NOME]'), '');
    L.push('Certifico, para os devidos fins, que em ' + soData(r.rec.data) + ', às ' + (hora(r.rec.data) || '[HORA]') + ', ' + qual + ' ' + (r.recorrente || '[NOME]') + ', ' + repr +
      ', interpôs Recurso Inominado (mov. ' + r.rec.seq + ') contra ' + art + ' ' + tipo + ' de mov. ' + (r.dec ? r.dec.seq : '[Nº]') + ', proferida em ' + (r.dec ? soData(r.dec.data) : '[DATA]') + '.');
    L.push('');
    const pub = r.pD ? r.pD.publicacao : '[DATA]';
    const vinc = 'Certifico que ' + art + ' referid' + art + ' ' + tipo + ' foi veiculad' + art + ' no DJEN em ' + (r.djen || '[DATA]') + ', considerando-se publicad' + art + ' em ' + pub;
    L.push(r.leitura ? vinc + ', e que ' + OA + ' recorrente foi intimad' + oa + ' eletronicamente em ' + r.leitura + ', com leitura confirmada no mov. ' + (r.confSeq || '[Nº]') + '.'
      : vinc + ', e que ' + OA + ' recorrente foi intimad' + oa + ' pela publicação no DJEN.');
    L.push('');
    const u = r.usado;
    let t = 'Certifico que o prazo recursal de 10 (dez) dias úteis teve início em ' + (u ? u.inicio : '[DATA]') + ' e término em ' + (u ? u.vencimento : '[DATA]') + ', sendo o recurso ';
    t += r.tempestivo === false ? 'INTEMPESTIVO.' : r.tempestivo === true ? 'TEMPESTIVO' + (r.antesInicio ? ', pois interposto antes do início da contagem (art. 218, § 4º, do CPC).' : '.') : '[TEMPESTIVO/INTEMPESTIVO].';
    L.push(t, '');
    const p = r.preparo;
    if (p.tipo === 'recolhido') L.push('Certifico, ainda, que o preparo recursal foi devidamente recolhido, mediante a Guia de Recolhimento nº [Nº], no valor de R$ [VALOR], paga em ' + (r.pagaEm || '[DATA]') + ' (mov. ' + (r.guiaArq ? r.guiaArq.seq : '[Nº]') + '), com pagamento confirmado pelo sistema no mov. ' + (r.guiaMov ? r.guiaMov.seq : '[Nº]') + '.');
    else if (p.tipo === 'gratuidade') L.push('Certifico, ainda, que ' + OA + ' recorrente é beneficiári' + oa + ' da gratuidade da justiça, deferida no mov. ' + r.grat.seq + ', estando dispensad' + oa + ' do preparo.');
    else if (p.tipo === 'fazenda') L.push('Certifico, ainda, que ' + OA + ' recorrente, por se tratar de Fazenda Pública, está dispensad' + oa + ' do preparo recursal. [CONFERIR: alternativa fora do modelo]');
    else L.push('Certifico, ainda, que não houve recolhimento do preparo recursal. O prazo de 48 (quarenta e oito) horas previsto no art. 42, § 1º, da Lei nº 9.099/1995 encerrou-se em ' + (r.lim48 ? r.lim48.data + ', às ' + r.lim48.hora : '[DATA], às [HORA]') + ', sem comprovação de pagamento.');
    L.push('', 'O referido é verdade e dou fé.', '', comarca + ', data da assinatura digital.', '', usuario, cargo);
    return L.join('\n');
  }

  /* ---------- quadro ---------- */
  let host = null, resultado = null, ocupado = false;
  function desenhar(msg) {
    if (!host) {
      host = document.createElement('div');
      host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;';
      host.attachShadow({ mode: 'open' });
      document.body.appendChild(host);
    }
    const raiz = host.shadowRoot;
    const min = raiz.getElementById('p') && raiz.getElementById('p').classList.contains('min');
    raiz.innerHTML = `<style>
      .p{font:13px/1.4 "Segoe UI",system-ui,sans-serif;background:#fff;color:#1b2631;border:1px solid #c9d1d8;border-top:3px solid #6b3fa0;
         border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.18);padding:10px 12px;width:420px;max-height:82vh;overflow:auto}
      .t{display:flex;justify-content:space-between;font-weight:700;margin-bottom:6px}
      dl{display:grid;grid-template-columns:auto 1fr;gap:3px 10px;margin:0 0 8px;font-size:12.5px} dt{color:#56626e} dd{margin:0}
      .ok{color:#2c7a37;font-weight:600} .no{color:#b42318;font-weight:600} .q{color:#a45a00;font-weight:600}
      textarea{width:100%;box-sizing:border-box;height:230px;font:12px/1.45 "Segoe UI",system-ui,sans-serif;border:1px solid #d3d9de;border-radius:6px;padding:6px}
      button{font:inherit;font-weight:600;padding:5px 10px;border-radius:6px;border:1px solid #6b3fa0;background:#6b3fa0;color:#fff;cursor:pointer;margin:6px 6px 0 0}
      button.s{background:#fff;color:#6b3fa0} input{width:60px;font:inherit;padding:3px 5px}
      .n{font-size:12px;color:#a45a00;margin:4px 0} .min .c{display:none} .min{width:auto}
    </style><div class="p${min ? ' min' : ''}" id="p"><div class="t"><span>Certidão de preparo recursal</span><span id="min" style="cursor:pointer">${min ? '+' : '–'}</span></div><div class="c" id="c"></div></div>`;
    const c = raiz.getElementById('c');
    if (msg) { const d = document.createElement('div'); d.className = 'n'; d.textContent = msg; c.appendChild(d); }
    const r = resultado;
    if (r && !r.erro) {
      const dl = document.createElement('dl');
      const linha = (k, v, cls) => { const dt = document.createElement('dt'); dt.textContent = k; const dd = document.createElement('dd'); dd.textContent = v; if (cls) dd.className = cls; dl.append(dt, dd); };
      linha('Recurso', 'mov. ' + r.rec.seq + ' · ' + r.rec.data.slice(0, 16) + ' · ' + (r.rec.por || ''));
      linha('Recorrente', (r.recorrente || '?') + (r.poloRec ? ' (' + r.poloRec.toLowerCase() + ')' : '') + (r.fazenda ? ' · Fazenda Pública' : ''));
      linha('Decisão', r.dec ? 'mov. ' + r.dec.seq + ' · ' + soData(r.dec.data) : 'não identificada', r.dec ? '' : 'q');
      linha('DJEN', r.djen ? r.djen + ' · publicação ' + (r.pD ? r.pD.publicacao : '') : 'não informado', r.djen ? '' : 'q');
      linha('Leitura', r.leitura ? r.leitura + (r.confSeq ? ' · mov. ' + r.confSeq : '') : 'não localizada', r.leitura ? '' : 'q');
      if (r.pL) linha('Pela leitura', 'vence ' + r.pL.vencimento + ' (' + r.pL.diaSemana + ')');
      if (r.pD) linha('Pelo DJEN', 'vence ' + r.pD.vencimento + ' (' + r.pD.diaSemana + ')');
      if (r.usado) linha('Prazo usado', 'início ' + r.usado.inicio + ' · término ' + r.usado.vencimento + (r.pL && r.pD ? (r.coincidem ? ' · coincidem' : ' · vale o que vence primeiro') : ''));
      if (r.usado && r.usado.pulados.length) linha('Dias não úteis', r.usado.pulados.join('; '));
      linha('Tempestividade', r.tempestivo === true ? 'TEMPESTIVO' + (r.antesInicio ? ' (antes do início, art. 218, § 4º, CPC)' : '') : r.tempestivo === false ? 'INTEMPESTIVO' : 'conferir',
        r.tempestivo === true ? 'ok' : r.tempestivo === false ? 'no' : 'q');
      if (r.projudi !== null) linha('PROJUDI', r.projudi ? 'cumprida antes do decurso' : 'decurso anterior ao recurso', r.projudi === r.tempestivo ? '' : 'q');
      linha('Preparo', r.preparo.resumo, r.preparo.ok === true ? 'ok' : r.preparo.ok === false ? 'no' : 'q');
      c.appendChild(dl);
      [...r.notas, ...((r.usado && r.usado.avisos) || [])].forEach(n => { const d = document.createElement('div'); d.className = 'n'; d.textContent = '⚠ ' + n; c.appendChild(d); });
      const ta = document.createElement('textarea'); ta.value = certidao(r); c.appendChild(ta);
      const nb = document.createElement('div'); nb.className = 'n'; nb.textContent = 'Complete os trechos entre colchetes antes de juntar.'; c.appendChild(nb);
      const b = document.createElement('button'); b.textContent = 'Copiar certidão';
      b.addEventListener('click', async () => { try { await navigator.clipboard.writeText(ta.value); } catch (e) { ta.select(); document.execCommand('copy'); } b.textContent = '✔ Copiada'; });
      c.appendChild(b);
      if (r.usado) { const k = document.createElement('button'); k.className = 's'; k.textContent = 'Abrir calculadora'; k.addEventListener('click', () => window.open(r.usado.link, '_blank')); c.appendChild(k); }
      const pend = Array.from(document.querySelectorAll('a')).find(a => /Certid[aã]o de Preparo Recursal/i.test(txt(a)));
      if (pend) { const p = document.createElement('button'); p.className = 's'; p.textContent = 'Abrir pendência'; p.addEventListener('click', () => pend.click()); c.appendChild(p); }
    }
    const lin = document.createElement('div'); lin.style.marginTop = '8px';
    const lb = document.createElement('span'); lb.textContent = 'Seq. do recurso: ';
    const inp = document.createElement('input'); inp.placeholder = 'auto'; inp.value = r && r.rec ? r.rec.seq : '';
    const go = document.createElement('button'); go.className = 's'; go.textContent = ocupado ? 'Analisando...' : (r ? 'Refazer' : 'Analisar');
    go.disabled = ocupado;
    go.addEventListener('click', () => iniciar(parseInt(inp.value, 10) || null));
    lin.append(lb, inp, go); c.appendChild(lin);
    raiz.getElementById('min').addEventListener('click', () => { raiz.getElementById('p').classList.toggle('min'); });
  }
  async function iniciar(seq) {
    if (ocupado) return;
    ocupado = true; desenhar('Lendo as movimentações...');
    try { resultado = await analisar(seq); } catch (e) { resultado = { erro: (e && e.message) || String(e) }; }
    ocupado = false;
    desenhar(resultado && resultado.erro ? resultado.erro : '');
  }
  let feito = false, espera = null;
  function verificar() {
    if (feito) return;
    const t = txt(document.body);
    if (!/Movimentado Por/i.test(t) || !/Certid[aã]o de Preparo Recursal|RECURSO INOMINADO/i.test(t)) return;
    feito = true; iniciar(null);
  }
  verificar();
  new MutationObserver(() => { clearTimeout(espera); espera = setTimeout(verificar, 500); }).observe(document.body, { childList: true, subtree: true });
})();
