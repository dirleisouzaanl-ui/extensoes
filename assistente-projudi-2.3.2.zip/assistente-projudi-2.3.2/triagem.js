/* triagem.js - marca cada linha da Análise de Juntadas com a classificação sugerida,
   lê as petições (PDF) quando pedido e marca lotes por categoria.
   Não analisa nem dispensa nada sozinho: os botões do PROJUDI continuam com você. */
(() => {
  const CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
  const dormir = ms => new Promise(r => setTimeout(r, ms));
  const CORES = {
    vermelho: ['#b42318', '#fde7e4'], roxo: ['#6b3fa0', '#efe7f8'], verde: ['#2c7a37', '#e3f3e5'],
    azul: ['#1a5fa8', '#e3eefb'], laranja: ['#a45a00', '#fdf0de'], cinza: ['#56626e', '#eef1f3']
  };
  const PAPEIS = /(ADVOGAD[OA]|PARTE|MINISTERIO PUBLICO|DEFENSOR\w*|PROCURADOR\w*|SERVIDOR\w*|MAGISTRAD[OA]|PERIT[OA]|OFICIAL DE JUSTICA)/;
  let filtro = null, agendado = null, lendo = false, aviso = '';
  const lidos = new Map();   // chave da linha -> { regra, trecho } | { erro }

  const ehTela = () => /An[aá]lise de Juntadas/i.test((document.body && document.body.innerText) || '');

  function classificar(titulo, descricao) {
    const t = N(titulo), d = N(descricao), tudo = t + ' ' + d;
    for (const r of REGRAS_TRIAGEM) {
      const alvo = r.em === 'titulo' ? t : r.em === 'descricao' ? d : tudo;
      if (r.se.test(alvo)) return r;
    }
    return { cat: 'Não classificada', cor: 'cinza', enc: 'Ler a petição e classificar manualmente.' };
  }

  function audienciaProxima(texto) {
    const m = /AUDI[EÊ]NCIA[^()]*\((\d{2})\/(\d{2})\/(\d{4})/i.exec(texto || '');
    if (!m) return null;
    const dias = Math.ceil((new Date(+m[3], +m[2] - 1, +m[1]) - new Date()) / 86400000);
    return dias >= 0 && dias <= 15 ? dias : null;
  }

  const ehLinhaDados = tr => {
    if (tr.querySelector('tr')) return false;
    return tr.querySelectorAll(':scope > td').length >= 5 && CNJ.test(tr.innerText || '') && !!tr.querySelector('input[type="checkbox"]');
  };
  const linhasDaTabela = () => Array.from(document.querySelectorAll('tr')).filter(ehLinhaDados);

  function celulaTipo(tr) {
    const cels = Array.from(tr.querySelectorAll(':scope > td'));
    return cels.filter(c => /^[A-ZÇÃÁÉÍÓÚÂÊÔ\s]{8,}/.test((c.innerText || '').trim()))
      .sort((a, b) => (b.innerText || '').length - (a.innerText || '').length)[0] || null;
  }

  function separar(cel) {
    const texto = (cel.innerText || '').replace(/\n?\s*(⚑ )?[^\n]*\n?Sugest[aã]o:[\s\S]*$/, '').trim();
    const b = cel.querySelector('b, strong');
    if (b && !b.closest('.triagem-selo')) {
      const titulo = b.innerText.trim();
      return { titulo, descricao: texto.slice(texto.indexOf(titulo) + titulo.length).trim() };
    }
    const linhas = texto.split('\n');
    let i = 0;
    while (i < linhas.length && linhas[i] === linhas[i].toUpperCase()) i++;
    return { titulo: linhas.slice(0, Math.max(i, 1)).join(' '), descricao: linhas.slice(Math.max(i, 1)).join(' ') };
  }

  function juntadoPor(tr, celTipo) {
    for (const c of tr.querySelectorAll(':scope > td')) {
      if (c === celTipo) continue;
      const linhas = (c.innerText || '').trim().split('\n').map(s => s.trim()).filter(Boolean);
      const ult = N(linhas[linhas.length - 1] || '');
      const m = PAPEIS.exec(ult);
      if (m && linhas.length >= 2 && ult.length < 40) return { nome: linhas.slice(0, -1).join(' '), papel: linhas[linhas.length - 1] };
    }
    return null;
  }

  const chaveDe = tr => {
    const m = CNJ.exec(tr.innerText || '');
    const nums = (tr.innerText || '').match(/\b\d{3,6}\b/g) || [];
    return (m ? m[0] : '') + '|' + nums.join(',');
  };

  /* ------------------------- marcação na lista ------------------------- */
  function marcar() {
    if (!ehTela()) return;
    const contagem = {};
    linhasDaTabela().forEach(tr => {
      const cel = celulaTipo(tr);
      if (!cel) return;
      const { titulo, descricao } = separar(cel);
      let r = classificar(titulo, descricao);
      const lido = lidos.get(chaveDe(tr));
      if (lido && lido.regra) r = lido.regra;
      const quem = juntadoPor(tr, cel);
      const ehMP = quem && /MINISTERIO PUBLICO/.test(N(quem.papel));
      const dias = audienciaProxima(descricao);
      const urgente = r.urgente || dias !== null || ehMP;
      const [borda, fundo] = CORES[r.cor] || CORES.cinza;

      let selo = cel.querySelector('.triagem-selo');
      if (!selo) { selo = document.createElement('div'); selo.className = 'triagem-selo'; cel.appendChild(selo); }
      selo.style.cssText = 'margin:6px 0 2px;padding:5px 8px;border-left:4px solid ' + borda + ';background:' + fundo +
        ';color:#1b2631;font:12px/1.35 "Segoe UI",system-ui,sans-serif;border-radius:3px;';
      selo.textContent = '';
      const c = document.createElement('b'); c.style.color = borda;
      c.textContent = (urgente ? '⚑ ' : '') + r.cat + (lido && lido.regra ? ' · lido no PDF' : '') +
        (dias !== null ? ' · audiência em ' + dias + ' dia(s)' : '') + (ehMP ? ' · Ministério Público' : '');
      const e = document.createElement('div'); e.textContent = 'Sugestão: ' + r.enc;
      selo.append(c, e);
      if (lido && lido.trecho) { const t = document.createElement('div'); t.style.cssText = 'color:#56626e;font-style:italic;margin-top:2px'; t.textContent = 'PDF: "…' + lido.trecho + '…"'; selo.appendChild(t); }
      if (lido && lido.erro) { const t = document.createElement('div'); t.style.color = '#56626e'; t.textContent = 'PDF: ' + lido.erro; selo.appendChild(t); }

      tr.dataset.triagem = r.cat;
      tr.style.display = filtro && filtro !== r.cat ? 'none' : '';
      contagem[r.cat] = contagem[r.cat] || { n: 0, cor: r.cor, urg: 0 };
      contagem[r.cat].n++;
      if (urgente) contagem[r.cat].urg++;
    });
    painel(contagem);
  }

  /* ------------------------- marcar lote ------------------------- */
  function marcarLote(cat) {
    let n = 0;
    linhasDaTabela().forEach(tr => {
      const cb = tr.querySelector('input[type="checkbox"]');
      const quer = tr.dataset.triagem === cat;
      if (cb.checked !== quer) cb.click();
      if (quer) n++;
    });
    aviso = n + ' juntada(s) marcada(s). Confira e use "Análise Múltipla" ou "Dispensar" do PROJUDI.';
    marcar();
  }
  function desmarcarTodas() {
    linhasDaTabela().forEach(tr => { const cb = tr.querySelector('input[type="checkbox"]'); if (cb.checked) cb.click(); });
    aviso = 'Marcações removidas.';
    marcar();
  }

  /* ------------------------- leitura dos PDFs ------------------------- */
  function linksDaLinha(tr) {
    const links = [];
    for (let s = tr.nextElementSibling; s && !ehLinhaDados(s); s = s.nextElementSibling) {
      s.querySelectorAll('a').forEach(a => { if (/\.pdf/i.test(a.textContent) || /\.pdf|arquivo|download/i.test(a.getAttribute('href') || '')) links.push(a); });
    }
    return links;
  }

  async function abrirArquivos(tr) {
    let links = linksDaLinha(tr);
    if (links.length) return links;
    const cel = tr.querySelectorAll(':scope > td')[1];
    const alvo = cel && (cel.querySelector('a, img, input, span') || cel);
    if (!alvo) return [];
    alvo.click();
    for (let i = 0; i < 20 && !links.length; i++) { await dormir(250); links = linksDaLinha(tr); }
    return links;
  }

  function urlDoLink(a) {
    const href = a.getAttribute('href') || '';
    if (href && !/^javascript:|^#/i.test(href)) return a.href;
    const m = /['"]([^'"]*(?:\.do|\.pdf|arquivo)[^'"]*)['"]/i.exec((a.getAttribute('onclick') || '') + ' ' + href);
    return m ? new URL(m[1], location.href).href : null;
  }

  async function baixarPdf(url, nivel) {
    const resp = await fetch(url, { credentials: 'include' });
    const buf = new Uint8Array(await resp.arrayBuffer());
    if (buf[0] === 0x25 && buf[1] === 0x50 && buf[2] === 0x44 && buf[3] === 0x46) return buf;   // %PDF
    if (nivel > 0) return null;
    // Página intermediária (visualizador): procura o PDF embutido.
    const html = new TextDecoder('latin1').decode(buf);
    const m = /<(?:iframe|embed|object)[^>]+(?:src|data)=["']([^"']+)["']/i.exec(html);
    return m ? baixarPdf(new URL(m[1].replace(/&amp;/g, '&'), url).href, 1) : null;
  }

  async function textoDoPdf(dados) {
    const doc = await pdfjsLib.getDocument({ data: dados, isEvalSupported: false, disableFontFace: true, verbosity: 0 }).promise;
    let t = '';
    for (let i = 1; i <= Math.min(doc.numPages, 4) && t.length < 12000; i++) {
      const p = await doc.getPage(i);
      const c = await p.getTextContent();
      t += c.items.map(x => x.str).join(' ') + '\n';
    }
    await doc.destroy();
    return t;
  }

  function aplicarRegrasTexto(texto) {
    const T = N(texto);
    for (const r of REGRAS_TEXTO) {
      const m = r.se.exec(T);
      if (m) {
        const i = Math.max(0, m.index - 60);
        return { regra: r, trecho: T.slice(i, m.index + m[0].length + 60).toLowerCase() };
      }
    }
    return null;
  }

  async function lerPeticoes() {
    if (lendo) return;
    lendo = true;
    try {
      if (typeof pdfjsLib === 'undefined') {
        aviso = 'Carregando o leitor de PDF...'; marcar();
        const r = await chrome.runtime.sendMessage({ cmd: 'carregarLeitorPdf' });
        if (!r || !r.ok || typeof pdfjsLib === 'undefined') { aviso = '✖ Não consegui carregar o leitor de PDF.'; return; }
      }
      const linhas = linhasDaTabela().filter(tr => tr.style.display !== 'none' && !lidos.has(chaveDe(tr)));
      let i = 0, achadas = 0;
      for (const tr of linhas) {
        i++;
        aviso = 'Lendo petição ' + i + ' de ' + linhas.length + '...'; marcar();
        const chave = chaveDe(tr);
        try {
          const links = await abrirArquivos(tr);
          if (!links.length) { lidos.set(chave, { erro: 'arquivo não localizado na linha' }); continue; }
          let texto = '';
          for (const a of links.slice(0, 3)) {
            const url = urlDoLink(a);
            if (!url) continue;
            const dados = await baixarPdf(url, 0);
            if (dados) texto += await textoDoPdf(dados) + '\n';
          }
          if (!texto.trim()) { lidos.set(chave, { erro: 'sem texto legível (PDF digitalizado ou inacessível)' }); continue; }
          const r = aplicarRegrasTexto(texto);
          lidos.set(chave, r || { erro: 'texto lido, sem padrão reconhecido; mantida a classificação pelo título' });
          if (r) achadas++;
        } catch (e) {
          lidos.set(chave, { erro: 'falha ao ler (' + ((e && e.message) || e) + ')' });
        }
      }
      aviso = '✔ ' + linhas.length + ' petição(ões) lida(s); ' + achadas + ' reclassificada(s) pelo texto.';
    } finally { lendo = false; marcar(); }
  }

  /* ------------------------- quadro ------------------------- */
  function painel(contagem) {
    let host = document.getElementById('triagem-juntadas-painel');
    const total = Object.values(contagem).reduce((s, c) => s + c.n, 0);
    if (!total) { if (host) host.remove(); return; }
    if (!host) {
      host = document.createElement('div');
      host.id = 'triagem-juntadas-painel';
      host.style.cssText = 'position:fixed;right:16px;top:16px;z-index:2147483647;';
      host.attachShadow({ mode: 'open' });
      document.body.appendChild(host);
    }
    const raiz = host.shadowRoot;
    const minimizado = raiz.getElementById('p') && raiz.getElementById('p').classList.contains('min');
    raiz.innerHTML = `<style>
      .p{font:13px/1.35 "Segoe UI",system-ui,sans-serif;background:#fff;color:#1b2631;border:1px solid #c9d1d8;border-top:3px solid #0f5f73;
         border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.18);padding:10px;width:310px;max-height:75vh;overflow:auto}
      .t{display:flex;justify-content:space-between;align-items:center;font-weight:700;margin-bottom:6px}
      .x{border:0;background:none;font-size:16px;cursor:pointer;color:#56626e}
      button.c{display:flex;justify-content:space-between;width:100%;margin-top:4px;font:inherit;text-align:left;padding:5px 8px;
         border-radius:5px;border:1px solid #d3d9de;background:#fff;color:#1b2631;cursor:pointer}
      button.c.on{outline:2px solid #0f5f73}
      button.a{display:block;width:100%;margin-top:6px;font:inherit;font-weight:600;padding:6px 8px;border-radius:6px;
         border:1px solid #0f5f73;background:#0f5f73;color:#fff;cursor:pointer;text-align:left}
      button.a.s{background:#fff;color:#0f5f73}
      button:disabled{opacity:.5;cursor:default}
      .min .corpo{display:none} .min{width:auto}
      .n{font-weight:700;margin-left:8px;white-space:nowrap}
      .r{margin-top:8px;font-size:12px;color:#56626e}
      .av{margin-top:8px;font-size:12px;font-weight:600;color:#0f5f73}
    </style>
    <div class="p${minimizado ? ' min' : ''}" id="p"><div class="t"><span>Triagem: ${total} juntada(s)</span><button class="x" id="min">${minimizado ? '+' : '–'}</button></div>
    <div class="corpo" id="corpo"></div></div>`;
    const corpo = raiz.getElementById('corpo');
    Object.entries(contagem).sort((a, b) => b[1].urg - a[1].urg || b[1].n - a[1].n).forEach(([cat, c]) => {
      const b = document.createElement('button');
      b.className = 'c' + (filtro === cat ? ' on' : '');
      b.style.borderLeft = '4px solid ' + (CORES[c.cor] || CORES.cinza)[0];
      const s1 = document.createElement('span'); s1.textContent = (c.urg ? '⚑ ' : '') + cat;
      const s2 = document.createElement('span'); s2.className = 'n'; s2.textContent = c.n;
      b.append(s1, s2);
      b.addEventListener('click', () => { filtro = filtro === cat ? null : cat; aviso = ''; marcar(); });
      corpo.appendChild(b);
    });
    const ler = document.createElement('button');
    ler.className = 'a'; ler.textContent = lendo ? 'Lendo petições...' : 'Ler petições (PDF)' + (filtro ? ' desta categoria' : '');
    ler.disabled = lendo;
    ler.addEventListener('click', lerPeticoes);
    corpo.appendChild(ler);
    if (filtro) {
      const lote = document.createElement('button');
      lote.className = 'a s'; lote.textContent = 'Marcar as ' + (contagem[filtro] ? contagem[filtro].n : 0) + ' desta categoria';
      lote.addEventListener('click', () => marcarLote(filtro));
      corpo.appendChild(lote);
    }
    const des = document.createElement('button');
    des.className = 'a s'; des.textContent = 'Desmarcar todas';
    des.addEventListener('click', desmarcarTodas);
    corpo.appendChild(des);
    if (aviso) { const a = document.createElement('div'); a.className = 'av'; a.textContent = aviso; corpo.appendChild(a); }
    const r = document.createElement('div'); r.className = 'r';
    r.textContent = filtro ? 'Mostrando só: ' + filtro + ' (clique de novo para ver todas).' : 'Clique numa categoria para filtrar a lista.';
    corpo.appendChild(r);
    raiz.getElementById('min').addEventListener('click', () => {
      const p = raiz.getElementById('p'); p.classList.toggle('min');
      raiz.getElementById('min').textContent = p.classList.contains('min') ? '+' : '–';
    });
  }

  const agendar = () => { clearTimeout(agendado); agendado = setTimeout(marcar, 400); };
  marcar();
  new MutationObserver(muts => {
    if (muts.every(m => m.target.closest && (m.target.closest('.triagem-selo') || m.target.closest('#triagem-juntadas-painel')))) return;
    agendar();
  }).observe(document.body, { childList: true, subtree: true });
})();
