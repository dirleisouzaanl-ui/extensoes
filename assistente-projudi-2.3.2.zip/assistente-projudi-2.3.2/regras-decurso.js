/* regras-decurso.js - classificação da tela "Analisar Decurso de Prazo" pela MOVIMENTAÇÃO de origem
   (o ato que gerou a intimação cujo prazo decorreu). A primeira regra que casar vale. */
var REGRAS_DECURSO = [
  // prazo recursal
  { cat: 'Prazo recursal (sentença/acórdão/embargos)', cor: 'roxo',
    se: /EMBARGOS DE DECLARACAO|JULGAD[OA]|SENTENCA|PROCEDENTE|IMPROCEDENTE|EXTINT|HOMOLOGAD|ACORDAO|PROVIMENTO/,
    enc: 'Verificar se houve recurso; sem recurso, certificar o trânsito em julgado e dar andamento.' },
  { cat: 'Contrarrazões ao recurso', cor: 'roxo', se: /RECURSO INOMINADO|INTERPOSTO RECURSO|CONTRARRAZ/,
    enc: 'Com ou sem contrarrazões, remeter à Turma Recursal.' },
  // conhecimento
  { cat: 'Prazo de contestação', cor: 'azul', se: /CITAD|CITACAO/,
    enc: 'Verificar a contestação; sem resposta, concluir (revelia/julgamento).' },
  { cat: 'Impugnação à contestação', cor: 'azul', se: /CONTESTACAO/,
    enc: 'Com ou sem impugnação, concluir para julgamento ou saneamento.' },
  // cumprimento de sentença
  { cat: 'Prazo de pagamento (cumprimento)', cor: 'verde', se: /PAGAMENTO|CUMPRIMENTO DE SENTENCA|ART\.? ?523|INTIMACAO PARA PAGAR/,
    enc: 'Sem pagamento: intimar o credor para indicar bens ou prosseguir (SISBAJUD).' },
  { cat: 'Impugnação ao cumprimento / cálculo', cor: 'verde', se: /CALCULO|IMPUGNACAO/,
    enc: 'Verificar impugnação; sem ela, concluir para homologação ou prosseguir.' },
  { cat: 'Retomada após suspensão', cor: 'laranja', se: /LEVANTADA A SUSPENSAO|SOBRESTAMENTO|SUSPENS/,
    enc: 'Verificar se o credor deu andamento; sem manifestação, concluir ou arquivar conforme a decisão.' },
  { cat: 'Ciência de diligência (SISBAJUD/RENAJUD/alvará)', cor: 'verde', se: /SISBAJUD|BACENJUD|RENAJUD|INFOJUD|CNIB|ALVARA|DESBLOQUEIO|PENHORA/,
    enc: 'Ciência decorrida: verificar pedido pendente; nada pendente, prosseguir ou arquivar.' },
  // atos do cartório e despachos
  { cat: 'Resposta a ato ordinatório', cor: 'cinza', se: /ATO ORDINATORIO/,
    enc: 'Verificar a manifestação; sem ela, cumprir a consequência prevista no ato ou concluir.' },
  { cat: 'Resposta a despacho/decisão', cor: 'cinza', se: /DESPACHO|DECISAO|DEFERID|INDEFERID|DETERMIN/,
    enc: 'Verificar a manifestação e concluir, se a decisão exigir.' },
  { cat: 'Decurso de outro prazo', cor: 'cinza', se: /DECORRIDO PRAZO|DECURSO/,
    enc: 'Concluir ou dar o andamento previsto para o fim do prazo.' },
  // apenas ciência
  { cat: 'Intimação para audiência', cor: 'laranja', se: /AUDIENCIA/,
    enc: 'Prazo sem efeito próprio: dispensar a análise e aguardar a audiência.' },
  { cat: 'Ciência simples (comunicação/ação vinculada)', cor: 'cinza', se: /COMUNICACAO|ACAO VINCULADA|CIENCIA/,
    enc: 'Ciência decorrida: dispensar a análise.' }
];
