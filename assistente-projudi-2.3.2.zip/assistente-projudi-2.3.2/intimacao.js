/* intimacao.js - janela "Intimar Partes" (Intimação de Partes).
   Marca as partes e o prazo conforme o passo do roteiro em que você clicou "Abrir",
   ou conforme os botões rápidos da barra. NÃO clica em "Intimar": isso fica com você. */
(() => {
  const N = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
  const POLO_AUTOR = /EXEQUENTE|AUTOR|RECLAMANTE|REQUERENTE|PROMOVENTE|CREDOR|IMPETRANTE|EMBARGANTE/;
  const POLO_REU = /EXECUTAD|\bREU\b|RECLAMAD|REQUERID|PROMOVID|DEVEDOR|IMPETRAD|EMBARGAD/;
  const antes = (a, b) => !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);

  const ehJanela = () => /Intima[cç][aã]o de Partes/i.test((document.body && document.body.innerText) || '') &&
    Array.from(document.querySelectorAll('input[type="button"], input[type="submit"], button')).some(b => N(b.value || b.textContent) === 'INTIMAR');

  function secoes() {
    // Cabeçalhos "Partes - Exequente", "Partes - Executado"...
    const cab = Array.from(document.querySelectorAll('body *')).filter(e => {
      if (e.children.length > 1) return false;
      return /^PARTES - /.test(N(e.textContent)) && N(e.textContent).length < 60;
    });
    const unicos = cab.filter(c => !cab.some(o => o !== c && c.contains(o)));
    return unicos.map((c, i) => {
      const prox = unicos[i + 1] || null;
      const dentro = el => antes(c, el) && (!prox || antes(el, prox));
      const polo = N(c.textContent).replace(/^PARTES - /, '');
      const linhas = Array.from(document.querySelectorAll('tr')).filter(tr => dentro(tr) && !tr.querySelector('tr'))
        .filter(tr => tr.querySelectorAll('input[type="checkbox"]').length >= 2 && !/INTIMACAO PESSOAL/.test(N(tr.innerText)));
      return {
        polo, cab: c,
        tipo: POLO_AUTOR.test(polo) ? 'autor' : POLO_REU.test(polo) ? 'reu' : 'outro',
        partes: linhas.map(tr => {
          const cbs = tr.querySelectorAll('input[type="checkbox"]');
          return { tr, pessoal: cbs[0], adv: cbs[1], nome: (tr.innerText || '').trim() };
        }),
        selPrazo: Array.from(document.querySelectorAll('select')).find(dentro),
        txtPrazo: Array.from(document.querySelectorAll('input[type="text"], input:not([type])')).find(dentro),
        radios: Array.from(document.querySelectorAll('input[type="radio"]')).filter(dentro)
      };
    });
  }

  const rotuloRadio = r => {
    const l = r.id && document.querySelector('label[for="' + r.id + '"]');
    return N(l ? l.textContent : (r.nextSibling && r.nextSibling.textContent) || r.parentElement.textContent || '');
  };
  const marcar = (cb, quer) => { if (cb && !cb.disabled && cb.checked !== quer) cb.click(); };
  const destacar = el => { if (el) { el.style.outline = '3px solid #e0a000'; el.style.outlineOffset = '1px'; } };

  function aplicar(pedido) {
    const sec = secoes();
    if (!sec.length) return 'Não reconheci as seções de partes nesta janela.';
    const alvo = pedido.alvo;
    const escolhidas = sec.filter(s => alvo === 'partes' || s.tipo === alvo);
    if (!escolhidas.length) return 'Não encontrei a seção do ' + (alvo === 'autor' ? 'autor/exequente' : 'requerido/executado') + '.';
    const faltas = [];
    escolhidas.forEach(s => {
      s.partes.forEach(p => {
        const usarAdv = !pedido.pessoal && p.adv && !p.adv.disabled;
        marcar(p.adv, usarAdv);
        marcar(p.pessoal, !usarAdv);
        if (!usarAdv && (!p.pessoal || p.pessoal.disabled)) faltas.push(p.nome);
      });
      if (s.selPrazo) {
        const op = Array.from(s.selPrazo.options).find(o => /DIAS/.test(N(o.text)));
        if (op && s.selPrazo.value !== op.value) { s.selPrazo.value = op.value; s.selPrazo.dispatchEvent(new Event('change', { bubbles: true })); }
      }
      if (s.txtPrazo) {
        if (pedido.dias) {
          s.txtPrazo.value = String(pedido.dias);
          ['input', 'change'].forEach(t => s.txtPrazo.dispatchEvent(new Event(t, { bubbles: true })));
        } else destacar(s.txtPrazo);
      }
      const corr = s.radios.find(r => /CORRIDOS/.test(rotuloRadio(r)));
      const uteis = s.radios.find(r => /UTEIS/.test(rotuloRadio(r)));
      if (pedido.corridos && corr && !corr.checked) corr.click();
      if (!pedido.corridos && uteis && !uteis.checked) uteis.click();
      if (pedido.urgente) {
        const sim = s.radios.filter(r => /^SIM/.test(rotuloRadio(r))).pop();
        if (sim && !sim.checked) sim.click();
      }
    });
    return 'Marcado: ' + escolhidas.map(s => s.polo.toLowerCase()).join(' e ') +
      (pedido.dias ? ' · ' + pedido.dias + ' dias ' + (pedido.corridos ? 'corridos' : 'úteis') : ' · prazo não consta da decisão: informe (campo em amarelo)') +
      (faltas.length ? ' · conferir: ' + faltas.join(', ') : '') + '. Confira e clique em Intimar.';
  }

  function barra(msg) {
    let host = document.getElementById('rc-intimacao-barra');
    if (!host) {
      host = document.createElement('div');
      host.id = 'rc-intimacao-barra';
      host.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:2147483647;';
      host.attachShadow({ mode: 'open' });
      document.body.appendChild(host);
    }
    const r = host.shadowRoot;
    r.innerHTML = `<style>
      .b{font:12.5px/1.4 "Segoe UI",system-ui,sans-serif;background:#fff;color:#1b2631;border:1px solid #c9d1d8;border-top:3px solid #0f5f73;
         border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.2);padding:8px 10px;max-width:520px}
      .t{font-weight:700;margin-bottom:4px} .m{margin-bottom:6px}
      button{font:inherit;font-weight:600;padding:3px 9px;border-radius:5px;border:1px solid #0f5f73;background:#fff;color:#0f5f73;cursor:pointer;margin-right:4px}
      input{width:42px;font:inherit;padding:2px 4px}
    </style>
    <div class="b"><div class="t">Retorno de Conclusão · intimação</div><div class="m" id="m"></div>
      <span>Intimar: </span><button id="a">Autor</button><button id="r">Requerido</button><button id="p">Partes</button>
      <span> prazo </span><input id="d" inputmode="numeric" placeholder="dias"> <span>dias úteis</span></div>`;
    r.getElementById('m').textContent = msg || 'Escolha quem intimar e o prazo; a extensão marca as caixas.';
    const go = alvo => barra(aplicar({ alvo, dias: parseInt(r.getElementById('d').value, 10) || null }));
    r.getElementById('a').addEventListener('click', () => go('autor'));
    r.getElementById('r').addEventListener('click', () => go('reu'));
    r.getElementById('p').addEventListener('click', () => go('partes'));
  }

  let feito = false;
  async function verificar() {
    if (feito || !ehJanela()) return;
    feito = true;
    let msg = '';
    try {
      const st = await chrome.storage.local.get('intimacaoPendente');
      const p = st.intimacaoPendente;
      if (p && Date.now() - p.ts < 3 * 60 * 1000) {
        await chrome.storage.local.remove('intimacaoPendente');
        msg = p.rotulo + ' → ' + aplicar(p);
      }
    } catch (e) {}
    barra(msg);
  }
  verificar();
  let espera = null;
  const obs = new MutationObserver(() => {
    clearTimeout(espera);
    espera = setTimeout(() => {
      if (!feito) verificar();
      else if (!ehJanela()) { feito = false; const b = document.getElementById('rc-intimacao-barra'); if (b) b.remove(); }
    }, 300);
  });
  obs.observe(document.documentElement, { childList: true, subtree: true });
})();
