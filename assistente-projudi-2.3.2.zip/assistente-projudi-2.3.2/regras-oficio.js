/* regras-oficio.js - destinatários de ofício (modelo do PROJUDI "Digitar Documento").
   Textos iniciais para revisão: cargo, entidade, envio (e-mail ou endereço) e o objeto
   ("... no prazo de até N dias, efetue <objeto>."). {PARTE} e {DOC} são trocados pela parte
   escolhida e seu CPF/CNPJ. O que você editar e salvar no quadro fica guardado e prevalece. */
var DESTINATARIOS_OFICIO = [
  { id: 'inss', nome: 'INSS – CNIS', chaves: ['INSS', 'CNIS', 'PREVJUD'], polo: 'reu', descricao: 'Ofício ao INSS - busca CNIS',
    cargo: 'Gerente da Agência da Previdência Social', entidade: 'Instituto Nacional do Seguro Social – INSS', envio: '',
    objeto: 'o envio a este Juízo das informações constantes do Cadastro Nacional de Informações Sociais (CNIS) – vínculos empregatícios, remunerações e benefícios – em nome de {PARTE}, CPF {DOC}' },
  { id: 'empregador', nome: 'Empregador – desconto mensal', chaves: ['EMPREGADOR', 'DESCONTO', 'FOLHA'], polo: 'reu', descricao: 'Ofício à EMPREGADOR - desconto mensal',
    cargo: 'Responsável pelo Departamento de Recursos Humanos', entidade: '[EMPREGADOR]', envio: '',
    objeto: 'o desconto mensal em folha de pagamento de {PARTE}, CPF {DOC}, de [percentual/valor], com depósito em conta judicial vinculada a estes autos, até a quitação do débito' },
  { id: 'caixa', nome: 'Caixa Econômica Federal', chaves: ['CAIXA'], polo: 'reu', descricao: 'Ofício à CAIXA ECONÔMICA FEDERAL',
    cargo: 'Gerente-Geral', entidade: 'Caixa Econômica Federal', envio: '', objeto: '[providência determinada] em relação a {PARTE}, CPF/CNPJ {DOC}' },
  { id: 'claro', nome: 'Claro / Net / Embratel', chaves: ['CLARO', 'NET', 'EMBRATEL'], polo: 'reu', descricao: 'Ofício CLARO-EMBRATEL',
    cargo: '', entidade: 'Claro S.A. / Net / Embratel', envio: '', objeto: 'o envio a este Juízo dos endereços e telefones cadastrados em nome de {PARTE}, CPF/CNPJ {DOC}' },
  { id: 'tim', nome: 'TIM', chaves: ['TIM'], polo: 'reu', descricao: 'Ofício à TIM',
    cargo: '', entidade: 'TIM S.A.', envio: '', objeto: 'o envio a este Juízo dos endereços e telefones cadastrados em nome de {PARTE}, CPF/CNPJ {DOC}' },
  { id: 'vivo', nome: 'Vivo / GVT', chaves: ['VIVO', 'GVT'], polo: 'reu', descricao: 'Ofício à VIVO - GVT',
    cargo: '', entidade: 'Telefônica Brasil S.A. – Vivo / GVT', envio: '', objeto: 'o envio a este Juízo dos endereços e telefones cadastrados em nome de {PARTE}, CPF/CNPJ {DOC}' },
  { id: 'oi', nome: 'Oi', chaves: ['OI'], polo: 'reu', descricao: 'Ofício à OI',
    cargo: '', entidade: 'Oi S.A.', envio: '', objeto: 'o envio a este Juízo dos endereços e telefones cadastrados em nome de {PARTE}, CPF/CNPJ {DOC}' },
  { id: 'serasa-inc', nome: 'SERASAJUD – inclusão', chaves: ['SERASAJUD', 'SERASA', 'INCLUSAO'], polo: 'reu', descricao: 'Ofício SERASAJUD - inclusão',
    cargo: '', entidade: 'Serasa Experian – SERASAJUD', envio: '', objeto: 'a inclusão do nome de {PARTE}, CPF/CNPJ {DOC}, no cadastro de inadimplentes, em razão do débito objeto destes autos, no valor de R$ [VALOR]' },
  { id: 'serasa-exc', nome: 'SERASAJUD – exclusão', chaves: ['SERASAJUD', 'SERASA', 'EXCLUSAO'], polo: 'reu', descricao: 'Ofício SERASAJUD - exclusão',
    cargo: '', entidade: 'Serasa Experian – SERASAJUD', envio: '', objeto: 'a exclusão do nome de {PARTE}, CPF/CNPJ {DOC}, do cadastro de inadimplentes, quanto ao débito objeto destes autos' },
  { id: 'spc', nome: 'SPC Brasil', chaves: ['SPC'], polo: 'reu', descricao: 'Ofício SPC BRASIL',
    cargo: '', entidade: 'SPC Brasil', envio: '', objeto: 'a [inclusão/exclusão] do nome de {PARTE}, CPF/CNPJ {DOC}, no cadastro de inadimplentes, quanto ao débito objeto destes autos' },
  { id: 'scpc', nome: 'SCPC Boa Vista', chaves: ['SCPC', 'BOA VISTA'], polo: 'reu', descricao: 'Ofício SCPC BOA VISTA',
    cargo: '', entidade: 'Boa Vista Serviços – SCPC', envio: '', objeto: 'a [inclusão/exclusão] do nome de {PARTE}, CPF/CNPJ {DOC}, no cadastro de inadimplentes, quanto ao débito objeto destes autos' },
  { id: 'alienadora', nome: 'Alienadora fiduciária', chaves: ['ALIENADORA', 'FIDUCIARIA'], polo: 'reu', descricao: 'Ofício à ALIENADORA FIDUCIÁRIA',
    cargo: '', entidade: '[INSTITUIÇÃO ALIENANTE]', envio: '', objeto: 'o envio a este Juízo de informações sobre o contrato de alienação fiduciária do veículo [PLACA] em nome de {PARTE}, CPF/CNPJ {DOC}, com o saldo devedor atualizado' },
  { id: 'natjus', nome: 'NatJus / e-NatJus', chaves: ['NATJUS', 'NAT', 'PARECER TECNICO', 'MEDICAMENTO'], polo: 'autor', descricao: 'Ofício ao NAT-Jus',
    cargo: '', entidade: 'Núcleo de Apoio Técnico do Poder Judiciário – NAT-Jus', envio: '', objeto: 'a emissão de nota técnica sobre o [medicamento/tratamento] pleiteado por {PARTE}, CPF {DOC}' },
  { id: 'generico', nome: 'Genérico (texto da decisão)', chaves: [], polo: 'reu', descricao: 'Ofício',
    cargo: '', entidade: '[DESTINATÁRIO]', envio: '', objeto: '{DECISAO}' }
];
