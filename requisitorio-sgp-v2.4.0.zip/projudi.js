/* Busca de advogado no cadastro do PROJUDI (Cadastro › Advogados). Roda DENTRO da aba do PROJUDI
   (chrome.scripting.executeScript), em segundo plano: não navega nem altera nada. */
async function buscaAdvogadoProjudi(q){ // q: {oab, nome, login}
  const norm = s => (s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  let menu = null;
  const walk = w => { let d; try { d = w.document; } catch(e){ return; }
    if (!menu) menu = [...d.querySelectorAll('a')].find(a => /^Advogados$/i.test(a.textContent.trim()) && /advogado\.do/.test(a.getAttribute('href')||''));
    [...d.querySelectorAll('iframe,frame')].forEach(f => walk(f.contentWindow)); };
  walk(window);
  if (!menu) return {erro:'Não achei o menu Cadastro › Advogados nesta aba do PROJUDI (sessão expirada ou perfil sem esse menu).'};
  const P = s => new DOMParser().parseFromString(s,'text/html');
  const get = async (u, o) => { const r = await fetch(u, Object.assign({credentials:'include'}, o||{})); return new TextDecoder('iso-8859-1').decode(await r.arrayBuffer()); };
  const d1 = P(await get(menu.href)); const f = d1.forms['advogadoForm'];
  if (!f) return {erro:'A tela de pesquisa de advogados não abriu (sessão do PROJUDI expirada?).'};
  const act = new URL(f.getAttribute('action'), menu.href).href; const fd = new URLSearchParams();
  [...f.elements].forEach(e => { if (e.name && e.type!=='button' && e.type!=='submit') fd.set(e.name, e.value||''); });
  const m = (q.oab||'').toUpperCase().match(/([A-Z]{2})?\s*0*(\d{3,7})\s*[A-Z]?\s*-?\s*([A-Z]{2})?/);
  const num = m ? m[2] : '', uf = m ? (m[1]||m[3]||'PR') : 'PR';
  if (q.login) fd.set('login', q.login); else if (num) fd.set('oab', num); else if (q.nome) fd.set('nome', q.nome); else return {erro:'Informe a OAB ou o nome.'};
  const d2 = P(await get(act, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body: fd.toString()}));
  const linhas = [...d2.querySelectorAll('table.resultTable tr')].filter(r => r.querySelector('a')).map(r => ({login: r.querySelector('a').textContent.trim(), nome: (r.children[1]||{}).textContent.trim(), href: r.querySelector('a').getAttribute('href')}));
  if (!linhas.length) return {erro:'Nenhum advogado encontrado no cadastro do PROJUDI.'};
  let alvo = null;
  if (q.login) alvo = linhas.find(l => l.login === q.login);
  else if (num) alvo = linhas.find(l => l.login === uf+num) || (linhas.length===1 ? linhas[0] : null);
  else alvo = linhas.find(l => norm(l.nome) === norm(q.nome)) || (linhas.length===1 ? linhas[0] : null);
  if (!alvo) return {lista: linhas.slice(0,30).map(l => ({login:l.login, nome:l.nome}))};
  const d3 = P(await get(new URL(alvo.href, act).href)); const kv = {};
  d3.querySelectorAll('tr').forEach(r => { if (r.children.length>=2 && !r.querySelector('tr')){ const l = r.children[0].textContent.replace(/\s+/g,' ').trim().replace(/:$/,'');
    if (l && l.length<25 && !(l in kv)) kv[l] = r.children[1].textContent.replace(/\s+/g,' ').trim(); } });
  const rg = kv['RG']||''; const rm = rg.match(/^([\d.\-xX]+)\s*(.*)$/) || [,'',''];
  const lg = kv['Logradouro']||''; const lm = lg.match(/^(.*?),\s*(\S+)\s*$/);
  const cid = (kv['Cidade']||'').split('/');
  return {adv: {login: kv['Login']||alvo.login, oab: kv['OAB']||'', nome: kv['Nome']||alvo.nome, cpf: (kv['CPF']||'').replace(/\D/g,''),
    rg: rm[1], rgOrgao: rm[2].trim().replace(/\s+/g,'/'), nascimento: kv['Dt. Nascimento']||'',
    logradouro: lm ? lm[1].trim() : lg, numero: lm ? lm[2] : '', complemento: kv['Complemento']||'', bairro: kv['Bairro']||'',
    cidade: (cid[0]||'').trim(), uf: (cid[1]||'PR').trim(), cep: (kv['CEP']||'').replace(/\D/g,''), telefone: kv['Celular']||kv['Telefone']||'', email: kv['E-mail']||''}};
}
