// Reconstrói linhas a partir do textContent do pdf.js (compartilhado com a extensão)
function itemsToLines(items){
  const rows=[];
  for(const it of items){
    if(!it.str && !it.hasEOL) continue;
    const y=Math.round(it.transform[5]), x=it.transform[4];
    let r=rows.find(r=>Math.abs(r.y-y)<=3);
    if(!r){r={y,parts:[]};rows.push(r);}
    r.parts.push({x,s:it.str,w:it.width||0});
  }
  rows.sort((a,b)=>b.y-a.y);
  return rows.map(r=>{r.parts.sort((a,b)=>a.x-b.x);let out='',end=null;
    for(const p of r.parts){ if(end!==null && p.x-end>2 && !out.endsWith(' ')) out+=' '; out+=p.s; end=p.x+p.w;}
    return out.replace(/\s+/g,' ').trim();}).filter(Boolean);
}
if(typeof module!=='undefined') module.exports={itemsToLines};
