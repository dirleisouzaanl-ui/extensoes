/* Requisitório → SGP v2 — painel lateral */
pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdf.worker.min.js');
const $ = id => document.getElementById(id);
const LIMITE = [{devedor:'Assis Chateaubriand', limite:8475.55}];
const novoAdv = () => ({conta:{procurador:'Não'}, falecido:'Não', herdeiro:'Não', sucumbencial:'Sim', contratual:'Não', uf:'PR'});
const vazio = () => ({avisos:[], advAutos:[], proc:{}, docs:{tipos:{}, naoConsta:[]}, cred:{conta:{procurador:'Não'}}, advs:[], orig:{}, nomePdf:'', cert:{decisao:'V. Acórdão', impugnacao:'Não', local:'Assis Chateaubriand'}});
let S = vazio();

/* ---------- esquema dos campos (rótulos = os do SGP) ---------- */
const SN = ['', 'Sim', 'Não'];
const CONTA = p => [
  {sub:'Conta bancária'},
  {g:3, c:[{k:p+'conta.banco', r:'Banco (código)', ph:'104'}, {k:p+'conta.agencia', r:'Agência'}, {k:p+'conta.dvAgencia', r:'DV agência'}]},
  {g:3, c:[{k:p+'conta.numero', r:'Número da conta'}, {k:p+'conta.dv', r:'DV conta'}, {k:p+'conta.operacao', r:'Operação (só Caixa)', ph:'001'}]},
  {k:p+'conta.procurador', r:'Titular da conta é procurador?', o:['Não','Sim'], d:'Se Sim, o SGP exige o CPF e o nome do titular da conta.'},
  {g:2, c:[{k:p+'conta.titularCpf', r:'CPF do titular (se procurador)'}, {k:p+'conta.titularNome', r:'Nome do titular (se procurador)'}]}];
const VALORES = p => [
  {sub:'Valores (tela 11)'},
  {g:2, c:[{k:p+'valorPrincipal', r:'Valor principal (R$)'}, {k:p+'dataAtualizacao', r:'Data de atualização'}]},
  {g:3, c:[{k:p+'valorSelic', r:'Valor Selic'}, {k:p+'jurosMoratorios', r:'Juros moratórios'}, {k:p+'jurosCompensatorios', r:'Juros compensatórios'}]},
  {k:p+'planilha', r:'Planilha de cálculo de valores originais (arquivo)', ph:'93.2'}];
const TIPOS_DOC = [['PF','Petição inicial da execução *'],['SC','Sentença condenatória / título *'],['HE','Homologação do cálculo + expedição (conjunta)'],
  ['DH','Decisão de homologação do cálculo *'],['DE','Decisão que determinou a expedição *'],['AC','Acórdão'],['SA','Acórdão nos embargos / decisão da impugnação'],
  ['CT','Certidão de trânsito em julgado'],['CF','Certidão de citação/intimação da Fazenda'],['CD','Certidão de decurso (embargos/impugnação)'],
  ['CP','Certidão de trânsito dos embargos/impugnação'],['PC','Planilha de cálculo homologada'],['PA','Planilha de valores originais'],
  ['MM','Manifestação ministerial'],['CM','Certidão de intimação do MP'],['CO','Conta de custas'],['PR','Procuração e substabelecimento'],
  ['CL','Certidão de preclusão da homologação'],['CX','Certidão de preclusão da expedição'],['DD','Decisão de pagamento preferencial']];
const SECOES = () => [
 {t:'Telas 1 e 2 · Processo', aberto:true, c:[
   {k:'proc.numero', r:'Numeração única'}, {k:'proc.juizo', r:'Juízo de origem (nome da vara)'},
   {k:'proc.limiteRpv', r:'Teto de RPV do devedor na data do trânsito – DC (R$)', ph:'8.475,55', d:'A modalidade é definida pelo valor de cada beneficiário (Res. CNJ 303/2019, art. 7º, § 3º), com o teto vigente na data do trânsito em julgado da fase de conhecimento (art. 47). O SGP recusa no precatório o credor abaixo desse teto.'},
   {g:2, c:[{k:'proc.descricaoAcao', r:'Descrição da ação'}, {k:'proc.tipoExecucao', r:'Tipo de execução', o:['','Judicial','Extrajudicial']}]},
   {sub:'Datas diversas'},
   {g:2, c:[{k:'proc.dtAjuizOriginal', r:'Ajuizamento da ação original', d:'Data da distribuição da ação de conhecimento (capa).'}, {k:'proc.dtAjuizConhecimento', r:'Ajuizamento do conhecimento', d:'Data da distribuição da ação de conhecimento (capa).'}]},
   {g:2, c:[{k:'proc.dtTransitoDC', r:'Trânsito em julgado – DC', d:'Trânsito da decisão condenatória: movimentação TRANSITADO EM JULGADO da sentença ou do acórdão.'}, {k:'proc.dtTransitoDEP', r:'Trânsito em julgado – DEP', d:'Preclusão/trânsito da decisão que homologou o cálculo e mandou expedir. É posterior ao decurso do prazo de impugnação; não confundir com o trânsito da sentença.'}]},
   {g:2, c:[{k:'proc.dtAjuizExecucao', r:'Ajuizamento da execução', d:'Data do protocolo da petição de cumprimento de sentença (após a evolução de classe).'}, {k:'proc.numeroOriginaria', r:'Nº ação originária (se diferente)'}]},
   {g:2, c:[{k:'proc.dtCitacaoFazenda', r:'Citação/intimação da Fazenda', d:'Data de leitura da intimação da executada para impugnar (CONFIRMADA A INTIMAÇÃO ELETRÔNICA).'}, {k:'proc.dtDecurso', r:'Decurso / trânsito da impugnação', d:'Decurso do prazo ou renúncia; havendo impugnação, trânsito da decisão que a julgou.'}]},
   {sub:'Movimentações no Projudi (certidões)'},
   {g:3, c:[{k:'proc.movTransito', r:'Trânsito *'}, {k:'proc.movCitacao', r:'Citação Fazenda'}, {k:'proc.movDecurso', r:'Decurso'}]},
   {g:3, c:[{k:'proc.movDestaque', r:'Precl. destaque'}, {k:'proc.movHomolog', r:'Precl. homolog. *'}, {k:'proc.movExped', r:'Precl. expedição *'}]}]},
 {t:'Tela 3 · Documentos (arquivo do PROJUDI, ex.: 93.1)', c:[
   ...TIPOS_DOC.map(([cod, r]) => ({k:'docs.tipos.'+cod, r, ph:'mov.seq — vários: 32.1, 34.1'})),
   {sub:'Não consta dos autos'},
   ...[['AC','Acórdão'],['SA','Acórdão nos embargos / decisão da impugnação'],['CD','Certidão de decurso'],['CP','Certidão de trânsito dos embargos']].map(([cod,r]) => ({nc:cod, r}))]},
 {t:'Tela 5 · Credor do valor principal', c:[
   {g:2, c:[{k:'cred.nome', r:'Nome'}, {k:'cred.cpf', r:'CPF/CNPJ'}]},
   {g:2, c:[{k:'cred.natureza', r:'Natureza do processo', o:['','Alimentar','Comum','Alimentar e Comum']},
            {k:'cred.classificacao', r:'Classificação p/ atualização', o:['','Diferenças remuneratórias de servidores','Condenação em geral','Desapropriação','Tributário','Custas']}]},
   {k:'cred.tipoNatureza', r:'Tipo da natureza', o:['','Salários, vencimentos, proventos, pensões e suas complementações','Benefícios previdenciários','Benefícios de aposentadoria por invalidez ou PDG, auxílios (acidente e doença)','Indenizações por morte ou por invalidez, fundadas em responsabilidade civil','Outras indenizações','Honorários Advocatícios Sucumbenciais','Lucros cessantes','Repetição de indébito','Demais descontos indevidos','Fornecimento de bens ou serviços','Outro']},
   {g:2, c:[{k:'cred.rg', r:'Doc. identificação'}, {k:'cred.rgOrgao', r:'Órgão expedidor', ph:'SSP/PR'}]},
   {g:2, c:[{k:'cred.falecido', r:'Falecido', o:SN}, {k:'cred.herdeiro', r:'Credor é herdeiro', o:SN}]},
   {g:2, c:[{k:'cred.procuracao', r:'Procuração (arquivo)', ph:'1.2'}, {k:'cred.semDestaque', r:'Destaque de contratuais: não consta', o:SN}]},
   {g:2, c:[{k:'cred.decisaoNatureza', r:'Decisão que fixou a natureza (arquivo)', ph:'19.1', d:'Obrigatório no SGP quando a natureza é Alimentar e há tipo da natureza.'}, {k:'cred.servidorPublico', r:'Servidor público da adm. direta?', o:SN, d:'Obrigatório no SGP quando a natureza é Alimentar.'}]},
   ...CONTA('cred.'), ...VALORES('cred.')]},
 {t:'Telas 4 e 6 · Advogados (honorários)', adv:true},
 {t:'Certidão (modelo fixo)', cert:true, c:[
   {k:'cert.decisao', r:'Decisão que transitou em julgado', o:['V. Acórdão','r. Sentença']},
   {g:2, c:[{k:'cert.dtCalculo', r:'Cálculo original — data'}, {k:'cert.movCalculo', r:'Cálculo original — mov.'}]},
   {g:2, c:[{k:'cert.dtHomolog', r:'Decisão de homologação/expedição — data'}, {k:'cert.movDecHomolog', r:'Decisão de homologação — mov.'}]},
   {k:'cert.impugnacao', r:'Houve impugnação/embargos da Fazenda?', o:['Não','Sim'], d:'Não: o texto certifica a renúncia/decurso sem manifestação. Sim: certifica a impugnação, a decisão que a julgou e o trânsito da decisão de homologação.'},
   {g:2, c:[{k:'cert.dtImpug', r:'Impugnação — data'}, {k:'cert.movImpug', r:'Impugnação — mov.'}]},
   {g:2, c:[{k:'cert.dtDecImpug', r:'Decisão da impugnação — data'}, {k:'cert.movDecImpug', r:'Decisão da impugnação — mov.'}]},
   {g:2, c:[{k:'cert.dtMP', r:'Remessa ao MP — data'}, {k:'cert.movMP', r:'Remessa ao MP — mov.'}]},
   {g:2, c:[{k:'cert.dtNatureza', r:'Decisão da natureza — data'}, {k:'cert.movNatureza', r:'Decisão da natureza — mov.', d:'O parágrafo da natureza só entra na certidão com data e movimentação da decisão.'}]},
   {g:2, c:[{k:'cert.servidor', r:'Servidor que subscreve'}, {k:'cert.local', r:'Local'}]}]}
];
const ADV = i => { const p = 'advs.'+i+'.'; return [
   {g:2, c:[{k:p+'contratual', r:'Honorários contratuais?', o:SN}, {k:p+'sucumbencial', r:'Honorários sucumbenciais?', o:SN}]},
   {g:2, c:[{k:p+'nome', r:'Nome'}, {k:p+'cpf', r:'CPF'}]},
   {g:3, c:[{k:p+'rg', r:'Doc. identificação'}, {k:p+'rgOrgao', r:'Órgão expedidor'}, {k:p+'nascimento', r:'Nascimento'}]},
   {g:2, c:[{k:p+'falecido', r:'Falecido', o:SN}, {k:p+'herdeiro', r:'Herdeiro', o:SN}]},
   {sub:'Endereço'},
   {g:3, c:[{k:p+'cep', r:'CEP'}, {k:p+'logradouro', r:'Logradouro'}, {k:p+'numero', r:'Número'}]},
   {g:3, c:[{k:p+'complemento', r:'Complemento'}, {k:p+'bairro', r:'Bairro'}, {k:p+'cidade', r:'Cidade'}]},
   {g:3, c:[{k:p+'uf', r:'UF'}, {k:p+'telefone', r:'Telefone'}, {k:p+'email', r:'E-mail'}]},
   ...CONTA(p), ...VALORES(p)]; };

/* ---------- estado ---------- */
const get = k => k.split('.').reduce((o,p) => o==null ? o : o[p], S);
const set = (k, v) => { const ps = k.split('.'); let o = S; ps.slice(0,-1).forEach(p => { if (o[p]==null) o[p] = {}; o = o[p]; }); o[ps[ps.length-1]] = v; };
const salvar = () => chrome.storage.local.set({estado: S});
const esc = s => String(s==null?'':s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');

function campo(c){
  if (c.sub) return `<div class="sub">${c.sub}</div>`;
  if (c.g) return `<div class="g${c.g}">${c.c.map(campo).join('')}</div>`;
  if (c.nc) return `<label class="chk"><input type="checkbox" data-nc="${c.nc}" ${S.docs.naoConsta.includes(c.nc)?'checked':''}> ${c.r}</label>`;
  const v = get(c.k) || ''; const og = S.orig[c.k]; const TG = {L:'✅ LITERAL', I:'⚠ INFERIDO', C:'🔢 CALCULADO'};
  const tag = og ? (typeof og === 'string' ? `✅ LITERAL ${og}` : `${TG[og.t]||''} ${esc(og.o)}`) : '';
  const inp = c.o ? `<select data-k="${c.k}">${c.o.map(o => `<option ${o===v?'selected':''}>${esc(o)}</option>`).join('')}</select>`
                  : `<input data-k="${c.k}" value="${esc(v)}" placeholder="${esc(c.ph||'')}">`;
  return `<div class="f"><label><span ${c.d?'title="'+esc(c.d)+'"':''}>${c.r}${c.d?' ⓘ':''}</span><span>${tag}</span></label>${inp}</div>`;
}
function render(){
  let h = '';
  for (const s of SECOES()){
    if (s.adv){
      h += `<details open><summary>${s.t} — ${S.advs.length}</summary>
        <div class="row"><input id="qAdv" placeholder="OAB (ex.: 51633 ou PR51633) ou nome" style="flex:1;border:1px solid var(--bd);border-radius:4px;padding:5px 6px">
        <button id="bAdv">Buscar no PROJUDI</button></div><div id="escolha"></div>
        <div class="row"><button class="sec mini" id="addAdv">+ advogado em branco</button></div>
        ${(S.advAutos||[]).length ? '<small>Advogados da parte nos autos (só entram aqui se houver honorários a requisitar):</small>'+S.advAutos.map(a => `<div class="row"><button class="sec mini" data-oab="${esc(a.oab)}">buscar</button> ${esc(a.oab)} — ${esc(a.nome)}</div>`).join('') : ''}` +
        S.advs.map((a,i) => `<div class="adv"><div class="row"><b>${i+1}. ${esc(a.nome||'(sem nome)')}</b> <small>${esc(a.oab||'')}</small>
          <button class="sec mini" data-del="${i}" style="margin-left:auto">remover</button></div>${ADV(i).map(campo).join('')}</div>`).join('') + `</details>`;
    } else h += `<details ${s.aberto?'open':''}><summary>${s.t}</summary>${s.c.map(campo).join('')}${s.cert?`<div class="row"><button id="bCert">Gerar certidão</button><button class="sec" id="bCopia">Copiar</button></div>
        <small>Usa também as datas e movimentações da seção “Telas 1 e 2”. Dado em falta sai como [PREJUDICADO].</small>
        <textarea id="txtCert" rows="14" style="width:100%;margin-top:6px;border:1px solid var(--bd);border-radius:4px;padding:6px;font:13px/1.45 Georgia,serif"></textarea>`:''}</details>`;
  }
  $('form').innerHTML = h;
  $('form').querySelectorAll('[data-k]').forEach(e => e.onchange = e.oninput = () => { set(e.dataset.k, e.value.trim()); delete S.orig[e.dataset.k]; salvar(); sugestao(); });
  $('form').querySelectorAll('[data-nc]').forEach(e => e.onchange = () => { S.docs.naoConsta = S.docs.naoConsta.filter(x => x!==e.dataset.nc); if (e.checked) S.docs.naoConsta.push(e.dataset.nc); salvar(); });
  $('form').querySelectorAll('[data-del]').forEach(b => b.onclick = () => { S.advs.splice(+b.dataset.del,1); salvar(); render(); });
  $('bCert').onclick = () => { $('txtCert').value = certidao(); };
  $('bCopia').onclick = () => { if (!$('txtCert').value) $('txtCert').value = certidao(); navigator.clipboard.writeText($('txtCert').value).then(() => msg('Certidão copiada.')); };
  $('form').querySelectorAll('[data-oab]').forEach(b => b.onclick = () => buscar({q: b.dataset.oab}));
  $('addAdv').onclick = () => { S.advs.push(novoAdv()); salvar(); render(); };
  $('bAdv').onclick = () => buscar({q: $('qAdv').value.trim()});
  $('qAdv').onkeydown = e => { if (e.key==='Enter') $('bAdv').click(); };
  sugestao();
}
function sugestao(){
  $('pend').style.display = (S.avisos||[]).length ? 'block' : 'none';
  $('pend').innerHTML = (S.avisos||[]).length ? '<b>Pendências encontradas nos autos</b><ul>'+S.avisos.map(a => '<li>'+esc(a)+'</li>').join('')+'</ul>' : '';
  const M = v => Requisitorio.moeda(v||'')||0, fm = n => n.toLocaleString('pt-BR',{minimumFractionDigits:2});
  const dev = Requisitorio.norm(S.proc.devedor||''); const g = LIMITE.find(g => dev.includes(Requisitorio.norm(g.devedor)));
  const teto = M(S.proc.limiteRpv) || (g ? g.limite : 0);
  const ps = [Object.assign({_t:'credor principal'}, S.cred), ...S.advs.map(a => Object.assign({_t:'honorários'}, a))]
    .map(p => ({nome: p.nome||'(sem nome)', t: p._t, tot: M(p.valorPrincipal)+M(p.valorSelic)+M(p.jurosMoratorios)+M(p.jurosCompensatorios)})).filter(p => p.tot);
  if (!S.proc.numero && !ps.length){ $('sug').style.display = 'none'; return; }
  $('sug').style.display = 'block';
  $('sug').innerHTML = `${S.nomePdf?'<b>'+esc(S.nomePdf)+'</b><br>':''}Processo ${esc(S.proc.numero||'?')}${S.proc.devedor?' · '+esc(S.proc.devedor):''}` +
    (ps.length && teto ? `<br>🔢 CALCULADO — por beneficiário, teto de R$ ${fm(teto)}${M(S.proc.limiteRpv)?'':' (regra local; confira o vigente na data do trânsito)'}:` +
      ps.map(p => `<br>• ${esc(p.nome)} (${p.t}): R$ ${fm(p.tot)} → <b>${p.tot>teto?'Precatório':'RPV — não entra no precatório'}</b>`).join('') : '');
}

/* ---------- certidão (modelo fixo da base de conhecimento, seção 7.2) ---------- */
function certidao(){
  const p = S.proc, c = S.cert || {}; const v = x => (x && String(x).trim()) || '[PREJUDICADO]';
  const ac = c.decisao !== 'r. Sentença'; const MES = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro']; const h = new Date();
  const f = [];
  f.push(`CERTIFICO que ${ac?'o V. Acórdão':'a r. Sentença'} transitou em julgado na data de ${v(p.dtTransitoDC)} (mov. seq. ${v(p.movTransito)}${ac?' dos autos de Recurso Inominado':''}).`);
  f.push(`CERTIFICO que o cálculo original foi apresentado aos ${v(c.dtCalculo)} e encontra-se no (mov. seq. ${v(c.movCalculo)}). A Execução judicial ou cumprimento de sentença iniciou aos ${v(p.dtAjuizExecucao)}.`);
  f.push(`CERTIFICO que a decisão que homologou o cálculo foi proferida aos ${v(c.dtHomolog)} e determinou a expedição do precatório requisitório, conforme (mov. seq. ${v(c.movDecHomolog)}).`);
  f.push(`CERTIFICO que a citação e intimação do executado para opor embargos foi realizada aos ${v(p.dtCitacaoFazenda)} no (mov. seq. ${v(p.movCitacao)}).`);
  if (c.impugnacao === 'Sim'){
    f.push(`CERTIFICO que Fazenda Pública executada opôs impugnação em data de ${v(c.dtImpug)} (mov. seq. ${v(c.movImpug)}). CERTIFICO que a decisão sobre impugnação ao cumprimento de sentença ou embargos do devedor foi proferida aos ${v(c.dtDecImpug)} (mov. seq. ${v(c.movDecImpug)}).`);
    f.push(`CERTIFICO que a decisão de HOMOLOGAÇÃO do valor e que determinou a expedição de PRECATÓRIO transitou em julgado na data de ${v(p.dtTransitoDEP)} (mov. seq. ${v(p.movExped)}).`);
  } else {
    f.push(`CERTIFICO que não houve oposição de embargos/impugnação ao cumprimento de sentença, conforme renúncia oferecida, sem manifestação. (mov. seq. ${v(p.movDecurso)})`);
    f.push(`CERTIFICO que a decisão que homologou o cálculo e determinou a expedição do precatório requisitório restaram preclusas, conforme renúncia oferecida pelo Executado aos ${v(p.dtTransitoDEP)} (mov. seq. ${v(p.movExped)}).`);
  }
  if (c.dtNatureza && c.movNatureza) f.push(`CERTIFICO que a decisão quanto à natureza do crédito foi proferida na data de ${c.dtNatureza} (mov. seq. ${c.movNatureza}).`);
  f.push(`CERTIFICO que houve a remessa ao Ministério Público aos ${v(c.dtMP)} (mov. seq. ${v(c.movMP)}).`);
  f.push('CERTIFICO que não há custas e despesas processuais, por tratar-se de Juizado Especial da Fazenda Pública.');
  return `CERTIDÃO\n\nEm cumprimento ao Código de Normas e ao Regimento Interno, ambos do TJPR:\n\n${f.join(' ')}\n\nO referido é verdade e dou fé. Eu, ${v(c.servidor)}, o digitei e subscrevi.\n\n${c.local||'Assis Chateaubriand'}, ${h.getDate()} de ${MES[h.getMonth()]} de ${h.getFullYear()}.`;
}

/* ---------- PDF do requisitório ---------- */
async function lerPdf(buf, nome){
  try {
    const doc = await pdfjsLib.getDocument({data: new Uint8Array(buf)}).promise; const lines = [];
    const pages = [];
    for (let i=1;i<=doc.numPages;i++){ const pg = await doc.getPage(i); const tc = await pg.getTextContent(); const L = itemsToLines(tc.items); pages.push(L); L.forEach(t => lines.push({t, p:i})); pg.cleanup();
      if (i % 50 === 0) msg(`Lendo o PDF… página ${i} de ${doc.numPages}`); }
    if (pages.slice(0,40).some(L => L.slice(0,4).some(l => /Ref\. mov\. \d+\.\d+/.test(l)))) return lerAutos(pages, nome);
    if (!lines.some(l => /Of[ií]cio Requisit[óo]rio|Dados do Of[ií]cio/i.test(l.t))) return msg('<span class="erro">O PDF não é um Ofício Requisitório nem os autos exportados do PROJUDI, ou é só imagem (sem texto para ler).</span>');
    const R = Requisitorio.parse(lines); const O = (k, v, p) => { if (v){ set(k, v); S.orig[k] = 'p. '+p; } };
    S.nomePdf = nome; const o = R.oficio, p = R.processo, pg = k => R.origem[k] || 1;
    O('proc.numero', p.numero, pg('processo.numero')); O('proc.juizo', o.vara, pg('oficio.vara')); set('proc.devedor', o.devedor||'');
    O('proc.descricaoAcao', p.nomeAcao, pg('processo.nomeAcao')); O('proc.tipoExecucao', /extra/i.test(p.tipoExecucao||'')?'Extrajudicial':(p.tipoExecucao?'Judicial':''), pg('processo.tipoExecucao'));
    O('proc.dtAjuizConhecimento', p.dtAjuizConhecimento, pg('processo.dtAjuizConhecimento')); O('proc.dtTransitoDC', p.dtTransito, pg('processo.dtTransito'));
    O('proc.dtAjuizExecucao', p.dtAjuizExecucao, pg('processo.dtAjuizExecucao')); O('proc.dtCitacaoFazenda', p.dtCitacaoFazenda, pg('processo.dtCitacaoFazenda'));
    O('proc.dtDecurso', p.dtDecursoEmbargos, pg('processo.dtDecursoEmbargos'));
    const princ = R.credores.find(c => /principal/i.test(c.tipo)) || R.credores[0];
    if (princ){ const P = princ.pagina; O('cred.nome', princ.nome, P); O('cred.cpf', princ.doc, P);
      O('cred.natureza', princ.naturezaCredito || o.naturezaCredito, P); O('cred.classificacao', princ.classificacao, P); O('cred.herdeiro', princ.herdeiro, P);
      O('cred.valorPrincipal', princ.valorPrincipal || princ.total, P); O('cred.jurosMoratorios', princ.valorJuros, P); O('cred.dataAtualizacao', princ.dataBase, P); }
    R.credores.filter(c => c !== princ && /honor/i.test(c.tipo)).forEach(c => { let a = S.advs.find(a => a.nome && Requisitorio.norm(a.nome)===Requisitorio.norm(c.nome));
      if (!a){ a = novoAdv(); S.advs.push(a); } const i = S.advs.indexOf(a), P = c.pagina, k = 'advs.'+i+'.';
      O(k+'nome', c.nome, P); O(k+'cpf', c.doc, P); O(k+'valorPrincipal', c.valorPrincipal || c.total, P); O(k+'jurosMoratorios', c.valorJuros, P); O(k+'dataAtualizacao', c.dataBase, P);
      if (/contrat/i.test(c.tipo)){ a.contratual = 'Sim'; a.sucumbencial = 'Não'; } });
    const G = n => R.documentos.find(d => d.num === n); const nc = (n, cod) => { const d = G(n); if (d && d.naoConsta && !S.docs.naoConsta.includes(cod)) S.docs.naoConsta.push(cod); };
    nc('2.b','AC'); nc('8','SA'); nc('6','CD'); nc('9','CP'); if (G('15') && G('15').naoConsta) O('cred.semDestaque', 'Sim', 3);
    salvar(); render(); msg(`PDF lido: ${R.credores.length} credor(es). Confira os campos e complete o que o requisitório não traz (movimentações, documentos, contas).`);
  } catch(e){ msg('<span class="erro">Falha ao ler o PDF: '+esc(e.message)+'</span>'); }
}
function lerAutos(pages, nome){
  const r = Autos.parseAutos(pages); const novo = r.campos['proc.numero'] && S.proc.numero && r.campos['proc.numero'].v !== S.proc.numero;
  if (novo){ const k = S.cert || {}; S = vazio(); if (k.servidor) S.cert.servidor = k.servidor; if (k.local) S.cert.local = k.local; }
  S.nomePdf = nome; let n = 0;
  for (const [k, c] of Object.entries(r.campos)){ if (k === 'cred.totalCalculo') continue; set(k, c.v); S.orig[k] = {t: c.t, o: c.o}; n++; }
  S.avisos = r.avisos; S.advAutos = r.advs; if (S.cred.conta && !S.cred.conta.procurador) S.cred.conta.procurador = 'Não';
  salvar(); render();
  msg(`Autos lidos: ${r.movs} movimentações, ${r.arquivos} arquivos, ${n} campos propostos. <b>Confira cada campo</b>: ⚠ INFERIDO e 🔢 CALCULADO são propostas, com a página e a movimentação de origem. Veja as pendências acima.`);
}
/* consulta, na aba do SGP, se já existe precatório para a numeração única (só leitura) */
async function sgpJaExiste(numero){
  const P = s => new DOMParser().parseFromString(s, 'text/html'); const url = '/precatorios/precatorioPesquisa.do';
  const d1 = P(await (await fetch(url, {credentials:'include'})).text()); const f = d1.forms[0]; if (!f || !f.elements['numeracaoUnicaFiltro']) return {erro:'A tela de pesquisa do SGP não abriu (sessão expirada?).'};
  const fd = new URLSearchParams(); [...f.elements].forEach(e => { if (!e.name || ['button','submit','reset'].includes(e.type)) return; if ((e.type==='radio'||e.type==='checkbox') && !e.checked) return; fd.set(e.name, e.value||''); });
  fd.set('numeracaoUnicaFiltro', numero);
  const d2 = P(await (await fetch(new URL(f.getAttribute('action')||url, location.origin+url).href, {method:'POST', credentials:'include', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body: fd.toString()})).text());
  const txt = d2.body ? d2.body.textContent : ''; const limpa = x => x.replace(/\s+/g,' ').trim();
  const tb = [...d2.querySelectorAll('table')].find(x => x.rows[0] && x.rows[0].cells.length >= 7 && /Credor principal/.test(x.rows[0].textContent));
  if (!tb) return /Nenhum registro/i.test(txt) ? {lista:[]} : {erro:'Não consegui ler o resultado da pesquisa do SGP.'};
  const H = [...tb.rows[0].cells].map(c => limpa(c.textContent)); const col = n => H.findIndex(h => h === n);
  const val = (r, n) => { const c = r.cells[col(n)]; if (!c) return ''; const k = c.cloneNode(true); k.querySelectorAll('table').forEach(x => x.remove()); return limpa(k.textContent); };
  const lista = [...tb.rows].slice(1).filter(r => r.cells.length === H.length).map(r => ({natureza: val(r,'Natureza'), autos: val(r,'Autos'), credor: val(r,'Credor principal'), ente: val(r,'Ente devedor'), situacao: val(r,'Situação'), pagamento: val(r,'Situação do Pagamento')}));
  return {lista};
}
async function verificar(){
  if (!S.proc.numero) return msg('Informe a numeração única (ou leia o PDF) antes de verificar.');
  const tabs = (await chrome.tabs.query({})).filter(t => /^https:\/\/portal\.tjpr\.jus\.br\/precatorios/.test(t.url||''));
  if (!tabs.length) return msg('<span class="erro">Abra o SGP (logado) em alguma aba para eu verificar.</span>');
  msg('Verificando no SGP…'); let r;
  try { [{result: r}] = await chrome.scripting.executeScript({target:{tabId: tabs[0].id}, func: sgpJaExiste, args:[S.proc.numero]}); } catch(e){ return msg('<span class="erro">Não consegui consultar o SGP: '+esc(e.message)+'</span>'); }
  if (!r || r.erro) return msg('<span class="erro">'+esc(r ? r.erro : 'O SGP não respondeu.')+'</span>');
  if (!r.lista.length) return msg(`<span class="ok">✓</span> Nenhum precatório encontrado no SGP para ${esc(S.proc.numero)}. <small>(Um rascunho de cadastro não concluído não aparece nesta pesquisa: o próprio SGP avisa ao iniciar.)</small>`);
  msg(`<span class="erro">✗ Já existe precatório no SGP para ${esc(S.proc.numero)}:</span><br>` + r.lista.map(l => `• ${esc(l.credor)} — ${esc(l.natureza)} — <b>${esc(l.situacao)}</b>${l.pagamento?' / '+esc(l.pagamento):''}`).join('<br>') + '<br><small>O SGP não aceita novo cadastro para a mesma parte: abra o existente em Precatórios › Pesquisa.</small>');
}
const msg = h => { $('log').style.display = 'block'; $('log').innerHTML = h; };
const drop = $('drop'); drop.onclick = () => $('file').click();
$('file').onchange = e => { const f = e.target.files[0]; if (f) f.arrayBuffer().then(b => lerPdf(b, f.name)); e.target.value = ''; };
drop.ondragover = e => { e.preventDefault(); drop.classList.add('on'); }; drop.ondragleave = () => drop.classList.remove('on');
drop.ondrop = e => { e.preventDefault(); drop.classList.remove('on'); const f = e.dataTransfer.files[0]; if (f) f.arrayBuffer().then(b => lerPdf(b, f.name)); };
$('limpar').onclick = () => { const k = S.cert || {}; S = vazio(); if (k.servidor) S.cert.servidor = k.servidor; if (k.local) S.cert.local = k.local; salvar(); render(); msg('Painel limpo.'); };

/* ---------- busca de advogado no PROJUDI ---------- */
async function buscar({q, login}){
  if (!q && !login) return msg('Informe a OAB ou o nome do advogado.');
  const tabs = (await chrome.tabs.query({})).filter(t => /^https:\/\/projudi\d*\.tjpr\.jus\.br\/projudi/.test(t.url||''));
  if (!tabs.length) return msg('<span class="erro">Abra o PROJUDI (logado) em alguma aba para eu consultar o cadastro de advogados.</span>');
  msg('Consultando o cadastro de advogados do PROJUDI…');
  const arg = login ? {login} : (/\d{3,}/.test(q) ? {oab:q} : {nome:q});
  let r; try { [{result: r}] = await chrome.scripting.executeScript({target:{tabId: tabs[0].id}, func: buscaAdvogadoProjudi, args:[arg]}); }
  catch(e){ return msg('<span class="erro">Não consegui consultar o PROJUDI: '+esc(e.message)+'</span>'); }
  if (!r) return msg('<span class="erro">O PROJUDI não respondeu.</span>');
  if (r.erro) return msg('<span class="erro">'+esc(r.erro)+'</span>');
  if (r.lista){ msg('Mais de um advogado encontrado — escolha abaixo.');
    $('escolha').innerHTML = r.lista.map(l => `<div class="row"><button class="sec mini" data-login="${esc(l.login)}">usar</button> ${esc(l.login)} — ${esc(l.nome)}</div>`).join('');
    $('escolha').querySelectorAll('[data-login]').forEach(b => b.onclick = () => buscar({login: b.dataset.login})); return; }
  const n = Requisitorio.norm(r.adv.nome); let a = S.advs.find(a => a.nome && Requisitorio.norm(a.nome)===n) || S.advs.find(a => a.cpf && a.cpf.replace(/\D/g,'')===r.adv.cpf);
  if (!a){ a = novoAdv(); S.advs.push(a); }
  Object.entries(r.adv).forEach(([k,v]) => { if (v) a[k] = v; });
  salvar(); render(); msg(`<span class="ok">✓</span> ${esc(r.adv.nome)} (${esc(r.adv.oab||r.adv.login)}) trazido do cadastro do PROJUDI. A conta bancária não existe lá: digite-a.`);
}

/* ---------- preencher a tela atual do SGP ---------- */
$('verificar').onclick = verificar;
$('preencher').onclick = async () => {
  const [tab] = await chrome.tabs.query({active:true, currentWindow:true});
  if (!tab || !/portal\.tjpr\.jus\.br\/precatorios/.test(tab.url||'')) return msg('<span class="erro">A aba ativa não é o cadastro de precatórios do SGP (portal.tjpr.jus.br/precatorios).</span>');
  msg('Preenchendo…');
  try {
    await chrome.scripting.executeScript({target:{tabId: tab.id}, files:['sgp.js']});
    const [{result: r}] = await chrome.scripting.executeScript({target:{tabId: tab.id}, func: (s, o) => window.__SGP2.preencher(s, o), args:[S, $('sobrescrever').checked]});
    const ic = {ok:'✓', erro:'✗', mantido:'=', nao:'–'};
    msg(`<b>${esc(r.tela||'')}</b><br>` + (r.log.length ? r.log.map(l => `<span class="${l.st}">${ic[l.st]||''}</span> ${esc(l.campo)}${l.msg?' <small>— '+esc(l.msg)+'</small>':''}`).join('<br>') : 'Nada a preencher nesta tela.') +
      `<br><small>✓ preenchido · = já estava preenchido (mantido) · – sem dado no painel · ✗ recusado. Confira e clique você mesmo em Próximo.</small>`);
  } catch(e){ msg('<span class="erro">Falha: '+esc(e.message)+'</span>'); }
};

chrome.storage.local.get('estado', s => { if (s.estado){ const z = vazio(); S = Object.assign(z, s.estado); S.cert = Object.assign(vazio().cert, s.estado.cert||{}); } render(); });
