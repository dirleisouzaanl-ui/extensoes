/* Parser do "Ofício Requisitório Judicial" (rascunho gerado pelo PROJUDI/TJPR).
   Entrada: array de {t: texto da linha, p: página}. Saída: objeto estruturado. */
(function(root){
const DATA=/(\d{2}\/\d{2}\/\d{4})/;
const norm=s=>(s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/\s+/g,' ').trim();

// rótulos conhecidos (ordem: mais longos primeiro p/ não "comer" um rótulo menor)
const LABELS=[
 'Data do decurso do prazo para opor embargos ou trânsito em julgado deste',
 'Data da citação da Fazenda Pública opor Embargos à Execução',
 'Data da citação da Fazenda Pública para opor Embargos à Execução',
 'Data do ajuizamento do processo de conhecimento',
 'Data do ajuizamento do processo de execução',
 'Data do trânsito em julgado da sentença/acórdão',
 'Maior de 60 anos na data da expedição do precatório',
 'Retenção de Contribuição Previdenciária',
 'Classificação para atualização do crédito',
 'Portador de doença grave descrita em lei',
 'Ente da Federação a que está vinculado',
 'Natureza da Obrigação (de acordo com a Tabela',
 'Data de nascimento','Data de Nascimento','Natureza do Crédito','Natureza do crédito',
 'Situação do CPF','Situação do CNPJ','Retenção de IRRF','Credor herdeiro','Autor da Ação',
 'CPF ou CNPJ','CPF/CNPJ','Número da Ação','Nome da Ação','Tipo de execução','Beneficiário',
 'Advogado','OAB','Percentual','Devedor','CNPJ','CPF','Total'
];
const LBL_RX=new RegExp('('+LABELS.map(l=>l.replace(/[.*+?^${}()|[\]\\\/]/g,'\\$&')).join('|')+')\\s*:','g');
const VALOR_RX=/^(Valor[^:]{0,60}):\s*R\$\s*([\d.]+,\d{2})(?:\s+em\s+(\d{2}\/\d{2}\/\d{4}))?/i;

function kv(line){ // devolve [[rotulo,valor],...] encontrados na linha
  const out=[];let m;const hits=[];LBL_RX.lastIndex=0;
  while((m=LBL_RX.exec(line))){hits.push({i:m.index,end:LBL_RX.lastIndex,l:m[1]});}
  hits.forEach((h,k)=>{const v=line.slice(h.end,k+1<hits.length?hits[k+1].i:undefined)
     .replace(/\*Na data da emiss[aã]o da minuta\.?/i,'').trim();out.push([h.l,v]);});
  return out;
}
const sim=v=>/^sim/i.test(v||'')?'Sim':(/^n[aã]o/i.test(v||'')?'Não':(v||''));
const moeda=s=>s?parseFloat(s.replace(/\./g,'').replace(',','.')):null;

function parse(lines){
  const r={oficio:{},processo:{},credores:[],resumo:{},documentos:[],origem:{}};
  const L=lines.map(x=>typeof x==='string'?{t:x,p:1}:x);
  const set=(obj,k,v,p)=>{if(v!==undefined&&v!==''&&obj[k]===undefined){obj[k]=v;r.origem[(obj===r.oficio?'oficio.':obj===r.processo?'processo.':'')+k]=p;}};
  let sec='',cred=null,docBuf=null;
  for(let i=0;i<L.length;i++){
    const {t,p}=L[i];
    if(/^RASCUNHO\s*\d*$/i.test(t)) continue;
    const em=t.match(/^\(em (\d{2}\/\d{2}\/\d{4})\)/); if(em){set(r.oficio,'dataMinuta',em[1],p);continue;}
    if(/^Do\(a\):/.test(t)){ // vara: linhas vizinhas
      const v=[L[i-1]&&L[i-1].t,t.replace(/^Do\(a\):/,''),L[i+1]&&L[i+1].t,L[i+2]&&!/^\(em/.test(L[i+2].t)?L[i+2].t:''];
      set(r.oficio,'vara',v.join(' ').replace(/\s+/g,' ').trim(),p);continue;}
    const hd=t.match(/^([A-G](?:\.\d+)?)\s*-\s*(.+)$/);
    if(hd){sec=hd[1];docBuf=null;
      if(/^[B-E]/.test(sec)){cred={secao:sec,tipo:hd[2].trim(),valores:[],campos:{},pagina:p};r.credores.push(cred);} else cred=null;
      continue;}
    if(sec==='A'||sec==='A.1'){
      if(/^Natureza da Obriga/.test(t)){const m=t.match(/TUA\)?:?\s*(.*)$/)||t.match(/Tabela\s*(.*)$/);
        let v=(m?m[1]:'').trim(); if(!v&&L[i+1]) v=L[i+1].t.replace(/^.*TUA\)?:?/,'').trim();
        const c=v.match(/^(\d{3,6})\s*(.*)$/); if(c){set(r.oficio,'tuaCodigo',c[1],p);set(r.oficio,'tuaDescricao',c[2].trim(),p);} else set(r.oficio,'tuaDescricao',v,p);
        continue;}
      if(/^Única de Assuntos/i.test(t)) continue;
      for(const [l,v] of kv(t)){const n=norm(l),o=sec==='A'?r.oficio:r.processo;
        const map={'natureza do credito':'naturezaCredito','autor da acao':'autor','cpf ou cnpj':'autorDoc','devedor':'devedor',
          'ente da federacao a que esta vinculado':'ente','numero da acao':'numero','nome da acao':'nomeAcao','tipo de execucao':'tipoExecucao',
          'data do ajuizamento do processo de conhecimento':'dtAjuizConhecimento','data do transito em julgado da sentenca/acordao':'dtTransito',
          'data do ajuizamento do processo de execucao':'dtAjuizExecucao','data da citacao da fazenda publica opor embargos a execucao':'dtCitacaoFazenda',
          'data da citacao da fazenda publica para opor embargos a execucao':'dtCitacaoFazenda',
          'data do decurso do prazo para opor embargos ou transito em julgado deste':'dtDecursoEmbargos'};
        const k=map[n]; if(!k) continue;
        let val=v; if(k==='devedor') val=v.replace(/de\(a\)\s*/i,'de ');
        if(/^dt/.test(k)){const d=v.match(DATA); val=d?d[1]:v;}
        set(o,k,val,p);}
      continue;}
    if(cred){
      const vm=t.match(VALOR_RX);
      if(vm){cred.valores.push({rotulo:vm[1].trim(),valor:vm[2],data:vm[3]||'',pagina:p}); if(vm[3]&&!cred.dataBase) cred.dataBase=vm[3]; continue;}
      for(const [l,v] of kv(t)){cred.campos[l]=v;const n=norm(l);
        const map={'beneficiario':'nome','cpf':'doc','cnpj':'doc','cpf/cnpj':'doc','cpf ou cnpj':'doc','natureza do credito':'naturezaCredito',
         'classificacao para atualizacao do credito':'classificacao','situacao do cpf':'situacaoDoc','situacao do cnpj':'situacaoDoc',
         'data de nascimento':'nascimento','maior de 60 anos na data da expedicao do precatorio':'maior60',
         'portador de doenca grave descrita em lei':'doencaGrave','credor herdeiro':'herdeiro','retencao de irrf':'irrf',
         'retencao de contribuicao previdenciaria':'previdencia','advogado':'advogado','oab':'oab','percentual':'percentual'};
        if(n==='total'){const m=v.match(/([\d.]+,\d{2})/); if(m) cred.total=m[1]; continue;}
        const k=map[n]; if(k&&cred[k]===undefined) cred[k]=['maior60','doencaGrave','herdeiro','irrf','previdencia'].includes(k)?sim(v):v;}
      continue;}
    if(sec==='F'){const m=t.match(/VALOR TOTAL REQUISITADO\s+([\d.]+,\d{2})/i); if(m){r.resumo.total=m[1];r.origem['resumo.total']=p;} continue;}
    if(sec==='G'){
      const m=t.match(/^(\d+(?:\.[a-z])?)\.\s+(.*)$/);
      if(m){docBuf={num:m[1],texto:m[2]};r.documentos.push(docBuf);}
      else if(docBuf && !/^[A-ZÀ-Ú ]+, em \d/.test(t) && !/Assinado/.test(t)) docBuf.texto+=' '+t;
      else docBuf=null;
    }
  }
  r.documentos.forEach(d=>{d.naoConsta=/N[ÃA]O CONSTA DOS AUTOS/i.test(d.texto);
    d.texto=d.texto.replace(/:\s*N[ÃA]O CONSTA DOS AUTOS;?/i,'').replace(/[:;.\s]+$/,'').trim();});
  r.credores.forEach(c=>{ if(!c.total&&c.valores.length) c.total=c.valores[0].valor;
    const pr=c.valores.find(v=>/principal/i.test(v.rotulo)); if(pr) c.valorPrincipal=pr.valor;
    const j=c.valores.find(v=>/juros/i.test(v.rotulo)); if(j) c.valorJuros=j.valor; });
  if(!r.resumo.total&&r.credores.length) r.resumo.total=r.credores.map(c=>c.total).filter(Boolean).reduce((a,b)=>a+moeda(b),0).toFixed(2).replace('.',',');
  return r;
}
function sugereTipo(r,regras){ // regras: [{devedor:'assis chateaubriand', limite: 8475.55}]
  const tot=moeda(r.resumo.total); const dev=norm(r.oficio.devedor);
  for(const g of (regras||[])){ if(dev.includes(norm(g.devedor))){
    const tipo=tot>g.limite?'Precatório':'RPV';
    return {tipo,motivo:`Total R$ ${r.resumo.total} ${tot>g.limite?'acima do':'dentro do'} limite de R$ ${g.limite.toLocaleString('pt-BR',{minimumFractionDigits:2})} (${g.devedor})`};}}
  return {tipo:'',motivo:'Sem regra de limite cadastrada para este devedor'};
}
const api={parse,sugereTipo,norm,moeda};
if(typeof module!=='undefined') module.exports=api; else root.Requisitorio=api;
})(this);
