/* Requisitório → SGP v2 — preenchimento das telas reais do cadastro (portal.tjpr.jus.br/precatorios/wizard/*).
   Regra fixa: NUNCA clica em Próximo, Prévio nem em botão de gerar precatório. Só preenche campos e
   confirma as janelinhas de pesquisa (endereço, conta, procuração) que ela mesma abriu. */
(function(){
if (window.__SGP2) return;
const W = ms => new Promise(r => setTimeout(r, ms));
const norm = s => (s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
const dig = s => (s||'').replace(/\D/g,'');
const F = () => document.forms[0];
const el = n => F() && F().elements[n];
const waitFor = async (fn, n=40) => { for (let i=0;i<n;i++){ const r = fn(); if (r) return r; await W(250); } return null; };
const UF = {AC:'Acre',AL:'Alagoas',AP:'Amapá',AM:'Amazonas',BA:'Bahia',CE:'Ceará',DF:'Distrito Federal',ES:'Espírito Santo',GO:'Goiás',MA:'Maranhão',MT:'Mato Grosso',MS:'Mato Grosso do Sul',MG:'Minas Gerais',PA:'Pará',PB:'Paraíba',PR:'Paraná',PE:'Pernambuco',PI:'Piauí',RJ:'Rio de Janeiro',RN:'Rio Grande do Norte',RS:'Rio Grande do Sul',RO:'Rondônia',RR:'Roraima',SC:'Santa Catarina',SP:'São Paulo',SE:'Sergipe',TO:'Tocantins'};

let LOG, OVER;
const log = (campo, st, msg) => LOG.push({campo, st, msg: msg||''});
const paint = (e, ok) => { if (e && e.style){ e.style.outline = '2px solid '+(ok?'#16a34a':'#dc2626'); e.style.outlineOffset = '1px'; } };
function fire(e){ ['input','keyup','change','blur'].forEach(t => e.dispatchEvent(new Event(t,{bubbles:true}))); }

function setText(e, v, rot){
  if (!e) return log(rot,'nao','campo não existe nesta tela');
  if (v===undefined || v===null || v==='') return;
  if (e.value && !OVER){ return log(rot, e.value===v?'ok':'mantido', e.value===v?'':'já tinha: '+e.value); }
  e.focus(); e.value = v; fire(e); paint(e, true); log(rot,'ok',v);
}
function setRadio(name, v, rot, root){
  if (v===undefined || v===null || v==='') return;
  const rs = [...(root||document).querySelectorAll(`input[type=radio][name="${name}"]`)];
  if (!rs.length) return log(rot,'nao','campo não existe nesta tela');
  const r = rs.find(x => x.value === String(v)); if (!r) return log(rot,'erro','opção "'+v+'" não existe');
  if (!r.checked) r.click(); paint(r.parentElement, true); log(rot,'ok',v);
}
function setSelect(e, v, rot){
  if (!e) return log(rot,'nao','campo não existe nesta tela');
  if (!v) return;
  const nv = norm(v);
  const o = [...e.options].find(o => o.value === v) || [...e.options].find(o => norm(o.text) === nv) ||
            [...e.options].find(o => o.value && (norm(o.text).startsWith(nv) || norm(o.text).includes(nv)));
  if (!o){ paint(e,false); return log(rot,'erro','opção "'+v+'" não encontrada'); }
  if (e.value !== o.value){ e.value = o.value; e.dispatchEvent(new Event('change',{bubbles:true})); }
  paint(e, true); log(rot,'ok',o.text.trim());
}
const simNao = v => /^s/i.test(v||'') ? 'true' : (/^n/i.test(v||'') ? 'false' : '');
const dialogo = sel => waitFor(() => { const d = document.querySelector('dialog[open]'); return d && d.querySelector(sel) ? d : null; });
const confirma = async d => { const b = [...d.querySelectorAll('button,input[type=button]')].find(b => /^Confirmar$/.test((b.textContent||b.value||'').trim())); if (b) b.click(); await W(1800); return !document.querySelector('dialog[open]'); };
const btnPesq = campo => { const e = el(campo); return e && e.parentElement.querySelector('button.pesquisa'); };

/* ---------- janelinhas ---------- */
async function conta(c, rot){
  if (!c || !c.agencia || !c.numero) return log(rot,'nao','conta não informada no painel');
  const alvo = el('contaBancaria.nomeNumeroCompletoComTitular');
  if (!alvo) return log(rot,'nao','campo não existe nesta tela');
  if (el('contaBancaria.id') && el('contaBancaria.id').value && !OVER) return log(rot,'mantido','já tinha: '+alvo.value);
  btnPesq('contaBancaria.nomeNumeroCompletoComTitular').click();
  let d = await dialogo('[name="conta.agencia"]'); if (!d) return log(rot,'erro','janela de conta não abriu');
  const cod = dig(c.banco).padStart(3,'0');
  const rb = d.querySelector(`input[name=codBanco][value="${cod}"]`) || d.querySelector('input[name=codBanco][value=""]');
  rb.click(); await W(1200); d = document.querySelector('dialog[open]');
  const set = (n, v) => { const e = document.querySelector('dialog[open]').querySelector(`[name="${n}"]`); if (e && v!==undefined && v!==''){ e.focus(); e.value = v; fire(e); } return e; };
  if (!rb.value){ const s = d.querySelector('[name="conta.banco"]'); const o = [...s.options].find(o => dig(o.text.split('-')[0]).padStart(3,'0') === cod);
    if (!o) return log(rot,'erro','banco '+cod+' não está na lista'); s.value = o.value; s.dispatchEvent(new Event('change',{bubbles:true})); await W(600); d = document.querySelector('dialog[open]'); }
  const op = d.querySelector('[name="conta.codigoOperacao"]');
  if (op){ if (!c.operacao) return log(rot,'erro','Caixa exige o código de operação (ex.: 001) — informe no painel');
    op.value = dig(c.operacao).padStart(3,'0'); op.dispatchEvent(new Event('change',{bubbles:true})); }
  set('conta.agencia', dig(c.agencia)); set('conta.dvAgencia', dig(c.dvAgencia)); set('conta.numero', dig(c.numero)); set('conta.dv', c.dv);
  const proc = simNao(c.procurador) === 'true';
  const tp = d.querySelector(`input[name="conta.titularEhProcurador"][value="${proc}"]`); if (tp) tp.click();
  if (proc){ await W(1500); d = document.querySelector('dialog[open]');
    if (!c.titularCpf || !c.titularNome){ log(rot,'erro','titular procurador: informe no painel o CPF e o nome do titular'); return; }
    const cpfT = dig(c.titularCpf); set('conta.cpfCnpjTitular', cpfT.length===11 ? cpfT.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/,'$1.$2.$3-$4') : c.titularCpf); await W(2500); d = document.querySelector('dialog[open]');
    const nt = d.querySelector('[name="conta.nomeTitular"]'); if (nt && !nt.value) set('conta.nomeTitular', c.titularNome); }
  const ok = await confirma(d);
  ok ? (paint(alvo,true), log(rot,'ok',alvo.value)) : log(rot,'erro','o SGP recusou a conta — confira a janela aberta');
}
async function endereco(a, rot){
  const alvo = el('enderecoNaoMP.enderecoCompleto'); if (!alvo) return;
  if (!a.cep && !a.logradouro) return log(rot,'nao','endereço não informado no painel');
  if (alvo.value && !OVER) return log(rot,'mantido','já tinha: '+alvo.value);
  btnPesq('enderecoNaoMP.enderecoCompleto').click();
  const d = await dialogo('[name="endereco.cep"]'); if (!d) return log(rot,'erro','janela de endereço não abriu');
  const set = (n, v) => { const e = d.querySelector(`[name="${n}"]`); if (e && v){ e.focus(); e.value = v; fire(e); } };
  set('endereco.cep', dig(a.cep).replace(/^(\d{5})(\d{3})$/,'$1-$2')); await W(1800);
  set('endereco.logradouro', a.logradouro); set('endereco.numero', a.numero || 'S/N'); set('endereco.complemento', a.complemento);
  set('endereco.bairro', a.bairro); set('endereco.localidade', a.cidade); set('endereco.telefone', a.telefone); set('endereco.email', a.email);
  const uf = d.querySelector('[name="endereco.UF"]'); const sig = (a.uf||'PR').toUpperCase();
  const o = [...uf.options].find(o => o.value === sig) || [...uf.options].find(o => norm(o.text) === norm(UF[sig]));
  if (o){ uf.value = o.value; uf.dispatchEvent(new Event('change',{bubbles:true})); }
  const ok = await confirma(d);
  ok ? (paint(alvo,true), log(rot,'ok',alvo.value)) : log(rot,'erro','o SGP recusou o endereço — confira a janela aberta');
}
async function docPicker(campoNome, campoCod, ref, rot){
  const alvo = el(campoNome); if (!alvo) return; if (!ref) return;
  if (el(campoCod) && el(campoCod).value && !OVER) return log(rot,'mantido','já tinha: '+alvo.value);
  btnPesq(campoNome).click();
  const d = await dialogo('input[name=codigoDocumentoProjudi]'); if (!d) return log(rot,'erro','janela de documentos não abriu');
  const a = [...d.querySelectorAll('a.files')].find(a => a.textContent.trim().startsWith(ref.trim()+' '));
  if (!a){ log(rot,'erro','arquivo '+ref+' não está na lista'); return; }
  a.closest('label').querySelector('input[type=radio]').click();
  const ok = await confirma(d); ok ? (paint(alvo,true), log(rot,'ok',alvo.value)) : log(rot,'erro','não confirmou');
}

/* ---------- telas ---------- */
const TELAS = [
 {nome:'1 · Identificação do processo', se:()=>el('numeracaoUnica'), faz: async S => {
    const e = el('numeracaoUnica'); if (e.value && !OVER) return log('Numeração única','mantido',e.value);
    e.focus(); e.value = S.proc.numero||''; fire(e); paint(e,true); log('Numeração única','ok',e.value); }},

 {nome:'2 · Dados do processo', se:()=>el('dataTransitoJulgado'), faz: async S => { const p = S.proc;
    if (p.juizo){ const rs = [...document.querySelectorAll('input[name=juizoOrigemId]')]; const alvo = norm(p.juizo);
      const r = rs.find(r => { const l = norm((r.labels && r.labels[0] ? r.labels[0].textContent : '') || (r.closest('label')||{}).textContent || (r.nextSibling||{}).textContent); return l && (l===alvo || l.includes(alvo) || alvo.includes(l)); });
      r ? (r.checked || r.click(), log('Juízo de origem','ok')) : log('Juízo de origem','erro','vara não encontrada entre as opções'); }
    const cpfs = [S.cred.cpf, ...(S.advs||[]).map(a=>a.cpf)].map(dig).filter(Boolean);
    document.querySelectorAll('input[name=partesCredoras]').forEach(c => { const nome = c.value.replace(/\d+$/,'');
      if (cpfs.some(x => c.value.endsWith(x))){ if (c.disabled) log('Parte: '+nome,'erro','bloqueada — já existe cadastro pendente para esta parte');
        else { c.checked || c.click(); paint(c.parentElement,true); log('Parte: '+nome,'ok'); } } });
    setText(el('descricaoAcao'), p.descricaoAcao, 'Descrição da ação');
    setRadio('tipoPrecatorio', /extra/i.test(p.tipoExecucao||'') ? 'EX' : (p.tipoExecucao ? 'JU' : ''), 'Tipo de execução');
    setText(el('dataAjuizamentoAcao'), p.dtAjuizOriginal, 'Ajuizamento da ação original');
    setText(el('dataTransitoJulgado'), p.dtTransitoDC, 'Trânsito em julgado – DC');
    setText(el('dataTransitoJulgadoDEP'), p.dtTransitoDEP, 'Trânsito em julgado – DEP');
    setText(el('numeroAcaoOriginaria'), p.numeroOriginaria, 'Número da ação originária');
    setText(el('dataDeAjuizamentoDoProcessoDeConhecimento'), p.dtAjuizConhecimento, 'Ajuizamento do conhecimento');
    setText(el('dataDeAjuizamentoDoProcessoDeExecucao'), p.dtAjuizExecucao, 'Ajuizamento da execução');
    setText(el('dataDeCitacaoDaFazendaPublicaOporEmbargosAExecucao'), p.dtCitacaoFazenda, 'Citação/intimação da Fazenda');
    setText(el('dataDeDecursoDoPrazoParaOporEmbargos'), p.dtDecurso, 'Decurso do prazo/trânsito da impugnação');
    setText(el('movCertTransitoEmJulgado'), p.movTransito, 'Mov. certidão de trânsito');
    setText(el('movCertCitacaoFazendaPublicaSobreEmbargosAExecucao'), p.movCitacao, 'Mov. citação/intimação da Fazenda');
    setText(el('movCertDecursoEmbargos'), p.movDecurso, 'Mov. decurso/trânsito da impugnação');
    setText(el('movCertPreclusaoDaDecisaoSobreHonorariosContratuais'), p.movDestaque, 'Mov. preclusão do destaque');
    setText(el('movCertPreclusaoDaDecisaoDeHomologacaoDoCalculo'), p.movHomolog, 'Mov. preclusão da homologação');
    setText(el('movCertPreclusaoDaDecisaoDeExpedicaoDoOficio'), p.movExped, 'Mov. preclusão da expedição'); }},

 {nome:'3 · Seleção de documentos', se:()=>document.querySelector('input[name=itensSelecionados]'), faz: async S => {
    for (const [tipo, refs] of Object.entries(S.docs.tipos||{})){
      for (const ref of String(refs||'').split(/[;,]/).map(s=>s.trim()).filter(Boolean)){
        const a = [...document.querySelectorAll('a.files')].find(a => a.textContent.trim().startsWith(ref+' '));
        if (!a){ log(tipo+' ← '+ref,'erro','arquivo não está na lista do PROJUDI'); continue; }
        const c = a.previousElementSibling; if (!c.checked) c.click();
        const s = await waitFor(() => document.getElementById(c.value).querySelector('select[name=tipoDocumento]'));
        if (!s){ log(tipo+' ← '+ref,'erro','lista de tipos não carregou'); continue; }
        if (s.value && s.value !== tipo && !OVER){ log(tipo+' ← '+ref,'mantido','arquivo já marcado como '+s.value+' (mesmo arquivo em 2 tipos: avance, volte e inclua de novo)'); continue; }
        s.value = tipo; s.dispatchEvent(new Event('change',{bubbles:true})); paint(s,true); log(tipo+' ← '+ref,'ok',a.textContent.trim());
      } }
    document.querySelectorAll('input[name=tiposDeDocumentoQueNaoConstamDosAutos]').forEach(c => { const quer = (S.docs.naoConsta||[]).includes(c.value);
      if (quer && !c.checked){ c.click(); paint(c.parentElement,true); log('Não consta: '+c.value,'ok'); } }); }},

 {nome:'4 · Advogados (honorários)', se:()=>document.querySelector('input[name=honorarioSucumbencial]'), faz: async S => {
    document.querySelectorAll('input[name=honorarioSucumbencial]').forEach(cs => { const tr = cs.closest('tr'); const nome = norm(tr.children[0].textContent);
      const a = (S.advs||[]).find(a => a.nome && (norm(a.nome)===nome || nome.includes(norm(a.nome)) || norm(a.nome).includes(nome)));
      if (!a) return log('Advogado '+tr.children[0].textContent.trim(),'nao','não está no painel');
      const cc = tr.querySelector('input[name=honorarioContratual]');
      const m = (c, quer, r) => { if (c && quer && !c.checked){ c.click(); } if (c && quer){ paint(c.parentElement,true); log(a.nome+' — '+r,'ok'); } };
      m(cc, simNao(a.contratual)==='true', 'contratuais'); m(cs, simNao(a.sucumbencial)==='true', 'sucumbenciais'); }); }},

 {nome:'6 · Credor de honorários (advogado)', se:()=>document.querySelector('input[name=radioCPFCNPJ]'), faz: async S => {
    const pj = sel => document.querySelector(`input[name=radioCPFCNPJ][value=${sel}]`);
    let a = null; const nomeTela = () => el('nomeCredor') && el('nomeCredor').value;
    if (!el('cpfCredor') && !el('cnpjCredor')){ pj('PF').click(); await waitFor(() => el('cpfCredor')); await W(300); }
    if (nomeTela()) a = (S.advs||[]).find(x => x.nome && (norm(x.nome)===norm(nomeTela()) || norm(nomeTela()).includes(norm(x.nome))));
    if (!a) a = (S.advs||[])[S.advSel||0];
    if (!a) return log('Advogado','erro','nenhum advogado no painel');
    log('Advogado da tela','ok',a.nome);
    if (el('cpfCredor')){ const c = el('cpfCredor'); if (!c.value || OVER){ c.focus(); c.value = dig(a.cpf).replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/,'$1.$2.$3-$4'); fire(c); await W(3000); paint(el('cpfCredor'),true); log('CPF','ok',a.cpf); } }
    setText(el('nomeCredor'), a.nome, 'Nome'); setText(el('rgCredor'), a.rg, 'Doc. identificação'); setText(el('orgaoExpedidorDocIdentificacaoCredor'), a.rgOrgao, 'Órgão expedidor');
    setText(el('dataNascimentoCredor'), a.nascimento, 'Data de nascimento');
    setRadio('credorFalecido', simNao(a.falecido), 'Falecido'); await W(1200); setRadio('credorHerdeiro', simNao(a.herdeiro), 'Herdeiro'); await W(1200);
    await endereco(a, 'Endereço'); await conta(a.conta, 'Conta bancária'); }},

 {nome:'5 · Credor do valor principal', se:()=>el('classificacaoCredito'), faz: async S => { const c = S.cred;
    const nat = {alimentar:'AL', comum:'CM', 'alimentar e comum':'ALCM'}[norm(c.natureza)]; if (c.natureza && !nat) log('Natureza do processo','erro','valor "'+c.natureza+'" não reconhecido');
    if (nat){ setRadio('naturezaProcessoId', nat, 'Natureza do processo'); await W(1500); }
    setSelect(el('classificacaoCredito'), c.classificacao, 'Classificação para atualização');
    if (c.tipoNatureza){ setSelect(el('tipoNatureza'), c.tipoNatureza, 'Tipo da natureza'); await W(1500); }
    if (c.decisaoNatureza) await docPicker('nomeComprovanteTipoNatureza', 'codComprovanteTipoNatureza', c.decisaoNatureza, 'Decisão que fixou a natureza');
    if (c.servidorPublico && el('credorServidorPublico')) setSelect(el('credorServidorPublico'), c.servidorPublico, 'Servidor público da adm. direta');
    setText(el('rgCredor'), c.rg, 'Doc. identificação'); setText(el('orgaoExpedidorDocIdentificacaoCredor'), c.rgOrgao, 'Órgão expedidor');
    setRadio('credorFalecido', simNao(c.falecido), 'Falecido'); await W(1200); setRadio('credorHerdeiro', simNao(c.herdeiro), 'Credor é herdeiro'); await W(1200);
    await conta(c.conta, 'Conta bancária');
    await docPicker('nomeDocumentoProcuracao', 'codDocumentoProcuracao', c.procuracao, 'Procuração/substabelecimento');
    const nc = document.getElementById('chk_naoConstaDecisaoHonorariosContratuais');
    if (nc && simNao(c.semDestaque)==='true'){ nc.checked || nc.click(); paint(nc.parentElement,true); log('Destaque de contratuais: não consta','ok'); }
    [...F().querySelectorAll(':invalid')].forEach(e => { const td = e.closest('td'); log('Obrigatório em branco', 'erro', td && td.previousElementSibling ? td.previousElementSibling.textContent.replace(/[*:]/g,'').trim().slice(0,70) : e.name); }); }},

 {nome:'11 · Valores dos credores', se:()=>document.querySelector('[name^=valorIndividualizado]'), faz: async S => {
    const todos = [Object.assign({_r:'Credor principal'}, S.cred), ...(S.advs||[]).map(a => Object.assign({_r:'Advogado'}, a))];
    for (const v of [...document.querySelectorAll('[name^=valorIndividualizado]')]){ const id = v.name.replace('valorIndividualizado',''); const tr = v.closest('tr'); const nome = norm(tr.children[0].textContent);
      const p = todos.find(p => p.nome && (norm(p.nome)===nome || nome.includes(norm(p.nome)))); const R = tr.children[0].textContent.trim().split('\n')[0];
      if (!p){ log(R,'nao','sem valores no painel'); continue; }
      setText(v, p.valorPrincipal, R+' — principal'); setText(el('valorSelic'+id), p.valorSelic, R+' — Selic'); setText(el('jurosMoratorios'+id), p.jurosMoratorios, R+' — juros moratórios');
      setText(el('jurosCompensatorios'+id), p.jurosCompensatorios, R+' — juros compensatórios'); setText(el('dataAtualizacao'+id), p.dataAtualizacao, R+' — data de atualização');
      // planilha de cálculo de valores originais (botão ^ → janela de documentos do Projudi)
      const box = document.getElementById(id); const bt = box && box.querySelector('button.attach'); const rp = R+' — planilha de cálculo';
      if (!p.planilha){ log(rp,'nao','arquivo não informado no painel'); continue; }
      if (box && box.querySelector('a') && !OVER){ log(rp,'mantido','já anexada: '+box.textContent.replace(/\s+/g,' ').trim().slice(0,60)); continue; }
      if (!bt){ log(rp,'erro','botão ^ não encontrado'); continue; }
      bt.click(); const d = await dialogo('input[name=codigoDocumentoProjudi]'); if (!d){ log(rp,'erro','janela de documentos não abriu'); continue; }
      const a = [...d.querySelectorAll('a.files')].find(a => a.textContent.trim().startsWith(p.planilha.trim()+' '));
      if (!a){ log(rp,'erro','arquivo '+p.planilha+' não está na lista'); const f = [...d.querySelectorAll('button')].find(b => /Fechar/.test(b.textContent)); if (f) f.click(); await W(500); continue; }
      a.closest('label').querySelector('input[type=radio]').click(); const ok = await confirma(d);
      ok ? log(rp,'ok',a.textContent.trim()) : log(rp,'erro','não confirmou');
    } }}
];

function avisoGerar(){ document.querySelectorAll('button,input[type=button],input[type=submit]').forEach(b => { const t = norm(b.value || b.textContent);
  if (/gerar (o |os )?precatorio|gerar requisi|gerar rpv|^gerar|^concluir$/.test(t) && !b.dataset.sgpAviso){ b.dataset.sgpAviso = '1'; b.style.outline = '3px dashed #dc2626';
    b.title = 'Requisitório → SGP: a extensão não aciona este botão. Concluir gera os precatórios e não pode ser desfeito.'; } }); }

window.__SGP2 = {
  preencher: async (S, overwrite) => { LOG = []; OVER = !!overwrite; avisoGerar();
    if (!/\/precatorios\//.test(location.pathname)) return {tela:null, log:[{campo:'Página', st:'erro', msg:'a aba atual não é o cadastro de precatórios do SGP'}]};
    const t = TELAS.find(t => t.se()); if (!t) return {tela:'Tela sem preenchimento automático', log:[]};
    try { await t.faz(S); } catch(e){ log('Falha','erro',e.message); }
    return {tela: t.nome, log: LOG}; },
  tela: () => { const t = TELAS.find(t => t.se()); return t ? t.nome : null; }
};
})();
