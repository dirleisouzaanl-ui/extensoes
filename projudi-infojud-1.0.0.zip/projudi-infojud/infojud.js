// INFOJUD (Receita Federal / e-CAC) — tela "Registrar Solicitação"
// Campos conforme o Manual do Usuário InfoJud: Processo*, Tipo do Processo, Vara, Plantão (Sim/Não),
// Justificativa, e a linha de pedidos CPF/CNPJ + Tipo + Ano + "Incluir Pedido". O botão "Enviar"
// NUNCA é clicado pela extensão.
// Localização por RÓTULO da tabela (célula do rótulo → campo seguinte), pois a tela não foi mapeada ao vivo.
(function () {
  if (window.__piInfojud) return;
  window.__piInfojud = true;

  const KEY_FILA = 'pi_fila';     // pedidos pendentes de "Incluir Pedido" (sobrevive ao recarregamento da tela)
  const KEY_PREF = 'pi_pref';     // escolhas memorizadas: tipo do processo, vara, justificativa, tipos, anos
  const st = {
    get: (k) => new Promise((r) => chrome.storage.local.get(k, (o) => r(o[k] || null))),
    set: (k, v) => new Promise((r) => chrome.storage.local.set({ [k]: v }, r))
  };
  const visivel = (el) => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  const ehTelaRegistrar = () => /registrar solicitacao/.test(PR.norm(document.body ? document.body.textContent.slice(0, 4000) : '')) && !!campo(/^processo/, 'input');

  // rótulo = NÓ DE TEXTO visível que casa com a expressão (a tela mistura rótulos e campos na mesma célula)
  function rotulo(re) {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const t = PR.norm(n.nodeValue);
      if (!t || t.length > 40 || !re.test(t)) continue;
      const pai = n.parentElement;
      if (!pai || pai.closest('#pi-painel, script, style, option, select') || !visivel(pai)) continue;
      return n;
    }
    return null;
  }
  function campo(re, sel) {
    const r = rotulo(re);
    if (!r) return null;
    return [...document.querySelectorAll(sel)].find((e) => visivel(e) && !e.closest('#pi-painel') && (r.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) || null;
  }
  const botao = (re) => [...document.querySelectorAll('input[type=button], input[type=submit], button, a')]
    .find((b) => visivel(b) && !b.closest('#pi-painel') && re.test(PR.norm(b.value || b.textContent))) || null;
  const opcoes = (sel) => sel ? [...sel.options].filter((o) => {
    const t = PR.norm(o.text).replace(/[^a-z0-9 ]/g, '').trim();
    return o.value && t && !/^(selecione|tipo|ano)$/.test(t);
  }) : [];

  function escolherOpcao(sel, texto) {
    if (!sel || !texto) return false;
    const o = opcoes(sel).find((x) => PR.norm(x.text) === PR.norm(texto)) || opcoes(sel).find((x) => PR.norm(x.text).includes(PR.norm(texto)));
    if (!o) return false;
    sel.value = o.value;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }
  function cnj(d, el) {
    // campo curto (sem máscara) recebe só os 20 dígitos
    return el && el.maxLength > 0 && el.maxLength < 25 ? d.processoDigitos : d.processo;
  }

  // ---------- cabeçalho da solicitação ----------
  async function preencherCabecalho(d, pref) {
    const feito = [], falta = [];
    const proc = campo(/^processo/, 'input[type=text], input:not([type])');
    if (proc && !proc.value) { PR.setValue(proc, cnj(d, proc)); feito.push('Processo'); }
    else if (!proc) falta.push('Processo');

    const tipoProc = campo(/^tipo do processo/, 'select');
    if (tipoProc && pref.tipoProcesso) (escolherOpcao(tipoProc, pref.tipoProcesso) ? feito : falta).push('Tipo do Processo');
    else if (tipoProc && !tipoProc.value) falta.push('Tipo do Processo (escolha e clique em Memorizar)');

    const vara = campo(/^vara/, 'select');
    if (vara && pref.vara) (escolherOpcao(vara, pref.vara) ? feito : falta).push('Vara');
    else if (vara && !vara.value) falta.push('Vara (escolha e clique em Memorizar)');

    const nao = [...document.querySelectorAll('input[type=radio]')].find((r) => visivel(r) && /plantao/.test(PR.norm(r.name + ' ' + r.id)) && /^n/.test(PR.norm(r.value)))
      || (() => { const r = rotulo(/^plantao/); return r && [...document.querySelectorAll('input[type=radio]')].filter((x) => r.compareDocumentPosition(x) & Node.DOCUMENT_POSITION_FOLLOWING)[1]; })();
    if (nao) { if (!nao.checked) nao.click(); feito.push('Plantão: Não'); } else falta.push('Plantão');

    const just = campo(/^justificativa/, 'textarea');
    if (just && !just.value && pref.justificativa) { PR.setValue(just, pref.justificativa); feito.push('Justificativa'); }
    return { feito, falta };
  }

  // ---------- pedidos: CPF/CNPJ × tipo × ano, um "Incluir Pedido" por vez ----------
  function montarFila(d, pref) {
    const docs = d.executados.filter((e) => PR.digits(e.documento).length >= 11);
    const anos = String(pref.anos || '').split(/[^\d]+/).filter((a) => /^\d{4}$/.test(a));
    const fila = [];
    for (const e of docs) {
      const pj = PR.digits(e.documento).length === 14;
      const tipos = (pj ? pref.tiposPJ : pref.tiposPF) || [];
      for (const t of tipos) {
        const comAno = !/cadastr|endere/.test(PR.norm(t)); // dados cadastrais não têm ano
        if (comAno && anos.length) anos.forEach((a) => fila.push({ doc: PR.digits(e.documento), nome: e.nome, tipo: t, ano: a }));
        else fila.push({ doc: PR.digits(e.documento), nome: e.nome, tipo: t, ano: '' });
      }
    }
    return fila;
  }

  let executando = false, saindo = false;
  window.addEventListener('beforeunload', () => { saindo = true; });
  window.addEventListener('pagehide', () => { saindo = true; });
  async function incluirProximo() {
    if (executando || saindo) return;
    const f = await st.get(KEY_FILA);
    if (!f || !f.ativo) return;
    if (f.i >= f.itens.length) {
      f.ativo = false; await st.set(KEY_FILA, f);
      PR.toast(`${f.itens.length} pedido(s) incluído(s). CONFIRA a lista e clique você em "Enviar".`, 'ok', 20000);
      const env = botao(/^enviar$/); if (env) env.classList.add('pi-destaque');
      return;
    }
    executando = true;
    try {
      const p = f.itens[f.i];
      const doc = campo(/^cpf\s*\/\s*cnpj/, 'input[type=text], input:not([type])');
      const tipo = campo(/^tipo:?$/, 'select');
      const ano = campo(/^ano:?$/, 'select');
      const incluir = botao(/incluir pedido/);
      if (!doc || !tipo || !incluir) { PR.toast('Linha de pedido (CPF/CNPJ, Tipo, Incluir Pedido) não localizada.', 'erro'); f.ativo = false; await st.set(KEY_FILA, f); return; }
      PR.setValue(doc, p.doc);
      await PR.sleep(300);
      if (!escolherOpcao(tipo, p.tipo)) {
        PR.toast(`Tipo "${p.tipo}" não existe para ${p.doc}. Pedido pulado.`, 'aviso');
        f.i++; await st.set(KEY_FILA, f); executando = false; return incluirProximo();
      }
      if (!p.ano) { const a = campo(/^ano:?$/, 'select'); if (a) { a.value = ''; a.dispatchEvent(new Event('change', { bubbles: true })); } }
      if (p.ano) {
        await PR.waitFor(() => opcoes(campo(/^ano:?$/, 'select')).length, 4000);
        if (!escolherOpcao(campo(/^ano:?$/, 'select'), p.ano)) {
          PR.toast(`Ano ${p.ano} indisponível para ${p.tipo}. Pedido pulado.`, 'aviso');
          f.i++; await st.set(KEY_FILA, f); executando = false; return incluirProximo();
        }
      }
      await PR.sleep(400);
      f.i++; await st.set(KEY_FILA, f);          // avança ANTES do clique (a tela pode recarregar)
      PR.toast(`Incluindo pedido ${f.i}/${f.itens.length}: ${p.doc} — ${p.tipo}${p.ano ? ' ' + p.ano : ''}`);
      incluir.click();
      // se a tela não recarregar (inclusão por script), segue para o próximo
      await PR.sleep(3000);
      executando = false;
      if (!saindo) incluirProximo();
    } finally {
      executando = false;
    }
  }

  async function iniciar() {
    const d = await PR.load();
    if (!d) return PR.toast('Nenhum processo capturado. No PROJUDI, clique em "Capturar p/ INFOJUD".', 'erro');
    const pref = (await st.get(KEY_PREF)) || {};
    if (!(pref.tiposPF || []).length && !(pref.tiposPJ || []).length) return PR.toast('Marque no painel os tipos de pedido (PF/PJ) e clique em Memorizar.', 'erro');
    const r = await preencherCabecalho(d, pref);
    const itens = montarFila(d, pref);
    if (!itens.length) return PR.toast('Nenhum pedido a incluir (confira executados, tipos e anos).', 'erro');
    await st.set(KEY_FILA, { ativo: true, i: 0, itens, processo: d.processo });
    PR.toast(`Cabeçalho: ${r.feito.join(', ') || '—'}${r.falta.length ? ' | Pendente: ' + r.falta.join(', ') : ''}. Incluindo ${itens.length} pedido(s)...`, r.falta.length ? 'aviso' : 'ok', 12000);
    await PR.sleep(800);
    incluirProximo();
  }

  // memoriza as escolhas feitas na tela e no painel
  async function memorizar() {
    const pref = (await st.get(KEY_PREF)) || {};
    const tp = campo(/^tipo do processo/, 'select');
    const vr = campo(/^vara/, 'select');
    const js = campo(/^justificativa/, 'textarea');
    if (tp && tp.value) pref.tipoProcesso = tp.options[tp.selectedIndex].text.trim();
    if (vr && vr.value) pref.vara = vr.options[vr.selectedIndex].text.trim();
    if (js && js.value.trim()) pref.justificativa = js.value.trim();
    pref.tiposPF = [...document.querySelectorAll('#pi-painel input[data-pf]:checked')].map((c) => c.value);
    pref.tiposPJ = [...document.querySelectorAll('#pi-painel input[data-pj]:checked')].map((c) => c.value);
    pref.anos = $('pi-anos').value.trim();
    await st.set(KEY_PREF, pref);
    PR.toast(`Memorizado: Tipo do Processo "${pref.tipoProcesso || '—'}", Vara "${pref.vara || '—'}", ${pref.tiposPF.length} tipo(s) PF, ${pref.tiposPJ.length} tipo(s) PJ, anos ${pref.anos || '—'}.`);
  }

  // ---------- painel ----------
  async function montarPainel() {
    if ($('pi-painel') || !ehTelaRegistrar()) return;
    const d = await PR.load();
    const pref = (await st.get(KEY_PREF)) || {};
    const tiposTela = opcoes(campo(/^tipo:?$/, 'select')).map((o) => o.text.trim());
    const anoAtual = new Date().getFullYear();
    const anosPadrao = pref.anos || [anoAtual - 2, anoAtual - 1, anoAtual].join(', ');
    const ck = (t, lista, attr) => `<label class="pi-ck"><input type="checkbox" ${attr} value="${esc(t)}" ${(lista || []).includes(t) ? 'checked' : ''}> ${esc(t)}</label>`;
    const docs = d ? d.executados.filter((e) => PR.digits(e.documento).length >= 11) : [];
    const p = document.createElement('div');
    p.id = 'pi-painel';
    p.innerHTML = `
      <div class="pi-tit">PROJUDI → INFOJUD <span class="pi-x" title="Minimizar">–</span></div>
      <div class="pi-corpo">
        ${d ? `<div><b>Proc.:</b> ${esc(d.processo)}</div>${docs.map((e) => `<div>• ${esc(e.nome)} — ${esc(e.documento)}</div>`).join('') || '<div>Sem executado com CPF/CNPJ.</div>'}`
            : '<div>Nenhum processo capturado. No PROJUDI, clique em <b>Capturar p/ INFOJUD</b>.</div>'}
        <div class="pi-sub">Tipos de pedido — Pessoa Física</div>
        <div class="pi-cks">${tiposTela.map((t) => ck(t, pref.tiposPF, 'data-pf')).join('') || '<i>sem opções na tela</i>'}</div>
        <div class="pi-sub">Tipos de pedido — Pessoa Jurídica</div>
        <div class="pi-cks">${tiposTela.map((t) => ck(t, pref.tiposPJ, 'data-pj')).join('') || '<i>sem opções na tela</i>'}</div>
        <div class="pi-sub">Anos das declarações</div>
        <input id="pi-anos" value="${esc(anosPadrao)}">
        <button type="button" id="pi-mem" class="pi-sec">Memorizar escolhas (tela + painel)</button>
        <button type="button" id="pi-go">Preencher solicitação</button>
        <button type="button" id="pi-stop" class="pi-sec">Parar</button>
        <div class="pi-nota">A extensão não clica em Enviar.</div>
      </div>`;
    document.body.appendChild(p);
    p.querySelector('.pi-x').onclick = () => p.classList.toggle('pi-min');
    $('pi-mem').onclick = memorizar;
    $('pi-go').onclick = iniciar;
    $('pi-stop').onclick = async () => { const f = await st.get(KEY_FILA); if (f) { f.ativo = false; await st.set(KEY_FILA, f); } PR.toast('Interrompido.', 'aviso'); };
  }

  const tick = () => { montarPainel(); };
  new MutationObserver(() => { clearTimeout(window.__piT); window.__piT = setTimeout(tick, 400); }).observe(document.documentElement, { childList: true, subtree: true });
  setTimeout(async () => { tick(); if (ehTelaRegistrar()) incluirProximo(); }, 800); // retoma a fila após recarregar
  chrome.storage.onChanged.addListener((ch) => { if (ch[PR.KEY]) { const x = $('pi-painel'); if (x) x.remove(); montarPainel(); } });
})();
