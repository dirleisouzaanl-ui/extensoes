// PROJUDI (TJPR) — captura dos dados do processo para o INFOJUD
// Mapeado em 10/10/2026 na tela "buscaProcesso.do" (frame userMainFrame):
//  - abas: li#tabItemprefix0..N (onclick setTab); a aba carregada vira div#tabprefixN
//  - Informações Gerais: td.labelRadio = rótulo, td seguinte = valor
//  - Partes e Outros: h4 (Exequente/Executado/...) + table.resultTable [ícone, Nome, RG, CPF/CNPJ, Observação, Advogados]
(function () {
  if (window.__piProjudi) return;
  window.__piProjudi = true;

  const ehTelaProcesso = () => document.getElementById('tabHorz') && document.getElementById('tabItemprefix2');

  const abaAtiva = () => {
    const d = document.querySelector('div[id^="tabprefix"]');
    return d ? Number(d.id.replace('tabprefix', '')) : null;
  };

  // setTab() do PROJUDI faz submit de document.forms[0] (recarrega a página).
  // Aqui o mesmo envio é feito por fetch, sem sair da tela, e o HTML é lido em memória.
  async function buscarAba(n, forcar) {
    if (!forcar && abaAtiva() === n) return document.getElementById('tabprefix' + n);
    const li = document.getElementById('tabItemprefix' + n);
    const m = li && (li.getAttribute('onclick') || '').match(/setTab\('([^']*)',\s*'([^']*)'/);
    const f = document.forms[0];
    if (!m || !f) return null;
    const fd = new FormData(f);
    fd.set('selectedIcon', m[2]);
    const url = m[1] && m[1] !== 'null' ? m[1] : f.action;
    let r;
    if ((f.method || 'get').toUpperCase() === 'POST') {
      r = await fetch(url, { method: 'POST', body: new URLSearchParams(fd), credentials: 'include' });
    } else {
      const u = new URL(url, location.href);
      for (const [k, v] of fd) u.searchParams.set(k, v);
      r = await fetch(u, { credentials: 'include' });
    }
    const buf = await r.arrayBuffer();
    const cs = ((r.headers.get('content-type') || '').match(/charset=([\w-]+)/i) || [])[1] || 'iso-8859-1';
    const doc = new DOMParser().parseFromString(new TextDecoder(cs).decode(buf), 'text/html');
    return doc.getElementById('tabprefix' + n);
  }

  const textoLimpo = (el) => {
    if (!el) return '';
    const c = el.cloneNode(true);
    c.querySelectorAll('script, style').forEach((x) => x.remove());
    return c.textContent.replace(/\s+/g, ' ').trim();
  };

  // rótulos em td.labelRadio (Informações Gerais) e td.label (capa: Classe, Assunto, Valor da Causa)
  function lerRotulos(raiz) {
    const out = {};
    raiz.querySelectorAll('td.labelRadio, th.labelRadio, td.label, th.label').forEach((td) => {
      const rot = textoLimpo(td).replace(/:$/, '');
      const val = textoLimpo(td.nextElementSibling);
      if (rot && !(rot in out)) out[rot] = val;
    });
    return out;
  }

  function lerPartes(raiz) {
    const partes = [];
    raiz.querySelectorAll('h4').forEach((h4) => {
      const polo = h4.textContent.trim();
      let t = h4.nextElementSibling;
      while (t && t.tagName !== 'TABLE' && t.tagName !== 'H4') t = t.nextElementSibling;
      if (!t || t.tagName !== 'TABLE' || !t.rows.length) return;
      const cab = [...t.rows[0].cells].map((c) => PR.norm(c.textContent));
      const iNome = cab.indexOf('nome');
      const iDoc = cab.findIndex((c) => c.includes('cpf'));
      if (iNome < 0 || iDoc < 0) return;
      for (let r = 1; r < t.rows.length; r++) {
        const cells = t.rows[r].cells;
        if (cells.length < cab.length) continue;
        const nome = cells[iNome].textContent.replace(/\s+/g, ' ').trim();
        const doc = cells[iDoc].textContent.replace(/\s+/g, ' ').trim();
        if (nome) partes.push({ polo, nome, documento: doc });
      }
    });
    return partes;
  }

  function moeda(s) {
    const m = String(s || '').match(/[\d.]+,\d{2}/);
    return m ? m[0] : '';
  }

  async function capturar() {
    const abaOriginal = abaAtiva();
    const texto = document.body.innerText;
    const cnj = (texto.match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/) || [''])[0];
    const topo = lerRotulos(document);

    const d0 = await buscarAba(0);
    const info = d0 ? lerRotulos(d0) : {};
    const d2 = await buscarAba(2);
    const partes = d2 ? lerPartes(d2) : [];
    const d3 = await buscarAba(3); // movimentações: procura placa/RENAVAM nas descrições
    const veic = PR.extrairVeiculos([texto, d2 ? d2.textContent : '', d3 ? d3.textContent : ''].join('\n'));
    // devolve ao servidor a aba que estava aberta (o PROJUDI memoriza a aba na sessão)
    if (abaOriginal !== null && abaOriginal !== 3) { try { await buscarAba(abaOriginal, true); } catch (e) {} }

    const executados = partes.filter((p) => /execut|requerid|reu|réu|devedor/i.test(p.polo));
    const dados = {
      capturadoEm: new Date().toISOString(),
      origem: location.host,
      processo: cnj,
      processoDigitos: PR.digits(cnj),
      classe: topo['Classe Processual'] || '',
      assunto: topo['Assunto Principal'] || '',
      comarca: info['Comarca'] || '',
      juizo: info['Juízo'] || '',
      juiz: info['Juiz'] || '',
      valorCausa: moeda(info['Valor da Causa'] || topo['Valor da Causa']),
      transito: info['Data do Trânsito em Julgado'] || '',
      partes,
      executados: executados.length ? executados : partes.filter((p) => !/exequente|autor|requerente/i.test(p.polo)),
      placas: veic.placas,
      renavams: veic.renavams,
      executadoSel: 0
    };
    await PR.save(dados);
    return dados;
  }

  function injetarBotao() {
    if (!ehTelaProcesso() || document.getElementById('pi-btn-capturar')) return;
    const b = document.createElement('button');
    b.id = 'pi-btn-capturar';
    b.className = 'pi-fab';
    b.type = 'button';
    b.textContent = 'Capturar p/ INFOJUD';
    b.title = 'Captura o processo e os executados (CPF/CNPJ) para preencher a solicitação no INFOJUD';
    b.addEventListener('click', async () => {
      b.disabled = true; b.textContent = 'Capturando...';
      try {
        const d = await capturar();
        const validos = d.executados.filter((e) => PR.digits(e.documento).length >= 11);
        if (!validos.length) { PR.toast('Nenhum executado com CPF/CNPJ no PROJUDI.', 'erro'); return; }
        PR.toast(`${d.processo}: ${validos.map((e) => e.nome + ' — ' + e.documento).join(' | ')}. Abra o INFOJUD > Registrar Solicitação.`);
      } catch (e) {
        PR.toast('Falha na captura: ' + e.message, 'erro');
      } finally {
        b.disabled = false; b.textContent = 'Capturar p/ INFOJUD';
      }
    });
    document.body.appendChild(b);
  }

  injetarBotao();
  new MutationObserver(() => injetarBotao()).observe(document.documentElement, { childList: true, subtree: true });
})();
