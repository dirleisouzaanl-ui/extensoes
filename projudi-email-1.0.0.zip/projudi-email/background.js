// Envio pelo Google Apps Script implantado na conta do próprio usuário (ver apps-script/Codigo.gs).
// O e-mail sai da conta Google que implantou o script e fica em "Enviados" do Gmail.

async function postScript(url, token, corpo) {
  if (!/^https:\/\/script\.google\.com\/macros\/s\/[^/]+\/exec/.test(url || '')) {
    throw new Error('Endereço do Apps Script não configurado ou inválido (deve terminar em /exec). Abra as opções da extensão.');
  }
  const r = await fetch(url, {
    method: 'POST',
    // text/plain evita a pré-verificação CORS; o script lê e.postData.contents
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify(Object.assign({ token }, corpo)),
    redirect: 'follow',
    credentials: 'omit'
  });
  const txt = await r.text();
  let j;
  try { j = JSON.parse(txt); } catch (e) {
    throw new Error('O Apps Script não devolveu JSON (HTTP ' + r.status + '). Confira se a implantação é "App da Web" com acesso "Qualquer pessoa" e se a URL é a da versão implantada.');
  }
  if (!j.ok) throw new Error(j.erro || 'Falha no envio.');
  return j;
}

chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  if (!msg || !msg.peAcao) return false;
  (async () => {
    const o = await chrome.storage.local.get('pe_cfg');
    const cfg = o.pe_cfg || {};
    if (msg.peAcao === 'teste') {
      return postScript(msg.url || cfg.urlScript, msg.token !== undefined ? msg.token : cfg.token, { acao: 'teste' });
    }
    if (msg.peAcao === 'enviar') {
      return postScript(cfg.urlScript, cfg.token, Object.assign({ acao: 'enviar' }, msg.email));
    }
    if (msg.peAcao === 'opcoes') { chrome.runtime.openOptionsPage(); return { ok: true }; }
    throw new Error('Ação desconhecida.');
  })().then((r) => responder({ ok: true, r }), (e) => responder({ ok: false, erro: e.message }));
  return true;
});

chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
