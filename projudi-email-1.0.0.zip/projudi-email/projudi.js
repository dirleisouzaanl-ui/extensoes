// PROJUDI (TJPR) — painel "Enviar por e-mail" nos autos
// Estrutura da tela "buscaProcesso.do" (frame userMainFrame), a mesma mapeada nas extensões INFOJUD/RENAJUD:
//  - abas: li#tabItemprefix0..N (onclick setTab); a aba carregada vira div#tabprefixN
//  - Informações Gerais: td.labelRadio = rótulo, td seguinte = valor
//  - Partes e Outros: h4 (Exequente/Executado/...) + table.resultTable
//  - Movimentações: tr com [ícone/+ Arquivos, Seq., Data, Evento, Movimentado por]; ao clicar no "+"
//    a linha seguinte traz os links /projudi/arquivo.do (o PDF em si).
(function () {
  if (window.__peProjudi) return;
  window.__peProjudi = true;

  const RASCUNHO = 'pe_rascunho';
  const LIMITE_BYTES = 24 * 1024 * 1024; // Gmail: 25 MB por mensagem

  const ehTelaProcesso = () => document.getElementById('tabHorz') && document.querySelector('li[id^="tabItemprefix"]');

  const lerSessao = () => { try { return JSON.parse(sessionStorage.getItem(RASCUNHO) || 'null'); } catch (e) { return null; } };
  const gravarSessao = (v) => { try { v ? sessionStorage.setItem(RASCUNHO, JSON.stringify(v)) : sessionStorage.removeItem(RASCUNHO); } catch (e) {} };

  // ---------------------------------------------------------------- captura dos dados do processo
  const abaAtiva = () => {
    const d = document.querySelector('div[id^="tabprefix"]');
    return d ? Number(d.id.replace('tabprefix', '')) : null;
  };
  const indiceAba = (re, padrao) => {
    const li = [...document.querySelectorAll('li[id^="tabItemprefix"]')].find((l) => re.test(PE.norm(l.textContent)));
    return li ? Number(li.id.replace('tabItemprefix', '')) : padrao;
  };

  // setTab() do PROJUDI faz submit de document.forms[0]; aqui o mesmo envio é feito por fetch, sem sair da tela.
  async function buscarAba(n, forcar) {
    if (!forcar && abaAtiva() === n) return document.getElementById('tabprefix' + n);
    const li = document.getElementById('tabItemprefix' + n);
    const m = li && (li.getAttribute('onclick') || '').match(/setTab\('([^']*)',\s*'([^']*)'/);
    const f = document.forms[0];
    if (!m || !f) return null;
    const fd = new FormData(f);
    fd.set('selectedIcon', m[2]);
    const url = m[1] && m[1] !== 'null' ? m[1] : f.action;
    let r;
    if ((f.method || 'get').toUpperCase() === 'POST') {
      r = await fetch(url, { method: 'POST', body: new URLSearchParams(fd), credentials: 'include' });
    } else {
      const u = new URL(url, location.href);
      for (const [k, v] of fd) u.searchParams.set(k, v);
      r = await fetch(u, { credentials: 'include' });
    }
    const buf = await r.arrayBuffer();
    const cs = ((r.headers.get('content-type') || '').match(/charset=([\w-]+)/i) || [])[1] || 'iso-8859-1';
    const doc = new DOMParser().parseFromString(new TextDecoder(cs).decode(buf), 'text/html');
    return doc.getElementById('tabprefix' + n);
  }

  const textoLimpo = (el) => {
    if (!el) return '';
    const c = el.cloneNode(true);
    c.querySelectorAll('script, style').forEach((x) => x.remove());
    return c.textContent.replace(/\s+/g, ' ').trim();
  };

  // texto com espaço entre os nós (textContent cola "NOME" + "email@..." de células vizinhas)
  const textoNos = (el) => {
    if (!el) return '';
    const w = (el.ownerDocument || document).createTreeWalker(el, NodeFilter.SHOW_TEXT);
    const out = [];
    while (w.nextNode()) out.push(w.currentNode.nodeValue);
    return out.join(' ');
  };

  function lerRotulos(raiz) {
    const out = {};
    raiz.querySelectorAll('td.labelRadio, th.labelRadio, td.label, th.label').forEach((td) => {
      const rot = textoLimpo(td).replace(/:$/, '');
      const val = textoLimpo(td.nextElementSibling);
      if (rot && !(rot in out)) out[rot] = val;
    });
    return out;
  }

  function lerPartes(raiz) {
    const partes = [];
    raiz.querySelectorAll('h4').forEach((h4) => {
      const polo = h4.textContent.trim();
      let t = h4.nextElementSibling;
      while (t && t.tagName !== 'TABLE' && t.tagName !== 'H4') t = t.nextElementSibling;
      if (!t || t.tagName !== 'TABLE' || !t.rows.length) return;
      const cab = [...t.rows[0].cells].map((c) => PE.norm(c.textContent));
      const iNome = cab.indexOf('nome');
      if (iNome < 0) return;
      for (let r = 1; r < t.rows.length; r++) {
        const cells = t.rows[r].cells;
        if (cells.length < cab.length) continue;
        const nome = cells[iNome].textContent.replace(/\s+/g, ' ').trim();
        if (nome) partes.push({ polo, nome, emails: PE.emails(textoNos(t.rows[r])) });
      }
    });
    return partes;
  }

  let processo = null;
  async function capturar() {
    if (processo) return processo;
    const texto = document.body.innerText;
    const cnj = (texto.match(PE.RE_CNJ) || [''])[0];
    const topo = lerRotulos(document);
    const original = abaAtiva();
    let info = {}, partes = [], emailsAutos = [];
    try {
      const iInfo = indiceAba(/informac/, 0);
      const iPartes = indiceAba(/partes/, 2);
      const d0 = await buscarAba(iInfo);
      info = d0 ? lerRotulos(d0) : {};
      const d2 = await buscarAba(iPartes);
      partes = d2 ? lerPartes(d2) : [];
      emailsAutos = PE.emails([textoNos(d0), textoNos(d2)].join(' '));
      // devolve ao servidor a aba que estava aberta (o PROJUDI memoriza a aba na sessão)
      if (original !== null && original !== iPartes) await buscarAba(original, true);
    } catch (e) { /* segue com o que houver na tela */ }
    const ativo = partes.filter((p) => /exequente|autor|requerente|reclamante|impetrante|promovente/i.test(p.polo));
    const passivo = partes.filter((p) => /executad|requerid|reu|réu|reclamad|impetrad|promovid|devedor/i.test(p.polo));
    processo = {
      processo: cnj,
      classe: topo['Classe Processual'] || info['Classe Processual'] || '',
      assunto: topo['Assunto Principal'] || info['Assunto Principal'] || '',
      comarca: info['Comarca'] || '',
      juizo: info['Juízo'] || info['Juizo'] || '',
      juiz: info['Juiz'] || '',
      polo_ativo: ativo.map((p) => p.nome).join(', '),
      polo_passivo: passivo.map((p) => p.nome).join(', '),
      partes,
      emailsAutos
    };
    return processo;
  }

  // ---------------------------------------------------------------- movimentações e arquivos (DOM da tela)
  const ehLinhaMov = (tr) => tr && tr.cells && tr.cells.length >= 5 && /^\d+$/.test(tr.cells[1].innerText.trim()) &&
    /^\d{2}\/\d{2}\/\d{4}/.test(tr.cells[2].innerText.trim());
  const linhasMov = () => [...document.querySelectorAll('tr')].filter(ehLinhaMov);

  function movimentos() {
    return linhasMov().map((tr) => ({
      tr,
      seq: +tr.cells[1].innerText.trim(),
      data: tr.cells[2].innerText.trim().slice(0, 10),
      evento: tr.cells[3].innerText.trim().split('\n')[0].trim().slice(0, 80),
      por: tr.cells[4].innerText.replace(/\s+/g, ' ').trim(),
      temArquivo: /arquivo/i.test(tr.cells[0].innerText) || !!tr.cells[0].querySelector('a')
    })).filter((m) => m.temArquivo).sort((a, b) => b.seq - a.seq);
  }

  const linksDe = (tr) => {
    const n = tr.nextElementSibling;
    return n && !ehLinhaMov(n)
      ? [...n.querySelectorAll('a[href]')].filter((a) => /arquivo\.do|\.pdf/i.test(a.href)) : [];
  };

  async function arquivosDe(mov) {
    if (!linksDe(mov.tr).length) {
      const t = mov.tr.cells[0].querySelector('a[href^="javascript"]') || mov.tr.cells[0].querySelector('a') ||
        mov.tr.cells[0].querySelector('img');
      if (t) t.click();
      for (let i = 0; i < 50 && !linksDe(mov.tr).length; i++) await PE.sleep(200);
    }
    const vistos = new Set();
    return linksDe(mov.tr).filter((a) => !vistos.has(a.href) && vistos.add(a.href)).map((a) => {
      const bruto = (a.textContent || a.title || 'documento').replace(/\s+/g, ' ').trim() || 'documento';
      const generico = /^(online|arquivo|documento)?\.?pdf$|^online/i.test(bruto);
      let nome = generico ? `${mov.evento} - mov ${mov.seq}` : bruto.replace(/\.pdf$/i, '');
      nome = PE.nomeArquivo(nome) + '.pdf';
      return { url: a.href, nome, rotulo: `Mov. ${mov.seq} – ${mov.evento} (${bruto})` };
    });
  }

  async function baixar(arq) {
    const r = await fetch(arq.url, { credentials: 'include' });
    if (!r.ok) throw new Error(`${arq.nome}: HTTP ${r.status}`);
    const tipo = (r.headers.get('content-type') || '').split(';')[0].trim() || 'application/pdf';
    if (/text\/html/i.test(tipo)) throw new Error(`${arq.nome}: o PROJUDI devolveu uma página, não o arquivo (sessão expirada?).`);
    const cd = r.headers.get('content-disposition') || '';
    const buf = await r.arrayBuffer();
    let nome = arq.nome;
    const mNome = cd.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
    if (mNome && !/^online\.pdf$/i.test(decodeURIComponent(mNome[1]))) {
      try { nome = PE.nomeArquivo(decodeURIComponent(mNome[1])); } catch (e) {}
    }
    if (tipo === 'application/pdf' && !/\.pdf$/i.test(nome)) nome += '.pdf';
    return { nome, tipo, base64: PE.ab2b64(buf), tamanho: buf.byteLength };
  }

  // ---------------------------------------------------------------- painel
  let painel = null, cfg = null;
  const sel = {}; // seq -> { mov, arquivos: [{url,nome,rotulo,marcado}] }

  const h = (tag, attrs = {}, ...filhos) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') e.className = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else if (v !== undefined && v !== null && v !== false) e.setAttribute(k, v === true ? '' : v);
    }
    filhos.flat().forEach((f) => f != null && e.append(f.nodeType ? f : document.createTextNode(String(f))));
    return e;
  };
  const $ = (id) => painel && painel.querySelector('#' + id);

  function varsBase() {
    const p = processo || {};
    const { data, hora } = PE.dataHora();
    const v = {
      processo: p.processo || '', classe: p.classe || '', assunto_processo: p.assunto || '', comarca: p.comarca || '',
      juizo: p.juizo || '', juiz: p.juiz || '', polo_ativo: p.polo_ativo || '', polo_passivo: p.polo_passivo || '',
      exequente: p.polo_ativo || '', executado: p.polo_passivo || '', autor: p.polo_ativo || '', reu: p.polo_passivo || '',
      data, hora
    };
    v.assinatura = PE.render(cfg.assinatura || '', v);
    return v;
  }

  function salvarRascunho(extra) {
    if (!painel) return;
    gravarSessao(Object.assign({
      aberto: true, modeloId: $('pe-modelo').value, para: $('pe-para').value, cc: $('pe-cc').value,
      assunto: $('pe-assunto').value, corpo: $('pe-corpo').value, processo: processo && processo.processo
    }, extra || {}));
  }

  function aplicarModelo(id, manterTexto) {
    const m = cfg.modelos.find((x) => x.id === id) || cfg.modelos[0];
    if (!m) return;
    if (!manterTexto) {
      const v = varsBase();
      $('pe-assunto').value = PE.render(m.assunto, v);
      $('pe-corpo').value = PE.render(m.corpo, v); // {documentos} e {destinatario} ficam para o envio
      if (m.para) $('pe-para').value = m.para;
    }
    autoMarcar(m);
  }

  async function autoMarcar(m) {
    if (!m || !m.autoAnexo) return;
    let re;
    try { re = new RegExp(m.autoAnexo, 'i'); } catch (e) { return; }
    if (Object.keys(sel).length) return; // não mexe no que o usuário já marcou
    const alvo = movimentos().find((x) => re.test(PE.norm(x.evento)) || re.test(x.evento));
    if (!alvo) return;
    const ck = painel.querySelector(`input[data-seq="${alvo.seq}"]`);
    if (ck && !ck.checked) { ck.checked = true; await marcarMov(alvo, true); }
  }

  async function marcarMov(mov, marcado) {
    const caixa = painel.querySelector(`div[data-arqs="${mov.seq}"]`);
    if (!marcado) { delete sel[mov.seq]; if (caixa) caixa.textContent = ''; atualizarResumo(); return; }
    if (caixa) caixa.textContent = 'carregando arquivos…';
    try {
      const arqs = await arquivosDe(mov);
      sel[mov.seq] = { mov, arquivos: arqs.map((a) => Object.assign(a, { marcado: true })) };
      if (caixa) {
        caixa.textContent = '';
        if (!arqs.length) caixa.textContent = 'sem arquivos legíveis nesta movimentação';
        arqs.forEach((a) => caixa.append(h('label', { class: 'pe-arq' },
          h('input', { type: 'checkbox', checked: true, onchange: (e) => { a.marcado = e.target.checked; atualizarResumo(); } }),
          ' ' + a.nome)));
      }
    } catch (e) {
      if (caixa) caixa.textContent = 'falha: ' + e.message;
    }
    atualizarResumo();
  }

  const selecionados = () => Object.values(sel).flatMap((s) => s.arquivos.filter((a) => a.marcado));
  function atualizarResumo() {
    const n = selecionados().length;
    const r = $('pe-resumo');
    if (r) r.textContent = n ? `${n} anexo(s) selecionado(s)` : 'nenhum anexo selecionado';
  }

  function montarListaMov() {
    const box = $('pe-movs');
    box.textContent = '';
    const movs = movimentos().slice(0, 30);
    if (!movs.length) {
      const iMov = indiceAba(/movimenta/, null);
      box.append(h('div', { class: 'pe-nota' }, 'Para anexar documentos, abra a aba Movimentações.'));
      if (iMov !== null) {
        box.append(h('button', { type: 'button', class: 'pe-sec', onclick: () => {
          salvarRascunho();
          const li = document.getElementById('tabItemprefix' + iMov);
          (li.querySelector('a') || li).click();
        } }, 'Abrir aba Movimentações'));
      }
      return;
    }
    movs.forEach((m) => {
      box.append(h('div', { class: 'pe-mov' },
        h('label', { title: m.por },
          h('input', { type: 'checkbox', 'data-seq': m.seq, onchange: (e) => marcarMov(m, e.target.checked) }),
          h('b', {}, ` ${m.seq} `), `${m.data} — ${m.evento}`),
        h('div', { class: 'pe-arqs', 'data-arqs': m.seq })));
    });
  }

  function montarDestinatarios() {
    const dl = $('pe-dl');
    dl.textContent = '';
    (cfg.destinatarios || []).forEach((d) => dl.append(h('option', { value: d.email }, d.nome)));
    const sc = $('pe-cat');
    sc.textContent = '';
    sc.append(h('option', { value: '' }, '+ adicionar do catálogo…'));
    (cfg.destinatarios || []).forEach((d) => sc.append(h('option', { value: d.email }, `${d.nome} <${d.email}>`)));
    const chips = $('pe-chips');
    chips.textContent = '';
    const doProc = new Map();
    (processo.partes || []).forEach((p) => p.emails.forEach((e) => doProc.set(e, `${p.polo}: ${p.nome}`)));
    (processo.emailsAutos || []).forEach((e) => { if (!doProc.has(e)) doProc.set(e, 'e-mail nos autos'); });
    if (doProc.size) {
      chips.append(h('div', { class: 'pe-sub2' }, 'E-mails encontrados nos autos:'));
      doProc.forEach((quem, e) => chips.append(h('span', { class: 'pe-chip', title: quem, onclick: () => adicionarPara(e) }, e)));
    }
  }

  function adicionarPara(email) {
    const atuais = PE.listaEmails($('pe-para').value);
    if (!atuais.includes(email)) atuais.push(email);
    $('pe-para').value = atuais.join(', ');
    salvarRascunho();
  }

  function nomeDestinatario(lista) {
    return lista.map((e) => {
      const d = (cfg.destinatarios || []).find((x) => x.email.toLowerCase() === e.toLowerCase());
      if (d) return d.nome;
      const p = (processo.partes || []).find((x) => x.emails.includes(e.toLowerCase()));
      return p ? p.nome : e;
    }).join(', ');
  }

  async function enviar(somenteGmail) {
    const para = PE.listaEmails($('pe-para').value);
    const cc = PE.listaEmails($('pe-cc').value);
    const invalidos = [...para, ...cc].filter((e) => !PE.emailValido(e));
    if (!para.length) return PE.toast('Informe ao menos um destinatário.', 'erro');
    if (invalidos.length) return PE.toast('E-mail inválido: ' + invalidos.join(', '), 'erro');

    const arqs = selecionados();
    const vars = Object.assign(varsBase(), {
      destinatario: nomeDestinatario(para),
      documentos: arqs.length ? arqs.map((a) => a.rotulo).join('; ') : '(sem anexos)'
    });
    const assunto = PE.render($('pe-assunto').value, vars);
    const texto = PE.render($('pe-corpo').value, vars);

    if (somenteGmail) {
      const u = new URL('https://mail.google.com/mail/');
      u.search = new URLSearchParams({ view: 'cm', fs: '1', to: para.join(','), cc: cc.join(','), su: assunto, body: texto }).toString();
      window.open(u.href, '_blank');
      PE.toast('Rascunho aberto no Gmail. Os anexos precisam ser incluídos manualmente.', 'aviso');
      return;
    }
    if (!cfg.urlScript) return PE.toast('Configure o envio (URL do Apps Script) nas opções da extensão.', 'erro');

    const bt = $('pe-enviar');
    bt.disabled = true;
    const status = (t) => { bt.textContent = t; };
    try {
      const anexos = [];
      let total = 0;
      for (let i = 0; i < arqs.length; i++) {
        status(`Baixando anexo ${i + 1}/${arqs.length}…`);
        const b = await baixar(arqs[i]);
        total += b.tamanho;
        if (total > LIMITE_BYTES) throw new Error('Os anexos passam de 24 MB (limite do Gmail). Desmarque algum arquivo.');
        anexos.push({ nome: b.nome, tipo: b.tipo, base64: b.base64 });
      }
      const mb = (total / 1048576).toFixed(1);
      if (cfg.confirmar !== false) {
        const ok = confirm(`ENVIAR E-MAIL?\n\nPara: ${para.join(', ')}${cc.length ? '\nCc: ' + cc.join(', ') : ''}\nAssunto: ${assunto}\nAnexos (${anexos.length}, ${mb} MB):\n${anexos.map((a) => ' • ' + a.nome).join('\n') || ' (nenhum)'}`);
        if (!ok) { PE.toast('Envio cancelado.', 'aviso'); return; }
      }
      status('Enviando…');
      const resp = await chrome.runtime.sendMessage({
        peAcao: 'enviar',
        email: {
          para: para.join(','), cc: cc.join(','), cco: cfg.cco || '', assunto, texto, html: PE.textoParaHtml(texto),
          nomeRemetente: cfg.nomeRemetente || '', responderPara: cfg.responderPara || '', anexos
        }
      });
      if (!resp || !resp.ok) throw new Error((resp && resp.erro) || 'Sem resposta do serviço de envio.');
      const r = resp.r || {};
      const dh = PE.dataHora();
      const certidao = PE.render(cfg.certidao, Object.assign({}, vars, dh, {
        conta: r.conta || 'o e-mail da Secretaria', para: para.join(', '), assunto,
        documentos: anexos.length ? anexos.map((a) => a.nome).join('; ') : '(sem anexos)'
      }));
      await PE.addHist({
        em: new Date().toISOString(), processo: processo.processo, para: para.join(', '), cc: cc.join(', '),
        assunto, anexos: anexos.map((a) => a.nome), conta: r.conta || ''
      });
      mostrarCertidao(certidao, r);
      gravarSessao(null);
      PE.toast(`E-mail enviado para ${para.join(', ')}${r.cota !== undefined ? ` (cota restante hoje: ${r.cota})` : ''}.`);
    } catch (e) {
      PE.toast('Não enviado: ' + e.message, 'erro', 12000);
    } finally {
      bt.disabled = false; bt.textContent = 'Enviar e-mail';
    }
  }

  function mostrarCertidao(texto) {
    const box = $('pe-cert');
    box.textContent = '';
    const ta = h('textarea', { rows: 6, readonly: true });
    ta.value = texto;
    box.append(h('div', { class: 'pe-sub' }, '✓ Enviado — certidão para juntar'), ta,
      h('button', { type: 'button', onclick: async () => {
        try { await navigator.clipboard.writeText(ta.value); PE.toast('Certidão copiada.'); }
        catch (e) { ta.select(); document.execCommand('copy'); PE.toast('Certidão copiada.'); }
      } }, 'Copiar certidão'));
    box.scrollIntoView({ block: 'nearest' });
  }

  async function abrirPainel(rascunho) {
    if (painel) { painel.classList.remove('pe-min'); return; }
    cfg = await PE.loadCfg();
    painel = h('div', { id: 'pe-painel' },
      h('div', { class: 'pe-tit' },
        h('span', {}, '✉ PROJUDI → E-mail'),
        h('span', {},
          h('span', { class: 'pe-x', title: 'Opções', onclick: () => chrome.runtime.sendMessage({ peAcao: 'opcoes' }) }, '⚙'),
          h('span', { class: 'pe-x', title: 'Minimizar', onclick: () => painel.classList.toggle('pe-min') }, '–'),
          h('span', { class: 'pe-x', title: 'Fechar', onclick: () => { painel.remove(); painel = null; document.body.classList.remove('pe-aberto'); gravarSessao(null); } }, '×'))),
      h('div', { class: 'pe-corpo' }, 'Lendo o processo…'));
    document.body.appendChild(painel);
    document.body.classList.add('pe-aberto');
    await capturar();
    const corpo = painel.querySelector('.pe-corpo');
    corpo.textContent = '';
    const p = processo;
    corpo.append(
      h('div', { class: 'pe-proc' }, h('b', {}, p.processo || 'processo não identificado'), p.classe ? ' — ' + p.classe : ''),
      h('label', { class: 'pe-sub' }, 'Modelo'),
      h('select', { id: 'pe-modelo', onchange: (e) => { aplicarModelo(e.target.value); salvarRascunho(); } },
        cfg.modelos.map((m) => h('option', { value: m.id }, m.nome))),
      h('label', { class: 'pe-sub' }, 'Para'),
      h('input', { id: 'pe-para', list: 'pe-dl', placeholder: 'e-mail(s) separados por vírgula', oninput: () => salvarRascunho() }),
      h('datalist', { id: 'pe-dl' }),
      h('select', { id: 'pe-cat', onchange: (e) => { if (e.target.value) adicionarPara(e.target.value); e.target.value = ''; } }),
      h('div', { id: 'pe-chips' }),
      h('label', { class: 'pe-sub' }, 'Cc'),
      h('input', { id: 'pe-cc', placeholder: 'opcional', oninput: () => salvarRascunho() }),
      h('label', { class: 'pe-sub' }, 'Assunto'),
      h('input', { id: 'pe-assunto', oninput: () => salvarRascunho() }),
      h('label', { class: 'pe-sub' }, 'Mensagem'),
      h('textarea', { id: 'pe-corpo', rows: 9, oninput: () => salvarRascunho() }),
      h('div', { class: 'pe-dica' }, '{documentos} e {destinatario} são preenchidos no envio.'),
      h('label', { class: 'pe-sub' }, 'Anexos (movimentações com arquivo)'),
      h('div', { id: 'pe-movs', class: 'pe-movs' }),
      h('div', { id: 'pe-resumo', class: 'pe-dica' }),
      h('button', { type: 'button', id: 'pe-enviar', onclick: () => enviar(false) }, 'Enviar e-mail'),
      h('button', { type: 'button', class: 'pe-sec', onclick: () => enviar(true) }, 'Abrir rascunho no Gmail (sem anexos)'),
      h('div', { id: 'pe-cert' }),
      cfg.urlScript ? null : h('div', { class: 'pe-nota' }, 'Envio automático ainda não configurado: clique em ⚙ e siga o passo a passo.')
    );
    montarDestinatarios();
    montarListaMov();
    const mesmo = rascunho && rascunho.processo === p.processo;
    if (mesmo) {
      $('pe-modelo').value = rascunho.modeloId || cfg.modelos[0].id;
      ['para', 'cc', 'assunto', 'corpo'].forEach((k) => { if (rascunho[k] !== undefined) $('pe-' + k).value = rascunho[k]; });
      aplicarModelo($('pe-modelo').value, true);
    } else {
      aplicarModelo(cfg.modelos[0] && cfg.modelos[0].id);
    }
    atualizarResumo();
  }

  function injetarBotao() {
    if (!ehTelaProcesso() || document.getElementById('pe-btn')) return;
    const b = h('button', { id: 'pe-btn', class: 'pe-fab', type: 'button',
      title: 'Enviar documentos deste processo por e-mail', onclick: () => abrirPainel(lerSessao()) }, '✉ Enviar por e-mail');
    document.body.appendChild(b);
    const r = lerSessao();
    if (r && r.aberto) abrirPainel(r);
  }

  injetarBotao();
  new MutationObserver(() => injetarBotao()).observe(document.documentElement, { childList: true, subtree: true });
})();
