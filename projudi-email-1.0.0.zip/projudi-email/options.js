(async function () {
  const $ = (id) => document.getElementById(id);
  const CAMPOS = ['urlScript', 'token', 'nomeRemetente', 'responderPara', 'cco', 'assinatura', 'certidao'];
  let cfg = await PE.loadCfg();

  const aviso = (t, erro) => {
    const s = $('status');
    s.textContent = t; s.style.display = 'block'; s.style.background = erro ? '#a12b2b' : '#1a5f8a';
    clearTimeout(aviso.t); aviso.t = setTimeout(() => { s.style.display = 'none'; }, 8000);
  };

  function blocoModelo(m) {
    const d = document.createElement('div');
    d.className = 'modelo';
    d.innerHTML = `
      <div class="linha"><div><label>Nome</label><input data-k="nome"></div>
        <div><label>Anexar automaticamente (regex)</label><input data-k="autoAnexo"></div></div>
      <label>Para padrão (opcional)</label><input data-k="para">
      <label>Assunto</label><input data-k="assunto">
      <label>Mensagem</label><textarea data-k="corpo" rows="7"></textarea>
      <button class="del" type="button">Excluir modelo</button>`;
    d.querySelectorAll('[data-k]').forEach((el) => { el.value = m[el.dataset.k] || ''; });
    d.dataset.id = m.id || ('m' + Date.now());
    d.querySelector('.del').onclick = () => { if (confirm('Excluir este modelo?')) d.remove(); };
    return d;
  }

  function preencher() {
    CAMPOS.forEach((k) => { $(k).value = cfg[k] || ''; });
    $('confirmar').checked = cfg.confirmar !== false;
    $('destinatarios').value = (cfg.destinatarios || []).map((d) => `${d.nome} ; ${d.email}`).join('\n');
    $('modelos').textContent = '';
    (cfg.modelos || []).forEach((m) => $('modelos').append(blocoModelo(m)));
  }

  function ler() {
    const c = Object.assign({}, cfg);
    CAMPOS.forEach((k) => { c[k] = $(k).value.trim(); });
    c.assinatura = $('assinatura').value; c.certidao = $('certidao').value;
    c.confirmar = $('confirmar').checked;
    c.destinatarios = $('destinatarios').value.split('\n').map((l) => {
      const p = l.split(/[;\t]/);
      const email = (p.length > 1 ? p[p.length - 1] : p[0]).trim();
      const nome = (p.length > 1 ? p.slice(0, -1).join(';') : email).trim();
      return { nome, email };
    }).filter((d) => PE.emailValido(d.email));
    c.modelos = [...$('modelos').children].map((d) => {
      const m = { id: d.dataset.id };
      d.querySelectorAll('[data-k]').forEach((el) => { m[el.dataset.k] = el.value; });
      return m;
    }).filter((m) => m.nome.trim());
    return c;
  }

  async function historico() {
    const h = await PE.loadHist();
    const tb = $('hist');
    tb.textContent = '';
    h.slice(0, 200).forEach((x) => {
      const tr = document.createElement('tr');
      [new Date(x.em).toLocaleString('pt-BR'), x.processo, x.para, x.assunto, (x.anexos || []).join('; ')].forEach((v) => {
        const td = document.createElement('td'); td.textContent = v || ''; tr.append(td);
      });
      tb.append(tr);
    });
    return h;
  }

  $('novoModelo').onclick = () => $('modelos').append(blocoModelo({ nome: 'Novo modelo', assunto: 'Processo nº {processo}', corpo: '\n\n{assinatura}' }));
  $('salvar').onclick = async () => {
    const c = ler();
    if (!c.modelos.length) return aviso('Mantenha ao menos um modelo.', true);
    for (const m of c.modelos) {
      if (m.autoAnexo) { try { new RegExp(m.autoAnexo, 'i'); } catch (e) { return aviso(`Regex inválida no modelo "${m.nome}".`, true); } }
    }
    cfg = c; await PE.saveCfg(cfg); preencher(); aviso('Opções salvas. Recarregue (F5) a aba do PROJUDI.');
  };
  $('restaurar').onclick = async () => {
    if (!confirm('Substituir os modelos e a certidão pelos padrões?')) return;
    cfg = Object.assign(ler(), { modelos: PE.CFG_PADRAO.modelos, certidao: PE.CFG_PADRAO.certidao });
    await PE.saveCfg(cfg); preencher(); aviso('Modelos padrão restaurados.');
  };
  $('testar').onclick = async () => {
    aviso('Testando…');
    const r = await chrome.runtime.sendMessage({ peAcao: 'teste', url: $('urlScript').value.trim(), token: $('token').value.trim() });
    if (r && r.ok) aviso(`✓ Conectado. Os e-mails sairão de ${r.r.conta}. Cota restante hoje: ${r.r.cota}.`);
    else aviso('Falhou: ' + ((r && r.erro) || 'sem resposta'), true);
  };
  $('csv').onclick = async () => {
    const h = await PE.loadHist();
    const q = (v) => '"' + String(v || '').replace(/"/g, '""') + '"';
    const linhas = [['data', 'processo', 'para', 'cc', 'assunto', 'anexos', 'conta'].join(';')]
      .concat(h.map((x) => [new Date(x.em).toLocaleString('pt-BR'), x.processo, x.para, x.cc, x.assunto, (x.anexos || []).join(' | '), x.conta].map(q).join(';')));
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + linhas.join('\r\n')], { type: 'text/csv' }));
    a.download = 'historico-emails-projudi.csv';
    a.click();
  };

  preencher();
  historico();
})();
