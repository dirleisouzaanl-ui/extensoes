// Utilidades compartilhadas (conteúdo do PROJUDI e página de opções)
var PE = (typeof window !== 'undefined' && window.PE) || {};
if (typeof window !== 'undefined') window.PE = PE;

PE.KEY_CFG = 'pe_cfg';
PE.KEY_HIST = 'pe_hist';

PE.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
PE.norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
PE.RE_EMAIL = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
PE.RE_CNJ = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;

PE.emails = (s) => [...new Set((String(s || '').match(PE.RE_EMAIL) || []).map((e) => e.toLowerCase()))];
PE.listaEmails = (s) => String(s || '').split(/[;,\s]+/).map((x) => x.trim()).filter(Boolean);
PE.emailValido = (e) => /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(e);

PE.CFG_PADRAO = {
  urlScript: '',
  token: '',
  nomeRemetente: '',
  responderPara: '',
  cco: '',
  assinatura: 'Atenciosamente,\n\nSecretaria do {juizo}\nComarca de {comarca}',
  confirmar: true,
  destinatarios: [
    { nome: 'Exemplo — Banco do Brasil (ofícios judiciais)', email: 'exemplo@exemplo.com.br' }
  ],
  modelos: [
    {
      id: 'oficio',
      nome: 'Encaminhamento de ofício',
      assunto: 'Ofício — Processo nº {processo}',
      corpo: 'Prezados,\n\nPor ordem do(a) MM. Juiz(a) de Direito, encaminho o(s) documento(s) anexo(s), extraído(s) dos autos nº {processo} ({classe}), em que figuram como partes {polo_ativo} e {polo_passivo}.\n\nDocumento(s): {documentos}.\n\nSolicito a gentileza de confirmar o recebimento e de responder com a referência ao número do processo.\n\n{assinatura}',
      autoAnexo: 'of[ií]cio',
      para: ''
    },
    {
      id: 'mandado',
      nome: 'Encaminhamento de mandado / carta',
      assunto: 'Cumprimento — Processo nº {processo}',
      corpo: 'Prezados,\n\nEncaminho, para cumprimento, o(s) documento(s) anexo(s) referente(s) aos autos nº {processo} ({classe}).\n\nDocumento(s): {documentos}.\n\n{assinatura}',
      autoAnexo: 'mandado|carta precat|carta de cita|carta de intima',
      para: ''
    },
    {
      id: 'intimacao',
      nome: 'Intimação por e-mail',
      assunto: 'Intimação — Processo nº {processo}',
      corpo: 'Prezado(a) {destinatario},\n\nFica Vossa Senhoria INTIMADO(A) do teor do(s) documento(s) anexo(s), proferido(s) nos autos nº {processo} ({classe}), em trâmite no {juizo} da Comarca de {comarca}.\n\nDocumento(s): {documentos}.\n\nPor favor, confirme o recebimento respondendo a esta mensagem.\n\n{assinatura}',
      autoAnexo: 'decis|despacho|senten',
      para: ''
    },
    {
      id: 'reiteracao',
      nome: 'Reiteração de ofício',
      assunto: 'REITERAÇÃO — Ofício — Processo nº {processo}',
      corpo: 'Prezados,\n\nReitero o ofício anexo, expedido nos autos nº {processo}, ainda sem resposta.\n\nSolicito o atendimento com urgência, com referência ao número do processo.\n\n{assinatura}',
      autoAnexo: 'of[ií]cio',
      para: ''
    }
  ],
  certidao: 'CERTIFICO, para os devidos fins, que nesta data ({data}, às {hora}) encaminhei por correio eletrônico, de {conta} para {para}, a mensagem "{assunto}", com o(s) seguinte(s) anexo(s): {documentos}. Do que dou fé.'
};

PE.loadCfg = () => new Promise((r) => chrome.storage.local.get(PE.KEY_CFG, (o) => {
  const c = Object.assign({}, PE.CFG_PADRAO, o[PE.KEY_CFG] || {});
  r(c);
}));
PE.saveCfg = (c) => new Promise((r) => chrome.storage.local.set({ [PE.KEY_CFG]: c }, r));
PE.loadHist = () => new Promise((r) => chrome.storage.local.get(PE.KEY_HIST, (o) => r(o[PE.KEY_HIST] || [])));
PE.addHist = async (item) => {
  const h = await PE.loadHist();
  h.unshift(item);
  await new Promise((r) => chrome.storage.local.set({ [PE.KEY_HIST]: h.slice(0, 500) }, r));
};

// Substitui {variavel} pelos valores; variáveis desconhecidas ficam como estão.
PE.render = (tpl, vars) => String(tpl || '').replace(/\{(\w+)\}/g, (m, k) =>
  Object.prototype.hasOwnProperty.call(vars, k) && vars[k] !== undefined && vars[k] !== null ? String(vars[k]) : m);

PE.escHtml = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
PE.textoParaHtml = (t) => '<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.5">' +
  PE.escHtml(t).replace(/\r?\n/g, '<br>') + '</div>';

PE.dataHora = (d = new Date()) => {
  const z = (n) => String(n).padStart(2, '0');
  return { data: `${z(d.getDate())}/${z(d.getMonth() + 1)}/${d.getFullYear()}`, hora: `${z(d.getHours())}:${z(d.getMinutes())}` };
};

PE.toast = (msg, tipo = 'ok', ms = 7000) => {
  const d = document.createElement('div');
  d.className = 'pe-toast pe-' + tipo;
  d.textContent = msg;
  document.body.appendChild(d);
  setTimeout(() => d.remove(), ms);
};

PE.ab2b64 = (buf) => {
  const bytes = new Uint8Array(buf);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
};

PE.nomeArquivo = (s) => String(s || 'documento').replace(/[\\/:*?"<>|]+/g, '_').replace(/\s+/g, ' ').trim().slice(0, 120);
