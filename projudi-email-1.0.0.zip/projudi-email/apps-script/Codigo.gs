/**
 * PROJUDI → E-mail — servidor de envio (Google Apps Script)
 *
 * 1. Acesse https://script.google.com com a conta que vai ENVIAR os e-mails
 *    (de preferência a conta institucional, se o Tribunal usar Google Workspace).
 * 2. Novo projeto → apague o conteúdo → cole este arquivo inteiro.
 * 3. Troque o TOKEN abaixo por uma senha longa só sua (a mesma vai nas opções da extensão).
 * 4. Implantar → Nova implantação → tipo "App da Web"
 *      Executar como: Eu
 *      Quem pode acessar: Qualquer pessoa
 *    → Implantar → autorize o acesso ao Gmail → copie a URL que termina em /exec.
 * 5. Cole a URL e o token nas opções da extensão e clique em "Testar conexão".
 *
 * Ao alterar este código, use Implantar → Gerenciar implantações → editar → Nova versão
 * (a URL continua a mesma).
 */
const TOKEN = 'TROQUE-POR-UMA-SENHA-LONGA';

function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    if (!TOKEN || TOKEN.indexOf('TROQUE') === 0) return saida({ ok: false, erro: 'Defina o TOKEN no Apps Script antes de usar.' });
    if (d.token !== TOKEN) return saida({ ok: false, erro: 'Token inválido.' });

    const conta = Session.getEffectiveUser().getEmail();
    if (d.acao === 'teste') {
      return saida({ ok: true, conta: conta, cota: MailApp.getRemainingDailyQuota() });
    }
    if (d.acao !== 'enviar') return saida({ ok: false, erro: 'Ação inválida.' });
    if (!d.para) return saida({ ok: false, erro: 'Sem destinatário.' });

    const anexos = (d.anexos || []).map(function (a) {
      return Utilities.newBlob(Utilities.base64Decode(a.base64), a.tipo || 'application/pdf', a.nome);
    });
    const opcoes = { htmlBody: d.html, attachments: anexos };
    if (d.cc) opcoes.cc = d.cc;
    if (d.cco) opcoes.bcc = d.cco;
    if (d.nomeRemetente) opcoes.name = d.nomeRemetente;
    if (d.responderPara) opcoes.replyTo = d.responderPara;

    GmailApp.sendEmail(d.para, d.assunto, d.texto || '', opcoes);
    return saida({ ok: true, conta: conta, enviadoEm: new Date().toISOString(), cota: MailApp.getRemainingDailyQuota() });
  } catch (err) {
    return saida({ ok: false, erro: String(err && err.message || err) });
  }
}

function doGet() {
  return saida({ ok: true, servico: 'PROJUDI → E-mail', info: 'Use POST.' });
}

function saida(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
