const $ = (id) => document.getElementById(id);
const CAMPOS = ['processo', 'placaManual', 'tipoRestricao', 'valorCausa', 'comarca', 'juizo', 'juiz'];
let dados = null;
const esc = (s) => String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function render() {
  const tem = !!dados;
  $('vazio').hidden = tem; $('f').hidden = !tem; $('salvar').hidden = !tem; $('abrir').hidden = !tem;
  if (!tem) return;
  CAMPOS.forEach((c) => { $(c).value = dados[c] || ''; });
  const sel = $('executadoSel');
  const lista = dados.executados.length ? dados.executados : dados.partes;
  sel.innerHTML = lista.map((p, i) => `<option value="${i}">${esc(p.nome)} — ${esc(p.polo)}</option>`).join('');
  sel.value = String(dados.executadoSel || 0);
  $('documento').value = (lista[sel.value] || {}).documento || '';
  $('placas').innerHTML = dados.placas.map((p) => `<option value="${esc(p)}">`).join('');
}

async function salvar() {
  CAMPOS.forEach((c) => { dados[c] = $(c).value.trim(); });
  dados.processoDigitos = PR.digits(dados.processo);
  dados.executadoSel = Number($('executadoSel').value);
  if (!dados.executados.length) dados.executados = dados.partes;
  await PR.save(dados);
  $('msg').textContent = 'Dados salvos.';
}

$('executadoSel').addEventListener('change', () => {
  const lista = dados.executados.length ? dados.executados : dados.partes;
  $('documento').value = (lista[$('executadoSel').value] || {}).documento || '';
});
$('salvar').onclick = salvar;
$('abrir').onclick = async () => {
  await salvar();
  chrome.tabs.create({ url: 'https://renajud.denatran.serpro.gov.br/renajud/restrito/restricoes-insercao.jsf' });
};
$('capturar').onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $('msg').textContent = 'Capturando...';
  chrome.tabs.sendMessage(tab.id, { tipo: 'pr-capturar' }, (r) => {
    if (chrome.runtime.lastError || !r) { $('msg').textContent = 'Abra a tela do processo no PROJUDI nesta aba.'; return; }
    if (!r.ok) { $('msg').textContent = 'Erro: ' + r.erro; return; }
    dados = r.dados; render(); $('msg').textContent = 'Capturado.';
  });
};

PR.load().then((d) => { dados = d; render(); });
