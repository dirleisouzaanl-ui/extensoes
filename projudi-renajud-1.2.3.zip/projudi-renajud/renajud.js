// RENAJUD (SERPRO) — preenchimento da inserção de restrição
// Mapeado em 10/10/2026 (RENAJUD 2.5.4), tela restricoes-insercao.jsf:
//  form-incluir-restricao:campo-placa (maxlength 7), :campo-chassi (21), :campo-cpf-cnpj (18),
//  :select-sem-restricao_input (checkbox), :botao-pesquisar
// Formulário da restrição: ver "etapa 2". A extensão NUNCA clica em "Inserir Restrição".
(function () {
  if (window.__prRenajud || window.top !== window) return;
  window.__prRenajud = true;

  const $ = (id) => document.getElementById(id);
  const F = 'form-incluir-restricao:';
  const visivel = (el) => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));

  // ---------- etapa 1: pesquisa ----------
  function preencherPesquisa(d) {
    const ex = d.executados[d.executadoSel || 0];
    // Com placa informada no popup, pesquisa só pela placa; senão, pelo CPF/CNPJ do executado
    const placa = (d.placaManual || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    PR.setValue($(F + 'campo-placa'), placa);
    const okPlaca = !!placa;
    const okDoc = !placa && ex && PR.setValue($(F + 'campo-cpf-cnpj'), PR.digits(ex.documento));
    if (placa) PR.setValue($(F + 'campo-cpf-cnpj'), '');
    const btn = $(F + 'botao-pesquisar');
    if (btn) { btn.classList.add('pr-destaque'); btn.focus(); }
    PR.toast(`Pesquisa preenchida${okDoc ? ' | CPF/CNPJ ' + ex.documento : ''}${okPlaca ? ' | placa ' + placa : ''}. Confira e clique em Pesquisar.`);
  }

  // ---------- etapa 2: formulário da restrição ----------
  // Tela mapeada em 12/11/2026 (veículos selecionados → "Inserir Restrição"):
  //  Restrições: rádios Transferência / Licenciamento / Circulação (Restrição Total)
  //  Dados do Processo: Ramo e Tribunal fixos; Comarca/Município *, Órgão Judiciário *,
  //  Juiz Inclusão * (selectOneMenu PrimeFaces, encadeados por ajax) e Nº do Processo *
  //  (habilitado depois do órgão). A extensão NUNCA clica em "Inserir Restrição".
  const COMARCA_FIXA = 'ASSIS CHATEAUBRIAND';

  // pontuação de semelhança entre dois textos (palavras em comum, com abreviaturas e plural)
  const PARADAS = new Set(['de', 'da', 'do', 'das', 'dos', 'e', 'a', 'o', 'em', 'na', 'no']);
  const ABREV = { esp: 'especial', espec: 'especial', civ: 'civel', crim: 'criminal', jec: 'juizado especial civel', jecrim: 'juizado especial criminal',
    faz: 'fazenda', pub: 'publica', jui: 'juizado', juiz: 'juizado', unid: 'unidade', jurisd: 'jurisdicional', comp: 'competencia' };
  const raiz = (w) => w.replace(/ais$/, 'al').replace(/eis$/, 'el').replace(/oes$/, 'ao').replace(/s$/, '');
  const palavras = (s) => PR.norm(s).replace(/[^a-z0-9 ]/g, ' ').split(' ')
    .flatMap((w) => (ABREV[w] || w).split(' ')).filter((w) => w && !PARADAS.has(w)).map(raiz);
  function semelhanca(a, b) {
    if (PR.norm(a) === PR.norm(b)) return 1;
    const A = palavras(a), B = new Set(palavras(b));
    if (!A.length || !B.size) return 0;
    const comuns = A.filter((w) => B.has(w)).length;
    return 0.7 * (comuns / A.length) + 0.3 * (comuns / B.size); // prioriza cobrir o texto do PROJUDI
  }

  // rótulo visível (Comarca/Município, Órgão Judiciário...) → componente seguinte no DOM
  function rotuloEl(re) {
    const cand = [...document.querySelectorAll('label, span, td, div, b, strong')]
      .filter((e) => !e.closest('#pr-painel') && visivel(e))
      .filter((e) => { const t = e.textContent; return t.length < 50 && re.test(PR.norm(t)); });
    // o mais interno (sem outro candidato dentro dele)
    return cand.find((e) => !cand.some((o) => o !== e && e.contains(o))) || null;
  }
  function depois(rot, sel) {
    if (!rot) return null;
    return [...document.querySelectorAll(sel)].find((e) => visivel(e) && (rot.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) || null;
  }
  const menuDe = (re) => depois(rotuloEl(re), '.ui-selectonemenu');

  // escolhe a opção de um selectOneMenu PrimeFaces pelo texto (exato ou mais parecido)
  const PAUSA = 1500; // pausa após cada escolha, para o ajax do RENAJUD carregar o campo seguinte
  const ehVazia = (t) => !t || /^selecione/.test(PR.norm(t));
  function lerOpcoes(menu) {
    const sel = menu && menu.querySelector('select');
    let ops = sel ? [...sel.options].filter((o) => o.value && !ehVazia(o.text)).map((o) => ({ texto: o.text.trim(), valor: o.value })) : [];
    if (!ops.length && menu) {
      const p = document.getElementById(menu.id + '_panel');
      ops = p ? [...p.querySelectorAll('li')].map((l) => ({ texto: (l.getAttribute('data-label') || l.textContent).trim() })).filter((o) => !ehVazia(o.texto)) : [];
    }
    return ops;
  }
  const rotuloAtual = (menu) => (menu && (menu.querySelector('.ui-selectonemenu-label') || {}).textContent || '').trim();
  const fechar = () => document.body.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));

  async function escolher(re, alvo, minimo = 0.6) {
    if (!alvo) return { ok: false, motivo: 'dado ausente no PROJUDI' };
    // componente presente e habilitado
    let menu = await PR.waitFor(() => { const m = menuDe(re); return m && !m.classList.contains('ui-state-disabled') ? m : null; }, 10000);
    if (!menu) return { ok: false, motivo: 'campo não localizado ou bloqueado' };
    const trig = () => (menuDe(re).querySelector('.ui-selectonemenu-trigger') || menuDe(re));
    // opções: no select oculto ou, se carregadas sob demanda, no painel aberto
    let ops = await PR.waitFor(() => { const o = lerOpcoes(menuDe(re)); return o.length ? o : null; }, 4000);
    if (!ops) { trig().click(); ops = await PR.waitFor(() => { const o = lerOpcoes(menuDe(re)); return o.length ? o : null; }, 8000); }
    if (!ops) { fechar(); return { ok: false, motivo: 'lista sem opções' }; }
    let melhor = null, nota = 0;
    for (const o of ops) { const n = semelhanca(alvo, o.texto); if (n > nota) { nota = n; melhor = o; } }
    if (!melhor || nota < minimo) {
      fechar();
      return { ok: false, motivo: 'sem opção parecida com "' + alvo + '". Opções: ' + ops.slice(0, 8).map((o) => o.texto).join('; ') };
    }
    menu = menuDe(re);
    if (PR.norm(rotuloAtual(menu)) === PR.norm(melhor.texto)) { await PR.sleep(PAUSA); return { ok: true, texto: melhor.texto }; }
    // abre o painel (se fechado) e clica no item
    const panelAberto = () => { const p = document.getElementById(menuDe(re).id + '_panel'); return p && visivel(p) && p.querySelectorAll('li').length ? p : null; };
    if (!panelAberto()) trig().click();
    const panel = await PR.waitFor(panelAberto, 5000);
    const li = panel && [...panel.querySelectorAll('li')].find((l) => PR.norm(l.getAttribute('data-label') || l.textContent) === PR.norm(melhor.texto));
    if (li) li.click();
    else {
      const sel = menuDe(re).querySelector('select');
      if (!sel || melhor.valor == null) { fechar(); return { ok: false, motivo: 'não foi possível clicar na opção' }; }
      sel.value = melhor.valor; sel.dispatchEvent(new Event('change', { bubbles: true }));
    }
    // espera o rótulo do componente mostrar a opção escolhida e o ajax assentar
    await PR.waitFor(() => PR.norm(rotuloAtual(menuDe(re))) === PR.norm(melhor.texto), 8000);
    await PR.sleep(PAUSA);
    return { ok: true, texto: melhor.texto };
  }

  function marcarTipo(tipo) {
    const alvo = PR.norm(tipo).slice(0, 6); // transf / licenc / circul
    const lbl = [...document.querySelectorAll('label')].find((l) => visivel(l) && PR.norm(l.textContent).startsWith(alvo));
    if (!lbl) return false;
    const box = lbl.previousElementSibling && lbl.previousElementSibling.querySelector('.ui-radiobutton-box');
    (box || lbl).click();
    return true;
  }

  let preenchendo = false;
  async function preencherRestricao(d) {
    if (preenchendo) return;
    preenchendo = true;
    const feito = [], falta = [];
    try {
      if (/registro de penhora/i.test(d.tipoRestricao || '')) falta.push('Penhora (preencher manualmente)');
      else if (marcarTipo(d.tipoRestricao || 'Transferência')) feito.push('Tipo: ' + d.tipoRestricao); else falta.push('Tipo de restrição');

      const r1 = await escolher(/^comarca\s*\/\s*municipio/, COMARCA_FIXA, 0.9);
      r1.ok ? feito.push('Comarca: ' + r1.texto) : falta.push('Comarca (' + r1.motivo + ')');

      const r2 = r1.ok ? await escolher(/^orgao judiciario/, d.juizo, 0.55) : { ok: false, motivo: 'depende da comarca' };
      r2.ok ? feito.push('Órgão: ' + r2.texto) : falta.push('Órgão Judiciário (' + r2.motivo + ')');

      const r3 = r2.ok ? await escolher(/^juiz inclusao/, d.juiz, 0.6) : { ok: false, motivo: 'depende do órgão' };
      r3.ok ? feito.push('Juiz: ' + r3.texto) : falta.push('Juiz Inclusão (' + r3.motivo + ')');

      // Nº do Processo: liberado depois do órgão/juiz
      const rotProc = rotuloEl(/^n.? do processo/);
      const campo = await PR.waitFor(() => { const e = depois(rotProc || rotuloEl(/^n.? do processo/), 'input[type=text], input:not([type])'); return e && !e.disabled && !e.readOnly ? e : null; }, 10000);
      if (campo) {
        const usarDigitos = campo.maxLength > 0 && campo.maxLength < 25;
        PR.setValue(campo, usarDigitos ? d.processoDigitos : d.processo);
        feito.push('Nº do processo');
      } else falta.push('Nº do Processo (campo bloqueado)');
    } catch (e) {
      falta.push('erro: ' + e.message);
    } finally {
      preenchendo = false;
    }
    PR.toast(`Preenchido: ${feito.join(' | ') || 'nada'}${falta.length ? ' || Pendente: ' + falta.join(' | ') : ''}. Confira e clique em "Inserir Restrição".`, falta.length ? 'aviso' : 'ok', 15000);
  }

  // ---------- painel ----------
  async function montarPainel() {
    if ($('pr-painel')) return;
    const d = await PR.load();
    const esc = (s) => String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const p = document.createElement('div');
    p.id = 'pr-painel';
    p.className = 'pr-painel';
    const ex = d && d.executados[d.executadoSel || 0];
    p.innerHTML = `
      <div class="pr-tit">PROJUDI → RENAJUD <span class="pr-x" title="Minimizar">–</span></div>
      <div class="pr-corpo">
        ${d ? `
          <div><b>Proc.:</b> ${esc(d.processo)}</div>
          <div><b>Executado:</b> ${esc(ex ? ex.nome : '—')}</div>
          <div><b>CPF/CNPJ:</b> ${esc(ex ? ex.documento : '—')}</div>
          <div><b>Placa:</b> ${esc(d.placaManual || (d.placas[0] || '—'))}</div>
          <div><b>Valor:</b> ${esc(d.valorCausa || '—')} &nbsp; <b>Tipo:</b> ${esc(d.tipoRestricao)}</div>
          <div><b>Juiz:</b> ${esc(d.juiz || '—')}</div>
          <div class="pr-bts">
            <button type="button" id="pr-b1">1. Preencher pesquisa</button>
            <button type="button" id="pr-b2">2. Preencher restrição</button>
          </div>
          <div class="pr-nota">A extensão só pesquisa; nunca insere restrição.</div>`
        : '<div>Nenhum processo capturado. Abra o processo no PROJUDI e clique em <b>Pesquisar no RENAJUD</b>.</div>'}
      </div>`;
    document.body.appendChild(p);
    p.querySelector('.pr-x').onclick = () => p.classList.toggle('pr-min');
    if (d) {
      $('pr-b1').onclick = async () => preencherPesquisa(await PR.load());
      $('pr-b2').onclick = async () => preencherRestricao(await PR.load());
    }
  }

  // ---------- pesquisa sem resultado: imprimir comprovante ----------
  // Mensagem mapeada: #messages li > span.ui-messages-error-detail "A pesquisa não retornou resultados."
  const TITULO_SEM_VEICULO = 'RENAJUD - inexistência de veículos licenciados';
  async function imprimirSemResultado() {
    const d = await PR.load();
    const ex = d && d.executados[d.executadoSel || 0];
    const docPesq = (($(F + 'campo-cpf-cnpj') || {}).value || '').trim();
    const placa = (($(F + 'campo-placa') || {}).value || '').trim();

    // cabeçalho só para impressão, com a identificação do processo
    let cab = $('pr-cab-impressao');
    if (!cab) { cab = document.createElement('div'); cab.id = 'pr-cab-impressao'; document.body.prepend(cab); }
    const mesmoDoc = ex && docPesq && PR.digits(docPesq) === PR.digits(ex.documento);
    cab.textContent = [
      d && d.processo ? 'Processo: ' + d.processo : '',
      docPesq ? 'CPF/CNPJ pesquisado: ' + (mesmoDoc ? ex.nome + ' — ' + ex.documento : docPesq) : '',
      placa ? 'Placa pesquisada: ' + placa : '',
      'Resultado: a pesquisa não retornou veículos',
      'Data/hora: ' + new Date().toLocaleString('pt-BR')
    ].filter(Boolean).join('  |  ');

    const tituloOriginal = document.title;
    document.title = TITULO_SEM_VEICULO; // nome sugerido do PDF em "Salvar como PDF"
    const restaurar = () => { document.title = tituloOriginal; window.removeEventListener('afterprint', restaurar); };
    window.addEventListener('afterprint', restaurar);
    setTimeout(() => window.print(), 300);
  }

  // cada mensagem é tratada uma única vez (o ajax do JSF recria o nó a cada pesquisa)
  function mensagemNova() {
    return [...document.querySelectorAll('.ui-messages-error-detail, .ui-messages-warn-detail, .ui-messages-info-detail')]
      .find((s) => !s.dataset.prVisto && visivel(s) && /nao retornou resultados/.test(PR.norm(s.textContent)));
  }

  const vigiarResultado = () => {
    if (!/restricoes-insercao/.test(location.pathname)) return;
    const m = mensagemNova();
    if (!m) return;
    m.dataset.prVisto = '1';
    imprimirSemResultado();
  };
  new MutationObserver(vigiarResultado).observe(document.body, { childList: true, subtree: true });
  vigiarResultado(); // caso a página tenha sido recarregada já com a mensagem

  // ---------- pesquisa automática (pedido vindo do PROJUDI) ----------
  let executando = false;
  async function pesquisaAutomatica() {
    if (executando) return;
    const o = await new Promise((res) => chrome.storage.local.get(PR.KEY_AUTO, (x) => res(x[PR.KEY_AUTO])));
    if (!o || Date.now() - o.ts > PR.AUTO_VALIDADE) return;
    if (!/restricoes-insercao/.test(location.pathname)) { location.href = '/renajud/restrito/restricoes-insercao.jsf'; return; }
    executando = true;
    try {
      const campo = await PR.waitFor(() => $(F + 'campo-cpf-cnpj'), 10000);
      const btn = $(F + 'botao-pesquisar');
      if (!campo || !btn) { PR.toast('Tela de inserção do RENAJUD não localizada (sessão expirada?).', 'erro'); return; }
      await new Promise((res) => chrome.storage.local.remove(PR.KEY_AUTO, res)); // consome o pedido uma única vez
      PR.setValue($(F + 'campo-placa'), '');
      PR.setValue($(F + 'campo-chassi'), '');
      PR.setValue(campo, o.documento);
      // marca mensagens antigas para não confundir com o resultado desta pesquisa
      document.querySelectorAll('.ui-messages-error-detail, .ui-messages-warn-detail, .ui-messages-info-detail').forEach((s) => { s.dataset.prVisto = '1'; });
      await PR.sleep(300);
      btn.click();
      PR.toast(`Pesquisando ${o.documento} (${o.processo})...`);
    } finally {
      executando = false;
    }
  }

  montarPainel();
  // atualiza o painel quando o PROJUDI ou o popup gravam novos dados
  chrome.storage.onChanged.addListener((ch) => {
    if (ch[PR.KEY]) { const p = $('pr-painel'); if (p) p.remove(); montarPainel(); }
    if (ch[PR.KEY_AUTO] && ch[PR.KEY_AUTO].newValue) pesquisaAutomatica();
  });
  pesquisaAutomatica(); // aba aberta/recarregada depois do pedido
})();
