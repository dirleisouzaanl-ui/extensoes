// Utilidades compartilhadas (PROJUDI e RENAJUD)
var PR = window.PR || {};
window.PR = PR;

PR.KEY = 'pr_dados';
PR.KEY_AUTO = 'pr_auto_pesquisa'; // pedido de pesquisa automática pendente
PR.AUTO_VALIDADE = 90000;        // ms

PR.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
PR.digits = (s) => String(s || '').replace(/\D/g, '');
PR.norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();

PR.waitFor = async (fn, timeout = 8000, step = 200) => {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    try { const v = fn(); if (v) return v; } catch (e) { /* tenta de novo */ }
    await PR.sleep(step);
  }
  return null;
};

PR.save = (dados) => new Promise((r) => chrome.storage.local.set({ [PR.KEY]: dados }, r));
PR.load = () => new Promise((r) => chrome.storage.local.get(PR.KEY, (o) => r(o[PR.KEY] || null)));

// Placa antiga (ABC1234 / ABC-1234) e Mercosul (ABC1D23)
PR.RE_PLACA = /\b([A-Z]{3})-?(\d[A-Z0-9]\d{2})\b/g;
// RENAVAM: 9 a 11 dígitos precedidos da palavra RENAVAM
PR.RE_RENAVAM = /RENAVAM\D{0,15}(\d{9,11})/gi;

PR.extrairVeiculos = (texto) => {
  const placas = new Set();
  const renavams = new Set();
  let m;
  const t = String(texto || '').toUpperCase();
  PR.RE_PLACA.lastIndex = 0;
  while ((m = PR.RE_PLACA.exec(t))) {
    const p = m[1] + m[2];
    // descarta falsos positivos comuns (OAB, SSP etc.)
    if (!/^(OAB|SSP|CPF|CEP|SEQ|MOV|ART|LEI|CNH|PRF|DJE)/.test(p)) placas.add(p);
  }
  PR.RE_RENAVAM.lastIndex = 0;
  while ((m = PR.RE_RENAVAM.exec(texto))) renavams.add(m[1]);
  return { placas: [...placas], renavams: [...renavams] };
};

PR.toast = (msg, tipo = 'ok', ms = 6000) => {
  const d = document.createElement('div');
  d.className = 'pr-toast pr-' + tipo;
  d.textContent = msg;
  document.body.appendChild(d);
  setTimeout(() => d.remove(), ms);
};

// Preenche input/select disparando os eventos que JSF/PrimeFaces/jQuery escutam
PR.setValue = (el, valor) => {
  if (!el) return false;
  el.focus();
  if (el.tagName === 'SELECT') {
    const alvo = PR.norm(valor);
    const opt = [...el.options].find((o) => PR.norm(o.text) === alvo) ||
                [...el.options].find((o) => PR.norm(o.text).includes(alvo)) ||
                [...el.options].find((o) => o.value === String(valor));
    if (!opt) return false;
    // PrimeFaces selectOneMenu: clicar no item visível para disparar o ajax do componente
    const wrap = el.closest('.ui-selectonemenu');
    if (wrap) {
      const panel = document.getElementById(wrap.id + '_panel');
      const li = panel && [...panel.querySelectorAll('li')].find((l) => PR.norm(l.getAttribute('data-label') || l.textContent) === PR.norm(opt.text));
      if (li) { wrap.click(); li.click(); return true; }
    }
    el.value = opt.value;
  } else if (el.type === 'checkbox' || el.type === 'radio') {
    if (!el.checked) el.click();
    return true;
  } else {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(el, valor);
  }
  ['input', 'keyup', 'change'].forEach((ev) => el.dispatchEvent(new Event(ev, { bubbles: true })));
  el.dispatchEvent(new Event('blur', { bubbles: true }));
  return true;
};
