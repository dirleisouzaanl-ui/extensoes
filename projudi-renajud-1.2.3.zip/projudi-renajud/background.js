// Leva a usuária à aba do RENAJUD já aberta (ou abre uma) depois da captura no PROJUDI.
const URL_INSERCAO = 'https://renajud.denatran.serpro.gov.br/renajud/restrito/restricoes-insercao.jsf';

chrome.runtime.onMessage.addListener((msg, sender, resp) => {
  if (!msg || msg.tipo !== 'pr-ir-renajud') return;
  (async () => {
    const abas = await chrome.tabs.query({ url: 'https://renajud.denatran.serpro.gov.br/renajud/*' });
    // prefere a aba de inserção; senão, qualquer aba do RENAJUD; senão, abre uma nova
    const aba = abas.find((t) => t.url && t.url.includes('restricoes-insercao')) || abas[0];
    if (aba) {
      await chrome.tabs.update(aba.id, { active: true });
      await chrome.windows.update(aba.windowId, { focused: true });
      if (!aba.url.includes('restricoes-insercao')) await chrome.tabs.update(aba.id, { url: URL_INSERCAO });
    } else {
      const janela = sender.tab ? sender.tab.windowId : undefined;
      await chrome.tabs.create({ url: URL_INSERCAO, windowId: janela, active: true });
    }
    resp({ ok: true, reaproveitada: !!aba });
  })().catch((e) => resp({ ok: false, erro: e.message }));
  return true;
});
