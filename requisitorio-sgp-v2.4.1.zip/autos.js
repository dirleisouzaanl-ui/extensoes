/* Leitura dos autos do PROJUDI exportados em PDF ("Exportar Processo").
   Entrada: pages = [[linha, ...], ...] (uma lista de linhas por página, como sai de itemsToLines).
   Saída: {campos:{chave:{v, o:'p. N · mov. X', t:'L'|'I'|'C'}}, advs:[{nome,oab}], avisos:[...], movs:n}
   t: L = literal dos autos · I = inferido (confirmar) · C = calculado. Nada é inventado: o que não for achado não entra. */
(function(root){
const DT = /(\d{2}\/\d{2}\/\d{4})/;
const norm = s => (s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
const num = s => parseFloat(String(s).replace(/\./g,'').replace(',','.'));
const brl = n => n.toLocaleString('pt-BR',{minimumFractionDigits:2, maximumFractionDigits:2});
const BANCOS = [[/caixa|cef\b/i,'104'],[/banco do brasil|\bbb\b/i,'001'],[/bradesco/i,'237'],[/santander/i,'033'],[/ita[uú]/i,'341'],[/sicredi/i,'748'],[/sicoob|bancoob/i,'756'],[/cresol/i,'133'],[/nubank|nu pagamentos/i,'260'],[/inter\b/i,'077']];

function parseAutos(pages){
  const campos = {}, avisos = [], files = [], movs = {};
  const put = (k, v, pg, mov, t) => { if (v && !campos[k]) campos[k] = {v: String(v).trim(), o: 'p. '+pg+(mov?' · mov. '+mov:''), t: t||'L'}; };

  /* ---------- índice de movimentações e arquivos ---------- */
  pages.forEach((L, i) => { const pg = i+1; const head = L.slice(0,4).join('\n');
    const m = head.match(/Ref\. mov\. (\d+)\.(\d+)/); if (!m) return;
    const seq = +m[1], arq = +m[2]; const d = L.slice(0,5).map(l => l.match(/^(\d{2}\/\d{2}\/\d{4}): (.+)$/)).find(Boolean);
    if (arq === 0){ const j = L.findIndex(l => /^Complemento:/.test(l)); let comp = '';
      if (j >= 0){ comp = L[j].replace(/^Complemento:\s*/,''); for (let k=j+1; k<L.length && !/^(Por:|Relação|Intimações)/.test(L[k]); k++) comp += ' '+L[k]; }
      movs[seq] = {seq, pg, data: d?d[1]:'', desc: d?d[2].replace(/\.$/,''):'', comp, por: (L.find(l => /^Por:/.test(l))||'').replace(/^Por:\s*/,''), lines: L};
    } else { let f = files[files.length-1];
      if (!f || f.seq !== seq || f.arq !== arq){ const a = d && d[2].match(/Arq: (.+)$/); f = {seq, arq, ref: seq+'.'+arq, pg, data: d?d[1]:'', tipo: a?a[1].trim():'', txt: ''}; files.push(f); }
      f.txt += '\n'+L.join('\n'); f.fim = pg; } });
  const M = Object.values(movs).sort((a,b) => a.seq-b.seq);
  const fileDe = seq => files.filter(f => f.seq === seq);
  const isDec = f => /^(Decis[ãa]o|Senten[çc]a|Despacho)/i.test(f.tipo);

  /* ---------- capa ---------- */
  const capa = (pages[0]||[]).join('\n');
  let m = capa.match(/Processo (\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4})/); if (m) put('proc.numero', m[1], 1);
  m = capa.match(/Data Distribuição:\s*(\d{2}\/\d{2}\/\d{4})/); if (m){ put('proc.dtAjuizOriginal', m[1], 1); put('proc.dtAjuizConhecimento', m[1], 1); }
  m = capa.match(/Tipo: Promovente\nNome: ([^\n]+)\nData de (\d{2}\/\d{2}\/\d{4}) RG: ([^\n]*?) CPF\/CNPJ: ([\d.\/-]+)/);
  if (m){ put('cred.nome', m[1], 1); put('cred.cpf', m[4], 1); if (!/n[ãa]o cadastrado/i.test(m[3])){ const r = m[3].match(/^([\d.\-xX]+)\s*(.*)$/); if (r){ put('cred.rg', r[1], 1); put('cred.rgOrgao', r[2].trim().replace(/\s+/g,'/'), 1); } } }
  m = capa.match(/Tipo: Promovido\nNome: ([^\n]+)/); if (m) put('proc.devedor', m[1], 1);
  const advs = []; const blocoAtivo = capa.split(/Tipo: Promovido/)[0];
  for (const a of blocoAtivo.matchAll(/^(\d{3,7})N?-([A-Z]{2}) (.+)$/gm)) advs.push({oab: a[2]+a[1], nome: a[3].trim()});
  if (!campos['cred.rg']){ const ini = files.find(f => f.seq === 1 && /RG n/i.test(f.txt)); const r = ini && ini.txt.match(/RG n\.?[ºo°]?\s*([\d.\-xX]+)\s*\/?\s*([A-Z]{2,5}\s*\/\s*[A-Z]{2})?/);
    if (r){ put('cred.rg', r[1], ini.pg, ini.ref); if (r[2]) put('cred.rgOrgao', r[2].replace(/\s+/g,''), ini.pg, ini.ref); } }

  /* ---------- trânsitos ---------- */
  const tr = M.filter(x => /^TRANSITADO EM JULGADO EM/.test(x.desc) && /para o processo/i.test(x.comp));
  const subida = M.find(x => /RECEBIDOS OS AUTOS/.test(x.desc) && /inst[âa]ncia superior/i.test(x.comp));
  if (subida){ let achou = null;
    for (const f of files){ if (f.seq < subida.seq || /Requisi[çc][ãa]o de Pequeno Valor/i.test(f.tipo)) continue;
      const mm = f.txt.replace(/\s+/g,' ').match(/(?:ac[óo]rd[ãa]o|senten[çc]a|recurso|decis[ãa]o condenat[óo]ria)[^.]{0,80}?transit\w+ em julgado[^.]{0,40}?(\d{2}\/\d{2}\/\d{4})/i);
      if (mm){ achou = {d: mm[1], f}; break; } }
    if (achou){ put('proc.dtTransitoDC', achou.d, achou.f.pg, achou.f.ref, 'I'); avisos.push('Trânsito em julgado (DC) em '+achou.d+': data apenas mencionada no mov. '+achou.f.ref+'. Confirme na aba Recursos do PROJUDI e informe a movimentação do Recurso Inominado.'); }
    else avisos.push('Trânsito em julgado da decisão condenatória (DC): não consta destes autos. Os autos voltaram da instância superior em '+subida.data+' (mov. '+subida.seq+'). Abra a aba Recursos do PROJUDI › Movimentações do Recurso Inominado e copie a data e a movimentação de "TRANSITADO EM JULGADO".'); }
  else if (tr.length > 1){ const t0 = tr[0]; put('proc.dtTransitoDC', (t0.desc.match(DT)||[])[1], t0.pg, t0.seq, 'I'); put('proc.movTransito', t0.seq, t0.pg, t0.seq, 'I'); }

  /* ---------- início do cumprimento (fase de execução) ---------- */
  const decs0 = files.filter(isDec);
  const rec = decs0.find(f => /recebo o pedido de cumprimento de senten[çc]a|art(igo)?\.? 534/i.test(f.txt));
  let exec = null;
  if (rec){ const r = rec.txt.match(/apresentado ao mov\.?\s*(\d+)/i); if (r) exec = files.find(f => f.seq === +r[1]); }
  if (!exec) exec = files.find(f => !isDec(f) && (!subida || f.seq > subida.seq) && (!rec || f.seq < rec.seq) && /art\.? 535|impugnar a execu[çc][ãa]o|cumprimento de senten[çc]a|juntada (aos autos )?dos c[áa]lculos/i.test(f.txt));
  if (exec){ put('proc.dtAjuizExecucao', exec.data, exec.pg, exec.ref, 'I'); put('docs.tipos.PF', exec.ref, exec.pg, exec.ref, 'I'); }

  const ini = exec ? exec.seq : (rec ? rec.seq : (subida ? subida.seq : 0));

  /* ---------- decisão de homologação / expedição ---------- */
  const decs = decs0; const HOM = /\bHOMOLOGO\b(?! (o|a) (projeto|parecer|decis[ãa]o|senten[çc]a))/i; const fase = decs.filter(f => f.seq >= ini);
  const expresso = [...fase].reverse().find(f => HOM.test(f.txt));
  const homol = expresso || fase.find(f => /por meio de PRECAT[ÓO]RIO|expe[çc]a-se\s+(precat[óo]rio|RPV)/i.test(f.txt));
  if (homol){ put('cert.dtHomolog', homol.data, homol.pg, homol.ref, expresso?'L':'I'); put('cert.movDecHomolog', homol.ref, homol.pg, homol.ref, expresso?'L':'I'); put('docs.tipos.HE', homol.ref, homol.pg, homol.ref, 'I'); }
  if (!expresso) avisos.push('Não achei decisão que homologue expressamente o cálculo (palavra "HOMOLOGO")'+(homol?'; usei a decisão do mov. '+homol.ref+', que manda expedir o precatório.':'.'));
  const dev = norm((campos['proc.devedor']||{}).v).split(/[ \/]/)[0];
  let trDep = homol ? tr.filter(x => x.seq > homol.seq).pop() : null, viaRen = false;
  if (!trDep && homol){ // sem "TRANSITADO EM JULGADO" posterior: renúncia de prazo do executado quanto à decisão
    const ultDec = decs.filter(f => f.seq >= homol.seq).pop() || homol; // última decisão da fase (ex.: embargos de declaração posteriores)
    const ren = M.filter(x => x.seq > ultDec.seq && /ren[úu]ncia de prazo de/i.test(x.comp) && (!dev || norm(x.comp).includes(dev))).pop()
      || M.filter(x => x.seq > ultDec.seq && /CONFIRMADA A INTIMAÇÃO/.test(x.desc) && x.lines.some(l => /REN[ÚU]NCIA/.test(l) && (!dev || norm(l).includes(dev)))).pop();
    if (ren){ const l = /ren[úu]ncia de prazo de/i.test(ren.comp) ? null : ren.lines.find(l => /REN[ÚU]NCIA/.test(l)); const ds = l ? [...l.matchAll(/\d{2}\/\d{2}\/\d{4}/g)].map(x => x[0]) : [];
      trDep = {seq: ren.seq, pg: ren.pg, desc: 'EM '+(ds[ds.length-1] || ren.data)}; viaRen = true;
      avisos.push('A decisão do mov. '+homol.ref+' não tem "TRANSITADO EM JULGADO" lançado; usei a renúncia de prazo do executado (mov. '+ren.seq+') como preclusão. Confirme se o exequente também renunciou ou deixou o prazo correr.'); }
    else avisos.push('A decisão do mov. '+homol.ref+' ('+homol.data+') ainda não tem trânsito em julgado nem renúncia de prazo lançados nos autos: providencie a certidão antes de expedir.'); }
  if (trDep && homol){ const d = (trDep.desc.match(DT)||[])[1];
    put('proc.dtTransitoDEP', d, trDep.pg, trDep.seq, 'I'); put('proc.movHomolog', trDep.seq, trDep.pg, trDep.seq, 'I'); put('proc.movExped', trDep.seq, trDep.pg, trDep.seq, 'I'); }

  /* ---------- intimação da Fazenda para impugnar (30 dias) ---------- */
  const int30 = M.filter(x => /CONFIRMADA A INTIMAÇÃO|EXPEDIÇÃO DE INTIMAÇÃO/.test(x.desc) && x.lines.some(l => /30 dias/.test(l)));
  const conf = int30.filter(x => /CONFIRMADA/.test(x.desc)).pop() || int30.pop();
  if (conf){ const l = conf.lines.find(l => /30 dias/.test(l)); const d = l.replace(/^.*?30 dias\s*\S*/,'').match(DT);
    if (d){ put('proc.dtCitacaoFazenda', d[1], conf.pg, conf.seq); put('proc.movCitacao', conf.seq, conf.pg, conf.seq); }
    const ds = [...l.replace(/^.*?30 dias\s*\S*/,'').matchAll(/\d{2}\/\d{2}\/\d{4}/g)].map(x => x[0]);
    const imp = M.find(x => x.seq > conf.seq && /IMPUGNA/i.test(x.desc)) || files.find(f => f.seq > conf.seq && (!homol || f.seq < homol.seq) && /excesso de execu[çc][ãa]o|impugna[çc][ãa]o ao cumprimento/i.test(f.txt) && !isDec(f));
    if (imp){ campos['cert.impugnacao'] = {v:'Sim', o:'p. '+imp.pg+' · mov. '+(imp.ref||imp.seq), t:'I'}; put('cert.dtImpug', imp.data, imp.pg, imp.ref||imp.seq, 'I'); put('cert.movImpug', imp.ref||imp.seq, imp.pg, imp.ref||imp.seq, 'I');
      if (homol){ put('cert.dtDecImpug', homol.data, homol.pg, homol.ref, 'I'); put('cert.movDecImpug', homol.ref, homol.pg, homol.ref, 'I'); put('docs.tipos.SA', homol.ref, homol.pg, homol.ref, 'I'); }
      if (trDep){ put('proc.dtDecurso', (trDep.desc.match(DT)||[])[1], trDep.pg, trDep.seq, 'I'); put('proc.movDecurso', trDep.seq, trDep.pg, trDep.seq, 'I'); } }
    else if (ds[1]){ put('proc.dtDecurso', ds[1], conf.pg, conf.seq, 'I'); put('proc.movDecurso', conf.seq, conf.pg, conf.seq, 'I'); } }
  else avisos.push('Não achei a intimação da Fazenda com prazo de 30 dias para impugnar.');

  /* ---------- cálculo (Calculadora Agnesi) ---------- */
  const ehCalc = f => !isDec(f) && (/c[áa]lculo|planilha|mem[óo]ria|demonstrativo|atualiza[çc][ãa]o/i.test(f.tipo) || /Calculadora Agnesi|Sistema Agnesi|mem[óo]ria de c[áa]lculo|planilha de c[áa]lculo/i.test(f.txt.slice(0,1500)));
  if (exec){ const orig = files.find(f => f.seq === exec.seq && f !== exec && ehCalc(f)) || files.find(f => f.seq > exec.seq && (!homol || f.seq < homol.seq) && ehCalc(f));
    if (orig){ const t = orig.seq === exec.seq ? 'L' : 'I'; put('cert.dtCalculo', orig.data, orig.pg, orig.ref, t); put('cert.movCalculo', orig.ref, orig.pg, orig.ref, t); }
    else if (/R\$\s*\d/.test(exec.txt)){ put('cert.dtCalculo', exec.data, exec.pg, exec.ref, 'I'); put('cert.movCalculo', exec.ref, exec.pg, exec.ref, 'I');
      avisos.push('Não achei planilha de cálculo anexa ao pedido de cumprimento; para a certidão usei a própria petição (mov. '+exec.ref+'), que traz o valor.'); }
    else avisos.push('Cálculo original: não achei planilha nem valor no pedido de cumprimento (mov. '+exec.ref+').'); }
  else avisos.push('Não identifiquei o pedido de cumprimento de sentença; a data de início da execução e o cálculo original ficaram em branco.');
  const calcs = files.filter(f => /Calculadora Agnesi|Sistema Agnesi/.test(f.txt) && /Principal original/.test(f.txt));
  let calc = null;
  if (expresso){ const cit = [...homol.txt.matchAll(/mov\.?\s*(\d+)/gi)].map(x => +x[1]); calc = calcs.filter(f => cit.includes(f.seq)).pop() || calcs.filter(f => f.seq < homol.seq).pop(); }
  else if (calcs.length && homol) avisos.push('Sem homologação expressa: usei o cálculo mais recente dos autos.');
  calc = calc || calcs[calcs.length-1];
  const soma = f => { let P=0, C=0, J=0, T=0, ate='';
    for (const b of f.txt.split(/(?:Cr[ée]dito|Pagamento):/).slice(1)){ const bb = b.split('Total lançamentos')[0];
      const vals = [...bb.matchAll(/(\d[\d.]*,\d{2})\s*[CP]\b/g)].map(x => num(x[1])); if (vals.length < 2) continue;
      const pr = (bb.match(/Principal original:\s*(\d[\d.]*,\d{2})/)||[])[1], cm = (bb.match(/Corre[çc][ãa]o monet[áa]ria[^\n]*?(\d[\d.]*,\d{2})\s*[CP]/)||[])[1]; if (!pr) continue;
      const tot = Math.max(...vals.slice(0,4)); P += num(pr); C += cm?num(cm):0; J += tot - num(pr) - (cm?num(cm):0); T += tot;
      const a = bb.match(/a (\d{2}\/\d{4})/); if (a && a[1].split('/').reverse().join('') > ate.split('/').reverse().join('')) ate = a[1]; }
    return {P, C, J, T, ate}; };
  if (calc){ const irmaos = calcs.filter(f => f.seq === calc.seq).map(f => ({f, r: soma(f)})).sort((x,y) => y.r.T - x.r.T);
    if (irmaos.length > 1) avisos.push('O mov. '+calc.seq+' tem '+irmaos.length+' planilhas de cálculo ('+irmaos.map(x => x.f.ref+' = R$ '+brl(x.r.T)).join('; ')+'); usei a de maior total.');
    calc = irmaos[0].f; const {P, C, J, T, ate} = irmaos[0].r;
    const o = 'p. '+calc.pg+'-'+calc.fim+' · mov. '+calc.ref;
    if (T){ campos['cred.valorPrincipal'] = {v: brl(P+C), o, t:'C'}; campos['cred.jurosMoratorios'] = {v: brl(J), o, t:'C'}; campos['cred.totalCalculo'] = {v: brl(T), o, t:'C'};
      if (ate) campos['cred.dataAtualizacao'] = {v: ate, o, t:'I'};
      const selic = /selic/i.test(calc.txt); if (selic) avisos.push('Os juros do cálculo são pela SELIC: defina se vão em "Juros moratórios" ou em "Valor Selic".');
      avisos.push('Valores somados dos lançamentos do cálculo do mov. '+calc.ref+' (principal + correção = R$ '+brl(P+C)+'; juros = R$ '+brl(J)+'; total = R$ '+brl(T)+'). Confira com o valor homologado e informe a data de atualização completa (o cálculo vai até '+(ate||'?')+').'); }
    put('cert.dtCalculo', calc.data, calc.pg, calc.ref, 'I'); put('cert.movCalculo', calc.ref, calc.pg, calc.ref, 'I'); put('docs.tipos.PC', calc.ref, calc.pg, calc.ref, 'I'); put('cred.planilha', calc.ref, calc.pg, calc.ref, 'I'); }
  else avisos.push('Não achei planilha de cálculo (Calculadora Agnesi) para somar principal e juros.');

  /* ---------- documentos ---------- */
  const sent = M.find(x => /^JULGADA (PROCEDENTE|PARCIALMENTE)/.test(x.desc)); if (sent){ const f = fileDe(sent.seq)[0]; if (f) put('docs.tipos.SC', f.ref, f.pg, f.ref); }
  const proc = files.find(f => /procura[çc][ãa]o/i.test(f.tipo)) || files.find(f => f.seq === 1 && /PROCURA[ÇC][ÃA]O/.test(f.txt.slice(0,600)));
  if (proc){ put('docs.tipos.PR', proc.ref, proc.pg, proc.ref, /procura/i.test(proc.tipo)?'L':'I'); put('cred.procuracao', proc.ref, proc.pg, proc.ref, /procura/i.test(proc.tipo)?'L':'I'); }

  /* ---------- conta bancária (última informada pela parte) ---------- */
  for (const f of [...files].reverse()){ if (isDec(f) || /Requisi[çc][ãa]o de Pequeno Valor/i.test(f.tipo)) continue;
    const t = f.txt; const i = t.search(/BANCO\s*:?\s*[A-Za-zÀ-ú]/i); if (i < 0 || !/AG[ÊE]?N?C?I?A?\.?\s*:?\s*n?[ºo°]?\s*\d{3,5}/i.test(t.slice(i, i+400))) continue;
    const seg = t.slice(i, i+500).replace(/\s+/g,' ');
    const banco = (seg.match(/BANCO\s*:?\s*([A-Za-zÀ-ú. ]{2,40}?)(?=,|\s+AG|\s+Ag)/i)||[])[1] || '';
    const ag = (seg.match(/AG[ÊE]?N?C?I?A?\.?\s*:?\s*n?[ºo°]?\s*(\d{3,5})(?:-(\d))?/i)||[]);
    const ct = (seg.match(/(?:CONTA(?: CORRENTE| POUPAN[ÇC]A)?|C\/C)\s*:?\s*n?[ºo°]?\s*([\d.]{3,15})-(\w)/i)||[]);
    if (!ag[1] || !ct[1]) continue;
    const cod = (BANCOS.find(([rx]) => rx.test(banco)) || [,''])[1]; const o = 'p. '+f.pg+' · mov. '+f.ref;
    campos['cred.conta.banco'] = {v: cod || banco.trim(), o, t: cod?'L':'I'}; campos['cred.conta.agencia'] = {v: ag[1], o, t:'L'}; if (ag[2]) campos['cred.conta.dvAgencia'] = {v: ag[2], o, t:'L'};
    campos['cred.conta.numero'] = {v: ct[1].replace(/\./g,''), o, t:'L'}; campos['cred.conta.dv'] = {v: ct[2], o, t:'L'};
    const tit = (seg.match(/TITULAR(?:IDADE)?\s*:?\s*([A-Za-zÀ-ú ]{5,60}?)(?=\.|,|\s+CPF|\s+Pugna|\s+Ap[óo]s|$)/i)||[])[1] || (t.slice(Math.max(0,i-120), i).match(/([A-ZÀ-Ú ]{8,60}) - CPF/)||[])[1] || '';
    const cpfT = (t.slice(Math.max(0,i-160), i+500).match(/CPF\s*:?\s*n?[ºo°]?\s*(\d{3}\.\d{3}\.\d{3}-\d{2})/)||[])[1] || '';
    const credNome = norm((campos['cred.nome']||{}).v), credCpf = ((campos['cred.cpf']||{}).v||'').replace(/\D/g,'');
    const doCredor = (tit && norm(tit) === credNome) || (cpfT && cpfT.replace(/\D/g,'') === credCpf);
    if (tit || cpfT){ if (!doCredor){ campos['cred.conta.procurador'] = {v:'Sim', o, t:'I'}; if (cpfT) campos['cred.conta.titularCpf'] = {v: cpfT, o, t:'L'}; if (tit) campos['cred.conta.titularNome'] = {v: tit.trim().toUpperCase(), o, t:'L'};
        avisos.push('A conta bancária mais recente nos autos (mov. '+f.ref+') está em nome de terceiro/advogado, não do credor.'); } }
    if (cod === '104') avisos.push('Conta na Caixa: o SGP exige o código de operação (ex.: 001).');
    break; }

  /* ---------- Ministério Público ---------- */
  const ehMP = x => /MINIST[ÉE]RIO P[ÚU]BLICO/i.test(x.desc+' '+x.comp) || /promotor(ia)? de justi[çc]a/i.test(x.comp);
  const baseMP = M.filter(x => ehMP(x) && x.seq >= ini);
  const mp = baseMP.filter(x => /ENTREGUES EM CARGA|REMETIDOS|REMESSA|EXPEDIÇÃO DE INTIMAÇÃO|VISTA/i.test(x.desc+' '+x.comp) && (!homol || x.seq > homol.seq)).shift()
    || baseMP.filter(x => !homol || x.seq > homol.seq).shift() || baseMP.pop();
  if (mp){ const ant = M.filter(x => x.seq < mp.seq && /JUNTADA DE CERTID[ÃA]O/.test(x.desc)).pop(); const r = ant && mp.seq - ant.seq <= 2 ? ant : mp; const t = (!homol || mp.seq > homol.seq) ? 'L' : 'I';
    put('cert.dtMP', r.data, r.pg, r.seq, t); put('cert.movMP', r.seq, r.pg, r.seq, t);
    if (t === 'I') avisos.push('A única remessa ao Ministério Público (mov. '+mp.seq+') é anterior à decisão de expedição; confira se serve para a certidão.'); }
  else avisos.push('Não há remessa nem vista ao Ministério Público lançada na fase de cumprimento: faça a remessa (certidão do art. 11, XIV, do Decreto Judiciário 520/2020) antes de certificar.');

  /* ---------- outros avisos ---------- */
  if (!decs.some(f => /natureza (alimentar|comum|do cr[ée]dito)/i.test(f.txt))) avisos.push('Nenhuma decisão fixa a natureza do crédito (alimentar ou comum). No SGP, "Alimentar" exige indicar a decisão que fixou a natureza.');
  const rpv = M.find(x => /REQUISIÇÃO DE PAGAMENTO DE PEQUENO VALOR PAGA/.test(x.desc)); if (rpv) avisos.push('Há RPV paga nestes autos (mov. '+rpv.seq+', '+rpv.data+'): confira o que já foi quitado antes de incluir honorários.');
  if (homol){ const pend = files.filter(f => f.seq > homol.seq && !isDec(f) && /astreintes|multa cominat[óo]ria/i.test(f.txt) && /redu[çc][ãa]o|exclus[ãa]o|revis[ãa]o|reavalia/i.test(f.txt)).pop();
    if (pend && !decs.some(d => d.seq > pend.seq && /astreintes|multa/i.test(d.txt))) avisos.push('Há pedido de revisão/redução de multa (astreintes) no mov. '+pend.ref+' sem decisão posterior que o aprecie.'); }
  if (!/destac/i.test(decs.map(f => f.txt).join(' ')) || !files.some(f => !isDec(f) && /destaque d[eo]s honor[áa]rios contratuais/i.test(f.txt))) campos['cred.semDestaque'] = campos['cred.semDestaque'] || {v:'Sim', o:'sem pedido de destaque nos autos', t:'I'};

  return {campos, advs, avisos, movs: M.length, arquivos: files.length};
}
const api = {parseAutos};
if (typeof module !== 'undefined') module.exports = api; else root.Autos = api;
})(this);
